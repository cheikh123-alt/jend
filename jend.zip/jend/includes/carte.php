<?php
/** Carte produit. Variable attendue : $p (ligne produit). */
$p = produit_avec_promo($p);                              // promotion de fête en cours, s'il y en a une
$remise = (!empty($p['prix_barre']) && $p['prix_barre'] > $p['prix'])
    ? (int) round((1 - $p['prix'] / $p['prix_barre']) * 100) : 0;
$lien = url('produit/' . $p['slug']);
?>
<article class="carte">
  <div class="photo <?= classe_fond((int) $p['id']) ?>">
    <a href="<?= e($lien) ?>" class="photo-lien" aria-label="<?= e($p['nom']) ?>">
      <?php if ($p['image']): ?>
        <img src="<?= e(url(image_miniature($p['image']))) ?>" alt="<?= e($p['nom']) ?>" loading="lazy" decoding="async">
      <?php else: ?>
        <i class="ph-fill <?= e($p['icone'] ?: 'ph-package') ?>" aria-hidden="true"></i>
      <?php endif; ?>
    </a>
    <?php if ($remise): ?><span class="promo"><?= !empty($p['promo_pct']) ? 'Promo fête ' : '' ?>-<?= $remise ?>%</span><?php endif; ?>
    <?php if (!empty($p['video_url'])): ?><span class="pastille-video" title="Ce produit a une vidéo"><i class="ph-fill ph-play-circle"></i></span><?php endif; ?>
    <?php $fav = isset(favoris_ids()[(int) $p['id']]); ?>
    <button class="coeur<?= $fav ? ' actif' : '' ?>" type="button" data-id="<?= (int) $p['id'] ?>" aria-pressed="<?= $fav ? 'true' : 'false' ?>" aria-label="Ajouter aux favoris"><i class="ph<?= $fav ? '-fill' : '' ?> ph-heart"></i></button>
  </div>
  <div class="infos">
    <span class="vendeur">chez <a href="<?= e(url('boutique/' . ($p['boutique_slug'] ?? ''))) ?>"><b><?= e($p['boutique']) ?></b></a><?php if (!empty($p['verifiee'])): ?> <i class="ph-fill ph-seal-check badge-verifie-icone" title="Boutique vérifiée" aria-label="Boutique vérifiée"></i><?php endif; ?></span>
    <h3><a href="<?= e($lien) ?>"><?= e($p['nom']) ?></a></h3>
    <?php if ($p['nb_avis'] > 0): ?>
      <span class="etoiles"><i class="ph-fill ph-star"></i> <?= e((string) $p['note_moyenne']) ?><small>(<?= (int) $p['nb_avis'] ?>)</small></span>
    <?php endif; ?>
    <div class="prix-ligne">
      <span class="prix"><?php if ($remise): ?><s><?= e(fcfa((int) $p['prix_barre'])) ?></s><?php endif; ?><b><?= e(fcfa((int) $p['prix'])) ?></b></span>
<?php if (!empty($p['a_tailles'])): ?>
      <a class="ajout" href="<?= e($lien) ?>" aria-label="Choisir la taille"><i class="ph ph-ruler"></i></a>
      <?php else: ?>
            <form method="post" action="<?= e(url('panier/ajouter')) ?>">
        <?= csrf_champ() ?>
        <input type="hidden" name="produit_id" value="<?= (int) $p['id'] ?>">
        <input type="hidden" name="retour" value="<?= e($_SERVER['REQUEST_URI'] ?? '') ?>">
        <button class="ajout" aria-label="Ajouter au panier"><i class="ph ph-plus"></i></button>
      </form>
      <?php endif; ?>
    </div>
  </div>
</article>
