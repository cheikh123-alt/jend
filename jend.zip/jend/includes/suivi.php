<?php
declare(strict_types=1);

/**
 * Suivi de livraison côté client : les étapes d'une livraison (sous-commande), avec l'heure de chacune.
 * @param array $sc  ligne de commande_boutiques (statut, affecte_le, recupere_le, en_route_le, livre_le, livreur_id) + livreur_nom
 * @param array $c   la commande (created_at, statut, statut_paiement, methode_paiement)
 * @return array liste de [libellé, heure|null, état] ; état : fait | courant | a_venir
 */
function suivi_etapes(array $sc, array $c): array
{
    $paye = commande_engagee($c);
    $etapes = [['Commande enregistrée', $c['created_at'], 'fait']];
    $etapes[] = [$paye ? 'Commande confirmée' : 'En attente de votre paiement', null, $paye ? 'fait' : 'courant'];
    $prepare = in_array($sc['statut'], ['expediee', 'livree'], true) || $sc['recupere_le'] !== null;
    $etapes[] = ['Préparée par le vendeur', null, $prepare ? 'fait' : ($paye ? 'courant' : 'a_venir')];
    if ($sc['livreur_id'] !== null) {
        $prenom = $sc['livreur_nom'] ? explode(' ', trim((string) $sc['livreur_nom']))[0] : '';
        $etapes[] = ['Livreur affecté' . ($prenom !== '' ? ' : ' . $prenom : ''), $sc['affecte_le'], 'fait'];
        $etapes[] = ['Colis récupéré chez le vendeur', $sc['recupere_le'], $sc['recupere_le'] ? 'fait' : 'a_venir'];
        $etapes[] = ['En route vers vous', $sc['en_route_le'], $sc['en_route_le'] ? 'fait' : 'a_venir'];
    } else {
        $etapes[] = ['Expédiée', null, in_array($sc['statut'], ['expediee', 'livree'], true) ? 'fait' : 'a_venir'];
    }
    $etapes[] = ['Livrée', $sc['livre_le'], $sc['statut'] === 'livree' ? 'fait' : 'a_venir'];

    // la première étape « à venir » (si rien n'est « en cours ») devient l'étape courante
    $aUnCourant = (bool) array_filter($etapes, fn ($e) => $e[2] === 'courant');
    if (!$aUnCourant && $sc['statut'] !== 'livree') {
        foreach ($etapes as $i => $e) {
            if ($e[2] === 'a_venir') {
                $etapes[$i][2] = 'courant';
                break;
            }
        }
    }
    return $etapes;
}

/** Prévient le client par e-mail d'un moment clé de sa livraison (le code de livraison n'est jamais envoyé par e-mail). */
function suivi_prevenir_client(int $commandeId, string $evenement): void
{
    $c = requete('SELECT c.reference, c.cadeau, c.livraison_nom, u.email, u.nom FROM commandes c JOIN users u ON u.id = c.client_id WHERE c.id = ?', [$commandeId])->fetch();
    if (!$c) {
        return;
    }
    $prenom = explode(' ', trim((string) $c['nom']))[0];
    $lien = app_url('commande/' . $c['reference']);
    if ($evenement === 'en_route') {
        envoyer_email($c['email'], 'Votre colis est en route (' . $c['reference'] . ')',
            "Bonjour $prenom,\n\nVotre livreur est en route. Tenez votre téléphone à portée : il peut vous appeler.\nVérifiez votre colis, puis donnez-lui le code de réception affiché dans votre commande.\n\nSuivre : $lien");
    } elseif ($evenement === 'livre') {
        envoyer_email($c['email'], ((int) $c['cadeau'] === 1 ? 'Votre cadeau a été remis à ' . $c['livraison_nom'] : 'Livraison confirmée') . ' (' . $c['reference'] . ')',
            "Bonjour $prenom,\n\n" . ((int) $c['cadeau'] === 1 ? "Votre cadeau a bien été remis à {$c['livraison_nom']} le " . date('d/m/Y à H:i') . "." : "Votre livraison est confirmée.") . " Un problème ? Vous pouvez le signaler pendant " . LITIGE_DELAI_SIGNALEMENT_JOURS . " jours depuis votre commande, avec des photos : nous répondons sous " . LITIGE_DELAI_REPONSE_HEURES . " h.\n\n$lien");
    }
}
