<?php
declare(strict_types=1);

/**
 * « La dépense du mois » : un panier enregistré (riz, huile, sucre, savon…) qui revient chaque mois, pour soi ou pour sa famille.
 * Chaque mois, un e-mail rappelle que la dépense est prête ; le client la commande et la paie en un clic (aucun prélèvement automatique).
 * Les prix et le stock sont toujours ceux du jour de la commande (relus en base).
 */

const DEPENSES_MAX = 5;              // par client
const DEPENSE_LIGNES_MAX = 30;
const DEPENSE_RAPPEL_FICHIER = 'storage/depenses-rappel.txt';

/** Prochaine date de rappel pour un jour du mois donné (1 à 28), strictement après $apres (aujourd'hui par défaut). */
function depense_prochaine_date(int $jour, ?string $apres = null): string
{
    $ref = strtotime($apres ?? date('Y-m-d'));
    $cette = mktime(0, 0, 0, (int) date('n', $ref), $jour, (int) date('Y', $ref));
    return date('Y-m-d', $cette > $ref ? $cette : mktime(0, 0, 0, (int) date('n', $ref) + 1, $jour, (int) date('Y', $ref)));
}

/** Contrôle des informations de livraison d'une dépense. @throws RuntimeException @return array valeurs nettoyées */
function depense_valider(array $d): array
{
    $nom = trim((string) ($d['nom'] ?? ''));
    $jour = (int) ($d['jour'] ?? 0);
    $livNom = trim((string) ($d['livraison_nom'] ?? ''));
    $tel = telephone_valide((string) ($d['livraison_telephone'] ?? ''));
    $adresse = trim((string) ($d['adresse'] ?? ''));
    $zone = requete('SELECT id FROM zones_livraison WHERE id = ? AND actif = 1', [(int) ($d['zone_id'] ?? 0)])->fetchColumn();
    if (mb_strlen($nom) < 3 || mb_strlen($nom) > 80) {
        throw new RuntimeException('Donnez un nom à cette dépense (ex. : « Dépense de Maman »).');
    }
    if ($jour < 1 || $jour > 28) {
        throw new RuntimeException('Choisissez le jour du rappel (du 1er au 28 du mois).');
    }
    if (mb_strlen($livNom) < 2 || mb_strlen($livNom) > 120) {
        throw new RuntimeException('Indiquez le nom de la personne qui reçoit la dépense.');
    }
    if ($tel === null) {
        throw new RuntimeException('Numéro de téléphone du destinataire invalide (ex. : 77 123 45 67).');
    }
    if (!$zone) {
        throw new RuntimeException('Choisissez la zone de livraison.');
    }
    if (mb_strlen($adresse) < 5 || mb_strlen($adresse) > 255) {
        throw new RuntimeException('Indiquez une adresse précise (quartier, rue, repère).');
    }
    return ['nom' => $nom, 'jour' => $jour, 'livraison_nom' => $livNom, 'livraison_telephone' => $tel, 'zone_id' => (int) $zone, 'adresse' => $adresse, 'cadeau' => !empty($d['cadeau']) ? 1 : 0];
}

/** Enregistre le panier actuel comme dépense du mois. @throws RuntimeException @return int identifiant */
function depense_creer(int $clientId, array $donnees): int
{
    $panier = $_SESSION['panier'] ?? [];
    if (!$panier) {
        throw new RuntimeException('Votre panier est vide : ajoutez d\'abord les produits de la dépense.');
    }
    if (count($panier) > DEPENSE_LIGNES_MAX) {
        throw new RuntimeException('Maximum ' . DEPENSE_LIGNES_MAX . ' produits par dépense.');
    }
    if ((int) requete('SELECT COUNT(*) FROM depenses WHERE client_id = ?', [$clientId])->fetchColumn() >= DEPENSES_MAX) {
        throw new RuntimeException('Vous avez déjà ' . DEPENSES_MAX . ' dépenses enregistrées : supprimez-en une d\'abord.');
    }
    $v = depense_valider($donnees);
    $pdo = pdo();
    $pdo->beginTransaction();
    try {
        requete('INSERT INTO depenses (client_id, nom, jour, livraison_nom, livraison_telephone, zone_id, adresse, cadeau, prochain_rappel) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)',
            [$clientId, $v['nom'], $v['jour'], $v['livraison_nom'], $v['livraison_telephone'], $v['zone_id'], $v['adresse'], $v['cadeau'], depense_prochaine_date($v['jour'])]);
        $id = (int) $pdo->lastInsertId();
        $n = 0;
        foreach ($panier as $cle => $q) {        // seuls les produits publiés, non réservés à un autre client (avec la taille choisie)
            [$pid, $vid] = panier_cle_lire($cle);
            $n += requete("INSERT INTO depense_lignes (depense_id, produit_id, quantite, variante_id) SELECT ?, id, ?, ? FROM produits WHERE id = ? AND statut = 'publie' AND reserve_client_id IS NULL",
                [$id, max(1, min(10, (int) $q)), (int) $vid, $pid])->rowCount();
        }
        if ($n === 0) {
            throw new RuntimeException('Aucun produit de votre panier ne peut être enregistré.');
        }
        $pdo->commit();
        return $id;
    } catch (Throwable $e) {
        $pdo->rollBack();
        throw $e;
    }
}

/** Une dépense du client (ou null). */
function depense_du_client(int $id, int $clientId): ?array
{
    return requete('SELECT d.*, z.nom AS zone FROM depenses d JOIN zones_livraison z ON z.id = d.zone_id WHERE d.id = ? AND d.client_id = ?', [$id, $clientId])->fetch() ?: null;
}

/** Lignes d'une dépense avec le prix du jour (promotion de fête comprise) et la disponibilité. */
function depense_lignes(int $depenseId): array
{
    $lignes = requete(
        "SELECT dl.quantite, dl.variante_id, p.id, p.nom, p.slug, p.prix, p.option_type, v.libelle AS variante,
                IF(dl.variante_id > 0, COALESCE(v.stock, 0), p.stock) AS stock, " . SQL_PROMO_FETE . " AS promo_pct,
                (p.statut = 'publie' AND b.statut = 'active' AND (dl.variante_id = 0 OR v.id IS NOT NULL)) AS disponible,
                (SELECT chemin FROM produit_images i WHERE i.produit_id = p.id ORDER BY i.position LIMIT 1) AS image
           FROM depense_lignes dl JOIN produits p ON p.id = dl.produit_id JOIN boutiques b ON b.id = p.boutique_id
           LEFT JOIN produit_variantes v ON v.id = dl.variante_id AND v.produit_id = p.id
          WHERE dl.depense_id = ? ORDER BY p.nom, v.position",
        [$depenseId]
    )->fetchAll();
    foreach ($lignes as &$l) {
        $l['prix_jour'] = prix_promo((int) $l['prix'], (int) $l['promo_pct']);
        $l['ok'] = (int) $l['disponible'] === 1 && (int) $l['stock'] >= (int) $l['quantite'];
        $l['cle'] = panier_cle((int) $l['id'], (int) $l['variante_id'] ?: null);
        $l['variante_libelle'] = $l['variante'] !== null ? option_libelle($l['option_type']) . ' : ' . $l['variante'] : null;
    }
    return $lignes;
}

/** Total estimé (produits disponibles, prix du jour, hors livraison). */
function depense_total(array $lignes): int
{
    return array_sum(array_map(fn ($l) => $l['ok'] ? $l['prix_jour'] * (int) $l['quantite'] : 0, $lignes));
}

/**
 * « Commander maintenant » : remplace le panier par les produits disponibles de la dépense et mémorise la dépense
 * pour pré-remplir l'adresse. @return array [nombre de produits mis au panier, noms des produits indisponibles]
 */
function depense_vers_panier(array $d): array
{
    $panier = [];
    $manquants = [];
    foreach (depense_lignes((int) $d['id']) as $l) {
        if ($l['ok']) {
            $panier[$l['cle']] = (int) $l['quantite'];
        } elseif ((int) $l['disponible'] === 1 && (int) $l['stock'] > 0) {
            $panier[$l['cle']] = (int) $l['stock'];          // stock insuffisant : on met ce qui reste
            $manquants[] = $l['nom'] . ' (seulement ' . (int) $l['stock'] . ')';
        } else {
            $manquants[] = $l['nom'];
        }
    }
    $_SESSION['panier'] = $panier;
    $_SESSION['depense_en_cours'] = (int) $d['id'];
    return [count($panier), $manquants];
}

/**
 * Rappels mensuels (e-mail) et alertes de promotion. Lancé au plus une fois par heure, au passage d'un visiteur (pas besoin de tâche planifiée
 * sur l'hébergement) ; peut aussi être lancé par une tâche cron.
 */
function depenses_rappels(bool $forcer = false): int
{
    $fichier = dirname(__DIR__) . '/' . DEPENSE_RAPPEL_FICHIER;
    if (!$forcer && is_file($fichier) && filemtime($fichier) > time() - 3600) {
        return 0;
    }
    @touch($fichier);
    try {
        alertes_promotions();                  // « Prévenez-moi » : promotions de fête qui viennent de commencer
    } catch (Throwable $e) {
        error_log('Jënd — alertes promotions : ' . $e->getMessage());
    }
    try {
        commission_annonce_appliquer();        // nouveau taux de commission annoncé : appliqué tout seul à sa date
    } catch (Throwable $e) {
        error_log('Jënd — application de la commission : ' . $e->getMessage());
    }
    try {
        vendeurs_prevenir_en_attente();        // commandes à préparer dont le vendeur n'a pas encore été prévenu (rattrapage)
    } catch (Throwable $e) {
        error_log('Jënd — prévenir les vendeurs : ' . $e->getMessage());
    }
    try {
        versements_preparer();                 // versements aux vendeurs, le jour fixé par l'administrateur
    } catch (Throwable $e) {
        error_log('Jënd — versements : ' . $e->getMessage());
    }
    $n = 0;
    foreach (requete('SELECT d.*, u.email, u.nom AS client_nom FROM depenses d JOIN users u ON u.id = d.client_id AND u.actif = 1
                       WHERE d.actif = 1 AND d.prochain_rappel <= CURDATE() ORDER BY d.prochain_rappel LIMIT 50')->fetchAll() as $d) {
        // on avance d'abord la date : même si l'envoi échoue, pas de rappel en double
        requete('UPDATE depenses SET dernier_rappel = CURDATE(), prochain_rappel = ? WHERE id = ? AND prochain_rappel <= CURDATE()', [depense_prochaine_date((int) $d['jour']), $d['id']]);
        $lignes = depense_lignes((int) $d['id']);
        $indispo = count(array_filter($lignes, fn ($l) => !$l['ok']));
        try {
            envoyer_email((string) $d['email'], 'Votre dépense « ' . $d['nom'] . ' » est prête',
                'Bonjour ' . explode(' ', trim((string) $d['client_nom']))[0] . ",\n\nC'est le moment de la dépense du mois pour {$d['livraison_nom']} : "
                . count($lignes) . ' produit(s), environ ' . fcfa(depense_total($lignes)) . " (hors livraison, prix du jour).\n"
                . ($indispo ? "$indispo produit(s) ne sont plus disponibles : vérifiez avant de commander.\n" : '')
                . "\nCommander en un clic :\n" . app_url('depense/' . $d['id']) . "\n\nVous pouvez modifier ou mettre en pause cette dépense depuis la même page.");
            $n++;
        } catch (Throwable $e) {
            error_log('Jënd — rappel dépense : ' . $e->getMessage());
        }
    }
    return $n;
}
