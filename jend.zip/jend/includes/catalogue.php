<?php
declare(strict_types=1);

const PRODUITS_PAR_PAGE = 12;
const CATALOGUE_TOTAL_CACHE_MIN = 500;          // au-delà, le nombre de résultats est mis en cache 2 minutes

/** Icônes proposées pour les catégories (seules ces icônes sont incluses dans la feuille d'icônes allégée du site). */
const ICONES_CATEGORIES = ['ph-t-shirt', 'ph-dress', 'ph-sneaker', 'ph-handbag', 'ph-eyeglasses', 'ph-watch', 'ph-diamond', 'ph-device-mobile', 'ph-laptop',
    'ph-television', 'ph-headphones', 'ph-camera', 'ph-game-controller', 'ph-armchair', 'ph-bed', 'ph-cooking-pot', 'ph-lamp', 'ph-broom', 'ph-flower-lotus',
    'ph-drop', 'ph-sparkle', 'ph-orange-slice', 'ph-bowl-food', 'ph-coffee', 'ph-carrot', 'ph-fish', 'ph-paint-brush-broad', 'ph-scissors', 'ph-needle',
    'ph-baby', 'ph-baby-carriage', 'ph-puzzle-piece', 'ph-car', 'ph-motorcycle', 'ph-wrench', 'ph-hammer', 'ph-book-open', 'ph-pencil', 'ph-first-aid-kit',
    'ph-barbell', 'ph-soccer-ball', 'ph-gift', 'ph-mosque', 'ph-music-notes', 'ph-plant', 'ph-dog', 'ph-package', 'ph-storefront'];

/**
 * Promotion de fête en cours pour le produit « p » (en %, 0 si aucune) : du début de la vitrine jusqu'au jour de la fête.
 * Toujours relue en base : le prix payé ne vient jamais du navigateur.
 */
const SQL_PROMO_FETE = "(SELECT COALESCE(MAX(pf.remise_pct), 0) FROM produit_fetes pf JOIN fetes f ON f.id = pf.fete_id
        WHERE pf.produit_id = p.id AND f.actif = 1 AND f.vitrine_des <= CURDATE() AND f.date_fete >= CURDATE())";

/** Colonnes communes à toutes les listes de produits. */
const SQL_PRODUIT_CARTE = "p.id, p.nom, p.slug, p.prix, p.prix_barre, p.stock, p.note_moyenne, p.nb_avis, p.video_url, " . SQL_PROMO_FETE . " AS promo_pct, (p.option_type IS NOT NULL) AS a_tailles,
        b.nom AS boutique, b.slug AS boutique_slug, b.verifiee, COALESCE(c.icone, pc.icone) AS icone,
        (SELECT chemin FROM produit_images i WHERE i.produit_id = p.id ORDER BY i.position LIMIT 1) AS image";

const SQL_PRODUIT_JOINTURES = "FROM produits p
        JOIN boutiques b ON b.id = p.boutique_id AND b.statut = 'active'
        JOIN categories c ON c.id = p.categorie_id
        LEFT JOIN categories pc ON pc.id = c.parent_id";

/**
 * Recherche paginée dans le catalogue.
 * $f accepte : categorie_id, boutique_id, fete_id, q, prix_min, prix_max, tri, sans_total (ne pas compter : seule la 1re page sert)
 * Retourne ['produits' => [...], 'total' => n, 'pages' => n, 'page' => n]
 */
function catalogue_chercher(array $f, int $page): array
{
    $where  = ["p.statut = 'publie'", 'p.stock > 0', 'p.reserve_client_id IS NULL'];      // les produits réservés (devis sur mesure) ne sont pas dans le catalogue
    $params = [];

    if (!empty($f['boutique_id'])) {
        $where[] = 'p.boutique_id = :bid';
        $params[':bid'] = (int) $f['boutique_id'];
    }

    if (!empty($f['fete_id'])) {
        $where[] = 'p.id IN (SELECT produit_id FROM produit_fetes WHERE fete_id = :fid)';
        $params[':fid'] = (int) $f['fete_id'];
    }

    if (!empty($f['categorie_id'])) {
        // la catégorie et ses sous-catégories, en liste de numéros : MySQL peut alors utiliser l'index (statut, categorie_id)
        $cats = array_map('intval', requete('SELECT id FROM categories WHERE id = ? OR parent_id = ?', [(int) $f['categorie_id'], (int) $f['categorie_id']])->fetchAll(PDO::FETCH_COLUMN));
        $where[] = 'p.categorie_id IN (' . implode(',', $cats ?: [0]) . ')';
    }

    if (!empty($f['q'])) {
        // chaque mot doit apparaître dans le nom ou la description (5 mots max)
        $mots = array_slice(preg_split('/\s+/u', trim($f['q'])), 0, 5);
        foreach ($mots as $n => $mot) {
            $motif = '%' . addcslashes($mot, '%_\\') . '%';
            $where[] = "(p.nom LIKE :mn$n OR p.description LIKE :md$n)";
            $params[":mn$n"] = $params[":md$n"] = $motif;
        }
    }

    if (!empty($f['prix_min'])) {
        $where[] = 'p.prix >= :pmin';
        $params[':pmin'] = (int) $f['prix_min'];
    }
    if (!empty($f['prix_max'])) {
        $where[] = 'p.prix <= :pmax';
        $params[':pmax'] = (int) $f['prix_max'];
    }

    $tris = [                                    // départage par id dans le même sens que le tri : l'index peut servir tel quel
        'recent'    => 'p.created_at DESC, p.id DESC',
        'prix_asc'  => 'p.prix ASC, p.id ASC',
        'prix_desc' => 'p.prix DESC, p.id DESC',
        'populaire' => 'p.nb_avis DESC, p.note_moyenne DESC, p.id DESC',
    ];
    $ordre = $tris[$f['tri'] ?? ''] ?? $tris['recent'];

    $clause = implode(' AND ', $where);
    // STRAIGHT_JOIN : MySQL part des produits (la grande table, avec ses index) au lieu des boutiques.
    // Grand catalogue : le nombre total est gardé 2 minutes (compter des dizaines de milliers de produits à chaque page coûte cher).
    // Petit catalogue (moins de 500) : toujours compté exactement.
    $compter = fn () => (int) requete("SELECT STRAIGHT_JOIN COUNT(*) " . SQL_PRODUIT_JOINTURES . " WHERE $clause", $params)->fetchColumn();
    $cleTotal = 'catalogue-total:' . $clause . ':' . json_encode($params);
    $total = !empty($f['sans_total']) ? PRODUITS_PAR_PAGE : cache_lire($cleTotal, 120);      // sans_total : une seule page affichée (accueil, produits similaires)
    if ($total === null || (empty($f['sans_total']) && (int) $total < CATALOGUE_TOTAL_CACHE_MIN)) {
        $total = $compter();
        if ($total >= CATALOGUE_TOTAL_CACHE_MIN) {
            cache_ecrire($cleTotal, $total);
        }
    }
    $total = (int) $total;
    $pages  = max(1, (int) ceil($total / PRODUITS_PAR_PAGE));
    $page   = min(max(1, $page), $pages);
    $offset = ($page - 1) * PRODUITS_PAR_PAGE;   // entiers déjà vérifiés : sûrs à insérer dans LIMIT

    // En deux temps (vitesse) : d'abord les numéros des produits de la page (tri + index, sans calcul),
    // puis les informations des cartes (promotion de fête, photo…) pour ces 12 produits seulement.
    // En une seule requête, MySQL calculait la promotion et la photo de TOUS les produits avant d'en garder 12.
    $ids = requete(
        'SELECT STRAIGHT_JOIN p.id ' . SQL_PRODUIT_JOINTURES . " WHERE $clause ORDER BY $ordre LIMIT " . PRODUITS_PAR_PAGE . " OFFSET $offset",
        $params
    )->fetchAll(PDO::FETCH_COLUMN);
    $produits = [];
    if ($ids) {
        $parId = [];
        foreach (requete('SELECT ' . SQL_PRODUIT_CARTE . ' ' . SQL_PRODUIT_JOINTURES . ' WHERE p.id IN (' . implode(',', array_map('intval', $ids)) . ')')->fetchAll() as $ligne) {
            $parId[(int) $ligne['id']] = $ligne;
        }
        foreach ($ids as $id) {
            if (isset($parId[(int) $id])) {
                $produits[] = $parId[(int) $id];
            }
        }
    }

    return ['produits' => $produits, 'total' => $total, 'pages' => $pages, 'page' => $page];
}

/** Classe CSS (fond-0 … fond-7) donnant la couleur de fond d'un produit sans photo (stable pour un même produit). */
function classe_fond(int $id): string
{
    return 'fond-' . ($id % 8);
}

/** Prix après promotion de fête (arrondi au franc). */
function prix_promo(int $prix, int $pct): int
{
    return $pct > 0 ? (int) round($prix * (100 - min($pct, FETE_REMISE_MAX)) / 100) : $prix;
}

/**
 * Applique la promotion de fête à une ligne produit pour l'affichage : « prix » devient le prix promo,
 * « prix_barre » le prix d'avant (ou l'ancien prix barré du vendeur s'il était plus haut).
 */
function produit_avec_promo(array $p): array
{
    $pct = (int) ($p['promo_pct'] ?? 0);
    if ($pct > 0) {
        $p['prix_barre'] = max((int) $p['prix'], (int) ($p['prix_barre'] ?? 0));
        $p['prix'] = prix_promo((int) $p['prix'], $pct);
    }
    return $p;
}
