<?php
declare(strict_types=1);

const IMAGE_MAX_OCTETS = 3 * 1024 * 1024;   // 3 Mo par photo
const IMAGE_MAX_COTE   = 1600;              // px : les photos plus grandes sont réduites
const IMAGES_PAR_PRODUIT = 5;
const MINIATURE_COTE   = 600;               // px : version légère pour les listes (cartes, panier) — la fiche produit garde la grande photo

/**
 * Enregistre une photo envoyée par un vendeur. Retourne le chemin relatif (ex : uploads/produits/ab12….jpg).
 *
 * Sécurité : on ne fait JAMAIS confiance au nom ni au type annoncés par le navigateur.
 *  - le vrai type est lu dans le contenu du fichier (finfo) ;
 *  - l'image est décodée puis RÉ-ENCODÉE avec GD : tout code caché dans le fichier disparaît ;
 *  - le nom final est aléatoire, l'extension vient du type détecté.
 *
 * @param array $f entrée de $_FILES (un seul fichier)
 * @throws RuntimeException message affichable
 */
function image_enregistrer(array $f, string $destination = 'uploads/produits'): string
{
    if (!in_array($destination, ['uploads/produits', 'uploads/boutiques', 'storage/litiges'], true)) {   // dossiers autorisés uniquement
        throw new RuntimeException('Destination non autorisée.');
    }
    if (($f['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) {
        throw new RuntimeException(match ($f['error'] ?? 0) {
            UPLOAD_ERR_INI_SIZE, UPLOAD_ERR_FORM_SIZE => 'Photo trop lourde (3 Mo maximum).',
            default => 'L\'envoi de la photo a échoué.',
        });
    }
    if (!is_uploaded_file($f['tmp_name']) || $f['size'] > IMAGE_MAX_OCTETS || $f['size'] < 100) {
        throw new RuntimeException('Photo invalide ou trop lourde (3 Mo maximum).');
    }

    $mime = (new finfo(FILEINFO_MIME_TYPE))->file($f['tmp_name']);
    if (!in_array($mime, ['image/jpeg', 'image/png'], true)) {
        throw new RuntimeException('Format non accepté : utilisez une photo JPEG ou PNG.');
    }
    $info = @getimagesize($f['tmp_name']);
    if (!$info || $info[0] < 50 || $info[1] < 50 || $info[0] * $info[1] > 24_000_000) {
        throw new RuntimeException('Image illisible ou de dimensions incorrectes.');
    }

    $src = $mime === 'image/png' ? @imagecreatefrompng($f['tmp_name']) : @imagecreatefromjpeg($f['tmp_name']);
    if (!$src) {
        throw new RuntimeException('Image illisible.');
    }

    [$l, $h] = [imagesx($src), imagesy($src)];
    $ratio = min(1, IMAGE_MAX_COTE / max($l, $h));
    $dst = imagecreatetruecolor((int) round($l * $ratio), (int) round($h * $ratio));
    if ($mime === 'image/png') {
        imagealphablending($dst, false);
        imagesavealpha($dst, true);
    }
    imagecopyresampled($dst, $src, 0, 0, 0, 0, imagesx($dst), imagesy($dst), $l, $h);

    $nom = bin2hex(random_bytes(16)) . ($mime === 'image/png' ? '.png' : '.jpg');
    $dossier = dirname(__DIR__) . '/' . $destination . '/';
    if (!is_dir($dossier) && !mkdir($dossier, 0755, true) && !is_dir($dossier)) {
        throw new RuntimeException('Impossible d\'enregistrer la photo.');
    }
    $ok = $mime === 'image/png' ? imagepng($dst, $dossier . $nom, 6) : imagejpeg($dst, $dossier . $nom, 85);
    if (!$ok) {
        throw new RuntimeException('Impossible d\'enregistrer la photo.');
    }
    if ($destination === 'uploads/produits' || $destination === 'uploads/boutiques') {
        miniature_creer($dst, $dossier . miniature_nom($nom));
    }
    return $destination . '/' . $nom;
}

/** Supprime un fichier image (uniquement dans uploads/produits/ ou storage/litiges/, jamais ailleurs), et sa miniature. */
function image_supprimer(string $chemin): void
{
    if (preg_match('#^(uploads/produits|uploads/boutiques|storage/litiges)/[a-f0-9]{32}\.(jpg|png)$#', $chemin)) {
        @unlink(dirname(__DIR__) . '/' . $chemin);
        @unlink(dirname(__DIR__) . '/' . miniature_nom($chemin));
    }
}

/** « ab12….png » → « ab12…-m.jpg » (les miniatures sont toujours en JPEG : bien plus légères). */
function miniature_nom(string $chemin): string
{
    return (string) preg_replace('#\.(jpg|png)$#', '-m.jpg', $chemin);
}

/** Écrit la miniature JPEG (600 px max) d'une image GD déjà chargée. */
function miniature_creer(GdImage $img, string $fichier): bool
{
    [$l, $h] = [imagesx($img), imagesy($img)];
    $ratio = min(1, MINIATURE_COTE / max($l, $h));
    $mini = imagecreatetruecolor(max(1, (int) round($l * $ratio)), max(1, (int) round($h * $ratio)));
    imagefill($mini, 0, 0, imagecolorallocate($mini, 255, 253, 248));      // fond crème sous les zones transparentes des PNG
    imagecopyresampled($mini, $img, 0, 0, 0, 0, imagesx($mini), imagesy($mini), $l, $h);
    imageinterlace($mini, true);                                             // JPEG progressif : s'affiche vite sur réseau lent
    return @imagejpeg($mini, $fichier, 78);
}

/**
 * Chemin de la miniature d'une photo produit, créée au premier besoin pour les photos plus anciennes.
 * En cas de problème, on renvoie simplement la photo d'origine.
 */
function image_miniature(?string $chemin): ?string
{
    if (!$chemin || !preg_match('#^uploads/(produits|boutiques)/[a-f0-9]{32}\.(jpg|png)$#', $chemin)) {
        return $chemin;
    }
    $mini = miniature_nom($chemin);
    $racine = dirname(__DIR__) . '/';
    if (is_file($racine . $mini)) {
        return $mini;
    }
    if (!is_file($racine . $chemin) || filesize($racine . $chemin) > 8 * 1024 * 1024) {
        return $chemin;
    }
    $img = str_ends_with($chemin, '.png') ? @imagecreatefrompng($racine . $chemin) : @imagecreatefromjpeg($racine . $chemin);
    return ($img && miniature_creer($img, $racine . $mini)) ? $mini : $chemin;
}

/** Réorganise $_FILES['photos'] (tableau de champs) en liste de fichiers simples, en ignorant les champs vides. */
function fichiers_envoyes(string $champ): array
{
    $liste = [];
    $f = $_FILES[$champ] ?? null;
    if (!$f || !is_array($f['name'])) {
        return $liste;
    }
    foreach ($f['name'] as $i => $nom) {
        if ($f['error'][$i] === UPLOAD_ERR_NO_FILE) {
            continue;
        }
        $liste[] = ['name' => $nom, 'tmp_name' => $f['tmp_name'][$i], 'size' => $f['size'][$i], 'error' => $f['error'][$i]];
    }
    return $liste;
}
