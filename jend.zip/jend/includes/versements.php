<?php
declare(strict_types=1);

/**
 * Versements aux vendeurs à date fixe : le jour choisi par l'administrateur (Paramètres → « Jour où tu reverses les vendeurs »),
 * le solde disponible de chaque vendeur est préparé automatiquement en versement (minimum RETRAIT_MINIMUM).
 * L'administrateur envoie l'argent (Wave / Orange Money) puis le marque « versé » avec la référence du transfert :
 * le vendeur reçoit un e-mail et retrouve tout dans son relevé mensuel.
 * Le vendeur peut toujours demander un retrait lui-même entre deux versements.
 */

const JOURS_VERSEMENT = ['lundi' => 1, 'mardi' => 2, 'mercredi' => 3, 'jeudi' => 4, 'vendredi' => 5];
const METHODES_VERSEMENT = ['wave' => 'Wave', 'orange_money' => 'Orange Money', 'free_money' => 'Free Money'];

/** Jour des versements (« lundi »…) ou null s'il n'y en a pas (versements sur demande seulement). */
function versement_jour(): ?string
{
    $j = function_exists('parametre') ? trim((string) parametre('jour_reversement', '')) : '';
    return isset(JOURS_VERSEMENT[$j]) ? $j : null;
}

/** Date (Y-m-d) du prochain versement, ou null. Aujourd'hui si c'est le jour et que les versements ne sont pas encore préparés. */
function prochain_versement(): ?string
{
    $jour = versement_jour();
    if (!$jour) {
        return null;
    }
    $cible = JOURS_VERSEMENT[$jour];
    $aujourdhui = (int) date('N');
    if ($aujourdhui === $cible && parametre('versements_prepares_le', '') !== date('Y-m-d')) {
        return date('Y-m-d');
    }
    $ecart = ($cible - $aujourdhui + 7) % 7 ?: 7;
    return date('Y-m-d', strtotime("+$ecart days"));
}

/** « lundi 20 octobre » */
function date_jour_fr(string $date): string
{
    $jours = [1 => 'lundi', 'mardi', 'mercredi', 'jeudi', 'vendredi', 'samedi', 'dimanche'];
    return $jours[(int) date('N', strtotime($date))] . ' ' . preg_replace('/ \d{4}$/', '', date_longue_fr($date));
}

/** Le versement peut-il partir vers cette boutique ? Renvoie la raison sinon. */
function versement_bloque(array $b, array $u): ?string
{
    if ($b['statut'] !== 'active') {
        return 'boutique non validée';
    }
    if (!$b['telephone_paiement']) {
        return 'numéro de paiement manquant';
    }
    if (!empty($b['telephone_modifie_le']) && strtotime((string) $b['telephone_modifie_le']) > time() - RETRAIT_DELAI_CHANGEMENT_HEURES * 3600) {
        return 'numéro de paiement changé il y a moins de ' . RETRAIT_DELAI_CHANGEMENT_HEURES . ' h';
    }
    if (parametre_actif('retrait_2fa', false) && (int) $u['totp_actif'] !== 1) {
        return 'double authentification non activée';
    }
    return null;
}

/**
 * Prépare les versements du jour (une seule fois par jour de versement). Lancé avec les tâches horaires.
 * @return int nombre de versements préparés
 */
function versements_preparer(bool $forcer = false): int
{
    $jour = versement_jour();
    if (!$forcer && (!$jour || (int) date('N') !== JOURS_VERSEMENT[$jour] || parametre('versements_prepares_le', '') === date('Y-m-d'))) {
        return 0;
    }
    parametre_definir('versements_prepares_le', date('Y-m-d'));      // d'abord : jamais deux fois le même jour
    $n = 0;
    $total = 0;
    foreach (requete("SELECT b.*, u.email, u.nom AS vendeur_nom, u.totp_actif FROM boutiques b JOIN users u ON u.id = b.user_id AND u.actif = 1
                       WHERE b.statut = 'active' AND b.versement_auto = 1")->fetchAll() as $b) {
        if (versement_bloque($b, $b)) {
            continue;
        }
        $pdo = pdo();
        $pdo->beginTransaction();
        try {
            requete('SELECT id FROM boutiques WHERE id = ? FOR UPDATE', [$b['id']]);     // même verrou que les demandes manuelles
            $solde = vendeur_gains((int) $b['id'])['solde'];
            if ($solde < RETRAIT_MINIMUM) {
                $pdo->rollBack();
                continue;
            }
            $methode = isset(METHODES_VERSEMENT[$b['methode_versement']]) ? $b['methode_versement'] : 'wave';
            requete('INSERT INTO retraits (boutique_id, montant, methode, automatique) VALUES (?, ?, ?, 1)', [$b['id'], $solde, $methode]);
            $pdo->commit();
        } catch (Throwable $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            error_log('Jënd — versement automatique : ' . $e->getMessage());
            continue;
        }
        $n++;
        $total += $solde;
        try {
            envoyer_email((string) $b['email'], 'Votre versement de ' . fcfa($solde) . ' est en préparation',
                'Bonjour ' . explode(' ', trim((string) $b['vendeur_nom']))[0] . ",\n\nC'est le jour des versements : " . fcfa($solde) . ' (tout votre solde disponible) vont être envoyés sur votre '
                . METHODES_VERSEMENT[$methode] . ' (' . $b['telephone_paiement'] . ").\nVous recevrez un e-mail avec la référence du transfert dès l'envoi.\n\nDétail dans votre relevé : " . app_url('vendeur/releves'));
        } catch (Throwable $e) {
            error_log('Jënd — e-mail versement : ' . $e->getMessage());
        }
    }
    if ($n > 0) {
        try {
            envoyer_email((string) env('ADMIN_EMAIL', 'admin@jend.local'), "$n versement(s) à envoyer aujourd'hui (" . fcfa($total) . ')',
                "Les versements du jour sont prêts : $n vendeur(s), " . fcfa($total) . " au total.\nEnvoie-les puis marque-les « versé » avec la référence du transfert :\n" . app_url('admin/retraits'));
        } catch (Throwable $e) {
            error_log('Jënd — e-mail versements admin : ' . $e->getMessage());
        }
    }
    return $n;
}

/** Marque un retrait comme versé, avec la référence du transfert, et prévient le vendeur. @return bool vrai si c'était bien une demande en attente */
function versement_confirmer(int $retraitId, string $reference): bool
{
    $reference = mb_substr(trim(preg_replace('/[\x00-\x1F]/u', '', $reference)), 0, 60);
    $n = requete("UPDATE retraits SET statut = 'paye', paye_le = NOW(), reference_transfert = ? WHERE id = ? AND statut = 'demande'", [$reference !== '' ? $reference : null, $retraitId])->rowCount();
    if ($n !== 1) {
        return false;
    }
    $r = requete('SELECT r.montant, r.methode, b.telephone_paiement, u.email, u.nom FROM retraits r JOIN boutiques b ON b.id = r.boutique_id JOIN users u ON u.id = b.user_id WHERE r.id = ?', [$retraitId])->fetch();
    if ($r) {
        try {
            envoyer_email((string) $r['email'], 'Versement envoyé : ' . fcfa((int) $r['montant']),
                'Bonjour ' . explode(' ', trim((string) $r['nom']))[0] . ",\n\nNous venons d'envoyer " . fcfa((int) $r['montant']) . ' sur votre ' . (METHODES_VERSEMENT[$r['methode']] ?? $r['methode'])
                . ' (' . $r['telephone_paiement'] . ') le ' . date('d/m/Y à H:i') . '.' . ($reference !== '' ? "\nRéférence du transfert : $reference" : '')
                . "\n\nVotre relevé du mois : " . app_url('vendeur/releves') . "\nUn souci ? Répondez à cet e-mail ou écrivez-nous depuis la page d'aide.");
        } catch (Throwable $e) {
            error_log('Jënd — e-mail versement envoyé : ' . $e->getMessage());
        }
    }
    return true;
}

/**
 * Relevé d'une boutique pour un mois (« 2026-10 ») : ventes confirmées, retenues, versements, totaux.
 */
function releve_mois(int $boutiqueId, string $mois): array
{
    $debut = $mois . '-01 00:00:00';
    $fin = date('Y-m-d H:i:s', strtotime($debut . ' +1 month'));
    $ventes = requete(
        "SELECT cb.livre_le AS date, c.reference, cb.sous_total, cb.commission, IF(cb.livre_par = 'vendeur', cb.frais_part, 0) AS frais,
                cb.net_vendeur + IF(cb.livre_par = 'vendeur', cb.frais_part, 0) AS net,
                (SELECT GROUP_CONCAT(CONCAT(cl.quantite, ' × ', cl.nom, IF(cl.variante_libelle IS NULL, '', CONCAT(' (', cl.variante_libelle, ')'))) SEPARATOR ', ') FROM commande_lignes cl WHERE cl.commande_boutique_id = cb.id) AS articles
           FROM commande_boutiques cb JOIN commandes c ON c.id = cb.commande_id
          WHERE cb.boutique_id = ? AND cb.statut = 'livree' AND c.statut_paiement = 'paye' AND cb.livre_le >= ? AND cb.livre_le < ?
          ORDER BY cb.livre_le",
        [$boutiqueId, $debut, $fin]
    )->fetchAll();
    $retenues = requete(
        "SELECT l.resolu_le AS date, l.reference, l.montant_rembourse AS montant FROM litiges l JOIN commande_boutiques cb ON cb.id = l.commande_boutique_id
          WHERE cb.boutique_id = ? AND l.statut = 'rembourse' AND l.a_charge_vendeur = 1 AND l.resolu_le >= ? AND l.resolu_le < ? ORDER BY l.resolu_le",
        [$boutiqueId, $debut, $fin]
    )->fetchAll();
    $versements = requete(
        "SELECT COALESCE(paye_le, created_at) AS date, montant, methode, statut, automatique, reference_transfert FROM retraits
          WHERE boutique_id = ? AND statut IN ('paye', 'demande') AND COALESCE(paye_le, created_at) >= ? AND COALESCE(paye_le, created_at) < ? ORDER BY COALESCE(paye_le, created_at)",
        [$boutiqueId, $debut, $fin]
    )->fetchAll();
    $reglements = requete(
        "SELECT created_at AS date, montant, methode, reference FROM reglements_commission WHERE boutique_id = ? AND created_at >= ? AND created_at < ? ORDER BY created_at",
        [$boutiqueId, $debut, $fin]
    )->fetchAll();
    $somme = fn (array $lignes, string $col) => array_sum(array_map(fn ($l) => (int) $l[$col], $lignes));
    return [
        'ventes' => $ventes, 'retenues' => $retenues, 'versements' => $versements, 'reglements' => $reglements, 'total_regle' => $somme($reglements, 'montant'),
        'total_ventes' => $somme($ventes, 'sous_total'), 'total_commission' => $somme($ventes, 'commission'),
        'total_frais' => $somme($ventes, 'frais'), 'total_net' => $somme($ventes, 'net'), 'total_retenues' => $somme($retenues, 'montant'),
        'total_verse' => $somme(array_filter($versements, fn ($v) => $v['statut'] === 'paye'), 'montant'),
        'en_cours' => $somme(array_filter($versements, fn ($v) => $v['statut'] === 'demande'), 'montant'),
    ];
}

/** Mois (« 2026-10 ») pour lesquels la boutique a de l'activité, du plus récent au plus ancien (au moins le mois en cours). */
function releve_mois_disponibles(int $boutiqueId): array
{
    $mois = requete(
        "SELECT DISTINCT DATE_FORMAT(d, '%Y-%m') AS m FROM (
            SELECT cb.livre_le AS d FROM commande_boutiques cb WHERE cb.boutique_id = ? AND cb.livre_le IS NOT NULL
            UNION ALL SELECT COALESCE(paye_le, created_at) FROM retraits WHERE boutique_id = ?
            UNION ALL SELECT created_at FROM reglements_commission WHERE boutique_id = ?) t ORDER BY m DESC LIMIT 24",
        [$boutiqueId, $boutiqueId, $boutiqueId]
    )->fetchAll(PDO::FETCH_COLUMN);
    return array_values(array_unique(array_merge([date('Y-m')], $mois)));
}
