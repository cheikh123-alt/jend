<?php
declare(strict_types=1);

/**
 * Paiement en ligne (Wave, Orange Money, Free Money, carte).
 *
 * Fonctionnement identique à celui d'un vrai agrégateur (PayDunya, CinetPay…) :
 *   1. paiement_initier()  crée une tentative de paiement et renvoie l'adresse de la page de paiement ;
 *   2. le client paie sur la page du fournisseur ;
 *   3. le fournisseur appelle notre WEBHOOK (paiement/webhook) avec une signature : c'est la SEULE preuve de paiement.
 *      Le retour du client sur le site (paiement/retour/…) ne fait qu'afficher le statut déjà enregistré.
 *
 * Pour passer à un vrai fournisseur : PAIEMENT_FOURNISSEUR dans .env, puis adapter paiement_initier()
 * (appel API du fournisseur) et le format lu par paiement_notification_traiter().
 */

const METHODES_EN_LIGNE = ['wave', 'orange_money', 'free_money', 'carte'];
const NOTIFICATION_TOLERANCE_SECONDES = 900;

/** Dernier échec de création d'un paiement (storage/, interdit depuis Internet) : affiché à l'administrateur, jamais au client. */
function paiement_erreur_fichier(): string
{
    return dirname(__DIR__) . '/storage/paiement-derniere-erreur.txt';
}

function paiement_derniere_erreur(): string
{
    $f = paiement_erreur_fichier();
    return is_file($f) ? trim((string) @file_get_contents($f)) : '';
}

/** Prestataires de paiement réels que le site sait utiliser (includes/paydunya.php, includes/paytech.php). */
const PRESTATAIRES = ['paydunya' => 'PayDunya', 'paytech' => 'PayTech', 'unitech' => 'UnitechPay'];

/**
 * Prestataires en service, lus dans PAIEMENT_FOURNISSEUR (config.env). Plusieurs possibles : « paydunya,paytech ».
 * Tous reçoivent leurs notifications ; le principal (choisi dans Administration → Paramètres) crée les nouveaux paiements,
 * les autres servent de secours automatique.
 */
function prestataires_actifs(): array
{
    $liste = array_map('trim', explode(',', strtolower((string) env('PAIEMENT_FOURNISSEUR', 'simulation'))));
    return array_values(array_filter(array_unique($liste), fn ($p) => isset(PRESTATAIRES[$p])));
}

/** Les clés d'un prestataire sont-elles renseignées ? */
function prestataire_configure(string $p): bool
{
    return match ($p) {
        'paydunya' => paydunya_configure(),
        'paytech'  => paytech_configure(),
        'unitech'  => unitech_configure(),
        default    => false,
    };
}

/** Le prestataire est-il en mode test (bac à sable) ? UnitechPay n'a pas de mode test documenté : toujours réel. */
function prestataire_mode_test(string $p): bool
{
    return match ($p) {
        'paydunya' => paydunya_mode_test(),
        'paytech'  => paytech_mode_test(),
        default    => false,
    };
}

/** Prestataire utilisé en premier pour les nouveaux paiements : celui choisi par l'administrateur, sinon le premier configuré de la liste. */
function prestataire_principal(): ?string
{
    $actifs = prestataires_actifs();
    $choisi = (string) parametre('prestataire_principal', '');
    if (in_array($choisi, $actifs, true)) {
        return $choisi;
    }
    foreach ($actifs as $p) {
        if (prestataire_configure($p)) {
            return $p;
        }
    }
    return $actifs[0] ?? null;
}

/** « simulation » (développement / site de test), sinon le prestataire principal (ou la valeur inconnue telle quelle : aucun paiement possible). */
function paiement_fournisseur(): string
{
    $liste = array_map('trim', explode(',', strtolower(trim((string) env('PAIEMENT_FOURNISSEUR', 'simulation')))));
    if ($liste === [''] || in_array('simulation', $liste, true)) {
        return 'simulation';
    }
    return prestataire_principal() ?? $liste[0];
}

/** La page de simulation n'existe qu'en développement et sur un site de TEST (APP_ENV=test) : jamais en production. */
function simulation_active(): bool
{
    return paiement_fournisseur() === 'simulation' && in_array(env('APP_ENV', 'prod'), ['dev', 'test'], true);
}

/** Clé secrète partagée avec le fournisseur, pour signer/vérifier les notifications. */
function paiement_secret(): string
{
    $secret = (string) env('PAIEMENT_SECRET', '');
    if ($secret !== '') {
        return $secret;
    }
    if (env('APP_ENV', 'prod') !== 'dev') {
        throw new RuntimeException('PAIEMENT_SECRET manquant dans .env');
    }
    // Développement : on génère une clé aléatoire une fois, gardée dans storage/ (jamais dans le code)
    $fichier = dirname(__DIR__) . '/storage/paiement-secret.txt';
    if (!is_file($fichier)) {
        file_put_contents($fichier, bin2hex(random_bytes(32)), LOCK_EX);
    }
    return trim((string) file_get_contents($fichier));
}

function paiement_signer(string $corps): string
{
    return hash_hmac('sha256', $corps, paiement_secret());
}

/**
 * Acompte demandé pour une commande payée à la livraison : ACOMPTE_POURCENT % du total (20 par défaut, 0 = pas d'acompte),
 * arrondi à la centaine supérieure, au moins ACOMPTE_MINIMUM FCFA (1000 par défaut), jamais plus que le total.
 */
function acompte_calculer(int $total): int
{
    if (function_exists('parametre_actif') && !parametre_actif('acompte_actif', true)) {
        return 0;                                          // acompte désactivé par l'administrateur
    }
    if (function_exists('paiement_en_ligne_actif') && !paiement_en_ligne_actif()) {
        return 0;                                          // paiement en ligne coupé : l'acompte ne pourrait pas être réglé
    }
    if (function_exists('paiement_livraison_actif') && !paiement_livraison_actif()) {
        return 0;                                          // pas de paiement à la livraison : pas d'acompte non plus
    }
    $pct = str_replace(',', '.', trim((string) (function_exists('parametre') ? parametre('acompte_pourcent', env('ACOMPTE_POURCENT', '20')) : env('ACOMPTE_POURCENT', '20'))));
    $pct = is_numeric($pct) ? max(0.0, min(100.0, (float) $pct)) : 20.0;
    if ($pct <= 0 || $total <= 0) {
        return 0;
    }
    $minimum = max(0, (int) (function_exists('parametre') ? parametre('acompte_minimum', env('ACOMPTE_MINIMUM', '1000')) : env('ACOMPTE_MINIMUM', '1000')));
    $acompte = (int) (ceil($total * $pct / 100 / 100) * 100);
    return min($total, max($acompte, $minimum));
}

/** Texte pour le client : « Acompte de 20 % … » (vide quand l'acompte est désactivé). */
function acompte_description(): string
{
    if (acompte_calculer(1_000_000) === 0) {
        return '';
    }
    $pct = str_replace(',', '.', trim((string) (function_exists('parametre') ? parametre('acompte_pourcent', env('ACOMPTE_POURCENT', '20')) : env('ACOMPTE_POURCENT', '20'))));
    $pct = rtrim(rtrim(number_format(max(0.0, min(100.0, (float) $pct)), 1, ',', ''), '0'), ',');
    $minimum = max(0, (int) (function_exists('parametre') ? parametre('acompte_minimum', env('ACOMPTE_MINIMUM', '1000')) : env('ACOMPTE_MINIMUM', '1000')));
    return 'Acompte de ' . $pct . ' % à régler en ligne pour confirmer (minimum ' . fcfa($minimum) . ') ; le reste en espèces à la réception';
}

/** SQL : la commande peut être préparée et livrée (payée en ligne, ou à la livraison avec acompte payé quand il est demandé). Alias de la table : c. */
const SQL_ENGAGEE = "(c.statut_paiement = 'paye' OR (c.methode_paiement = 'livraison' AND (c.acompte = 0 OR c.statut_paiement = 'acompte')))";

function commande_a_acompte(array $c): bool
{
    return $c['methode_paiement'] === 'livraison' && (int) ($c['acompte'] ?? 0) > 0;
}

/** Même règle que SQL_ENGAGEE, pour une commande déjà chargée. */
function commande_engagee(array $c): bool
{
    return $c['statut_paiement'] === 'paye' || ($c['methode_paiement'] === 'livraison' && ((int) ($c['acompte'] ?? 0) === 0 || $c['statut_paiement'] === 'acompte'));
}

/** Moyen de paiement en ligne à utiliser (celui de la commande, ou celui choisi pour l'acompte), ou null s'il n'y a rien à payer en ligne. */
function commande_methode_en_ligne(array $c): ?string
{
    if (commande_a_acompte($c)) {
        return $c['acompte_methode'] ?: null;
    }
    return in_array($c['methode_paiement'], METHODES_EN_LIGNE, true) ? $c['methode_paiement'] : null;
}

/** Montant à régler en ligne : l'acompte (paiement à la livraison) ou le total. */
function commande_a_payer(array $c): int
{
    return commande_a_acompte($c) ? (int) $c['acompte'] : (int) $c['total'];
}

/** Une commande est payable en ligne (paiement complet ou acompte) tant qu'elle n'est ni payée, ni annulée. */
function commande_payable(array $c): bool
{
    return paiement_en_ligne_actif()
        && commande_methode_en_ligne($c) !== null
        && in_array($c['statut_paiement'], ['en_attente', 'echoue'], true)
        && $c['statut'] !== 'annulee';
}

/**
 * Crée une nouvelle tentative de paiement pour la commande et renvoie l'adresse où envoyer le client.
 * Les tentatives précédentes encore ouvertes sont abandonnées.
 */
function paiement_initier(array $commande): string
{
    if (paiement_fournisseur() !== 'simulation') {
        // Le principal d'abord ; s'il ne répond pas ou refuse, les autres prestataires configurés prennent le relais (le client ne voit rien)
        $principal = prestataire_principal();
        $ordre = array_values(array_unique(array_merge($principal ? [$principal] : [], prestataires_actifs())));
        $erreur = null;
        $raisons = [];                                   // pour l'administrateur : pourquoi chaque prestataire a échoué (jamais de clé)
        foreach ($ordre as $p) {
            if (!prestataire_configure($p)) {
                $raisons[] = PRESTATAIRES[$p] . ' : clés manquantes';
                continue;
            }
            try {
                $adresse = match ($p) {
                    'paytech' => paytech_initier($commande),
                    'unitech' => unitech_initier($commande),
                    default   => paydunya_initier($commande),
                };
                if ($erreur !== null) {
                    alerter('paiement-secours:' . $p, 'Paiement : prestataire de secours utilisé', 'Le prestataire principal (' . (PRESTATAIRES[$principal] ?? $principal) . ') n\'a pas pu créer le paiement (' . $erreur->getMessage() . ') : ' . PRESTATAIRES[$p] . ' a pris le relais. Vérifiez le principal.');
                }
                return $adresse;
            } catch (RuntimeException $e) {
                error_log('Jënd — paiement : ' . (PRESTATAIRES[$p] ?? $p) . ' indisponible (' . $e->getMessage() . ')');
                $raisons[] = (PRESTATAIRES[$p] ?? $p) . ' : ' . $e->getMessage();
                $erreur = $e;
            }
        }
        // Dernier échec, visible dans Administration → Paramètres → Prestataires (les messages ne contiennent ni clé ni réponse brute)
        @file_put_contents(paiement_erreur_fichier(), date('d/m/Y H:i') . ' — ' . mb_substr(implode(' · ', $raisons ?: ['aucun prestataire en service']), 0, 1000), LOCK_EX);
        throw $erreur ?? new RuntimeException('Fournisseur de paiement non configuré.');
    }

    $reference = 'SIM-' . bin2hex(random_bytes(12));
    $pdo = pdo();
    $pdo->beginTransaction();
    try {
        // Les tentatives précédentes déjà envoyées au fournisseur sont abandonnées
        requete("UPDATE paiements SET statut = 'echoue' WHERE commande_id = ? AND statut = 'initie' AND reference_externe IS NOT NULL", [$commande['id']]);
        // La ligne créée avec la commande (pas encore envoyée au fournisseur) est réutilisée pour la 1re tentative
        $reutilise = requete(
            "UPDATE paiements SET fournisseur = 'simulation', reference_externe = ?, methode = ?, montant = ?
              WHERE commande_id = ? AND statut = 'initie' AND reference_externe IS NULL LIMIT 1",
            [$reference, commande_methode_en_ligne($commande), commande_a_payer($commande), $commande['id']]
        )->rowCount();
        if ($reutilise === 0) {
            requete(
                "INSERT INTO paiements (commande_id, methode, montant, statut, fournisseur, reference_externe) VALUES (?, ?, ?, 'initie', 'simulation', ?)",
                [$commande['id'], commande_methode_en_ligne($commande), commande_a_payer($commande), $reference]
            );
        }
        $pdo->commit();
    } catch (Throwable $e) {
        $pdo->rollBack();
        throw $e;
    }
    return url('paiement/simulation/' . $reference);
}

/**
 * Traite une notification du fournisseur. Retourne [code HTTP, message].
 * Corps attendu (JSON) : {"reference": "...", "statut": "reussi|echoue", "montant": 99000, "t": 1700000000}
 */
function paiement_notification_traiter(string $corps, string $signature): array
{
    if ($signature === '' || !hash_equals(paiement_signer($corps), $signature)) {
        error_log('Jënd — webhook paiement : signature invalide');
        return [401, 'Signature invalide'];
    }

    $d = json_decode($corps, true);
    if (!is_array($d) || !isset($d['reference'], $d['statut'], $d['montant'], $d['t'])
        || !is_string($d['reference']) || !in_array($d['statut'], ['reussi', 'echoue'], true)
        || !is_int($d['montant']) || !is_int($d['t'])) {
        return [400, 'Notification mal formée'];
    }
    if (abs(time() - $d['t']) > NOTIFICATION_TOLERANCE_SECONDES) {
        return [400, 'Notification expirée'];
    }

    return paiement_appliquer($d['reference'], $d['statut'], $d['montant'], $corps);
}

/**
 * Applique le résultat d'un paiement (réussi / échoué) : cœur commun à la notification signée (simulation) et à PayDunya.
 * Idempotent : une même notification rejouée est ignorée ; un montant différent de celui attendu n'est JAMAIS accepté.
 * Retourne [code HTTP, message].
 */
function paiement_appliquer(string $reference, string $statut, int $montant, string $brut): array
{
    $prevenir = 0;
    $pdo = pdo();
    $pdo->beginTransaction();
    try {
        $p = requete('SELECT * FROM paiements WHERE reference_externe = ? FOR UPDATE', [$reference])->fetch();
        if (!$p) {
            $pdo->rollBack();
            return [404, 'Paiement inconnu'];
        }
        $c = requete('SELECT id, statut, statut_paiement, methode_paiement, acompte FROM commandes WHERE id = ? FOR UPDATE', [$p['commande_id']])->fetch();

        if ($p['statut'] === 'reussi') {                       // le fournisseur peut renvoyer la même notification : on ignore
            $pdo->rollBack();
            return [200, 'Déjà traité'];
        }
        if ($montant !== (int) $p['montant']) {           // on ne valide jamais un montant différent de celui attendu
            error_log("Jënd — webhook paiement : montant incohérent pour {$reference} ({$montant} reçu, {$p['montant']} attendu)");
            alerter('montant:' . $reference, 'Paiement : montant incohérent', "Notification signée reçue avec un montant différent de celui attendu : {$montant} reçu, {$p['montant']} attendu (paiement {$reference}). Vérifiez chez votre fournisseur.");
            $pdo->rollBack();
            return [400, 'Montant incohérent'];
        }

        if ($statut === 'reussi') {
            requete("UPDATE paiements SET statut = 'reussi', reponse_brute = ? WHERE id = ?", [$brut, $p['id']]);

            if (in_array($c['statut_paiement'], ['paye', 'acompte'], true)) {
                error_log("Jënd — DOUBLE PAIEMENT à rembourser : commande {$c['id']}, paiement {$p['reference_externe']}");
                alerter('double-paiement:' . $p['reference_externe'], 'Double paiement à rembourser', "La commande n° {$c['id']} a été payée deux fois (paiement {$p['reference_externe']}). Un remboursement est à faire.");
            } else {
                // Acompte (commande à payer à la livraison) : la commande est confirmée, le reste sera payé en espèces
                requete("UPDATE commandes SET statut_paiement = ? WHERE id = ?", [commande_a_acompte($c) ? 'acompte' : 'paye', $c['id']]);
                $prevenir = (int) $c['id'];             // vendeurs prévenus après l'enregistrement (e-mail + notification)
                if ($c['statut'] === 'en_attente') {
                    requete("UPDATE commandes SET statut = 'confirmee' WHERE id = ?", [$c['id']]);
                }
                if ($c['statut'] === 'annulee') {
                    error_log("Jënd — paiement reçu sur une commande ANNULÉE à rembourser : commande {$c['id']}");
                    alerter('paiement-annulee:' . $c['id'], 'Paiement reçu sur une commande annulée', "La commande n° {$c['id']} avait été annulée mais un paiement est arrivé. Un remboursement est à faire (Administration → Commandes → À rembourser).");
                }
            }
        } elseif ($p['statut'] === 'initie') {
            requete("UPDATE paiements SET statut = 'echoue', reponse_brute = ? WHERE id = ?", [$brut, $p['id']]);
            if ($c['statut_paiement'] === 'en_attente') {
                requete("UPDATE commandes SET statut_paiement = 'echoue' WHERE id = ?", [$c['id']]);
            }
        }

        $pdo->commit();
        if ($prevenir && function_exists('vendeur_prevenir_commande')) {
            try {
                vendeur_prevenir_commande($prevenir);
            } catch (Throwable $e) {
                error_log('Jënd — prévenir les vendeurs : ' . $e->getMessage());
            }
        }
        return [200, 'OK'];
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        error_log('Jënd — webhook paiement : ' . $e->getMessage());
        return [500, 'Erreur interne'];
    }
}
