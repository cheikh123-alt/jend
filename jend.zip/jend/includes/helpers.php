<?php
declare(strict_types=1);

/** Échappe du texte avant de l'afficher (protège des failles XSS). À utiliser pour TOUT affichage. */
function e(?string $texte): string
{
    return htmlspecialchars((string) $texte, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

/**
 * Site de TEST en ligne (APP_ENV=test) : sécurisé comme la production (erreurs masquées, HTTPS, cookies, CSP…),
 * mais avec le paiement SIMULÉ, un bandeau « SITE DE TEST » et l'indexation par les moteurs de recherche interdite.
 */
function est_test(): bool
{
    return env('APP_ENV') === 'test';
}

/** Dossier d'installation vu du navigateur : "" à la racine, "/jend" dans un sous-dossier. */
function base_path(): string
{
    $dir = str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? '/index.php'));
    return $dir === '/' || $dir === '.' ? '' : rtrim($dir, '/');
}

/** URL d'une page du site : url('produits') → /jend/produits */
function url(string $chemin = ''): string
{
    return base_path() . '/' . ltrim($chemin, '/');
}

/** URL d'un fichier statique, avec un numéro de version pour forcer le rafraîchissement du cache. */
function asset(string $chemin): string
{
    $fichier = dirname(__DIR__) . '/assets/' . ltrim($chemin, '/');
    $version = is_file($fichier) ? '?v=' . filemtime($fichier) : '';
    return url('assets/' . ltrim($chemin, '/')) . $version;
}

/** Commission (en %) donnée aux NOUVELLES boutiques : COMMISSION_DEFAUT du .env (0 = offre de lancement), 8 si non défini. */
function commission_defaut(): float
{
    $brut = function_exists('parametre') ? parametre('commission_defaut', env('COMMISSION_DEFAUT', '8')) : env('COMMISSION_DEFAUT', '8');   // réglage de l'administrateur, sinon .env
    $v = str_replace(',', '.', trim((string) $brut));
    $pct = is_numeric($v) ? round((float) $v, 2) : 8.0;
    return ($pct >= 0.0 && $pct <= 50.0) ? $pct : 8.0;      // valeur invalide ou hors de 0-50 % : retour au taux standard
}
/** 8.0 → "8" ; 7.5 → "7,5" */
function commission_texte(?float $pct = null): string
{
    return str_replace('.', ',', rtrim(rtrim(number_format($pct ?? commission_defaut(), 2, '.', ''), '0'), '.'));
}

/** 18500 → "18 500 FCFA" */
function fcfa(int $montant): string
{
    return number_format($montant, 0, ',', ' ') . ' FCFA';
}

/**
 * "Pagne Wax Premium" → "pagne-wax-premium" ; "Beurre de karité" → "beurre-de-karite".
 * Table de transcription intégrée : le résultat ne dépend ni du système ni de la configuration régionale du serveur
 * (la fonction iconv(), elle, donne des résultats différents d'un serveur à l'autre : « karit-e », « karit? »…).
 */
function slugify(string $texte): string
{
    static $table = [
        'à' => 'a', 'á' => 'a', 'â' => 'a', 'ã' => 'a', 'ä' => 'a', 'å' => 'a', 'æ' => 'ae', 'ç' => 'c',
        'è' => 'e', 'é' => 'e', 'ê' => 'e', 'ë' => 'e', 'ì' => 'i', 'í' => 'i', 'î' => 'i', 'ï' => 'i',
        'ñ' => 'n', 'ŋ' => 'n', 'ò' => 'o', 'ó' => 'o', 'ô' => 'o', 'õ' => 'o', 'ö' => 'o', 'œ' => 'oe',
        'ù' => 'u', 'ú' => 'u', 'û' => 'u', 'ü' => 'u', 'ý' => 'y', 'ÿ' => 'y', 'ß' => 'ss',
        '’' => '', '\'' => '',
    ];
    $texte = strtr(mb_strtolower($texte, 'UTF-8'), $table);
    $texte = trim((string) preg_replace('/[^a-z0-9]+/', '-', $texte), '-');
    return $texte !== '' ? $texte : 'article';
}

function rediriger(string $chemin): void
{
    header('Location: ' . url($chemin));
    exit;
}

/**
 * Un mot de passe est-il trop faible ? Retourne le message d'erreur à afficher, ou null s'il est acceptable.
 * 8 caractères minimum (72 maximum : au-delà, le hachage bcrypt ignore la suite), ni une suite triviale, ni un mot de passe
 * parmi les plus utilisés, ni l'adresse e-mail ou le nom de l'utilisateur.
 */
function mot_de_passe_faible(string $mdp, string $email = '', string $nom = ''): ?string
{
    if (strlen($mdp) < 8) {
        return 'Le mot de passe doit contenir au moins 8 caractères.';
    }
    if (strlen($mdp) > 72) {
        return 'Le mot de passe est trop long (72 caractères maximum).';
    }
    $bas = mb_strtolower($mdp);
    static $courants = ['12345678', '123456789', '1234567890', '0123456789', '87654321', '11111111', '00000000', 'password', 'password1', 'password123', 'motdepasse',
        'azertyui', 'azerty123', 'azertyuiop', 'qwertyui', 'qwerty123', 'qwertyuiop', 'abcd1234', 'abcdefgh', 'iloveyou', 'jend1234', 'senegal', 'senegal1', 'senegal123',
        'touba123', 'bismillah', 'bismillah1', 'alhamdulillah', 'passer123', 'admin123', 'administrateur', 'welcome1', 'letmein1', 'changeme', 'changeme1'];
    if (in_array($bas, $courants, true) || count(array_unique(mb_str_split($bas))) < 4
        || ($email !== '' && $bas === mb_strtolower($email))
        || ($nom !== '' && mb_strlen($nom) >= 4 && str_contains($bas, mb_strtolower(preg_replace('/\s+/', '', $nom))))) {
        return 'Ce mot de passe est trop facile à deviner. Mélangez lettres et chiffres, et évitez votre nom ou une suite simple.';
    }
    return null;
}

/* ---------- Protection CSRF (formulaires POST) ---------- */

function csrf_token(): string
{
    if (empty($_SESSION['csrf'])) {
        $_SESSION['csrf'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf'];
}

function csrf_champ(): string
{
    return '<input type="hidden" name="csrf" value="' . e(csrf_token()) . '">';
}

function csrf_valide(?string $token): bool
{
    return is_string($token) && isset($_SESSION['csrf']) && hash_equals($_SESSION['csrf'], $token);
}

/* ---------- Panier (compteur affiché dans l'en-tête) ---------- */

function panier_quantite(): int
{
    return array_sum($_SESSION['panier'] ?? []);
}

/* ---------- Messages flash (affichés une seule fois) ---------- */

function flash(string $message, string $type = 'ok', ?array $lien = null): void
{
    $_SESSION['flash'] = ['message' => $message, 'type' => $type, 'lien' => $lien];      // $lien : ['url' => …, 'texte' => …] (bouton d'action)
}

function flash_lire(): ?array
{
    $f = $_SESSION['flash'] ?? null;
    unset($_SESSION['flash']);
    return $f;
}

/** Valide une adresse de retour : uniquement un chemin de CE site (évite les redirections vers un site pirate). */
function retour_sur(?string $cible): string
{
    $cible = (string) $cible;
    $base  = base_path();
    $ok = $cible !== ''
        && $cible[0] === '/'
        && strpos($cible, '//') !== 0
        && !preg_match('/[\\\\\r\n]/', $cible)
        && ($base === '' || strpos($cible, $base . '/') === 0 || $cible === $base);
    return $ok ? $cible : url();
}

/** URL de la page courante avec certains paramètres modifiés : url_avec(['page' => 2]) */
function url_avec(array $changements): string
{
    $chemin = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH);
    $params = array_merge($_GET, $changements);
    $params = array_filter($params, fn($v) => $v !== null && $v !== '');
    return $chemin . ($params ? '?' . http_build_query($params) : '');
}

/* ---------- Mode « économie de données » (petit forfait, 3G) ---------- */

/**
 * Activé par le client (cookie), ou automatiquement quand le téléphone signale qu'il économise les données (en-tête Save-Data).
 * Effet : pas de bibliothèques d'animation, pas de motifs décoratifs, pages plus légères.
 */
function mode_leger(): bool
{
    $choix = $_COOKIE['jend_leger'] ?? null;
    if ($choix === '1' || $choix === '0') {
        return $choix === '1';
    }
    return strtolower(trim((string) ($_SERVER['HTTP_SAVE_DATA'] ?? ''))) === 'on';
}

/* ---------- Petit cache sur disque (storage/cache) : valeurs coûteuses à recalculer, gardées quelques instants ---------- */

function cache_fichier(string $cle): string
{
    return dirname(__DIR__) . '/storage/cache/' . hash('sha256', $cle) . '.json';
}

/** Valeur gardée depuis moins de $secondes, ou null. */
function cache_lire(string $cle, int $secondes)
{
    $f = cache_fichier($cle);
    if (!is_file($f) || filemtime($f) < time() - $secondes) {
        return null;
    }
    $v = json_decode((string) @file_get_contents($f), true);
    return is_array($v) && array_key_exists('v', $v) ? $v['v'] : null;
}

/** Enregistre une valeur (écriture atomique). De temps en temps, les fichiers de plus d'une heure sont supprimés. */
function cache_ecrire(string $cle, $valeur): void
{
    $f = cache_fichier($cle);
    $dossier = dirname($f);
    if (!is_dir($dossier) && !@mkdir($dossier, 0755, true) && !is_dir($dossier)) {
        return;
    }
    $tmp = $f . '.' . getmypid() . '.tmp';
    if (@file_put_contents($tmp, json_encode(['v' => $valeur])) !== false) {
        @rename($tmp, $f);
    }
    if (random_int(1, 200) === 1) {
        foreach (glob($dossier . '/*.json') ?: [] as $vieux) {
            if (filemtime($vieux) < time() - 3600) {
                @unlink($vieux);
            }
        }
    }
}

