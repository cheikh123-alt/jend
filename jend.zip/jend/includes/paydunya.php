<?php
declare(strict_types=1);

/**
 * Paiement PayDunya (https://paydunya.com) : Wave, Orange Money, Free Money, cartes… sur la page de paiement de PayDunya.
 *
 * Principe de sécurité (le même que pour tout agrégateur) : le navigateur du client ne prouve JAMAIS un paiement.
 * Une commande n'est marquée payée que si NOTRE serveur interroge PayDunya (avec la clé privée) et reçoit « completed »
 * pour le bon montant. Cette vérification est déclenchée :
 *   1. par la notification IPN de PayDunya (paiement/webhook), après contrôle du hash de la clé principale ;
 *   2. par le retour du client sur le site (paiement/retour/…), pour les hébergements qui bloquent les appels entrants
 *      (ex : InfinityFree) : même contrôle serveur à serveur, rien n'est cru sur parole.
 *
 * Réglages (.env) : PAIEMENT_FOURNISSEUR=paydunya, PAYDUNYA_MODE=test|live,
 *   PAYDUNYA_MASTER_KEY, PAYDUNYA_PRIVATE_KEY, PAYDUNYA_TOKEN (3 clés de l'application PayDunya, jamais dans le code).
 */

const PAYDUNYA_HOTE_AUTORISE = 'paydunya.com';

/** PayDunya est-il en service ? (seul ou à côté de PayTech : ses notifications sont alors toujours acceptées) */
function paydunya_actif(): bool
{
    return in_array('paydunya', prestataires_actifs(), true);
}

function paydunya_configure(): bool
{
    return env('PAYDUNYA_MASTER_KEY', '') !== '' && env('PAYDUNYA_PRIVATE_KEY', '') !== '' && env('PAYDUNYA_TOKEN', '') !== '';
}

/** Mode réel si PAYDUNYA_MODE vaut « live » (le mot de PayDunya) ; « prod » et « production » sont acceptés aussi, tout le reste = test. */
function paydunya_mode_test(): bool
{
    return !in_array(strtolower(trim((string) env('PAYDUNYA_MODE', 'test'))), ['live', 'prod', 'production'], true);
}

/** Adresse de l'API. PAYDUNYA_API_BASE (faux serveur des tests) n'est lu qu'en développement. */
function paydunya_base(): string
{
    $autre = (string) env('PAYDUNYA_API_BASE', '');
    if ($autre !== '' && env('APP_ENV', 'prod') === 'dev') {
        return rtrim($autre, '/');
    }
    return paydunya_mode_test() ? 'https://app.paydunya.com/sandbox-api/v1' : 'https://app.paydunya.com/api/v1';
}

/**
 * Appel de l'API PayDunya. Retourne la réponse décodée.
 * @throws RuntimeException message sûr (jamais les clés ni la réponse brute)
 */
function paydunya_requete(string $methode, string $chemin, ?array $corps = null): array
{
    if (!paydunya_configure()) {
        throw new RuntimeException('PayDunya n\'est pas configuré (clés manquantes dans .env).');
    }
    $url = paydunya_base() . '/' . ltrim($chemin, '/');
    $entetes = [
        'Content-Type: application/json', 'Accept: application/json',
        'PAYDUNYA-MASTER-KEY: ' . env('PAYDUNYA_MASTER_KEY'),
        'PAYDUNYA-PRIVATE-KEY: ' . env('PAYDUNYA_PRIVATE_KEY'),
        'PAYDUNYA-TOKEN: ' . env('PAYDUNYA_TOKEN'),
    ];
    $json = $corps !== null ? json_encode($corps, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) : null;
    $reponse = false;
    $code = 0;
    if (function_exists('curl_init')) {
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_CUSTOMREQUEST => $methode, CURLOPT_HTTPHEADER => $entetes, CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => 20, CURLOPT_CONNECTTIMEOUT => 8, CURLOPT_FOLLOWLOCATION => false,
            CURLOPT_PROTOCOLS => str_starts_with($url, 'http://') ? (CURLPROTO_HTTP | CURLPROTO_HTTPS) : CURLPROTO_HTTPS,
        ] + ($json !== null ? [CURLOPT_POSTFIELDS => $json] : []));
        $reponse = curl_exec($ch);
        $code = (int) curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
        curl_close($ch);
    } else {
        $ctx = stream_context_create(['http' => ['method' => $methode, 'header' => implode("\r\n", $entetes), 'content' => $json ?? '', 'timeout' => 20, 'ignore_errors' => true, 'follow_location' => 0]]);
        $reponse = @file_get_contents($url, false, $ctx);
        $code = isset($http_response_header[0]) && preg_match('#\s(\d{3})\s#', $http_response_header[0], $m) ? (int) $m[1] : 0;
    }
    if ($reponse === false || $code === 0) {
        error_log('Jënd — PayDunya injoignable (' . $methode . ' ' . parse_url($url, PHP_URL_PATH) . ')');
        throw new RuntimeException('serveur PayDunya injoignable depuis cet hébergement (connexion sortante bloquée ?)');
    }
    $data = json_decode((string) $reponse, true);
    if (!is_array($data)) {
        error_log('Jënd — PayDunya : réponse illisible (HTTP ' . $code . ')');
        throw new RuntimeException('Réponse invalide du service de paiement.');
    }
    return $data;
}

/**
 * Crée la facture PayDunya de la commande (montant à régler = total, ou acompte) et renvoie l'adresse de leur page de paiement.
 */
function paydunya_initier(array $commande): string
{
    $montant = commande_a_payer($commande);
    $ref = $commande['reference'];
    $acompte = commande_a_acompte($commande);
    $retour = app_url('paiement/retour/' . $ref);
    $rep = paydunya_requete('POST', 'checkout-invoice/create', [
        'invoice' => ['total_amount' => $montant, 'description' => 'Jënd — commande ' . $ref . ($acompte ? ' (acompte)' : '')],
        'store' => ['name' => 'Jënd', 'website_url' => app_url()],
        'actions' => ['return_url' => $retour, 'cancel_url' => $retour, 'callback_url' => app_url('paiement/webhook')],
        'custom_data' => ['commande' => $ref],
    ]);
    $token = (string) ($rep['token'] ?? '');
    $page = (string) ($rep['response_text'] ?? '');
    if (($rep['response_code'] ?? '') !== '00' || $token === '' || !preg_match('/^[A-Za-z0-9_-]{6,80}$/', $token)) {
        error_log('Jënd — PayDunya a refusé la facture (code ' . ($rep['response_code'] ?? '?') . ')');
        throw new RuntimeException('demande refusée par PayDunya en mode ' . (paydunya_mode_test() ? 'TEST (bac à sable)' : 'RÉEL (live)') . ' (code ' . preg_replace('/[^0-9A-Za-z]/', '', (string) ($rep['response_code'] ?? '?')) . ' : ' . mb_substr(strip_tags((string) ($rep['response_text'] ?? '')), 0, 120) . ') — clés ou mode (PAYDUNYA_MODE) à vérifier');
    }
    $hote = (string) parse_url($page, PHP_URL_HOST);
    $hoteOk = $hote === PAYDUNYA_HOTE_AUTORISE || str_ends_with($hote, '.' . PAYDUNYA_HOTE_AUTORISE);
    if (!(preg_match('#^https://#', $page) && $hoteOk) && !(env('APP_ENV', 'prod') === 'dev' && env('PAYDUNYA_API_BASE', '') !== '' && str_starts_with($page, 'http://127.0.0.1'))) {
        error_log('Jënd — PayDunya : adresse de paiement inattendue (' . $hote . ')');
        throw new RuntimeException('Adresse de paiement invalide.');
    }

    $pdo = pdo();
    $pdo->beginTransaction();
    try {
        requete("UPDATE paiements SET statut = 'echoue' WHERE commande_id = ? AND statut = 'initie' AND reference_externe IS NOT NULL", [$commande['id']]);
        $reutilise = requete(
            "UPDATE paiements SET fournisseur = 'paydunya', reference_externe = ?, methode = ?, montant = ? WHERE commande_id = ? AND statut = 'initie' AND reference_externe IS NULL LIMIT 1",
            [$token, commande_methode_en_ligne($commande), $montant, $commande['id']]
        )->rowCount();
        if ($reutilise === 0) {
            requete("INSERT INTO paiements (commande_id, methode, montant, statut, fournisseur, reference_externe) VALUES (?, ?, ?, 'initie', 'paydunya', ?)",
                [$commande['id'], commande_methode_en_ligne($commande), $montant, $token]);
        }
        $pdo->commit();
    } catch (Throwable $e) {
        $pdo->rollBack();
        throw $e;
    }
    return $page;
}

/** Interroge PayDunya sur l'état d'une facture. Retourne la réponse « confirm » décodée. */
function paydunya_confirmation(string $token): array
{
    if (!preg_match('/^[A-Za-z0-9_-]{6,80}$/', $token)) {
        throw new RuntimeException('Jeton de paiement invalide.');
    }
    return paydunya_requete('GET', 'checkout-invoice/confirm/' . $token);
}

/**
 * Traite l'état d'une facture PayDunya déjà confirmé par l'API : completed → réussi ; failed / cancelled → échoué ; pending → rien.
 * Contrôle aussi que la facture correspond bien à NOTRE commande (custom_data) et au montant attendu (paiement_appliquer).
 * Retourne [code HTTP, message].
 */
function paydunya_appliquer(string $token, array $conf): array
{
    if (($conf['response_code'] ?? '') !== '00') {
        return [404, 'Facture inconnue'];
    }
    $statut = match ((string) ($conf['status'] ?? '')) {
        'completed' => 'reussi',
        'failed', 'cancelled' => 'echoue',
        default => null,
    };
    if ($statut === null) {
        return [200, 'En attente'];
    }
    $p = requete("SELECT p.id, p.fournisseur, c.reference FROM paiements p JOIN commandes c ON c.id = p.commande_id WHERE p.reference_externe = ?", [$token])->fetch();
    if (!$p || $p['fournisseur'] !== 'paydunya') {
        return [404, 'Paiement inconnu'];
    }
    $refFacture = (string) ($conf['custom_data']['commande'] ?? '');
    if ($refFacture !== '' && $refFacture !== $p['reference']) {
        alerter('paydunya-commande:' . $token, 'PayDunya : facture non conforme', 'La facture ' . $token . ' porte la référence « ' . $refFacture . ' » mais est liée à la commande ' . $p['reference'] . '. Vérifiez chez PayDunya.');
        return [400, 'Commande incohérente'];
    }
    $montant = (int) round((float) ($conf['invoice']['total_amount'] ?? -1));
    return paiement_appliquer($token, $statut, $montant, json_encode($conf, JSON_UNESCAPED_UNICODE) ?: '{}');
}

/**
 * Notification IPN de PayDunya (POST form-urlencoded, tableau « data »). Authentification : hash SHA-512 de la clé principale,
 * puis confirmation par appel direct à l'API (on ne se fie à aucun montant ni statut reçus).
 */
function paydunya_notification(array $post): array
{
    $data = $post['data'] ?? null;
    if (!is_array($data) || !paydunya_configure()) {
        return [400, 'Notification mal formée'];
    }
    $hash = (string) ($data['hash'] ?? '');
    if ($hash === '' || !hash_equals(hash('sha512', (string) env('PAYDUNYA_MASTER_KEY')), $hash)) {
        error_log('Jënd — IPN PayDunya : hash invalide');
        return [401, 'Hash invalide'];
    }
    $token = (string) ($data['invoice']['token'] ?? '');
    if ($token === '') {
        return [400, 'Jeton manquant'];
    }
    try {
        return paydunya_appliquer($token, paydunya_confirmation($token));
    } catch (RuntimeException $e) {
        return [502, 'Vérification impossible'];
    }
}

/**
 * Au retour du client : si le paiement est encore en attente, on demande l'état à PayDunya (serveur à serveur) et on l'applique.
 * Sans effet pour une commande déjà réglée. Limité en fréquence.
 */
function paydunya_verifier_commande(array $commande): void
{
    if (!paydunya_actif() || !paydunya_configure() || in_array($commande['statut_paiement'], ['paye', 'acompte', 'rembourse'], true)) {
        return;
    }
    $token = requete("SELECT reference_externe FROM paiements WHERE commande_id = ? AND fournisseur = 'paydunya' AND statut = 'initie' AND reference_externe IS NOT NULL ORDER BY id DESC LIMIT 1", [$commande['id']])->fetchColumn();
    if (!$token || limite_atteinte('paydunya-verif:' . $commande['id'], 20, 600)) {
        return;
    }
    limite_enregistrer('paydunya-verif:' . $commande['id']);
    try {
        paydunya_appliquer((string) $token, paydunya_confirmation((string) $token));
    } catch (RuntimeException $e) {
        // service injoignable : le client verra « en cours de vérification » et la page se met à jour au prochain passage
    }
}
