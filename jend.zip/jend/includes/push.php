<?php
declare(strict_types=1);

/**
 * Notifications sur le téléphone (« Web Push »), même quand le site est fermé — sans service payant.
 *
 * Le navigateur du vendeur (Chrome, Firefox, Safari…) donne une adresse chez son service de notification (Google, Mozilla, Apple)
 * et deux clés. Pour chaque notification, le site :
 *  1. chiffre le message avec les clés du téléphone (RFC 8291, « aes128gcm ») : le service de notification ne peut pas le lire ;
 *  2. signe la demande avec la clé du site (VAPID, RFC 8292) : personne d'autre ne peut écrire à nos abonnés ;
 *  3. l'envoie à l'adresse du navigateur, qui réveille le téléphone (sw.js affiche la notification).
 * La clé du site est créée automatiquement dans storage/vapid-prive.pem (dossier protégé, jamais dans les archives).
 */

const PUSH_CLE_FICHIER = 'storage/vapid-prive.pem';
const PUSH_ABONNEMENTS_MAX = 10;                     // appareils par compte (les plus anciens sont remplacés)

/** Services de notification autorisés (les adresses viennent du navigateur : on n'envoie jamais ailleurs). */
const PUSH_HOTES = ['fcm.googleapis.com', 'android.googleapis.com', 'updates.push.services.mozilla.com', 'push.services.mozilla.com',
    'web.push.apple.com', 'api.push.apple.com', '.notify.windows.com', '.push.apple.com'];

function b64url(string $binaire): string
{
    return rtrim(strtr(base64_encode($binaire), '+/', '-_'), '=');
}

function b64url_lire(string $texte): string
{
    return (string) base64_decode(strtr($texte, '-_', '+/') . str_repeat('=', (4 - strlen($texte) % 4) % 4), true);
}

/** Le serveur sait-il chiffrer et envoyer des notifications ? (extensions openssl et curl) */
function push_possible(): bool
{
    return function_exists('openssl_pkey_derive') && function_exists('curl_init') && in_array('aes-128-gcm', openssl_get_cipher_methods(), true);
}

/**
 * Notifications sur le téléphone activées ? DÉSACTIVÉES par défaut (bouton retiré des pages) : sur un hébergement gratuit,
 * le serveur ne peut souvent pas joindre les services de notification. Pour les rallumer (hébergement payant) :
 * ajouter NOTIFICATIONS_TELEPHONE=1 dans config.env — le bouton « Être prévenu des commandes » réapparaît.
 */
function push_disponible(): bool
{
    return (string) env('NOTIFICATIONS_TELEPHONE', '0') === '1' && push_possible();
}

/** Clé publique EC P-256 brute (65 octets, 0x04 || X || Y) d'une clé openssl. */
function push_point_public($cle): string
{
    $d = openssl_pkey_get_details($cle);
    return "\x04" . str_pad($d['ec']['x'], 32, "\0", STR_PAD_LEFT) . str_pad($d['ec']['y'], 32, "\0", STR_PAD_LEFT);
}

/** Clé publique brute (65 octets) → objet openssl (enveloppe SubjectPublicKeyInfo P-256). */
function push_cle_depuis_point(string $point)
{
    $der = hex2bin('3059301306072a8648ce3d020106082a8648ce3d030107034200') . $point;
    $pem = "-----BEGIN PUBLIC KEY-----\n" . chunk_split(base64_encode($der), 64, "\n") . "-----END PUBLIC KEY-----\n";
    return openssl_pkey_get_public($pem);
}

/** Clé du site (VAPID) : ['privee' => clé openssl, 'publique' => texte base64url à donner au navigateur]. Créée au premier besoin. */
function push_cle_site(): array
{
    static $cle = null;
    if ($cle !== null) {
        return $cle;
    }
    $fichier = dirname(__DIR__) . '/' . PUSH_CLE_FICHIER;
    if (!is_file($fichier)) {
        $nouvelle = openssl_pkey_new(['private_key_type' => OPENSSL_KEYTYPE_EC, 'curve_name' => 'prime256v1']);
        if (!$nouvelle || !openssl_pkey_export($nouvelle, $pem)) {
            throw new RuntimeException('Impossible de créer la clé des notifications.');
        }
        $tmp = $fichier . '.' . getmypid() . '.tmp';
        file_put_contents($tmp, $pem, LOCK_EX);
        @chmod($tmp, 0640);            // lisible par le groupe : le propriétaire de l'ordinateur peut copier ou compresser le dossier (storage/ reste interdit depuis Internet)
        if (!is_file($fichier)) {            // deux visiteurs en même temps : la première clé écrite est gardée
            rename($tmp, $fichier);
        } else {
            @unlink($tmp);
        }
    }
    $privee = openssl_pkey_get_private((string) file_get_contents($fichier));
    if (!$privee) {
        throw new RuntimeException('Clé des notifications illisible (' . PUSH_CLE_FICHIER . ').');
    }
    return $cle = ['privee' => $privee, 'publique' => b64url(push_point_public($privee))];
}

/** L'adresse donnée par le navigateur est-elle celle d'un vrai service de notification ? (sinon le serveur pourrait être utilisé pour contacter n'importe quel site) */
function push_endpoint_autorise(string $url): bool
{
    if (strlen($url) > 600 || !filter_var($url, FILTER_VALIDATE_URL)) {
        return false;
    }
    $p = parse_url($url);
    $hote = strtolower((string) ($p['host'] ?? ''));
    // Tests automatiques uniquement : faux service de notification sur l'ordinateur (jamais en production)
    $prefixeTest = (string) env('PUSH_TEST_ENDPOINT', '');
    if ($prefixeTest !== '' && env('APP_ENV', 'prod') !== 'prod' && str_starts_with($url, $prefixeTest)) {
        return true;
    }
    if (($p['scheme'] ?? '') !== 'https' || isset($p['user']) || isset($p['port'])) {
        return false;
    }
    foreach (PUSH_HOTES as $h) {
        if ($h[0] === '.' ? str_ends_with($hote, $h) : $hote === $h) {
            return true;
        }
    }
    return false;
}

/**
 * Enregistre l'abonnement d'un appareil pour un compte.
 * @throws RuntimeException message affichable
 */
function push_abonner(int $userId, string $endpoint, string $p256dh, string $auth, string $appareil = ''): void
{
    if (!push_endpoint_autorise($endpoint)) {
        throw new RuntimeException('Service de notification non reconnu.');
    }
    $point = b64url_lire($p256dh);
    $secret = b64url_lire($auth);
    if (strlen($point) !== 65 || $point[0] !== "\x04" || strlen($secret) !== 16 || !push_cle_depuis_point($point)) {
        throw new RuntimeException('Clés de notification invalides.');
    }
    $hash = hash('sha256', $endpoint);
    requete('INSERT INTO push_abonnements (user_id, endpoint, endpoint_hash, cle_p256dh, cle_auth, appareil) VALUES (?, ?, ?, ?, ?, ?)
             ON DUPLICATE KEY UPDATE user_id = VALUES(user_id), cle_p256dh = VALUES(cle_p256dh), cle_auth = VALUES(cle_auth), appareil = VALUES(appareil)',
        [$userId, $endpoint, $hash, b64url($point), b64url($secret), mb_substr($appareil, 0, 120) ?: null]);
    // Pas plus de PUSH_ABONNEMENTS_MAX appareils par compte : les plus anciens sont retirés
    $ids = requete('SELECT id FROM push_abonnements WHERE user_id = ? ORDER BY id DESC', [$userId])->fetchAll(PDO::FETCH_COLUMN);
    foreach (array_slice($ids, PUSH_ABONNEMENTS_MAX) as $id) {
        requete('DELETE FROM push_abonnements WHERE id = ?', [$id]);
    }
}

function push_desabonner(int $userId, string $endpoint): void
{
    requete('DELETE FROM push_abonnements WHERE user_id = ? AND endpoint_hash = ?', [$userId, hash('sha256', $endpoint)]);
}

/** Nombre d'appareils qui reçoivent les notifications de ce compte. */
function push_nb_appareils(int $userId): int
{
    return (int) requete('SELECT COUNT(*) FROM push_abonnements WHERE user_id = ?', [$userId])->fetchColumn();
}

/** Signature ECDSA DER (openssl) → format JWT (r || s, 64 octets). */
function push_signature_brute(string $der): string
{
    $pos = 3;                                             // 0x30 len 0x02
    $lr = ord($der[$pos]);
    $r = substr($der, $pos + 1, $lr);
    $pos += 1 + $lr + 1;                                  // 0x02
    $ls = ord($der[$pos]);
    $s = substr($der, $pos + 1, $ls);
    $norm = fn (string $v) => str_pad(ltrim($v, "\0"), 32, "\0", STR_PAD_LEFT);
    return $norm($r) . $norm($s);
}

/** En-tête Authorization VAPID pour une adresse de notification. */
function push_vapid(string $endpoint): string
{
    $cle = push_cle_site();
    $p = parse_url($endpoint);
    $aud = $p['scheme'] . '://' . $p['host'] . (isset($p['port']) ? ':' . $p['port'] : '');
    $contact = (string) env('ADMIN_EMAIL', 'admin@jend.local');
    $entete = b64url(json_encode(['typ' => 'JWT', 'alg' => 'ES256']));
    $corps = b64url(json_encode(['aud' => $aud, 'exp' => time() + 12 * 3600, 'sub' => 'mailto:' . $contact]));
    if (!openssl_sign($entete . '.' . $corps, $der, $cle['privee'], OPENSSL_ALGO_SHA256)) {
        throw new RuntimeException('Signature VAPID impossible.');
    }
    return 'vapid t=' . $entete . '.' . $corps . '.' . b64url(push_signature_brute($der)) . ', k=' . $cle['publique'];
}

/**
 * Chiffre un message pour un appareil (RFC 8291, aes128gcm). Retourne le corps binaire à envoyer.
 * $ephemere / $sel : uniquement pour les tests (valeurs fixes), sinon tirés au hasard.
 */
function push_chiffrer(string $message, string $p256dh, string $auth, $ephemere = null, ?string $sel = null): string
{
    $pointClient = b64url_lire($p256dh);
    $secretAuth = b64url_lire($auth);
    $ephemere = $ephemere ?: openssl_pkey_new(['private_key_type' => OPENSSL_KEYTYPE_EC, 'curve_name' => 'prime256v1']);
    $pointServeur = push_point_public($ephemere);
    $partage = openssl_pkey_derive(push_cle_depuis_point($pointClient), $ephemere, 32);
    if ($partage === false) {
        throw new RuntimeException('Clé du téléphone invalide.');
    }
    $partage = str_pad($partage, 32, "\0", STR_PAD_LEFT);
    $sel = $sel ?? random_bytes(16);
    $prkCle = hash_hmac('sha256', $partage, $secretAuth, true);
    $ikm = hash_hmac('sha256', "WebPush: info\0" . $pointClient . $pointServeur . "\x01", $prkCle, true);
    $prk = hash_hmac('sha256', $ikm, $sel, true);
    $cek = substr(hash_hmac('sha256', "Content-Encoding: aes128gcm\0\x01", $prk, true), 0, 16);
    $nonce = substr(hash_hmac('sha256', "Content-Encoding: nonce\0\x01", $prk, true), 0, 12);
    $chiffre = openssl_encrypt($message . "\x02", 'aes-128-gcm', $cek, OPENSSL_RAW_DATA, $nonce, $tag, '', 16);
    if ($chiffre === false) {
        throw new RuntimeException('Chiffrement impossible.');
    }
    return $sel . pack('N', 4096) . chr(65) . $pointServeur . $chiffre . $tag;
}

/**
 * Envoie une notification à tous les appareils d'un compte. Retourne le nombre d'appareils joints.
 * $message : ['titre' => …, 'texte' => …, 'url' => chemin du site, 'tag' => regroupement (une seule notification par tag)].
 * Les appareils désabonnés ou dont la clé a changé (réponses 403, 404, 410) sont retirés.
 */
function push_envoyer(int $userId, array $message): int
{
    if (!push_disponible()) {
        return 0;
    }
    $abonnements = requete('SELECT * FROM push_abonnements WHERE user_id = ?', [$userId])->fetchAll();
    if (!$abonnements) {
        return 0;
    }
    $charge = json_encode([
        'titre' => mb_substr((string) ($message['titre'] ?? 'Jënd'), 0, 80),
        'texte' => mb_substr((string) ($message['texte'] ?? ''), 0, 180),
        'url'   => app_url(ltrim((string) ($message['url'] ?? ''), '/')),
        'tag'   => mb_substr((string) ($message['tag'] ?? 'jend'), 0, 60),
    ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    $joints = 0;
    foreach ($abonnements as $a) {
        try {
            $corps = push_chiffrer($charge, $a['cle_p256dh'], $a['cle_auth']);
            $ch = curl_init($a['endpoint']);
            curl_setopt_array($ch, [
                CURLOPT_POST => true, CURLOPT_POSTFIELDS => $corps, CURLOPT_RETURNTRANSFER => true,
                CURLOPT_CONNECTTIMEOUT => 3, CURLOPT_TIMEOUT => 5, CURLOPT_FOLLOWLOCATION => false,
                CURLOPT_PROTOCOLS => CURLPROTO_HTTPS | CURLPROTO_HTTP,
                CURLOPT_HTTPHEADER => [
                    'Content-Type: application/octet-stream', 'Content-Encoding: aes128gcm', 'TTL: 86400', 'Urgency: high',
                    'Authorization: ' . push_vapid($a['endpoint']),
                ],
            ]);
            $reponse = curl_exec($ch);
            $code = (int) curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
            $erreurCurl = curl_errno($ch) ? curl_error($ch) : '';
            curl_close($ch);
            if ($code >= 200 && $code < 300) {
                $joints++;
                requete('UPDATE push_abonnements SET dernier_envoi = NOW() WHERE id = ?', [$a['id']]);
            } elseif (in_array($code, [403, 404, 410], true)) {
                requete('DELETE FROM push_abonnements WHERE id = ?', [$a['id']]);     // appareil désabonné ou clé du site changée
                push_probleme($code === 403
                    ? 'Le service de notification a refusé la signature du site (clé changée ?) : ce téléphone a été retiré, touchez « Activer » à nouveau.'
                    : 'Ce téléphone n\'est plus inscrit chez le service de notification : touchez « Activer » à nouveau.');
            } elseif ($erreurCurl !== '' || $code === 0) {
                push_probleme('Le serveur du site n\'arrive pas à joindre le service de notification (' . parse_url($a['endpoint'], PHP_URL_HOST) . ' : ' . mb_substr($erreurCurl ?: 'pas de réponse', 0, 120)
                    . '). L\'hébergeur bloque probablement les connexions sortantes.');
                error_log('Jënd — notification : connexion impossible (' . $erreurCurl . ')');
            } else {
                push_probleme('Le service de notification a répondu « ' . $code . ' » : ' . mb_substr(trim(strip_tags((string) $reponse)), 0, 160));
                error_log('Jënd — notification non délivrée (code ' . $code . ') : ' . mb_substr((string) $reponse, 0, 300));
            }
        } catch (Throwable $e) {
            push_probleme('Erreur du site : ' . $e->getMessage());
            error_log('Jënd — notification : ' . $e->getMessage());
        }
    }
    return $joints;
}

/** Dernier problème d'envoi, expliqué simplement (affiché au vendeur qui teste, et dans le diagnostic). */
function push_probleme(?string $nouveau = null): ?string
{
    static $dernier = null;
    if ($nouveau !== null) {
        $dernier = $nouveau;
    }
    return $dernier;
}

/**
 * Bloc « 🔔 Être prévenu » (activé par assets/js/notifications.js) : le vendeur autorise les notifications sur son téléphone.
 * $grand : version à grand bouton du mode simple.
 */
function push_bloc(bool $grand = false): string
{
    if (!push_disponible()) {
        return '';
    }
    try {
        $cle = push_cle_site()['publique'];
    } catch (Throwable $e) {
        error_log('Jënd — clé des notifications : ' . $e->getMessage());
        return '';
    }
    global $scripts_extra;                      // assets/js/notifications.js chargé seulement quand le bloc est affiché
    $scripts_extra = array_values(array_unique(array_merge($scripts_extra ?? [], ['js/notifications.js'])));
    return '<section class="push-bloc' . ($grand ? ' push-bloc-grand' : '') . '" data-push="' . e($cle) . '" data-csrf="' . e(csrf_token()) . '" hidden>'
        . '<div class="push-off"><i class="ph-fill ph-bell-ringing"></i><span><b>Être prévenu des commandes</b><small>Votre téléphone sonne à chaque nouvelle commande, même si Jënd est fermé.</small></span>'
        . '<button type="button" class="btn btn-primaire" data-push-activer><i class="ph-fill ph-bell"></i> Activer</button></div>'
        . '<div class="push-on" hidden><i class="ph-fill ph-check-circle"></i><span><b>Notifications activées</b><small>sur ce téléphone</small></span>'
        . '<button type="button" class="btn btn-contour" data-push-tester><i class="ph ph-speaker-high"></i> Tester</button></div>'
        . '<p class="push-info" data-push-info hidden></p>'
        . '</section>';
}
