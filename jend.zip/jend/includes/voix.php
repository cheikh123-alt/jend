<?php
declare(strict_types=1);

/**
 * Description vocale d'un produit : le vendeur enregistre quelques secondes (en wolof, en français…) ou envoie un message vocal.
 * Le format est reconnu par le contenu du fichier (jamais par son nom), et le fichier reçoit un nom aléatoire dans uploads/voix/.
 */

const VOIX_TAILLE_MAX = 3 * 1024 * 1024;        // ~ 1 à 3 minutes selon le format
const VOIX_DOSSIER = 'uploads/voix';

/** Format audio d'après les premiers octets, ou null. */
function voix_format(string $debut): ?string
{
    if (strncmp($debut, "\x1A\x45\xDF\xA3", 4) === 0) {
        return 'webm';                                    // enregistrement Chrome / Android
    }
    if (strncmp($debut, 'OggS', 4) === 0) {
        return 'ogg';                                     // message vocal WhatsApp (opus), Firefox
    }
    if (substr($debut, 4, 4) === 'ftyp') {
        return 'm4a';                                     // enregistrement iPhone / Safari
    }
    if (strncmp($debut, 'ID3', 3) === 0 || (strlen($debut) > 1 && ord($debut[0]) === 0xFF && (ord($debut[1]) & 0xE0) === 0xE0)) {
        return 'mp3';
    }
    return null;
}

/** Enregistre un fichier audio envoyé. @throws RuntimeException message affichable @return string chemin relatif */
function voix_enregistrer(array $f): string
{
    if (($f['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK || !is_uploaded_file((string) $f['tmp_name'])) {
        throw new RuntimeException(($f['error'] ?? 0) === UPLOAD_ERR_INI_SIZE ? 'Enregistrement trop lourd (3 Mo maximum, soit environ 1 minute).' : 'L\'enregistrement n\'a pas pu être envoyé, réessayez.');
    }
    if ((int) $f['size'] < 1000 || (int) $f['size'] > VOIX_TAILLE_MAX) {
        throw new RuntimeException('Enregistrement trop court ou trop lourd (3 Mo maximum, soit environ 1 minute).');
    }
    $format = voix_format((string) file_get_contents((string) $f['tmp_name'], false, null, 0, 16));
    if ($format === null) {
        throw new RuntimeException('Format audio non reconnu : enregistrez directement depuis la page, ou envoyez un message vocal (.ogg, .m4a, .mp3).');
    }
    $dossier = dirname(__DIR__) . '/' . VOIX_DOSSIER;
    if (!is_dir($dossier) && !mkdir($dossier, 0755, true)) {
        throw new RuntimeException('Enregistrement impossible pour le moment.');
    }
    $chemin = VOIX_DOSSIER . '/' . bin2hex(random_bytes(16)) . '.' . $format;
    if (!move_uploaded_file((string) $f['tmp_name'], dirname(__DIR__) . '/' . $chemin)) {
        throw new RuntimeException('Enregistrement impossible pour le moment.');
    }
    @chmod(dirname(__DIR__) . '/' . $chemin, 0644);
    return $chemin;
}

/** Supprime un fichier audio (uniquement dans uploads/voix/). */
function voix_supprimer(?string $chemin): void
{
    if ($chemin && preg_match('#^uploads/voix/[a-f0-9]{32}\.(webm|ogg|m4a|mp3)$#', $chemin)) {
        @unlink(dirname(__DIR__) . '/' . $chemin);
    }
}

/** Type MIME pour la balise <audio>. */
function voix_type(string $chemin): string
{
    return ['webm' => 'audio/webm', 'ogg' => 'audio/ogg', 'm4a' => 'audio/mp4', 'mp3' => 'audio/mpeg'][pathinfo($chemin, PATHINFO_EXTENSION)] ?? 'audio/mpeg';
}
