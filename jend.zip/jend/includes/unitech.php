<?php
declare(strict_types=1);

/**
 * Paiement UnitechPay (https://pay.unitech.sn) : Wave et Orange Money (Max It) au Sénégal. Pas de carte ni de Free Money :
 * pour ces moyens, le site passe au prestataire suivant (PayDunya, PayTech) s'il est configuré.
 *
 * Fonctionnement (documentation UnitechPay v1.2.0) :
 *  - création : POST https://api.unitech.sn/api.php?action=create_wave_payment (ou create_orange_maxit / create_orange_om),
 *    en-tête « Authorization: Bearer <clé API> », avec le montant et le numéro Wave / Orange Money du CLIENT ;
 *    réponse : référence générée par UnitechPay + adresse de paiement (lien Wave, ou lien vers l'application Max It / OM) ;
 *  - confirmation : uniquement par le webhook (adresse unique, enregistrée chez UnitechPay : bouton dans Administration → Paramètres),
 *    signé HMAC-SHA256 avec la clé API : sur le corps brut (en-tête X-UnitechPay-Signature) ou sur
 *    « event|reference|amount|status|signed_at » (champ signature). Le montant et la référence sont revérifiés (paiement_appliquer).
 *
 * Réglages (config.env) : UNITECH_API_KEY (jamais dans le code), UNITECH_ORANGE=maxit|om (application Orange ouverte, maxit par défaut).
 * ⚠ Pas de mode test documenté : chaque essai est un vrai paiement.
 */

const UNITECH_ACTIONS = ['wave' => 'create_wave_payment', 'orange_money' => 'create_orange_maxit'];

function unitech_configure(): bool
{
    return (string) env('UNITECH_API_KEY', '') !== '';
}

function unitech_actif(): bool
{
    return in_array('unitech', prestataires_actifs(), true);
}

/** Adresse de l'API. UNITECH_API_BASE (faux serveur des tests) n'est lu qu'en développement. */
function unitech_base(): string
{
    $autre = (string) env('UNITECH_API_BASE', '');
    if ($autre !== '' && env('APP_ENV', 'prod') === 'dev') {
        return rtrim($autre, '/');
    }
    return 'https://api.unitech.sn/api.php';
}

/**
 * Appel de l'API UnitechPay depuis le serveur (la clé ne passe jamais par le navigateur).
 * @throws RuntimeException message sûr (jamais la clé)
 */
function unitech_requete(string $action, ?array $corps = null): array
{
    if (!unitech_configure()) {
        throw new RuntimeException('UnitechPay n\'est pas configuré (UNITECH_API_KEY manquant dans config.env).');
    }
    $url = unitech_base() . '?action=' . rawurlencode($action);
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_CUSTOMREQUEST => $corps === null ? 'GET' : 'POST', CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 20, CURLOPT_CONNECTTIMEOUT => 8,
        CURLOPT_FOLLOWLOCATION => false,
        CURLOPT_PROTOCOLS => str_starts_with($url, 'http://') ? (CURLPROTO_HTTP | CURLPROTO_HTTPS) : CURLPROTO_HTTPS,
        CURLOPT_HTTPHEADER => ['Accept: application/json', 'Content-Type: application/json', 'Authorization: Bearer ' . env('UNITECH_API_KEY')],
    ] + ($corps !== null ? [CURLOPT_POSTFIELDS => json_encode($corps, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)] : []));
    $reponse = curl_exec($ch);
    $code = (int) curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
    curl_close($ch);
    if ($reponse === false || $code === 0) {
        error_log('Jënd — UnitechPay injoignable (' . $action . ')');
        throw new RuntimeException('serveur UnitechPay injoignable depuis cet hébergement (connexion sortante bloquée ?)');
    }
    $data = json_decode((string) $reponse, true);
    if (!is_array($data)) {
        error_log('Jënd — UnitechPay : réponse illisible (HTTP ' . $code . ')');
        throw new RuntimeException('réponse illisible de UnitechPay (HTTP ' . $code . ')');
    }
    if (($data['success'] ?? false) !== true) {
        $msg = mb_substr(strip_tags((string) ($data['message'] ?? '')), 0, 120);
        error_log('Jënd — UnitechPay a refusé « ' . $action . ' » (HTTP ' . $code . ')');
        throw new RuntimeException('demande refusée par UnitechPay (HTTP ' . $code . ($msg !== '' ? ' : ' . $msg : '') . ')' . ($code === 401 ? ' — clé API à vérifier' : ''));
    }
    return $data;
}

/** Numéro Wave / Orange Money du client qui paie (9 chiffres, sans 221) : celui de son compte, sinon celui de la livraison (pas pour un cadeau). */
function unitech_numero_client(array $commande): ?string
{
    $candidats = [(string) requete('SELECT telephone FROM users WHERE id = ?', [$commande['client_id']])->fetchColumn()];
    if ((int) ($commande['cadeau'] ?? 0) !== 1) {
        $candidats[] = (string) ($commande['livraison_telephone'] ?? '');       // pour un cadeau, c'est le numéro du proche, pas du payeur
    }
    foreach ($candidats as $t) {
        $v = $t !== '' ? telephone_valide($t) : null;
        if ($v) {
            return substr($v, -9);
        }
    }
    return null;
}

/** Demande de paiement UnitechPay (total ou acompte) ; renvoie l'adresse de paiement (lien Wave ou application Orange). */
function unitech_initier(array $commande): string
{
    $methode = (string) commande_methode_en_ligne($commande);
    $action = UNITECH_ACTIONS[$methode] ?? null;
    if ($action === null) {
        throw new RuntimeException('moyen de paiement non proposé par UnitechPay (Wave et Orange Money seulement)');
    }
    if ($methode === 'orange_money' && strtolower((string) env('UNITECH_ORANGE', 'maxit')) === 'om') {
        $action = 'create_orange_om';
    }
    $numero = unitech_numero_client($commande);
    if ($numero === null) {
        throw new RuntimeException('numéro Wave / Orange Money du client inconnu (téléphone du compte à renseigner)');
    }
    $montant = commande_a_payer($commande);
    $ref = (string) $commande['reference'];
    $retour = app_url('paiement/retour/' . $ref);
    $rep = unitech_requete($action, [
        'amount' => $montant,
        'customer_number' => $numero,
        'description' => 'Jënd — commande ' . $ref . (commande_a_acompte($commande) ? ' (acompte)' : ''),
        'callback_success' => $retour,
        'callback_cancel' => $retour,
    ]);
    $d = is_array($rep['data'] ?? null) ? $rep['data'] : [];
    $reference = (string) ($d['reference'] ?? '');
    $page = (string) ($d['payment_url'] ?? '');
    if (!preg_match('/^[A-Za-z0-9_.:-]{4,100}$/', $reference)) {
        throw new RuntimeException('réponse de UnitechPay sans référence de paiement');
    }
    if ((int) ($d['amount'] ?? $montant) !== $montant) {
        throw new RuntimeException('montant de UnitechPay différent de la commande');
    }
    // Lien https (Wave…) ou lien vers une application (Max It / Orange Money) ; jamais javascript:, data:, etc.
    $schema = strtolower((string) parse_url($page, PHP_URL_SCHEME));
    if ($page === '' || in_array($schema, ['', 'javascript', 'data', 'vbscript', 'file', 'http'], true) && !(env('APP_ENV', 'prod') === 'dev' && env('UNITECH_API_BASE', '') !== '' && str_starts_with($page, 'http://127.0.0.1'))) {
        throw new RuntimeException('adresse de paiement UnitechPay invalide');
    }

    $pdo = pdo();
    $pdo->beginTransaction();
    try {
        requete("UPDATE paiements SET statut = 'echoue' WHERE commande_id = ? AND statut = 'initie' AND reference_externe IS NOT NULL", [$commande['id']]);
        $reutilise = requete(
            "UPDATE paiements SET fournisseur = 'unitech', reference_externe = ?, methode = ?, montant = ? WHERE commande_id = ? AND statut = 'initie' AND reference_externe IS NULL LIMIT 1",
            [$reference, $methode, $montant, $commande['id']]
        )->rowCount();
        if ($reutilise === 0) {
            requete("INSERT INTO paiements (commande_id, methode, montant, statut, fournisseur, reference_externe) VALUES (?, ?, ?, 'initie', 'unitech', ?)",
                [$commande['id'], $methode, $montant, $reference]);
        }
        $pdo->commit();
    } catch (Throwable $e) {
        $pdo->rollBack();
        throw $e;
    }
    return $page;
}

/** Est-ce une notification UnitechPay ? (JSON avec « event » et « reference », ou en-tête de signature UnitechPay) */
function unitech_est_notification(array $d): bool
{
    return (isset($d['event'], $d['reference']) && is_string($d['event'])) || !empty($_SERVER['HTTP_X_UNITECHPAY_SIGNATURE']);
}

/**
 * Webhook UnitechPay. Retourne [code HTTP, message].
 * Signature HMAC-SHA256 (clé API) valide sur le corps brut OU sur « event|reference|amount|status|signed_at », puis
 * paiement connu et lié à UnitechPay, montant identique (paiement_appliquer). Rejouer une notification n'a aucun effet.
 */
function unitech_notification(string $brut, array $d, string $enteteSignature): array
{
    if (!unitech_configure()) {
        return [400, 'UnitechPay non configuré'];
    }
    $cle = (string) env('UNITECH_API_KEY');
    $okEntete = $enteteSignature !== '' && hash_equals(hash_hmac('sha256', $brut, $cle), strtolower(trim($enteteSignature)));
    $chaine = implode('|', [(string) ($d['event'] ?? ''), (string) ($d['reference'] ?? ''), (string) ($d['amount'] ?? ''), (string) ($d['status'] ?? ''), (string) ($d['signed_at'] ?? '')]);
    $okCorps = is_string($d['signature'] ?? null) && $d['signature'] !== '' && hash_equals(hash_hmac('sha256', $chaine, $cle), strtolower($d['signature']));
    if (!$okEntete && !$okCorps) {
        error_log('Jënd — webhook UnitechPay : signature invalide ou absente');
        return [401, 'Signature invalide'];
    }
    $statut = match ((string) ($d['event'] ?? '')) {
        'payment_completed' => 'reussi',
        'payment_failed', 'payment_expired' => 'echoue',
        default => null,
    };
    if ($statut === null) {
        return [200, 'Ignoré'];                                  // retraits, autres événements
    }
    $reference = (string) $d['reference'];
    $p = requete('SELECT fournisseur FROM paiements WHERE reference_externe = ?', [$reference])->fetchColumn();
    if ($p !== 'unitech') {
        return [404, 'Paiement inconnu'];
    }
    if (!is_int($d['amount'] ?? null) && !(is_string($d['amount'] ?? null) && ctype_digit($d['amount']))) {
        return [400, 'Montant illisible'];
    }
    $trace = json_encode(array_diff_key($d, array_flip(['signature'])), JSON_UNESCAPED_UNICODE) ?: '{}';
    return paiement_appliquer($reference, $statut, (int) $d['amount'], $trace);
}

/** Enregistre l'adresse de notification du site chez UnitechPay (Administration → Paramètres). @throws RuntimeException */
function unitech_configurer_webhook(): void
{
    unitech_requete('configure_webhook', ['webhook_url' => app_url('paiement/webhook'), 'events' => ['payment_completed', 'payment_failed', 'payment_expired']]);
}
