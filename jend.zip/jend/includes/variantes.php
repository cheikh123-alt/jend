<?php
declare(strict_types=1);

/**
 * Tailles et pointures. L'administrateur indique quelles catégories s'y prêtent (Administration → Catégories) ;
 * le vendeur coche alors les tailles disponibles pour son produit, chacune avec son stock ; le client doit en choisir une.
 * Le stock du produit est toujours la somme des stocks de ses tailles (le reste du site n'a pas à s'en soucier).
 *
 * Dans le panier, un article est rangé sous la clé « 12 » (produit sans taille) ou « 12:34 » (produit 12, taille 34).
 */

const OPTIONS_PRODUIT = [
    'taille'        => ['Taille', ['XS', 'S', 'M', 'L', 'XL', 'XXL', '3XL', '4XL']],
    'pointure'      => ['Pointure', ['35', '36', '37', '38', '39', '40', '41', '42', '43', '44', '45', '46', '47']],
    'taille_enfant' => ['Taille', ['0-3 mois', '3-6 mois', '6-12 mois', '1 an', '2 ans', '3 ans', '4 ans', '5 ans', '6 ans', '8 ans', '10 ans', '12 ans', '14 ans']],
];
const VARIANTES_MAX = 25;

/** Type de taille proposé pour une catégorie (le sien, sinon celui de la catégorie parente), ou null. */
function categorie_option(int $categorieId): ?string
{
    $r = requete('SELECT c.option_type, p.option_type AS parent FROM categories c LEFT JOIN categories p ON p.id = c.parent_id WHERE c.id = ?', [$categorieId])->fetch();
    $type = $r ? ($r['option_type'] ?: $r['parent']) : null;
    return isset(OPTIONS_PRODUIT[$type]) ? $type : null;
}

/** Libellé du choix : « Taille », « Pointure ». */
function option_libelle(?string $type): string
{
    return OPTIONS_PRODUIT[$type][0] ?? 'Taille';
}

/** Tailles d'un produit, dans l'ordre. */
function variantes_produit(int $produitId): array
{
    return requete('SELECT id, libelle, stock FROM produit_variantes WHERE produit_id = ? ORDER BY position, id', [$produitId])->fetchAll();
}

/**
 * Enregistre les tailles d'un produit (remplace la liste) et recalcule son stock.
 * @param array $lignes [libellé => stock] ; vide : le produit n'a plus de tailles. @throws RuntimeException
 */
function variantes_enregistrer(int $produitId, ?string $type, array $lignes): void
{
    $propres = [];
    foreach ($lignes as $libelle => $stock) {
        $libelle = trim(preg_replace('/\s+/u', ' ', (string) $libelle));
        if ($libelle === '') {
            continue;
        }
        if (mb_strlen($libelle) > 20) {
            throw new RuntimeException('Une taille est trop longue (20 caractères maximum) : « ' . mb_substr($libelle, 0, 25) . ' ».');
        }
        if (!ctype_digit((string) $stock) || (int) $stock > 100000) {
            throw new RuntimeException('Stock invalide pour la taille « ' . $libelle . ' ».');
        }
        $propres[$libelle] = (int) $stock;
    }
    if (count($propres) > VARIANTES_MAX) {
        throw new RuntimeException('Maximum ' . VARIANTES_MAX . ' tailles par produit.');
    }
    if ($propres && !isset(OPTIONS_PRODUIT[$type])) {
        throw new RuntimeException('Cette catégorie ne propose pas de tailles.');
    }
    $existantes = [];
    foreach (variantes_produit($produitId) as $v) {
        $existantes[mb_strtolower((string) $v['libelle'])] = (int) $v['id'];
    }
    $gardees = [];
    $pos = 0;
    foreach ($propres as $libelle => $stock) {
        $libelle = (string) $libelle;                // « 40 » devient un entier comme clé de tableau
        $cle = mb_strtolower($libelle);
        if (isset($existantes[$cle])) {
            requete('UPDATE produit_variantes SET libelle = ?, stock = ?, position = ? WHERE id = ?', [$libelle, $stock, $pos, $existantes[$cle]]);
            $gardees[] = $existantes[$cle];
        } else {
            requete('INSERT INTO produit_variantes (produit_id, libelle, stock, position) VALUES (?, ?, ?, ?)', [$produitId, $libelle, $stock, $pos]);
            $gardees[] = (int) pdo()->lastInsertId();
        }
        $pos++;
    }
    $aRetirer = array_diff(array_values($existantes), $gardees);
    if ($aRetirer) {
        requete('DELETE FROM produit_variantes WHERE produit_id = ? AND id IN (' . implode(',', array_map('intval', $aRetirer)) . ')', [$produitId]);
    }
    if ($propres) {
        requete('UPDATE produits SET option_type = ?, stock = (SELECT COALESCE(SUM(stock), 0) FROM produit_variantes WHERE produit_id = ?) WHERE id = ?', [$type, $produitId, $produitId]);
    } else {
        requete('UPDATE produits SET option_type = NULL WHERE id = ?', [$produitId]);
    }
}

/** Clé d'un article dans le panier. */
function panier_cle(int $produitId, ?int $varianteId = null): string
{
    return $varianteId ? $produitId . ':' . $varianteId : (string) $produitId;
}

/** « 12:34 » → [12, 34] ; « 12 » → [12, null]. */
function panier_cle_lire(int|string $cle): array
{
    $parts = explode(':', (string) $cle, 2);
    return [(int) $parts[0], isset($parts[1]) && ctype_digit($parts[1]) ? (int) $parts[1] : null];
}

/**
 * Remet en stock les produits et les tailles des lignes de commande qui correspondent à la condition (annulation, expiration, retour).
 * Les quantités sont d'abord additionnées par produit : une commande peut contenir le même produit en plusieurs tailles,
 * et une mise à jour avec jointure ne modifierait chaque produit qu'une seule fois.
 * @param string $condition clause SQL sur cl / cb, ex. « cb.commande_id = ? »
 */
function stock_restituer(string $condition, array $params): void
{
    requete('UPDATE produits p JOIN (SELECT cl.produit_id, SUM(cl.quantite) AS q FROM commande_lignes cl JOIN commande_boutiques cb ON cb.id = cl.commande_boutique_id
                WHERE ' . $condition . ' GROUP BY cl.produit_id) t ON t.produit_id = p.id SET p.stock = p.stock + t.q', $params);
    requete('UPDATE produit_variantes v JOIN (SELECT cl.variante_id, SUM(cl.quantite) AS q FROM commande_lignes cl JOIN commande_boutiques cb ON cb.id = cl.commande_boutique_id
                WHERE cl.variante_id IS NOT NULL AND ' . $condition . ' GROUP BY cl.variante_id) t ON t.variante_id = v.id SET v.stock = v.stock + t.q', $params);
}
