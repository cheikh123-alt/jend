<?php
declare(strict_types=1);

/**
 * Contenu juridique et informatif du site (CGU, CGV, conditions vendeur, confidentialité, mentions légales...).
 *
 * Les informations de l'exploitant viennent du fichier .env (SOCIETE_*). Tant qu'elles ne sont pas renseignées,
 * les pages affichent « [À COMPLÉTER : ...] » et le vérificateur de production le signale.
 * Ces textes sont un modèle solide mais GÉNÉRIQUE : faites-les relire par un juriste sénégalais avant l'ouverture au public.
 */

const LEGAL_VERSION = '1.7';
const LEGAL_DATE = '2026-10-18';

/** Champs de l'exploitant : clé => [variable .env, libellé]. */
function societe_champs(): array
{
    return [
        'nom'        => ['SOCIETE_NOM', 'dénomination de l\'exploitant'],
        'forme'      => ['SOCIETE_FORME', 'forme juridique (ex : SARL, entreprise individuelle)'],
        'capital'    => ['SOCIETE_CAPITAL', 'capital social (ou « sans objet »)'],
        'adresse'    => ['SOCIETE_ADRESSE', 'adresse du siège'],
        'ninea'      => ['SOCIETE_NINEA', 'numéro NINEA'],
        'rccm'       => ['SOCIETE_RCCM', 'numéro RCCM'],
        'telephone'  => ['SOCIETE_TEL', 'téléphone / WhatsApp de contact'],
        'email'      => ['CONTACT_EMAIL', 'e-mail de contact'],
        'directeur'  => ['SOCIETE_DIRECTEUR', 'directeur de la publication'],
        'hebergeur'  => ['HEBERGEUR', 'nom et adresse de l\'hébergeur du site'],
    ];
}

/** Valeur d'un champ de l'exploitant, ou un repère visible « À COMPLÉTER » s'il manque. */
function societe(string $cle): string
{
    $c = societe_champs()[$cle];
    $v = trim((string) env($c[0], ''));
    return $v !== '' ? $v : '[À COMPLÉTER : ' . $c[1] . ']';
}

/** Liste des champs de l'exploitant encore vides (pour le vérificateur de production). */
function societe_manquants(): array
{
    $m = [];
    foreach (societe_champs() as [$var, $libelle]) {
        if (trim((string) env($var, '')) === '') {
            $m[] = $var;
        }
    }
    return $m;
}

/** Documents disponibles : URL => [titre, titre court du pied de page]. */
function documents_legaux(): array
{
    return [
        'cgu'               => 'Conditions générales d\'utilisation',
        'cgv'               => 'Conditions générales de vente',
        'conditions-vendeur'=> 'Conditions générales des vendeurs',
        'livraison-retours' => 'Livraison, annulation et retours',
        'confidentialite'   => 'Politique de confidentialité',
        'mentions-legales'  => 'Mentions légales',
        'a-propos'          => 'À propos de Jënd',
        'contact'           => 'Aide et contact',
        'frais-commissions' => 'Frais et commissions',
        'paiements-vendeurs' => 'Paiements et reversements',
    ];
}

/** Où livrent les vendeurs : une rubrique par ville, avec les boutiques qui y livrent et les frais de chaque zone (lu en base). */
function tableau_livraison_boutiques(): string
{
    $html = '';
    $vides = [];
    foreach (regions_desservies() as $region => $r) {
        $nb = count($r['boutiques']);
        if ($nb === 0) {
            $vides[] = e($region);
            continue;
        }
        $frais = $r['frais_min'] === $r['frais_max'] ? e(fcfa($r['frais_min'])) : 'de ' . e(fcfa($r['frais_min'])) . ' à ' . e(fcfa($r['frais_max']));
        $delai = $r['delai_min'] === $r['delai_max'] ? $r['delai_min'] . ' jour(s)' : $r['delai_min'] . ' à ' . $r['delai_max'] . ' jours';
        $propres = frais_boutiques(array_map(fn ($b) => $b[2], array_slice($r['boutiques'], 0, 12)));
        $noms = array_map(function ($b) use ($r, $propres) {
            $f = array_map(fn ($z) => frais_livraison($b[2], $z, false, $propres)['frais'], $r['zones']);
            $fourchette = min($f) === max($f) ? fcfa(min($f)) : fcfa(min($f)) . ' à ' . fcfa(max($f));
            return '<a class="lien" href="@@boutique/' . e($b[1]) . '@@">' . e($b[0]) . '</a> <small class="doux">(' . e($fourchette) . ')</small>';
        }, array_slice($r['boutiques'], 0, 12));
        $reste = $nb > 12 ? ' et ' . ($nb - 12) . ' autre(s)' : '';
        $lignes = '';
        foreach ($r['zones'] as $z) {
            $lignes .= '<tr><td>' . e($z['nom']) . '</td><td>' . e(fcfa((int) $z['frais'])) . '</td><td>' . (int) $z['delai_jours'] . ' jour(s)</td></tr>';
        }
        $html .= '<details class="region-livraison"' . ($html === '' ? ' open' : '') . '><summary><b>' . e($region) . '</b><span>' . $nb . ' boutique' . ($nb > 1 ? 's' : '') . ' · frais de référence ' . $frais . ' · ' . $delai . '</span></summary>'
               . '<p><b>Boutiques qui livrent ici</b> <small class="doux">(et leurs frais dans cette ville)</small> : ' . implode(', ', $noms) . $reste . '</p>'
               . '<div class="table-defile"><table class="table"><thead><tr><th>Zone</th><th>Frais de référence</th><th>Délai indicatif</th></tr></thead><tbody>' . $lignes . '</tbody></table></div></details>';
    }
    if ($html === '') {
        $html = '<p class="doux">Aucune boutique n\'est encore ouverte : les zones de livraison s\'afficheront ici dès l\'arrivée des premiers vendeurs.</p>';
    }
    if ($vides) {
        $html .= '<p class="doux petit">Pas encore de boutique qui livre à : ' . implode(', ', $vides) . '.</p>';
    }
    return $html;
}

/** Tableau des zones de livraison (lu en base pour rester toujours exact). */
function tableau_zones_livraison(): string
{
    $lignes = '';
    foreach (zones_par_ville(requete('SELECT nom, region, frais, delai_jours FROM zones_livraison WHERE actif = 1 ORDER BY region, frais, nom')->fetchAll()) as $ville => $zones) {
        foreach ($zones as $z) {
            $lignes .= '<tr><td>' . e($ville) . '</td><td>' . e($z['nom']) . '</td><td>' . e(fcfa((int) $z['frais'])) . '</td><td>' . (int) $z['delai_jours'] . ' jour(s)</td></tr>';
        }
    }
    return '<div class="table-defile"><table class="table"><thead><tr><th>Ville / région</th><th>Zone</th><th>Frais</th><th>Délai indicatif</th></tr></thead><tbody>' . $lignes . '</tbody></table></div>';
}

/** Renvoie le contenu HTML (déjà échappé) d'un document. */
function contenu_document_brut(string $doc): string
{
    $n = e(societe('nom'));
    $email = e(societe('email'));
    $tel = e(societe('telephone'));
    $commission = e(commission_texte());
    $offre = commission_defaut() == 0.0;
    $lancement = function_exists('offre_lancement') && offre_lancement();      // taux réduit présenté comme une offre de lancement
    $phraseCommission = $offre
        ? "<b>Offre de lancement : 0 % de commission.</b> Au lancement, la commission est de 0 % : vous gardez 100 % du prix de vos ventes. Jënd pourra introduire ou modifier une commission plus tard ; vous en serez prévenu par e-mail <b>au moins 30 jours avant</b> son entrée en vigueur, et elle ne s'appliquera qu'aux commandes passées après la date annoncée. Vous pourrez alors fermer votre boutique si vous refusez."
        : ($lancement
            ? "<b>Offre de lancement : seulement $commission % de commission.</b> Jënd démarre : pour accueillir les premiers vendeurs, la commission est réduite à $commission % du prix des produits d'une commande <b>livrée et payée</b>. Ce taux pourra évoluer quand le site aura grandi ; vous en serez prévenu par e-mail <b>au moins 30 jours avant</b>, et le nouveau taux ne s'appliquera qu'aux commandes passées après la date annoncée. Vous pourrez alors fermer votre boutique si vous le refusez."
            : "Jënd prélève une <b>commission de $commission %</b> (taux de votre boutique, modifiable avec un préavis de 30 jours) sur le prix des produits d'une commande <b>livrée et payée</b>.");
    $tauxExemple = $offre ? 5.0 : commission_defaut();                 // en période sans commission : exemple chiffré avec un taux FICTIF
    $exCommission = (int) round(20000 * $tauxExemple / 100);
    $exemple = 'Exemple' . ($offre ? ' (taux fictif, pour illustrer)' : '') . ' : vous vendez un pagne à ' . fcfa(20000) . '. Avec ' . commission_texte($tauxExemple) . ' % de commission : ' . fcfa($exCommission) . ' retenus, vous recevez ' . fcfa(20000 - $exCommission) . '.' . ($offre ? ' Aujourd\'hui (0 %), vous recevez ' . fcfa(20000) . '.' : '');
    $retraitMin = e(fcfa(RETRAIT_MINIMUM));
    $jr = function_exists('delai_retrait_jours') ? delai_retrait_jours() : 3;
    $jourRev = function_exists('parametre') ? trim((string) parametre('jour_reversement', '')) : '';
    $quandRev = in_array($jourRev, ['lundi', 'mardi', 'mercredi', 'jeudi', 'vendredi'], true) ? 'chaque <b>' . $jourRev . '</b>' : 'dans les meilleurs délais, après vérification';
    $tauxPd = function_exists('parametre') ? trim((string) parametre('paydunya_taux_indicatif', '')) : '';
    // Prestataire(s) de paiement réellement en service : PayDunya, PayTech, ou les deux (Administration → Paramètres)
    $prestActifs = (function_exists('prestataires_actifs') ? prestataires_actifs() : []) ?: ['paydunya'];     // site de test (paiement simulé) : le prestataire prévu
    $nomsPrest = defined('PRESTATAIRES') ? PRESTATAIRES : ['paydunya' => 'PayDunya', 'paytech' => 'PayTech', 'unitech' => 'UnitechPay'];     // ce fichier peut être chargé seul (scripts, tests)
    $nomsListe = array_map(fn ($p) => $nomsPrest[$p] ?? $p, $prestActifs);
    $prestNoms = count($nomsListe) > 1 ? implode(', ', array_slice($nomsListe, 0, -1)) . ' et ' . end($nomsListe) : implode('', $nomsListe);
    $prestPluriel = count($prestActifs) > 1;
    $prestS = $prestPluriel ? 's' : '';
    $prestOnt = $prestPluriel ? 'ont leurs' : 'a ses';
    $prestPreleve = $prestPluriel ? 'prélèvent' : 'prélève';
    $delaisPd = in_array('paydunya', $prestActifs, true) ? ' Les conditions de PayDunya indiquent aussi des délais de retrait pouvant aller jusqu\'à 24 heures pour le mobile money.' : '';
    if (!in_array('paydunya', $prestActifs, true)) {
        $tauxPdHtml = 'Leurs taux exacts et à jour sont publiés sur leur site.';          // le taux indicatif saisi par l'admin concerne PayDunya
    }
    $grilles = ['paydunya' => '<a class="lien" href="https://paydunya.com/service-fees" target="_blank" rel="noopener noreferrer">grille PayDunya</a>',
                'paytech'  => '<a class="lien" href="https://paytech.sn/#plans" target="_blank" rel="noopener noreferrer">grille PayTech</a>',
                'unitech'  => '<a class="lien" href="https://pay.unitech.sn" target="_blank" rel="noopener noreferrer">grille UnitechPay</a>'];
    $grillesHtml = $prestActifs ? implode(' · ', array_map(fn ($p) => $grilles[$p], $prestActifs)) : '';
    $conditionsPrest = ['paydunya' => '<a class="lien" href="https://paydunya.com/terms-of-service" target="_blank" rel="noopener noreferrer">conditions de PayDunya</a>',
                        'paytech'  => '<a class="lien" href="https://paytech.sn" target="_blank" rel="noopener noreferrer">conditions de PayTech</a>',
                        'unitech'  => '<a class="lien" href="https://pay.unitech.sn" target="_blank" rel="noopener noreferrer">site de UnitechPay</a>'];
    $conditionsHtml = $prestActifs ? implode(' · ', array_map(fn ($p) => $conditionsPrest[$p], $prestActifs)) : '';
    $tauxPdHtml = $tauxPd !== '' ? 'Taux indiqués à Jënd par PayDunya, <b>à titre indicatif</b> : ' . e($tauxPd) . ' (à vérifier sur leur grille officielle).' : 'Leurs taux exacts et à jour sont publiés sur leur site.';
    $delaiRetrait = $jr === 0 ? 'immédiatement' : $jr . ' jour' . ($jr > 1 ? 's' : '');
    // Versements à date fixe (Paramètres → jour de reversement) : engagement affiché aux vendeurs
    $phraseVersement = in_array($jourRev, ['lundi', 'mardi', 'mercredi', 'jeudi', 'vendredi'], true)
        ? "<b>Chaque $jourRev, votre solde disponible vous est versé automatiquement</b> (dès $retraitMin) sur votre numéro Wave ou Orange Money. Vous recevez un e-mail avec le montant et la <b>référence du transfert</b>. Entre deux versements, vous pouvez aussi demander un retrait vous-même."
        : "Vous demandez un retrait (minimum $retraitMin) vers votre numéro Wave ou Orange Money. Jënd l'envoie $quandRev et vous prévient par e-mail avec la référence du transfert.";
    $maj = '<p class="doux">Version ' . LEGAL_VERSION . ' — dernière mise à jour : ' . e(date('d/m/Y', strtotime(LEGAL_DATE))) . '.</p>';

    switch ($doc) {
        case 'cgu':
            return $maj . <<<HTML
<h2>1. Objet</h2>
<p>Jënd est une place de marché en ligne exploitée par $n (« Jënd »). Elle met en relation des vendeurs indépendants et des acheteurs au Sénégal. Les présentes conditions encadrent l'utilisation du site. En créant un compte ou en utilisant le site, vous les acceptez.</p>
<h2>2. Rôle de Jënd</h2>
<p>Jënd fournit la plateforme technique, encaisse le paiement, organise le suivi de la commande et verse ensuite le produit de la vente au vendeur. <b>Le contrat de vente est conclu entre l'acheteur et le vendeur</b> ; Jënd n'est pas le vendeur des produits, sauf mention contraire. Jënd intervient comme intermédiaire de paiement et de confiance.</p>
<h2>3. Compte</h2>
<ul>
<li>Vous devez avoir 18 ans révolus, ou l'accord d'un représentant légal.</li>
<li>Les informations fournies doivent être exactes et tenues à jour. Un compte est personnel.</li>
<li>Vous êtes responsable de la confidentialité de votre mot de passe. Prévenez-nous sans délai en cas de suspicion d'accès non autorisé.</li>
<li>Jënd peut suspendre ou fermer un compte en cas de fraude, d'usurpation d'identité, de non-respect des présentes conditions ou de comportement abusif.</li>
</ul>
<h2>4. Comportements interdits</h2>
<ul>
<li>Publier ou vendre des produits illicites, contrefaits, dangereux ou interdits (voir les conditions des vendeurs).</li>
<li>Tenter de contourner la plateforme, notamment pour conclure ou payer une vente hors de Jënd après un contact établi sur le site.</li>
<li>Usurper une identité, publier de faux avis, manipuler les notes ou les prix.</li>
<li>Perturber le fonctionnement du site : attaques, extraction automatisée massive, tentative d'accès aux comptes d'autrui.</li>
</ul>
<h2>5. Avis</h2>
<p>Seuls les acheteurs d'un produit livré peuvent le noter. Les avis doivent être sincères, respectueux et ne contenir ni données personnelles ni propos injurieux ou discriminatoires. Jënd peut retirer un avis contraire à ces règles.</p>
<h2>6. Propriété intellectuelle</h2>
<p>La marque Jënd, le logo, le design et le code du site sont protégés. Les vendeurs restent propriétaires de leurs photos et descriptions et accordent à Jënd le droit de les afficher sur le site pour la promotion de leurs produits.</p>
<h2>7. Responsabilité</h2>
<p>Jënd s'efforce d'assurer la disponibilité du site mais ne peut garantir un accès sans interruption. Jënd n'est pas responsable de la description fournie par les vendeurs ni des dommages indirects, dans les limites permises par la loi. Rien dans ces conditions ne limite les droits que la loi reconnaît aux consommateurs.</p>
<h2>8. Modification des conditions</h2>
<p>Jënd peut modifier ces conditions ; la version applicable est celle publiée au moment de votre action. En cas de changement important, les utilisateurs en sont informés.</p>
<h2>9. Droit applicable et litiges</h2>
<p>Les présentes conditions sont soumises au droit sénégalais. En cas de différend, nous vous invitons à nous écrire d'abord ($email) pour chercher une solution amiable. À défaut, les tribunaux compétents de Dakar sont saisis, sans préjudice des règles de compétence protectrices du consommateur.</p>
HTML;

        case 'cgv':
            $acompteTexte = e(acompte_description() !== '' ? acompte_description() . '.' : 'Selon la configuration du site, cet acompte peut être désactivé.');
            return $maj . <<<HTML
<h2>1. Champ d'application</h2>
<p>Ces conditions s'appliquent à tout achat effectué sur Jënd par un acheteur. Elles complètent les <a class="lien" href="@@cgu@@">conditions générales d'utilisation</a>.</p>
<h2>2. Produits et prix</h2>
<p>Les produits sont décrits par les vendeurs, sous leur responsabilité. Les prix sont indiqués en francs CFA (FCFA), toutes taxes comprises lorsque celles-ci s'appliquent. Les frais de livraison, calculés selon la zone, sont affichés avant la validation de la commande. Le prix payé est celui affiché au moment de la commande.</p>
<h2>3. Commande</h2>
<p>La commande est enregistrée lorsque vous la validez. Elle peut contenir des produits de plusieurs boutiques ; elle est alors divisée en plusieurs livraisons. Les articles sont réservés en stock dès la validation. Une commande non payée peut être annulée automatiquement ou par vous-même, et les articles sont alors remis en stock.</p>
<h2>4. Paiement</h2>
<p>Le paiement est effectué en ligne par les moyens proposés sur le site (par exemple Wave, Orange Money, carte bancaire, selon disponibilité). Les données de carte ne transitent jamais par les serveurs de Jënd : elles sont traitées par le prestataire de paiement. <b>Le montant versé est conservé par Jënd jusqu'à la livraison</b> et n'est reversé au vendeur qu'une fois la livraison confirmée. Des <b>frais de paiement sécurisé</b> peuvent s'ajouter au total ; ils sont toujours affichés avant la validation de la commande et sont remboursés si la commande est annulée avant d'être préparée.</p>
<!--COD--><p><b>Paiement à la livraison et acompte.</b> Pour confirmer une commande payée à la livraison, un <b>acompte</b> est réglé en ligne (Wave, Orange Money, Free Money ou carte) : $acompteTexte Le reste est payé <b>en espèces à la réception</b>. L'acompte est <b>remboursé</b> si la commande est annulée avant sa préparation, si le vendeur ne livre pas, ou si le produit n'est pas conforme (voir « Livraison, annulation et retours »). Il est <b>conservé</b> si, à la livraison, le client est absent, injoignable ou refuse un colis conforme : il indemnise le vendeur ou le livreur du déplacement.</p><!--/COD-->
<h2>5. Livraison et code de livraison</h2>
<p>Les zones, frais et délais indicatifs sont détaillés sur la page <a class="lien" href="@@livraison-retours@@">Livraison, annulation et retours</a>. Pour chaque livraison, un <b>code à 4 chiffres</b> est affiché dans votre espace commande. Ne le communiquez au livreur ou au vendeur <b>qu'après avoir reçu et vérifié votre colis</b> : c'est lui qui confirme la livraison et déclenche le paiement du vendeur.</p>
<h2>6. Conformité et garanties</h2>
<p>Le vendeur doit livrer un produit conforme à sa description. Vous bénéficiez des garanties prévues par la loi en cas de produit non conforme, défectueux ou non livré. Contactez-nous rapidement, avec des photos si possible : voir la page livraison et retours.</p>
<h2>7. Droit de rétractation</h2>
<p>Les conditions de retour et de remboursement applicables sont décrites sur la page « Livraison, annulation et retours ». Certains produits ne peuvent pas être repris pour des raisons d'hygiène ou de sécurité (produits d'hygiène ou cosmétiques ouverts, denrées périssables, articles sur mesure).</p>
<h2>8. Service client et réclamations</h2>
<p>Pour toute question ou réclamation : $email ou $tel. Nous accusons réception et répondons dans les meilleurs délais.</p>
<h2>9. Droit applicable</h2>
<p>Droit sénégalais. Voir l'article « Droit applicable et litiges » des conditions d'utilisation.</p>
HTML;

        case 'conditions-vendeur':
            return $maj . <<<HTML
<h2>1. Ouvrir une boutique</h2>
<p>Toute personne majeure, ou toute entreprise, peut demander l'ouverture d'une boutique. Le vendeur déclare exercer son activité conformément à la loi sénégalaise (inscription au registre du commerce ou statut équivalent, obligations fiscales). Jënd valide chaque boutique avant sa mise en ligne et peut demander des justificatifs (pièce d'identité, NINEA, RCCM le cas échéant). La validation n'est pas une garantie de qualité de la part de Jënd.</p>
<h2>2. Produits autorisés et interdits</h2>
<p>Le vendeur ne publie que des produits dont il dispose réellement ou qu'il peut fournir dans les délais annoncés. Sont <b>interdits</b> : armes et munitions, stupéfiants, médicaments sans autorisation, produits contrefaits ou volés, produits dangereux ou périmés, espèces protégées, contenus pour adultes, tout produit dont la vente est interdite au Sénégal.</p>
<h2>3. Fiches produits</h2>
<ul>
<li>Titre clair, description honnête, photos réelles du produit (pas d'images trompeuses), prix en FCFA, stock à jour.</li>
<li>Les caractéristiques essentielles (taille, couleur, matière, état neuf ou occasion, garantie) doivent figurer dans la description.</li>
<li>Jënd peut masquer ou retirer toute fiche non conforme.</li>
</ul>
<h2>4. Commandes et livraison</h2>
<p><b>Au démarrage, le vendeur livre lui-même ses commandes</b> (sauf si Jënd lui confie des livreurs Jënd, ce que Jënd peut décider boutique par boutique). Le client paie tout en ligne à Jënd, qui conserve l'argent jusqu'à la livraison. Quand le vendeur livre : Jënd lui reverse l'<b>intégralité du frais de livraison</b> payé par le client, avec le prix des produits, une fois la livraison confirmée<!--COD--> ; pour un paiement à la livraison il encaisse lui-même l'argent en espèces et <b>reverse à Jënd la commission</b> (retenue sur son solde)<!--/COD-->. Il organise et finance le transport, et reste responsable du colis jusqu'à la remise. Quand un livreur Jënd livre, Jënd conserve le frais de livraison.</p>
<p>Le vendeur prépare chaque commande payée sans retard, la remet à la livraison et la marque comme expédiée sur la plateforme. Pour marquer une commande « livrée », il doit saisir le <b>code de livraison</b> donné par le client à la réception. Le code est secret : le vendeur ne peut pas le voir et ne doit jamais demander à un client de le communiquer avant la remise du colis. Après plusieurs codes erronés, la saisie est bloquée et Jënd est alerté.</p>
<h2>5. Commission, frais de livraison et paiement du vendeur</h2>
<p>Ouvrir une boutique est gratuit. $phraseCommission Ce principe (préavis de 30 jours, aucun effet sur les commandes déjà passées) s'applique à <b>tous les frais</b> de Jënd, pas seulement à la commission. Le client règle en ligne le prix des produits et le frais de livraison : <b>Jënd conserve la totalité de cet argent jusqu'à la confirmation de la livraison</b>, puis crédite le vendeur du prix des produits (moins la commission) et, lorsqu'il livre lui-même, du frais de livraison. Le solde est crédité sur le compte du vendeur et peut être retiré sur son numéro Wave ou Orange Money à partir de $retraitMin. Détails sur la page <a class="lien" href="@@frais-commissions@@">Frais et commissions</a>.</p>
<h2>6. Annulations, retours et litiges</h2>
<p>Le vendeur répond aux réclamations des acheteurs et reprend ou remplace un produit non conforme, défectueux ou non livré. En cas de litige, Jënd peut suspendre le versement concerné, demander des preuves aux deux parties et décider d'un remboursement à l'acheteur, à la charge du vendeur, lorsque le manquement est établi.</p>
<h2>7. Interdiction de contourner la plateforme</h2>
<p>Il est interdit d'inciter un acheteur rencontré sur Jënd à payer en dehors de la plateforme. Un manquement peut entraîner la suspension de la boutique et la retenue des sommes dues à hauteur du préjudice.</p>
<h2>8. Suspension et fermeture</h2>
<p>Jënd peut suspendre une boutique en cas de fraude, de plaintes répétées, de produits interdits ou de non-respect de ces conditions. Le vendeur peut fermer sa boutique à tout moment après avoir livré ses commandes en cours ; ses gains disponibles lui sont versés.</p>
<h2>9. Données des acheteurs</h2>
<p>Le vendeur reçoit le nom, le téléphone et l'adresse de livraison de l'acheteur <b>uniquement pour livrer la commande</b>. Il s'interdit toute autre utilisation (démarchage, revente, partage) et doit supprimer ces données lorsqu'elles ne sont plus nécessaires.</p>
HTML;

        case 'paiements-vendeurs':
            return $maj . <<<HTML
<h2>En bref</h2>
<ul>
<li>Les paiements <b>en ligne</b> (Wave, Orange Money, carte…) passent par <b>$prestNoms</b> (prestataire$prestS de paiement) et arrivent sur le compte de Jënd. Jënd tient pour chaque vendeur le décompte de ce qui lui revient (« Mes gains »).</li>
<li>Le client paie <b>tout en ligne</b> (produits + frais de livraison) : Jënd conserve cet argent jusqu'à la livraison. Il n'y a donc ni espèces à encaisser, ni risque d'impayé pour vous.</li>
<li>Votre part est comptée <b>après la livraison</b> confirmée par le client (code ou bouton « J'ai bien reçu »), puis devient <b>retirable $delaiRetrait après la livraison</b>. Elle comprend le prix des produits moins la commission, <b>plus le frais de livraison</b> quand vous livrez vous-même.</li>
<li>$phraseVersement</li>
<li>Chaque mois, un <b>relevé</b> détaille vos ventes livrées, la commission, les éventuelles retenues et les versements reçus. Vous le trouvez dans « Mes gains → Mes relevés », à imprimer ou à ouvrir dans Excel.</li>
<li><b>Commission de Jënd : $commission %</b> du prix des produits livrés et payés (taux modifiable, avec 30 jours de préavis : voir <a class="lien" href="@@frais-commissions@@">Frais et commissions</a>).</li>
<li><b>Les frais de $prestNoms sont aujourd'hui à la charge de Jënd</b> : ils ne sont pas déduits de vos gains (si Jënd l'active, une partie peut être payée par le client sous forme de « frais de paiement sécurisé », toujours affichés avant le paiement).</li>
</ul>
<h2>Frais de paiement ($prestNoms)</h2>
<p>$prestNoms $prestPreleve ses propres frais sur chaque paiement en ligne. $tauxPdHtml Grille$prestS officielle$prestS : $grillesHtml.</p>
<p>Pour l'instant, <b>Jënd supporte ces frais</b> : le prix des produits que vous touchez n'est pas diminué. Si Jënd décidait un jour de les répercuter (sur les vendeurs ou sur les clients), vous en seriez prévenu <b>au moins 30 jours à l'avance</b>, comme pour la commission (voir <a class="lien" href="@@frais-commissions@@">Frais et commissions</a>).</p>
<h2>Quand et comment suis-je payé ?</h2>
<ol>
<li>Le client paie sur Jënd <!--COD-->(en ligne, ou un acompte puis des espèces à la livraison)<!--/COD-->.</li>
<li>Vous livrez ; la livraison est confirmée par le code que le client vous donne (ou par le client lui-même sur son compte) : la vente, avec le frais de livraison si vous avez livré, est alors comptée dans « Mes gains ».</li>
<li>Pendant $delaiRetrait après la livraison, le montant est « bientôt retirable » : c'est le temps laissé au client pour signaler un problème.</li>
<li>Ensuite, le montant fait partie de votre solde disponible : $phraseVersement</li>
</ol>
<!--COD--><h2>Paiement à la livraison (espèces)</h2><!--/COD-->
<!--COD--><p>Quand le client paie en espèces et que <b>vous livrez</b>, vous encaissez vous-même le reste en main propre : Jënd ne vous le verse pas une deuxième fois. Seul l'<b>acompte</b> réglé en ligne passe par Jënd (il vous est crédité, moins la commission quand elle existe). Si le client est absent ou refuse un colis conforme, l'acompte est conservé et vous est acquis lorsque vous livriez.</p><!--/COD-->
<h2>Cas particuliers</h2>
<ul>
<li><b>Signalement d'un client</b> : les gains de cette livraison sont mis de côté jusqu'à la décision. S'il est justifié, le remboursement peut être retenu sur vos gains.</li>
<li><b>Livraison par un livreur Jënd</b> (service activé plus tard, boutique par boutique) : le frais de livraison reste à Jënd.</li>
<li><b>Retrait refusé ou erreur de numéro</b> : le montant revient dans votre solde ; vérifiez le numéro de votre boutique.</li>
</ul>
<h2>Ce que décide le prestataire de paiement, pas Jënd</h2>
<p>$prestNoms $prestOnt propres conditions. Un prestataire de paiement peut notamment <b>retenir ou bloquer des fonds</b> en cas de litige bancaire ou de soupçon de fraude, ce qui pourrait retarder des reversements.$delaisPd Lisez-les : $conditionsHtml.</p>
<p class="doux petit">Ces informations sont données à titre d'explication ; en cas de différence, les conditions du prestataire de paiement et les conditions des vendeurs de Jënd font foi. Une question ? $email — $tel.</p>
HTML;

        case 'frais-commissions':
            $ann = function_exists('commission_annonce') ? commission_annonce() : null;
            $annHtml = $ann ? '<p class="alerte alerte-info"><i class="ph ph-megaphone"></i> <span><b>Annonce :</b> à partir du <b>' . e(date('d/m/Y', strtotime($ann['le']))) . '</b>, la commission sera de <b>' . e(commission_texte($ann['pct'])) . ' %</b> sur les commandes passées à partir de cette date. Les commandes passées avant ne sont pas concernées.</span></p>' : '';
            $titreAujourdhui = $offre ? 'Aujourd\'hui : aucune commission' : ($lancement ? 'Offre de lancement : ' . $commission . ' % de commission' : 'Aujourd\'hui : commission de ' . $commission . ' %');
            $demain = $offre
                ? '<h2>Plus tard : une commission pourra être appliquée</h2>
<p>Jënd démarre : pour aider les premiers vendeurs à s\'installer, <b>aucune commission n\'est prélevée pour l\'instant</b>. Quand le site aura pris de l\'ampleur, une commission sur les ventes livrées pourra être appliquée afin de financer le service (paiement protégé, assistance, suivi des livraisons, litiges). Ce moment n\'est pas fixé à l\'avance : il vous sera annoncé.</p>'
                : '';
            return $maj . $annHtml . <<<HTML
<h2>$titreAujourdhui</h2>
<p>$phraseCommission</p>
<ul>
<li>Ouvrir une boutique est <b>gratuit</b> : pas d'abonnement, pas de frais de mise en ligne des produits.</li>
<li>La commission, quand elle existe, se calcule sur le prix des produits, <b>hors frais de livraison</b>, et seulement sur les commandes <b>livrées et payées</b>.</li>
</ul>
$demain
<h2>Les taux peuvent changer avec le temps</h2>
<p>La commission, comme tout autre frais de Jënd, <b>peut évoluer au fil de la croissance du site</b> (augmentation, baisse ou taux différent selon les cas). Voici ce que Jënd s'engage à respecter à chaque changement :</p>
<ol>
<li><b>Vous êtes prévenu par e-mail au moins 30 jours à l'avance</b>, avec le nouveau taux et la date d'entrée en vigueur. L'annonce est aussi affichée sur cette page et dans votre espace vendeur.</li>
<li><b>Jamais de rétroactivité</b> : le nouveau taux ne s'applique qu'aux commandes passées à partir de la date annoncée.</li>
<li><b>Vous restez libre</b> : si le nouveau taux ne vous convient pas, vous pouvez fermer votre boutique avant la date ; vos gains vous sont versés normalement.</li>
<li><b>Transparence</b> : votre taux actuel est toujours visible dans votre espace vendeur (« Mes gains »).</li>
</ol>
<h2>Comment la commission se calcule</h2>
<p>$exemple</p>
<p class="doux petit">L'exemple sert uniquement à illustrer le calcul; il ne constitue pas un engagement sur un taux futur.</p>
<h2>Frais de livraison : comment ils sont payés et à qui ils vont</h2>
<p>Le client règle <b>en ligne</b>, en une seule fois, le prix des produits <b>et</b> le frais de livraison de sa zone (affiché avant de payer). <b>Tout cet argent est d'abord reçu et conservé par Jënd</b> : ni le vendeur ni le livreur n'encaissent d'argent auprès du client à la livraison<!--COD--> (sauf si le paiement à la livraison est activé : voir « Paiements et reversements »)<!--/COD-->.</p>
<ul>
<li><b>Le vendeur livre lui-même</b> (cas général) : il organise la livraison (ses livreurs, un transporteur…), <b>fixe ses frais de livraison zone par zone</b> dans son espace (sinon, ce sont les frais de référence de Jënd), et <b>le frais payé par le client lui revient en entier</b>. Jënd le lui verse avec le prix des produits, une fois la livraison confirmée.</li>
<li><b>Livraison par un livreur Jënd</b> (service activé plus tard, boutique par boutique) : Jënd <b>conserve le frais de livraison</b> pour rémunérer ses livreurs. Le vendeur reçoit le prix des produits, moins la commission.</li>
<li>La <b>commission ne s'applique jamais au frais de livraison</b>, seulement au prix des produits.</li>
<li>Si une commande contient des produits de plusieurs boutiques, chaque boutique livre son colis et facture sa propre livraison.</li>
<li>Les frais et délais de chaque zone sont affichés sur la page <a class="lien" href="@@livraison-retours@@">Livraison, annulation et retours</a>.</li>
</ul>
<h2>Quand êtes-vous payé ?</h2>
<p>Tout est détaillé sur la page <a class="lien" href="@@paiements-vendeurs@@">Paiements et reversements</a> (frais du prestataire de paiement, délais, retraits).</p>
<ol>
<li>Le client paie sur Jënd <b>(prix des produits + frais de livraison)</b><!--COD--> en ligne, ou un acompte puis des espèces à la livraison<!--/COD-->. <b>L'argent est conservé par Jënd</b> : vous n'êtes pas encore payé, mais le client a bien payé, vous pouvez donc préparer la commande en confiance.</li>
<li>Vous préparez la commande, la marquez « expédiée », puis la livrez.</li>
<li><b>La livraison est confirmée</b> par le client (il vous donne le code, ou clique sur « J'ai bien reçu ma commande »).</li>
<li><b>À ce moment seulement</b>, Jënd crédite votre solde : prix des produits − commission, plus le frais de livraison si vous avez livré vous-même.</li>
<li>Le montant devient <b>retirable $delaiRetrait après la livraison</b>, le temps que le client puisse signaler un problème.</li>
<li>Vous demandez un retrait vers votre numéro Wave ou Orange Money, à partir de $retraitMin.</li>
</ol>
<p class="doux">Les frais éventuels de l'opérateur de paiement mobile sur les retraits sont indiqués avant confirmation lorsqu'ils s'appliquent.</p>
HTML;

        case 'livraison-retours':
            $villes = e(villes_livrees());
            $uniquement = livraison_nationale() ? '' : ' uniquement';
            $zones = tableau_livraison_boutiques();
            return $maj . <<<HTML
<h2>Où livrent nos vendeurs ?</h2>
<p>Sur Jënd, <b>chaque boutique livre elle-même</b> ses commandes et choisit les villes où elle livre. Aujourd'hui, nos boutiques livrent à <b>$villes</b>$uniquement. Ouvrez une ville pour voir les boutiques qui y livrent, et les frais et délais de chaque zone.</p>
<p>Au moment de commander, nous vérifions que <b>toutes les boutiques de votre panier livrent dans votre zone</b> : sinon, nous vous le disons avant le paiement. <b>Chaque boutique fixe ses propres frais de livraison</b> selon la zone (sinon, ce sont les frais de référence de Jënd). Le total s'affiche avant de payer. Une commande avec des produits de plusieurs boutiques arrive en plusieurs colis, et chaque boutique facture sa livraison. Les délais sont indicatifs et comptés à partir de l'expédition par le vendeur.</p>
$zones
<h2>Suivre ma commande</h2>
<p>Connectez-vous, puis ouvrez « Mon compte » pour voir l'état de chaque livraison. Si une commande contient des produits de plusieurs boutiques, chacun peut arriver séparément.</p>
<h2>Confirmer la réception avec le code</h2>
<p>Votre espace commande affiche un code à 4 chiffres par livraison. Donnez-le <b>seulement après avoir reçu et vérifié votre colis</b>. Il protège votre argent : tant que le code n'est pas saisi, le vendeur n'est pas payé.</p>
<h2>Annuler une commande</h2>
<p>Vous pouvez annuler vous-même une commande tant qu'elle n'est pas préparée, depuis la page de la commande. Les articles sont remis en stock<!--COD--> et, si vous aviez payé un acompte, il vous est remboursé<!--/COD-->. Après paiement, contactez l'assistance : $email ou $tel.</p>
<h2>Client absent ou colis refusé</h2>
<!--COD--><p>Si, à la livraison, vous êtes absent, injoignable ou si vous refusez un colis conforme, <b>l'acompte n'est pas remboursé</b> : il indemnise le vendeur ou le livreur. Gardez votre téléphone allumé le jour de la livraison.</p><!--/COD-->
<h2>Problème avec un produit</h2>
<p>Si le produit est non conforme, défectueux, endommagé ou n'est jamais arrivé, contactez-nous <b>dès réception, ou dans les 7 jours suivant la date de livraison prévue</b>, avec votre numéro de commande et des photos. Nous contactons le vendeur et proposons selon le cas un remplacement, une réparation ou un remboursement. Si le vendeur est en tort, le remboursement est à sa charge.</p>
<h2>Produits non repris</h2>
<p>Pour des raisons d'hygiène ou de sécurité, ne sont en principe pas repris : produits cosmétiques ou d'hygiène ouverts, denrées périssables, articles faits sur mesure, sauf défaut ou non-conformité.</p>
<h2>Remboursement</h2>
<p>Un remboursement accepté est effectué par le moyen de paiement mobile utilisé ou par crédit sur votre compte, dans un délai raisonnable que nous vous indiquons au moment de la décision.</p>
HTML;

        case 'confidentialite':
            return $maj . <<<HTML
<p>Jënd respecte votre vie privée. Cette politique explique quelles données nous collectons, pourquoi, et quels sont vos droits, conformément à la loi sénégalaise n° 2008-12 du 25 janvier 2008 sur la protection des données à caractère personnel.</p>
<h2>Responsable du traitement</h2>
<p>$n — $email.</p>
<h2>Données collectées et finalités</h2>
<table class="table"><thead><tr><th>Données</th><th>Pourquoi</th></tr></thead><tbody>
<tr><td>Nom, e-mail, téléphone, mot de passe (stocké haché, jamais en clair)</td><td>Créer et sécuriser votre compte</td></tr>
<tr><td>Adresses de livraison</td><td>Livrer vos commandes</td></tr>
<tr><td>Commandes, paiements (état et montant ; pas de numéro de carte)</td><td>Exécuter le contrat, comptabilité, lutte contre la fraude</td></tr>
<tr><td>Numéro Wave / Orange Money du vendeur</td><td>Verser les gains</td></tr>
<tr><td>Adresse IP, journaux de sécurité</td><td>Sécurité, blocage des tentatives abusives, preuve en cas de litige</td></tr>
<tr><td>Avis et favoris</td><td>Fonctionnement du site</td></tr>
</tbody></table>
<h2>Base légale</h2>
<p>L'exécution du contrat (commande, livraison, paiement), votre consentement lorsqu'il est demandé (inscription), nos obligations légales et notre intérêt légitime à sécuriser le site.</p>
<h2>Destinataires</h2>
<ul>
<li>Le <b>vendeur</b> concerné reçoit votre nom, téléphone et adresse de livraison, uniquement pour livrer.</li>
<li>Le <b>prestataire de paiement</b> traite votre paiement.</li>
<li>Notre <b>hébergeur</b> stocke les données.</li>
<li>Les autorités, si la loi l'exige.</li>
</ul>
<p>Nous ne vendons pas vos données et n'utilisons ni publicité ciblée ni outil de suivi tiers : le site n'appelle aucun service externe (polices et scripts hébergés chez nous).</p>
<h2>Cookies</h2>
<p>Le site utilise uniquement un cookie de session, nécessaire à la connexion et au panier. Il n'y a pas de cookie publicitaire ni de mesure d'audience tierce.</p>
<h2>Durée de conservation</h2>
<p>Compte : tant qu'il est actif, puis suppression ou anonymisation sur demande. Commandes et pièces comptables : durée légale de conservation. Journaux de sécurité : durée limitée.</p>
<h2>Sécurité</h2>
<p>Mots de passe hachés, connexions chiffrées (HTTPS), double authentification pour l'administration, limitation des tentatives, sauvegardes chiffrées. Aucun système n'étant infaillible, nous vous informerons en cas d'incident affectant vos données.</p>
<h2>Vos droits</h2>
<p>Vous pouvez demander l'accès, la rectification, l'opposition ou la suppression de vos données en écrivant à $email. Vous pouvez aussi saisir la Commission de Protection des Données Personnelles (CDP) du Sénégal.</p>
HTML;

        case 'mentions-legales':
            $nom = e(societe('nom')); $forme = e(societe('forme')); $cap = e(societe('capital'));
            $adr = e(societe('adresse')); $ninea = e(societe('ninea')); $rccm = e(societe('rccm'));
            $dir = e(societe('directeur')); $heb = e(societe('hebergeur'));
            return $maj . <<<HTML
<h2>Éditeur du site</h2>
<ul>
<li>Dénomination : <b>$nom</b></li>
<li>Forme juridique : $forme — Capital : $cap</li>
<li>Siège : $adr</li>
<li>NINEA : $ninea — RCCM : $rccm</li>
<li>Téléphone : $tel — E-mail : $email</li>
<li>Directeur de la publication : $dir</li>
</ul>
<h2>Hébergeur</h2>
<p>$heb</p>
<h2>Propriété intellectuelle</h2>
<p>L'ensemble du site (marque, logo, textes, design, code) est protégé. Toute reproduction sans autorisation est interdite.</p>
<h2>Données personnelles</h2>
<p>Voir la <a class="lien" href="@@confidentialite@@">politique de confidentialité</a>.</p>
HTML;

        case 'a-propos':
            $villes = e(villes_livrees());
            return <<<HTML
<p><b>Jënd</b> vient du wolof <i>jënd</i> : « acheter ». C'est une place de marché sénégalaise où l'on achète et vend en confiance.</p>
<h2>Notre idée</h2>
<p>Donner aux commerçants, créateurs et artisans du Sénégal une vitrine simple, et aux acheteurs des produits locaux ou importés avec un paiement protégé : l'argent n'est versé au vendeur qu'une fois le colis reçu et confirmé par un code.</p>
<h2>Ce qui nous distingue</h2>
<ul>
<li><b>Paiement protégé</b> par le code de livraison.</li>
<li><b>Paiement mobile</b> : Wave, Orange Money et autres moyens.</li>
<li><b>Livraison</b> à domicile : $villes.</li>
<li><b>Boutiques gratuites</b> : commission seulement sur les ventes livrées.</li>
<li><b>Données respectées</b> : aucun traceur publicitaire.</li>
</ul>
<p>Une question, une idée ? <a class="lien" href="@@contact@@">Écrivez-nous</a>.</p>
HTML;

        case 'contact':
            return <<<HTML
<p>Notre équipe répond du lundi au samedi.</p>
<ul>
<li><i class="ph ph-envelope-simple"></i> E-mail : <b>$email</b></li>
<li><i class="ph ph-phone"></i> Téléphone / WhatsApp : <b>$tel</b></li>
</ul>
<p>Pour une commande, indiquez toujours votre <b>numéro de commande</b> (page « Mon compte »). Ne nous envoyez <b>jamais</b> votre mot de passe ni votre code de livraison : nous ne vous les demanderons jamais.</p>
<p>Vendeur ? Voir les <a class="lien" href="@@conditions-vendeur@@">conditions des vendeurs</a>.</p>
HTML;
    }
    return '';
}

/** Contenu final : les liens internes « @@doc@@ » deviennent de vraies adresses du site. */
function contenu_document(string $doc): string
{
    $html = contenu_document_brut($doc);
    // Passages relatifs au paiement à la livraison : retirés tant que cette option est désactivée
    $html = (!function_exists('paiement_livraison_actif') || paiement_livraison_actif()) ? str_replace(['<!--COD-->', '<!--/COD-->'], '', $html) : preg_replace('/<!--COD-->.*?<!--\/COD-->/s', '', $html);
    return preg_replace_callback('#@@([a-z0-9-]+(?:/[a-z0-9-]+)?)@@#', fn ($m) => e(url($m[1])), $html);
}
