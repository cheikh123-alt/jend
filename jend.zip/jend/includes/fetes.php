<?php
declare(strict_types=1);

/**
 * « Spécial fêtes » : Grand Magal de Touba, Tabaski, Korité, Gamou…
 * Les dates suivent le calendrier lunaire et changent chaque année : c'est l'administrateur qui les saisit (rien n'est deviné ici).
 * Les vendeurs rattachent leurs produits à une fête à venir ; la vitrine s'affiche à partir de « vitrine_des » jusqu'au jour de la fête.
 */

const FETES_SUGGEREES = ['Grand Magal de Touba', 'Tabaski', 'Korité', 'Gamou', 'Tamkharit', 'Fête de l\'Indépendance', 'Rentrée scolaire', 'Fêtes de fin d\'année'];
const FETE_PRODUITS_MAX = 100;                  // par boutique et par fête
const FETE_REMISES = [0, 5, 10, 15, 20, 25, 30, 40, 50];   // promotions proposées au vendeur (en %)
const FETE_REMISE_MAX = 50;

/** Fête dont la vitrine est en cours (la plus proche), ou null. */
function fete_en_vitrine(): ?array
{
    return requete('SELECT * FROM fetes WHERE actif = 1 AND vitrine_des <= CURDATE() AND date_fete >= CURDATE() ORDER BY date_fete LIMIT 1')->fetch() ?: null;
}

/** Fêtes actives pas encore passées (pour que les vendeurs préparent leurs produits à l'avance). */
function fetes_a_venir(): array
{
    return requete('SELECT * FROM fetes WHERE actif = 1 AND date_fete >= CURDATE() ORDER BY date_fete')->fetchAll();
}

/** Nombre de jours avant la fête (0 = aujourd'hui). */
function fete_jours(array $f): int
{
    return (int) ((strtotime($f['date_fete']) - strtotime(date('Y-m-d'))) / 86400);
}

/** « Dans 12 jours », « Demain », « Aujourd'hui » */
function fete_compte(array $f): string
{
    $j = fete_jours($f);
    return $j <= 0 ? 'Aujourd\'hui' : ($j === 1 ? 'Demain' : 'Dans ' . $j . ' jours');
}

/** La date limite de commande est-elle encore à venir ? */
function fete_commande_a_temps(array $f): bool
{
    return $f['date_limite'] !== null && $f['date_limite'] >= date('Y-m-d');
}

/** Date au format « 21 août 2026 ». */
function date_longue_fr(string $date): string
{
    static $mois = ['', 'janvier', 'février', 'mars', 'avril', 'mai', 'juin', 'juillet', 'août', 'septembre', 'octobre', 'novembre', 'décembre'];
    $t = (int) strtotime($date);
    return (int) date('j', $t) . ($t && date('j', $t) === '1' ? 'er' : '') . ' ' . $mois[(int) date('n', $t)] . ' ' . date('Y', $t);
}

/** Fête en vitrine à laquelle ce produit est rattaché, ou null. */
function fete_du_produit(int $produitId): ?array
{
    return requete(
        'SELECT f.*, pf.remise_pct FROM fetes f JOIN produit_fetes pf ON pf.fete_id = f.id
          WHERE pf.produit_id = ? AND f.actif = 1 AND f.vitrine_des <= CURDATE() AND f.date_fete >= CURDATE() ORDER BY pf.remise_pct DESC, f.date_fete LIMIT 1',
        [$produitId]
    )->fetch() ?: null;
}

/**
 * Création ou modification d'une fête par l'administrateur. @throws RuntimeException message affichable
 */
function fete_enregistrer(?int $id, string $nom, string $date, string $limite, string $vitrine, string $texte, bool $actif): int
{
    $nom = trim($nom);
    $texte = trim($texte);
    $estDate = fn (string $d) => (bool) preg_match('/^\d{4}-\d{2}-\d{2}$/', $d) && checkdate((int) substr($d, 5, 2), (int) substr($d, 8, 2), (int) substr($d, 0, 4));
    if (mb_strlen($nom) < 3 || mb_strlen($nom) > 80) {
        throw new RuntimeException('Nom de la fête : 3 à 80 caractères.');
    }
    if (!$estDate($date)) {
        throw new RuntimeException('Date de la fête invalide.');
    }
    if ($vitrine === '') {
        $vitrine = date('Y-m-d', strtotime($date . ' -21 days'));
    }
    if (!$estDate($vitrine) || $vitrine > $date) {
        throw new RuntimeException('Le début de la vitrine doit être une date avant la fête.');
    }
    if ($limite !== '' && (!$estDate($limite) || $limite > $date)) {
        throw new RuntimeException('La date limite de commande doit être au plus tard le jour de la fête.');
    }
    if (mb_strlen($texte) > 300) {
        throw new RuntimeException('Texte de présentation : 300 caractères maximum.');
    }
    $valeurs = [$nom, $date, $limite !== '' ? $limite : null, $vitrine, $texte !== '' ? $texte : null, $actif ? 1 : 0];
    if ($id) {
        if (requete('UPDATE fetes SET nom = ?, date_fete = ?, date_limite = ?, vitrine_des = ?, texte = ?, actif = ? WHERE id = ?', [...$valeurs, $id])->rowCount() === 0
            && !requete('SELECT 1 FROM fetes WHERE id = ?', [$id])->fetch()) {
            throw new RuntimeException('Fête introuvable.');
        }
        return $id;
    }
    $base = slugify($nom . ' ' . substr($date, 0, 4)) ?: 'fete';
    $slug = $base;
    for ($i = 2; requete('SELECT 1 FROM fetes WHERE slug = ?', [$slug])->fetch(); $i++) {
        $slug = $base . '-' . $i;
    }
    requete('INSERT INTO fetes (nom, slug, date_fete, date_limite, vitrine_des, texte, actif) VALUES (?, ?, ?, ?, ?, ?, ?)', [$valeurs[0], $slug, ...array_slice($valeurs, 1)]);
    return (int) pdo()->lastInsertId();
}

/**
 * Le vendeur choisit ses produits pour une fête à venir, avec une promotion facultative par produit (remplace sa sélection précédente).
 * @param array $remises [produit_id => pourcentage] @throws RuntimeException
 */
function fete_produits_vendeur(int $feteId, int $boutiqueId, array $produitIds, array $remises = []): int
{
    if (!requete('SELECT 1 FROM fetes WHERE id = ? AND actif = 1 AND date_fete >= CURDATE()', [$feteId])->fetch()) {
        throw new RuntimeException('Cette fête n\'est plus ouverte.');
    }
    $produitIds = array_values(array_unique(array_filter(array_map('intval', $produitIds))));
    if (count($produitIds) > FETE_PRODUITS_MAX) {
        throw new RuntimeException('Maximum ' . FETE_PRODUITS_MAX . ' produits par fête.');
    }
    $pdo = pdo();
    $pdo->beginTransaction();
    try {
        requete('DELETE pf FROM produit_fetes pf JOIN produits p ON p.id = pf.produit_id WHERE pf.fete_id = ? AND p.boutique_id = ?', [$feteId, $boutiqueId]);
        $n = 0;
        foreach ($produitIds as $pid) {      // seuls les produits de CETTE boutique sont acceptés
            $pct = (int) ($remises[$pid] ?? 0);
            if (!in_array($pct, FETE_REMISES, true)) {
                throw new RuntimeException('Promotion invalide : choisissez un pourcentage proposé (' . FETE_REMISE_MAX . ' % maximum).');
            }
            $n += requete('INSERT INTO produit_fetes (produit_id, fete_id, remise_pct) SELECT id, ?, ? FROM produits WHERE id = ? AND boutique_id = ? AND reserve_client_id IS NULL', [$feteId, $pct, $pid, $boutiqueId])->rowCount();
        }
        $pdo->commit();
        return $n;
    } catch (Throwable $e) {
        $pdo->rollBack();
        throw $e;
    }
}
