<?php
/**
 * Fiche de confiance d'une boutique. Variables : $confiance (boutique_confiance), $compact (bool, ligne courte pour la fiche produit).
 */
$compact = $compact ?? false;
?>
<?php if ($compact): ?>
  <p class="confiance-ligne">
    <?php if ($confiance['assez']): ?>
      <span><i class="ph ph-package"></i> <b><?= (int) $confiance['ventes'] ?></b> ventes livrées</span>
      <?php if ($confiance['delai_heures'] !== null): ?><span><i class="ph ph-truck"></i> reçu en <b><?= e(delai_texte($confiance['delai_heures'])) ?></b> en moyenne</span><?php endif; ?>
      <span><i class="ph ph-shield-check"></i> <b><?= (int) $confiance['sans_probleme'] ?> %</b> sans problème</span>
    <?php else: ?>
      <span><i class="ph ph-sparkle"></i> Nouvelle boutique · votre argent reste protégé par Jënd jusqu'à la réception</span>
    <?php endif; ?>
  </p>
<?php else: ?>
  <section class="confiance" aria-labelledby="titre-confiance">
    <h2 id="titre-confiance"><i class="ph ph-chart-bar"></i> Fiche de confiance</h2>
    <?php if ($confiance['assez']): ?>
      <dl class="confiance-chiffres">
        <div><dt>Ventes livrées</dt><dd><?= (int) $confiance['ventes'] ?></dd></div>
        <div><dt>Délai moyen de réception</dt><dd><?= $confiance['delai_heures'] !== null ? e(delai_texte($confiance['delai_heures'])) : '—' ?></dd></div>
        <div><dt>Commandes sans problème</dt><dd><?= (int) $confiance['sans_probleme'] ?> %</dd></div>
        <div><dt>Sur Jënd depuis</dt><dd><?= e(anciennete_texte($confiance['depuis'])) ?></dd></div>
      </dl>
    <?php else: ?>
      <p>Cette boutique a moins de <?= CONFIANCE_VENTES_MIN ?> ventes livrées : ses statistiques apparaîtront après ses premières livraisons. Sur Jënd depuis <?= e(anciennete_texte($confiance['depuis'])) ?>.</p>
    <?php endif; ?>
    <p class="confiance-source">Chiffres calculés par Jënd à partir des livraisons et des signalements réels : le vendeur ne peut pas les modifier. Quelle que soit la boutique, votre argent reste bloqué jusqu'à la réception.</p>
  </section>
<?php endif; ?>
