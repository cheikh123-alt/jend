<?php
declare(strict_types=1);

/**
 * Générateur de QR code (norme ISO/IEC 18004), sans bibliothèque externe : mode octets, correction d'erreur « M » (~15 %),
 * versions 1 à 10 (jusqu'à 213 caractères, bien assez pour une adresse de boutique). Sortie en SVG, net à toutes les tailles.
 * Inspiré de l'algorithme de référence publié par Project Nayuki (domaine public / MIT).
 */

/** Pour chaque version (niveau M) : [codes de correction par bloc, [[nombre de blocs, octets de données par bloc], …]] */
const QR_BLOCS_M = [
    1 => [10, [[1, 16]]], 2 => [16, [[1, 28]]], 3 => [26, [[1, 44]]], 4 => [18, [[2, 32]]], 5 => [24, [[2, 43]]],
    6 => [16, [[4, 27]]], 7 => [18, [[4, 31]]], 8 => [22, [[2, 38], [2, 39]]], 9 => [22, [[3, 36], [2, 37]]], 10 => [26, [[4, 43], [1, 44]]],
];
const QR_ALIGNEMENTS = [1 => [], 2 => [6, 18], 3 => [6, 22], 4 => [6, 26], 5 => [6, 30], 6 => [6, 34], 7 => [6, 22, 38], 8 => [6, 24, 42], 9 => [6, 26, 46], 10 => [6, 28, 50]];

/** Matrice du QR code : tableau [ligne][colonne] de booléens (vrai = module noir). @throws RuntimeException si le texte est trop long */
function qr_matrice(string $texte): array
{
    $octets = array_values(unpack('C*', $texte) ?: []);
    $n = count($octets);
    // 1. Plus petite version qui contient le texte
    $version = 0;
    foreach (QR_BLOCS_M as $v => [$ec, $groupes]) {
        $capacite = array_sum(array_map(fn ($g) => $g[0] * $g[1], $groupes));
        $bits = 4 + ($v < 10 ? 8 : 16) + 8 * $n;
        if ((int) ceil($bits / 8) <= $capacite) {
            $version = $v;
            break;
        }
    }
    if (!$version) {
        throw new RuntimeException('Texte trop long pour le QR code.');
    }
    [$ecParBloc, $groupes] = QR_BLOCS_M[$version];
    $capacite = array_sum(array_map(fn ($g) => $g[0] * $g[1], $groupes));

    // 2. Flux de bits : mode octets, longueur, données, terminaison, remplissage
    $bits = [];
    $ajouter = function (int $val, int $long) use (&$bits): void {
        for ($i = $long - 1; $i >= 0; $i--) {
            $bits[] = ($val >> $i) & 1;
        }
    };
    $ajouter(0b0100, 4);
    $ajouter($n, $version < 10 ? 8 : 16);
    foreach ($octets as $o) {
        $ajouter($o, 8);
    }
    $ajouter(0, min(4, $capacite * 8 - count($bits)));
    $ajouter(0, (8 - count($bits) % 8) % 8);
    for ($pad = 0xEC; count($bits) < $capacite * 8; $pad ^= 0xEC ^ 0x11) {
        $ajouter($pad, 8);
    }
    $donnees = [];
    for ($i = 0; $i < count($bits); $i += 8) {
        $o = 0;
        for ($j = 0; $j < 8; $j++) {
            $o = ($o << 1) | $bits[$i + $j];
        }
        $donnees[] = $o;
    }

    // 3. Blocs + codes correcteurs Reed-Solomon, puis entrelacement
    $blocs = [];
    $k = 0;
    foreach ($groupes as [$nb, $taille]) {
        for ($b = 0; $b < $nb; $b++) {
            $d = array_slice($donnees, $k, $taille);
            $k += $taille;
            $blocs[] = [$d, qr_reed_solomon($d, $ecParBloc)];
        }
    }
    $final = [];
    $max = max(array_map(fn ($b) => count($b[0]), $blocs));
    for ($i = 0; $i < $max; $i++) {
        foreach ($blocs as [$d]) {
            if ($i < count($d)) {
                $final[] = $d[$i];
            }
        }
    }
    for ($i = 0; $i < $ecParBloc; $i++) {
        foreach ($blocs as [, $e]) {
            $final[] = $e[$i];
        }
    }

    // 4. Motifs fixes, puis placement des données, puis le meilleur des 8 masques
    $taille = 17 + 4 * $version;
    $m = array_fill(0, $taille, array_fill(0, $taille, false));
    $fixe = array_fill(0, $taille, array_fill(0, $taille, false));
    $poser = function (int $x, int $y, bool $noir) use (&$m, &$fixe): void {
        $m[$y][$x] = $noir;
        $fixe[$y][$x] = true;
    };
    for ($i = 0; $i < $taille; $i++) {                                      // motifs de synchronisation
        $poser(6, $i, $i % 2 === 0);
        $poser($i, 6, $i % 2 === 0);
    }
    foreach ([[3, 3], [$taille - 4, 3], [3, $taille - 4]] as [$cx, $cy]) {  // les 3 carrés de repérage + séparateurs
        for ($dy = -4; $dy <= 4; $dy++) {
            for ($dx = -4; $dx <= 4; $dx++) {
                $x = $cx + $dx;
                $y = $cy + $dy;
                if ($x >= 0 && $x < $taille && $y >= 0 && $y < $taille) {
                    $dist = max(abs($dx), abs($dy));
                    $poser($x, $y, $dist !== 2 && $dist !== 4);
                }
            }
        }
    }
    $pos = QR_ALIGNEMENTS[$version];
    $np = count($pos);
    for ($i = 0; $i < $np; $i++) {                                           // motifs d'alignement
        for ($j = 0; $j < $np; $j++) {
            if (($i === 0 && $j === 0) || ($i === 0 && $j === $np - 1) || ($i === $np - 1 && $j === 0)) {
                continue;
            }
            for ($dy = -2; $dy <= 2; $dy++) {
                for ($dx = -2; $dx <= 2; $dx++) {
                    $poser($pos[$i] + $dx, $pos[$j] + $dy, max(abs($dx), abs($dy)) !== 1);
                }
            }
        }
    }
    qr_format($m, $fixe, $taille, 0, $poser);                                // réserve les zones de format (masque provisoire)
    if ($version >= 7) {                                                       // informations de version
        $rem = $version;
        for ($i = 0; $i < 12; $i++) {
            $rem = ($rem << 1) ^ (($rem >> 11) * 0x1F25);
        }
        $vb = ($version << 12) | $rem;
        for ($i = 0; $i < 18; $i++) {
            $bit = (($vb >> $i) & 1) === 1;
            $a = $taille - 11 + $i % 3;
            $b = intdiv($i, 3);
            $poser($a, $b, $bit);
            $poser($b, $a, $bit);
        }
    }
    $nbBits = count($final) * 8;
    $i = 0;
    for ($droite = $taille - 1; $droite >= 1; $droite -= 2) {                 // placement en zigzag, de droite à gauche
        if ($droite === 6) {
            $droite = 5;
        }
        for ($vert = 0; $vert < $taille; $vert++) {
            for ($j = 0; $j < 2; $j++) {
                $x = $droite - $j;
                $monte = (($droite + 1) & 2) === 0;
                $y = $monte ? $taille - 1 - $vert : $vert;
                if (!$fixe[$y][$x] && $i < $nbBits) {
                    $m[$y][$x] = (($final[$i >> 3] >> (7 - ($i & 7))) & 1) === 1;
                    $i++;
                }
            }
        }
    }
    $meilleur = null;
    $meilleurScore = PHP_INT_MAX;
    for ($masque = 0; $masque < 8; $masque++) {
        $essai = qr_masquer($m, $fixe, $taille, $masque);
        qr_format($essai, $fixe, $taille, $masque, function (int $x, int $y, bool $noir) use (&$essai): void { $essai[$y][$x] = $noir; });
        $score = qr_penalite($essai, $taille);
        if ($score < $meilleurScore) {
            $meilleurScore = $score;
            $meilleur = $essai;
        }
    }
    return $meilleur;
}

/** Codes correcteurs Reed-Solomon (corps GF(256), polynôme 0x11D). */
function qr_reed_solomon(array $donnees, int $degre): array
{
    static $exp = null, $log = null;
    if ($exp === null) {
        $exp = array_fill(0, 512, 0);
        $log = array_fill(0, 256, 0);
        $x = 1;
        for ($i = 0; $i < 255; $i++) {
            $exp[$i] = $x;
            $log[$x] = $i;
            $x <<= 1;
            if ($x & 0x100) {
                $x ^= 0x11D;
            }
        }
        for ($i = 255; $i < 512; $i++) {
            $exp[$i] = $exp[$i - 255];
        }
    }
    $mul = fn (int $a, int $b): int => ($a === 0 || $b === 0) ? 0 : $exp[$log[$a] + $log[$b]];
    $gen = [1];                                                               // polynôme générateur de degré $degre
    for ($i = 0; $i < $degre; $i++) {
        $nouveau = array_fill(0, count($gen) + 1, 0);
        foreach ($gen as $j => $c) {
            $nouveau[$j] ^= $c;
            $nouveau[$j + 1] ^= $mul($c, $exp[$i]);
        }
        $gen = $nouveau;
    }
    $reste = array_fill(0, $degre, 0);
    foreach ($donnees as $o) {
        $facteur = $o ^ array_shift($reste);
        $reste[] = 0;
        for ($j = 0; $j < $degre; $j++) {
            $reste[$j] ^= $mul($gen[$j + 1], $facteur);
        }
    }
    return $reste;
}

/** Dessine les informations de format (niveau M + masque) aux deux emplacements prévus. */
function qr_format(array &$m, array $fixe, int $taille, int $masque, callable $poser): void
{
    $data = (0 << 3) | $masque;                                               // niveau M = 00
    $rem = $data;
    for ($i = 0; $i < 10; $i++) {
        $rem = ($rem << 1) ^ (($rem >> 9) * 0x537);
    }
    $bits = (($data << 10) | $rem) ^ 0x5412;
    $b = fn (int $i): bool => (($bits >> $i) & 1) === 1;
    for ($i = 0; $i <= 5; $i++) {
        $poser(8, $i, $b($i));
    }
    $poser(8, 7, $b(6));
    $poser(8, 8, $b(7));
    $poser(7, 8, $b(8));
    for ($i = 9; $i < 15; $i++) {
        $poser(14 - $i, 8, $b($i));
    }
    for ($i = 0; $i < 8; $i++) {
        $poser($taille - 1 - $i, 8, $b($i));
    }
    for ($i = 8; $i < 15; $i++) {
        $poser(8, $taille - 15 + $i, $b($i));
    }
    $poser(8, $taille - 8, true);                                             // module toujours noir
}

/** Applique un des 8 masques normalisés aux modules de données. */
function qr_masquer(array $m, array $fixe, int $taille, int $masque): array
{
    for ($y = 0; $y < $taille; $y++) {
        for ($x = 0; $x < $taille; $x++) {
            if ($fixe[$y][$x]) {
                continue;
            }
            $inverser = match ($masque) {
                0 => ($x + $y) % 2 === 0,
                1 => $y % 2 === 0,
                2 => $x % 3 === 0,
                3 => ($x + $y) % 3 === 0,
                4 => (intdiv($x, 3) + intdiv($y, 2)) % 2 === 0,
                5 => ($x * $y) % 2 + ($x * $y) % 3 === 0,
                6 => (($x * $y) % 2 + ($x * $y) % 3) % 2 === 0,
                default => ((($x + $y) % 2) + ($x * $y) % 3) % 2 === 0,
            };
            if ($inverser) {
                $m[$y][$x] = !$m[$y][$x];
            }
        }
    }
    return $m;
}

/** Score de pénalité normalisé (plus il est bas, plus le code se lit facilement). */
function qr_penalite(array $m, int $taille): int
{
    $score = 0;
    $noirs = 0;
    for ($a = 0; $a < 2; $a++) {                                              // lignes puis colonnes
        for ($i = 0; $i < $taille; $i++) {
            $ligne = [];
            for ($j = 0; $j < $taille; $j++) {
                $ligne[] = $a === 0 ? $m[$i][$j] : $m[$j][$i];
            }
            $serie = 1;
            for ($j = 1; $j <= $taille; $j++) {
                if ($j < $taille && $ligne[$j] === $ligne[$j - 1]) {
                    $serie++;
                } else {
                    if ($serie >= 5) {
                        $score += 3 + ($serie - 5);
                    }
                    $serie = 1;
                }
            }
            $chaine = implode('', array_map(fn ($v) => $v ? '1' : '0', $ligne));
            $score += 40 * (substr_count($chaine, '10111010000') + substr_count($chaine, '00001011101'));
        }
    }
    for ($y = 0; $y < $taille; $y++) {
        for ($x = 0; $x < $taille; $x++) {
            if ($m[$y][$x]) {
                $noirs++;
            }
            if ($x < $taille - 1 && $y < $taille - 1 && $m[$y][$x] === $m[$y][$x + 1] && $m[$y][$x] === $m[$y + 1][$x] && $m[$y][$x] === $m[$y + 1][$x + 1]) {
                $score += 3;
            }
        }
    }
    $total = $taille * $taille;
    $score += 10 * (intdiv(abs($noirs * 20 - $total * 10) + $total - 1, $total) - 1);
    return $score;
}

/** QR code en SVG (avec la marge blanche obligatoire de 4 modules). $couleur : couleur des modules. */
function qr_svg(string $texte, string $couleur = '#1B1410', string $titre = 'QR code'): string
{
    $m = qr_matrice($texte);
    $taille = count($m);
    $tracé = '';
    foreach ($m as $y => $ligne) {
        foreach ($ligne as $x => $noir) {
            if ($noir) {
                $tracé .= 'M' . ($x + 4) . ' ' . ($y + 4) . 'h1v1h-1z';
            }
        }
    }
    $cote = $taille + 8;
    return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ' . $cote . ' ' . $cote . '" shape-rendering="crispEdges" role="img" aria-label="' . htmlspecialchars($titre, ENT_QUOTES) . '">'
        . '<rect width="100%" height="100%" fill="#fff"/><path fill="' . htmlspecialchars($couleur, ENT_QUOTES) . '" d="' . $tracé . '"/></svg>';
}
