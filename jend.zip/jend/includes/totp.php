<?php
declare(strict_types=1);

/**
 * Double authentification par code à usage unique (TOTP, RFC 6238) :
 * compatible Google Authenticator, Microsoft Authenticator, Authy, Aegis, FreeOTP…
 * Code à 6 chiffres, renouvelé toutes les 30 secondes.
 */
const TOTP_PERIODE = 30;
const TOTP_CHIFFRES = 6;

function base32_encoder(string $binaire): string
{
    $alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
    $bits = '';
    foreach (str_split($binaire) as $c) {
        $bits .= str_pad(decbin(ord($c)), 8, '0', STR_PAD_LEFT);
    }
    $sortie = '';
    foreach (str_split($bits, 5) as $morceau) {
        $sortie .= $alphabet[bindec(str_pad($morceau, 5, '0'))];
    }
    return $sortie;
}

function base32_decoder(string $texte): string
{
    $alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
    $bits = '';
    foreach (str_split(strtoupper(preg_replace('/[\s=-]/', '', $texte))) as $c) {
        $p = strpos($alphabet, $c);
        if ($p === false) {
            return '';
        }
        $bits .= str_pad(decbin($p), 5, '0', STR_PAD_LEFT);
    }
    $sortie = '';
    foreach (str_split($bits, 8) as $octet) {
        if (strlen($octet) === 8) {
            $sortie .= chr(bindec($octet));
        }
    }
    return $sortie;
}

function totp_nouveau_secret(): string
{
    return base32_encoder(random_bytes(20));         // 160 bits, taille recommandée
}

/** Code attendu pour un secret (binaire) à un « pas » de 30 s donné. */
function totp_code(string $secretBinaire, int $pas): string
{
    $hmac = hash_hmac('sha1', pack('J', $pas), $secretBinaire, true);
    $o = ord($hmac[19]) & 0x0F;
    $n = ((ord($hmac[$o]) & 0x7F) << 24) | (ord($hmac[$o + 1]) << 16) | (ord($hmac[$o + 2]) << 8) | ord($hmac[$o + 3]);
    return str_pad((string) ($n % (10 ** TOTP_CHIFFRES)), TOTP_CHIFFRES, '0', STR_PAD_LEFT);
}

/**
 * Vérifie un code saisi (tolérance : 30 s avant/après, pour les horloges un peu décalées).
 * Retourne le pas validé (à mémoriser pour interdire la réutilisation), ou null si le code est faux.
 */
function totp_verifier(string $secretBase32, string $saisi, int $dernierPas = 0, ?int $maintenant = null): ?int
{
    $saisi = preg_replace('/\s+/', '', $saisi);
    if (!preg_match('/^\d{6}$/', $saisi)) {
        return null;
    }
    $secret = base32_decoder($secretBase32);
    if ($secret === '') {
        return null;
    }
    $pasActuel = intdiv($maintenant ?? time(), TOTP_PERIODE);
    for ($d = -1; $d <= 1; $d++) {
        $pas = $pasActuel + $d;
        if ($pas > $dernierPas && hash_equals(totp_code($secret, $pas), $saisi)) {
            return $pas;
        }
    }
    return null;
}

/** Adresse à saisir (ou à scanner si on en fait un QR code) dans l'application d'authentification. */
function totp_uri(string $secretBase32, string $compte): string
{
    return 'otpauth://totp/' . rawurlencode('Jënd:' . $compte) . '?secret=' . $secretBase32 . '&issuer=' . rawurlencode('Jënd') . '&digits=6&period=30';
}

/** 8 codes de secours (usage unique) à conserver si le téléphone est perdu : on ne stocke que leur empreinte. */
function codes_secours_generer(int $userId): array
{
    requete('DELETE FROM codes_secours WHERE user_id = ?', [$userId]);
    $codes = [];
    for ($i = 0; $i < 8; $i++) {
        $c = strtoupper(bin2hex(random_bytes(5)));                    // 10 caractères hexadécimaux
        $codes[] = substr($c, 0, 5) . '-' . substr($c, 5);
        requete('INSERT INTO codes_secours (user_id, code_hash) VALUES (?, ?)', [$userId, hash('sha256', str_replace('-', '', strtoupper($c)))]);
    }
    return $codes;
}

/** Consomme un code de secours s'il est valable (une seule fois). */
function code_secours_utiliser(int $userId, string $saisi): bool
{
    $propre = strtoupper(preg_replace('/[^A-Za-z0-9]/', '', $saisi));
    if (!preg_match('/^[0-9A-F]{10}$/', $propre)) {
        return false;
    }
    return requete('UPDATE codes_secours SET utilise = 1 WHERE user_id = ? AND code_hash = ? AND utilise = 0', [$userId, hash('sha256', $propre)])->rowCount() === 1;
}
