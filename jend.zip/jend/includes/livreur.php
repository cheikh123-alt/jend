<?php
declare(strict_types=1);

/**
 * Espace livreur : une « course » est une sous-commande (commande_boutiques) à récupérer chez un vendeur puis à livrer au client.
 * Étapes : affectée (par l'admin) → récupérée → en route → livrée (le livreur saisit le code à 4 chiffres que le client lui donne).
 */

/** Accès réservé aux livreurs. Retourne [utilisateur, fiche livreur]. Les autres voient une page 404. */
function exiger_livreur(bool $autoriserProvisoire = false): array
{
    $u = utilisateur();
    if (!$u) {
        rediriger('livreur/connexion');             // les livreurs se connectent d'abord, sur leur propre page
    }
    $l = $u['role'] === 'livreur' ? requete('SELECT * FROM livreurs WHERE user_id = ?', [$u['id']])->fetch() : null;
    if (!$l) {
        http_response_code(403);
        livreur_entete('Espace livreur — Jënd', '');
        ?>
<div class="app-vide"><i class="ph ph-lock-key"></i><b>Espace réservé aux livreurs</b>
  <p>Vous êtes connecté avec un autre type de compte. Déconnectez-vous, puis connectez-vous avec votre compte livreur.</p></div>
<form method="post" action="<?= e(url('deconnexion')) ?>"><?= csrf_champ() ?><button class="bouton-principal" type="submit"><i class="ph-fill ph-sign-out"></i> Me déconnecter</button></form>
<p class="doux petit-centre"><a class="lien-app" href="<?= e(url()) ?>">Retour à la boutique</a></p>
<?php
        livreur_pied(false);
        exit;
    }
    if (!$autoriserProvisoire && (int) requete('SELECT mdp_provisoire FROM users WHERE id = ?', [$u['id']])->fetchColumn() === 1) {
        flash('Pour votre sécurité, choisissez un nouveau mot de passe personnel avant de continuer.', 'erreur');
        rediriger('livreur/mot-de-passe');
    }
    return [$u, $l];
}

/** Sélection commune d'une course avec tout ce dont le livreur et l'admin ont besoin. */
const SQL_COURSE = "SELECT cb.id, cb.statut, cb.sous_total, cb.livreur_id, cb.affecte_le, cb.recupere_le, cb.en_route_le, cb.livre_le, cb.boutique_id, cb.livre_par, cb.frais_part, cb.acompte_part,
        b.nom AS boutique, uv.telephone AS tel_vendeur,
        c.id AS commande_id, c.reference, c.created_at, c.statut AS statut_commande, c.statut_paiement, c.methode_paiement, c.acompte, c.frais_livraison,
        c.livraison_nom, c.livraison_telephone, c.livraison_zone, c.livraison_adresse, c.livraison_lat, c.livraison_lng,
        (cb.id = (SELECT MIN(x.id) FROM commande_boutiques x WHERE x.commande_id = c.id)) AS porte_frais,
        ul.nom AS livreur_nom, ul.telephone AS livreur_tel
   FROM commande_boutiques cb
   JOIN commandes c ON c.id = cb.commande_id
   JOIN boutiques b ON b.id = cb.boutique_id
   JOIN users uv ON uv.id = b.user_id
   LEFT JOIN users ul ON ul.id = cb.livreur_id";

/** Montant que le livreur doit encaisser en espèces : produits + part du frais de livraison − acompte déjà payé en ligne (paiement à la livraison seulement). */
function course_a_encaisser(array $c): int
{
    if ($c['methode_paiement'] !== 'livraison') {
        return 0;
    }
    return max(0, (int) $c['sous_total'] + (int) $c['frais_part'] - (int) $c['acompte_part']);
}

/** Étape de la course : annulee | affectee | recuperee | en_route | livree. */
function course_etape(array $c): string
{
    if ($c['statut_commande'] === 'annulee' || in_array($c['statut'], ['annulee', 'retournee'], true)) {
        return 'annulee';
    }
    if ($c['statut'] === 'livree') {
        return 'livree';
    }
    if ($c['en_route_le'] !== null) {
        return 'en_route';
    }
    return $c['recupere_le'] !== null ? 'recuperee' : 'affectee';
}

const ETAPES_COURSE = ['affectee' => 'À récupérer', 'recuperee' => 'Récupérée', 'en_route' => 'En route', 'livree' => 'Livrée', 'annulee' => 'Annulée'];

/** Une course est-elle affectable / ré-affectable ? Renvoie un message d'erreur, ou null si c'est possible. */
function course_non_affectable(array $c): ?string
{
    if ($c['livre_par'] !== 'jend') {
        return 'Cette boutique livre elle-même ses commandes : aucun livreur Jënd à affecter.';
    }
    if ($c['statut_commande'] === 'annulee' || $c['statut'] !== 'a_preparer' && $c['statut'] !== 'expediee') {
        return 'Cette livraison est terminée ou annulée.';
    }
    if (!commande_engagee($c)) {
        return 'Le client n\'a pas encore payé : attendez la confirmation du paiement.';
    }
    if ($c['recupere_le'] !== null) {
        return 'Le livreur a déjà récupéré le colis : on ne peut plus changer de livreur.';
    }
    return null;
}

/** Affecte (ou ré-affecte) une course à un livreur actif. @throws RuntimeException message affichable */
function course_affecter(int $sousCommandeId, int $livreurId): void
{
    $liv = requete("SELECT u.id FROM users u JOIN livreurs l ON l.user_id = u.id WHERE u.id = ? AND u.role = 'livreur' AND u.actif = 1", [$livreurId])->fetch();
    if (!$liv) {
        throw new RuntimeException('Livreur introuvable ou désactivé.');
    }
    $pdo = pdo();
    $pdo->beginTransaction();
    try {
        $c = requete(SQL_COURSE . ' WHERE cb.id = ? FOR UPDATE', [$sousCommandeId])->fetch();
        if (!$c) {
            throw new RuntimeException('Livraison introuvable.');
        }
        if ($msg = course_non_affectable($c)) {
            throw new RuntimeException($msg);
        }
        requete('UPDATE commande_boutiques SET livreur_id = ?, affecte_le = NOW() WHERE id = ?', [$livreurId, $sousCommandeId]);
        $pdo->commit();
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        throw $e;
    }
}

/**
 * Fait avancer une course : action = recuperer | en_route | livrer.
 * « livrer » exige le code à 4 chiffres donné par le client (même contrôle et mêmes limites d'essais que pour un vendeur).
 * @throws RuntimeException message affichable
 */
function course_avancer(int $sousCommandeId, int $livreurId, string $action, ?string $code = null): void
{
    $c = requete(SQL_COURSE . ' WHERE cb.id = ? AND cb.livreur_id = ?', [$sousCommandeId, $livreurId])->fetch();
    if (!$c) {
        throw new RuntimeException('Course introuvable.');
    }
    $etape = course_etape($c);
    if ($etape === 'annulee') {
        throw new RuntimeException('Cette commande a été annulée : ne livrez pas ce colis.');
    }
    if ($etape === 'livree') {
        throw new RuntimeException('Cette course est déjà livrée.');
    }
    if (!commande_engagee($c)) {
        throw new RuntimeException('Le client n\'a pas encore payé : attendez la confirmation du paiement.');
    }

    if ($action === 'recuperer') {
        if ($etape !== 'affectee') {
            throw new RuntimeException('Ce colis est déjà récupéré.');
        }
        if ($c['statut'] === 'a_preparer') {
            sous_commande_avancer($sousCommandeId, (int) $c['boutique_id'], null);     // le colis part : « expédiée »
        }
        requete('UPDATE commande_boutiques SET recupere_le = NOW() WHERE id = ? AND recupere_le IS NULL', [$sousCommandeId]);
    } elseif ($action === 'en_route') {
        if ($etape !== 'recuperee') {
            throw new RuntimeException($etape === 'affectee' ? 'Récupérez d\'abord le colis chez le vendeur.' : 'Vous êtes déjà en route.');
        }
        requete('UPDATE commande_boutiques SET en_route_le = NOW() WHERE id = ? AND en_route_le IS NULL', [$sousCommandeId]);
        suivi_prevenir_client((int) $c['commande_id'], 'en_route');
    } elseif ($action === 'livrer') {
        if ($etape !== 'en_route') {
            throw new RuntimeException('Passez d\'abord la course « en route ».');
        }
        sous_commande_avancer($sousCommandeId, (int) $c['boutique_id'], null, $code, true);
    } else {
        throw new RuntimeException('Action inconnue.');
    }
}

/**
 * Espèces des livreurs Jënd : encaissé (reste à payer des courses livrées, paiement à la livraison), remis à Jënd (caisse), reste à remettre.
 * Sans argument : tous les livreurs, indexés par identifiant.
 */
function livreur_especes(?int $livreurId = null): array
{
    $filtre = $livreurId !== null ? ' AND cb.livreur_id = ' . (int) $livreurId : '';
    $res = [];
    foreach (requete("SELECT cb.livreur_id AS id, COALESCE(SUM(GREATEST(0, CAST(cb.sous_total AS SIGNED) + cb.frais_part - cb.acompte_part)), 0) AS encaisse
                        FROM commande_boutiques cb JOIN commandes c ON c.id = cb.commande_id
                       WHERE cb.statut = 'livree' AND c.methode_paiement = 'livraison' AND cb.livre_par = 'jend' AND cb.livreur_id IS NOT NULL$filtre GROUP BY cb.livreur_id")->fetchAll() as $l) {
        $res[(int) $l['id']] = ['encaisse' => (int) $l['encaisse'], 'remis' => 0];
    }
    foreach (requete('SELECT livreur_id AS id, COALESCE(SUM(montant), 0) AS remis FROM caisse_livreurs' . ($livreurId !== null ? ' WHERE livreur_id = ' . (int) $livreurId : '') . ' GROUP BY livreur_id')->fetchAll() as $l) {
        $res[(int) $l['id']] = ['encaisse' => $res[(int) $l['id']]['encaisse'] ?? 0, 'remis' => (int) $l['remis']];
    }
    foreach ($res as $id => $v) {
        $res[$id]['a_remettre'] = max(0, $v['encaisse'] - $v['remis']);
    }
    if ($livreurId !== null) {
        return $res[$livreurId] ?? ['encaisse' => 0, 'remis' => 0, 'a_remettre' => 0];
    }
    return $res;
}

/** Lien WhatsApp (wa.me) avec un message prêt à envoyer. Le téléphone du client n'y figure pas : il reste dans l'appli. */
function course_lien_whatsapp(array $c): ?string
{
    $tel = preg_replace('/\D/', '', (string) ($c['livreur_tel'] ?? ''));
    if ($tel === '') {
        return null;
    }
    $encaisser = course_a_encaisser($c);
    $msg = "Jënd — nouvelle course\n"
        . "Commande : {$c['reference']}\n"
        . "À récupérer chez : {$c['boutique']}\n"
        . "Livrer à : {$c['livraison_nom']} — {$c['livraison_zone']}, {$c['livraison_adresse']}\n"
        . ($encaisser > 0 ? 'À encaisser : ' . fcfa($encaisser) . "\n" : "Déjà payé en ligne.\n")
        . 'Détails : ' . app_url('livreur/course/' . $c['id']);
    return 'https://wa.me/' . $tel . '?text=' . rawurlencode($msg);
}

/** « à l'instant », « il y a 12 min », « il y a 3 h », « hier », « il y a 4 j » */
function il_y_a(?string $dateHeure): string
{
    if (!$dateHeure) {
        return '';
    }
    $d = max(0, time() - (int) strtotime($dateHeure));
    if ($d < 90) {
        return 'à l\'instant';
    }
    if ($d < 3600) {
        return 'il y a ' . intdiv($d, 60) . ' min';
    }
    if ($d < 86400) {
        return 'il y a ' . intdiv($d, 3600) . ' h';
    }
    return $d < 172800 ? 'hier' : 'il y a ' . intdiv($d, 86400) . ' j';
}

/** Heure ou date courte pour la chronologie : « 14:05 » aujourd'hui, « 07/10 14:05 » sinon. */
function heure_courte(?string $dateHeure): string
{
    if (!$dateHeure) {
        return '';
    }
    $t = (int) strtotime($dateHeure);
    return date('Y-m-d', $t) === date('Y-m-d') ? date('H:i', $t) : date('d/m H:i', $t);
}

/** Identifiants des courses en cours d'un livreur (sert au badge des onglets et au rafraîchissement automatique). */
function courses_actives_ids(int $livreurId): array
{
    return array_map('intval', requete(
        "SELECT cb.id FROM commande_boutiques cb JOIN commandes c ON c.id = cb.commande_id
          WHERE cb.livreur_id = ? AND cb.statut IN ('a_preparer', 'expediee') AND c.statut <> 'annulee' ORDER BY cb.id",
        [$livreurId]
    )->fetchAll(PDO::FETCH_COLUMN));
}

/** Lien d'itinéraire (Google Maps) : vers le point GPS donné par le client s'il existe, sinon vers l'adresse écrite. */
function lien_itineraire(array $c): string
{
    if (isset($c['livraison_lat'], $c['livraison_lng'])) {
        return lien_gps($c['livraison_lat'], $c['livraison_lng']);
    }
    return 'https://www.google.com/maps/search/?api=1&query=' . rawurlencode($c['livraison_adresse'] . ', ' . $c['livraison_zone'] . ', Sénégal');
}

/**
 * Début de page de l'appli livreur (habillage propre, sans l'en-tête de la boutique).
 * @param string $actif  courses | historique | profil ('' : page de détail, sans barre d'onglets)
 * @param ?string $retour adresse du bouton « retour » (pages de détail)
 */
function livreur_entete(string $titre, string $actif, ?string $retour = null): void
{
    $u = utilisateur();
    $l = $u ? requete('SELECT disponible FROM livreurs WHERE user_id = ?', [$u['id']])->fetch() : null;
    $ids = $u ? courses_actives_ids((int) $u['id']) : [];
    $message = flash_lire();
    $GLOBALS['livreur_actif'] = $actif;
    $GLOBALS['livreur_nb'] = count($ids);
    ?>
<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<title><?= e($titre) ?></title>
<meta name="robots" content="noindex, nofollow">
<meta name="base" content="<?= e(url()) ?>">
<meta name="theme-color" content="#C2471F">
<link rel="manifest" href="<?= e(url('manifest.webmanifest')) ?>">
<link rel="apple-touch-icon" href="<?= e(asset('img/apple-touch-icon.png')) ?>">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
<meta name="apple-mobile-web-app-title" content="Jënd Livreur">
<link rel="stylesheet" href="<?= e(asset('vendor/css/fontshare.css')) ?>">
<link rel="stylesheet" href="<?= e(asset('vendor/css/phosphor-regular.css')) ?>">
<link rel="stylesheet" href="<?= e(asset('vendor/css/phosphor-fill.css')) ?>">
<link rel="stylesheet" href="<?= e(asset('css/livreur.css')) ?>">
</head>
<body class="app" data-courses="<?= e(implode(',', $ids)) ?>">
<header class="app-barre">
  <?php if ($retour): ?>
    <a class="app-retour" href="<?= e($retour) ?>" aria-label="Retour"><i class="ph ph-arrow-left"></i></a>
  <?php endif; ?>
  <span class="app-logo">Jënd<span>.</span> <small>Livreur</small></span>
  <?php if ($l): ?><a class="app-etat <?= $l['disponible'] ? 'dispo' : '' ?>" href="<?= e(url('livreur')) ?>"><i class="ph-fill ph-circle"></i> <?= $l['disponible'] ? 'Disponible' : 'Indisponible' ?></a><?php endif; ?>
</header>
<?php if (est_test()): ?><div class="app-test"><i class="ph-fill ph-flask"></i> Site de test : aucune vraie livraison</div><?php endif; ?>
<?php if ($message): ?><div class="app-flash app-flash-<?= e($message['type']) ?>" role="status"><?= e($message['message']) ?></div><?php endif; ?>
<main class="app-contenu">
<?php
}

/** Fin de page de l'appli livreur : barre d'onglets du bas (si $afficherOnglets) et scripts. */
function livreur_pied(bool $afficherOnglets = true): void
{
    $actif = $GLOBALS['livreur_actif'] ?? '';
    $nb = (int) ($GLOBALS['livreur_nb'] ?? 0);
    ?>
</main>
<?php if ($afficherOnglets): ?>
<nav class="app-onglets" aria-label="Navigation">
  <?php foreach (['courses' => ['livreur', 'ph-motorcycle', 'Courses'], 'historique' => ['livreur/historique', 'ph-clock-counter-clockwise', 'Historique'], 'profil' => ['livreur/profil', 'ph-user-circle', 'Profil']] as $cle => [$chemin, $icone, $libelle]): ?>
    <a href="<?= e(url($chemin)) ?>" class="<?= $cle === $actif ? 'actif' : '' ?>" <?= $cle === $actif ? 'aria-current="page"' : '' ?>>
      <i class="<?= $cle === $actif ? 'ph-fill' : 'ph' ?> <?= e($icone) ?>"></i><span><?= e($libelle) ?></span>
      <?php if ($cle === 'courses' && $nb > 0): ?><b class="app-pastille"><?= $nb ?></b><?php endif; ?>
    </a>
  <?php endforeach; ?>
</nav>
<?php endif; ?>
<div class="app-toast" id="toast" role="status" aria-live="polite" hidden></div>
<script src="<?= e(asset('js/livreur.js')) ?>"></script>
</body>
</html>
<?php
}
