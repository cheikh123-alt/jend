<?php
declare(strict_types=1);

/**
 * Marketing : on retient d'où vient chaque visiteur (lien partagé sur WhatsApp, statut, lien de paiement, affiche QR, TikTok…),
 * pour savoir quels canaux amènent vraiment des commandes (Administration → Croissance).
 * Aucune donnée personnelle : seulement le nom du canal, gardé dans la session puis copié sur l'inscription et la commande.
 */

const SOURCES_MARKETING = [
    'whatsapp'  => 'Partage WhatsApp',
    'statut'    => 'Images de statut',
    'lien'      => 'Lien de paiement',
    'affiche'   => 'Affiche / QR code',
    'tiktok'    => 'TikTok',
    'facebook'  => 'Facebook',
    'instagram' => 'Instagram',
    'google'    => 'Google',
    'parrain'   => 'Parrainage vendeur',
    'autre'     => 'Autre site',
    'direct'    => 'Direct / inconnu',
];

/** Ajoute le canal à une adresse du site : lien_source(app_url('boutique/x'), 'whatsapp') → …?src=whatsapp */
function lien_source(string $url, string $source): string
{
    return $url . (str_contains($url, '?') ? '&' : '?') . 'src=' . rawurlencode($source);
}

/** À chaque visite : retient le PREMIER canal connu de la session (paramètre ?src=, sinon le site d'où l'on vient). */
function source_memoriser(): void
{
    if (!empty($_SESSION['source'])) {
        return;
    }
    $src = strtolower((string) ($_GET['src'] ?? $_GET['utm_source'] ?? ''));
    if ($src !== '' && preg_match('/^[a-z0-9_-]{2,30}$/', $src)) {
        $_SESSION['source'] = isset(SOURCES_MARKETING[$src]) ? $src : 'autre';
        return;
    }
    $ref = strtolower((string) parse_url((string) ($_SERVER['HTTP_REFERER'] ?? ''), PHP_URL_HOST));
    if ($ref === '' || $ref === strtolower((string) parse_url(app_url(''), PHP_URL_HOST))) {
        return;                                    // pas d'information (ou navigation interne) : on attend
    }
    foreach (['tiktok' => 'tiktok.com', 'facebook' => 'facebook.com', 'instagram' => 'instagram.com', 'google' => 'google.', 'whatsapp' => 'whatsapp.'] as $cle => $motif) {
        if (str_contains($ref, $motif)) {
            $_SESSION['source'] = $cle;
            return;
        }
    }
    $_SESSION['source'] = 'autre';
}

/** Canal de la session courante (« direct » si inconnu). */
function source_courante(): string
{
    return (string) ($_SESSION['source'] ?? 'direct');
}
