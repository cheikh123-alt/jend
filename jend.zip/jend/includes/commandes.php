<?php
declare(strict_types=1);

/**
 * Crée une commande à partir du panier (session), en une seule transaction.
 * - les prix et le stock sont relus en base (jamais ceux du navigateur) ;
 * - une sous-commande par boutique, avec la commission de Jënd ;
 * - le stock est décrémenté, et tout est annulé en cas de problème.
 *
 * @throws RuntimeException message affichable au client
 * @return string référence de la commande
 */
/** SQL : commande qui attend un paiement en ligne (paiement complet ou acompte). Alias de la table : c. */
const SQL_EN_ATTENTE_PAIEMENT = "(c.statut = 'en_attente' AND c.statut_paiement IN ('en_attente', 'echoue') AND (c.methode_paiement <> 'livraison' OR c.acompte > 0))";
const COMMANDES_EN_ATTENTE_MAX = 5;              // par client : empêche de bloquer tout le stock avec des commandes jamais payées
const COMMANDE_EXPIRATION_HEURES = 48;

/**
 * Libère le stock des commandes jamais payées depuis plus de 48 h (annulées et remises en stock).
 * Appelée au passage des clients (pas de tâche planifiée sur l'hébergement gratuit), au plus une fois toutes les 10 minutes.
 * Si le client paie quand même plus tard, le paiement est signalé à l'administrateur comme « à rembourser ».
 */
function commandes_expirer(): void
{
    if (limite_atteinte('maintenance:expiration', 1, 600)) {
        return;
    }
    limite_enregistrer('maintenance:expiration');
    $ids = requete(
        "SELECT c.id FROM commandes c
          WHERE " . SQL_EN_ATTENTE_PAIEMENT . " AND c.created_at < (NOW() - INTERVAL " . COMMANDE_EXPIRATION_HEURES . " HOUR)
            AND NOT EXISTS (SELECT 1 FROM commande_boutiques cb WHERE cb.commande_id = c.id AND cb.statut <> 'a_preparer')
          LIMIT 50"
    )->fetchAll(PDO::FETCH_COLUMN);
    foreach ($ids as $id) {
        $pdo = pdo();
        $pdo->beginTransaction();
        try {
            $c = requete('SELECT c.id FROM commandes c WHERE c.id = ? AND ' . SQL_EN_ATTENTE_PAIEMENT . ' FOR UPDATE', [$id])->fetch();
            if ($c) {
                stock_restituer('cb.commande_id = ?', [$id]);
                requete("UPDATE commandes SET statut = 'annulee' WHERE id = ?", [$id]);
                requete("UPDATE commande_boutiques SET statut = 'annulee' WHERE commande_id = ?", [$id]);
                requete("UPDATE paiements SET statut = 'echoue' WHERE commande_id = ? AND statut = 'initie'", [$id]);
            }
            $pdo->commit();
        } catch (Throwable $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            error_log('Jënd — expiration de commande échouée : ' . $e->getMessage());
        }
    }
}

function commande_creer(int $clientId, array $adresse, array $zone, string $methode, ?string $acompteMethode = null): string
{
    $panier = $_SESSION['panier'] ?? [];
    if (!$panier) {
        throw new RuntimeException('Votre panier est vide.');
    }
    if ($methode !== 'livraison' && function_exists('paiement_en_ligne_actif') && !paiement_en_ligne_actif()) {
        throw new RuntimeException('Le paiement en ligne est momentanément indisponible : choisissez le paiement à la livraison.');
    }
    if ($methode === 'livraison' && function_exists('paiement_livraison_actif') && !paiement_livraison_actif()) {
        throw new RuntimeException('Le paiement à la livraison n\'est pas proposé pour le moment. Choisissez un paiement en ligne (Wave, Orange Money, carte).');
    }
    commandes_expirer();
    // Anti-abus : trop de commandes jamais payées, ou trop de commandes en peu de temps
    $enAttente = (int) requete('SELECT COUNT(*) FROM commandes c WHERE c.client_id = ? AND ' . SQL_EN_ATTENTE_PAIEMENT, [$clientId])->fetchColumn();
    if ($enAttente >= COMMANDES_EN_ATTENTE_MAX) {
        throw new RuntimeException('Vous avez déjà ' . COMMANDES_EN_ATTENTE_MAX . ' commandes en attente de paiement. Réglez-les (ou annulez-les) avant d\'en passer une nouvelle.');
    }
    if (limite_atteinte('commande:client:' . $clientId, 15, 3600) || limite_atteinte('commande:ip:' . ip_client(), 30, 3600)) {
        throw new RuntimeException('Trop de commandes en peu de temps. Réessayez dans un moment.');
    }
    limite_enregistrer('commande:client:' . $clientId);
    limite_enregistrer('commande:ip:' . ip_client());

    $pdo = pdo();
    $pdo->beginTransaction();
    try {
        $ids = array_values(array_unique(array_map(fn ($c) => panier_cle_lire($c)[0], array_keys($panier))));
        sort($ids);                                   // ordre fixe : évite les blocages entre commandes simultanées
        $in = implode(',', array_fill(0, count($ids), '?'));
        $produits = requete(
            "SELECT p.id, p.nom, p.prix, p.option_type, " . SQL_PROMO_FETE . " AS promo_pct, p.stock, p.boutique_id, IF(b.commission_gratuite_jusqu IS NOT NULL AND b.commission_gratuite_jusqu >= CURDATE(), 0, b.commission_pct) AS commission_pct, b.livraison_par
               FROM produits p JOIN boutiques b ON b.id = p.boutique_id AND b.statut = 'active'
              WHERE p.id IN ($in) AND p.statut = 'publie' AND (p.reserve_client_id IS NULL OR p.reserve_client_id = " . (int) $clientId . ")
              ORDER BY p.id FOR UPDATE",
            $ids
        )->fetchAll();

        $parId = [];
        foreach ($produits as $p) {
            $parId[(int) $p['id']] = $p;
        }

        // Tailles / pointures : verrouillées comme les produits (deux clients ne peuvent pas prendre la dernière taille M)
        $variantes = [];
        $avecTailles = [];
        foreach (requete("SELECT id, produit_id, libelle, stock FROM produit_variantes WHERE produit_id IN ($in) ORDER BY id FOR UPDATE", $ids)->fetchAll() as $v) {
            $variantes[(int) $v['id']] = $v;
            $avecTailles[(int) $v['produit_id']] = true;
        }

        $offres = offres_valides($clientId);         // prix négociés acceptés par les vendeurs (relus en base)
        $offresUtilisees = [];
        $parBoutique = [];
        $sousTotal = 0;
        foreach ($panier as $cle => $qte) {
            [$id, $vid] = panier_cle_lire($cle);
            $p = $parId[$id] ?? null;
            $qte = (int) $qte;
            $v = $vid ? ($variantes[$vid] ?? null) : null;
            if ($p && ($vid ? (!$v || (int) $v['produit_id'] !== $id) : isset($avecTailles[$id]))) {
                throw new RuntimeException('Choisissez la ' . mb_strtolower(option_libelle($p['option_type'])) . ' de « ' . $p['nom'] . ' » : retirez-le du panier puis ajoutez-le depuis sa page.');
            }
            if (!$p || $qte < 1 || (int) $p['stock'] < $qte || ($v && (int) $v['stock'] < $qte)) {
                throw new RuntimeException('« ' . ($p['nom'] ?? 'Un produit') . ($v ? ' (' . option_libelle($p['option_type']) . ' ' . $v['libelle'] . ')' : '') . ' » n\'est plus disponible en quantité suffisante. Vérifiez votre panier.');
            }
            $p['variante_id'] = $v ? (int) $v['id'] : null;
            $p['variante_libelle'] = $v ? option_libelle($p['option_type']) . ' : ' . $v['libelle'] : null;
            $p['prix'] = prix_promo((int) $p['prix'], (int) $p['promo_pct']);      // promotion de fête en cours (relue en base)
            $prixUnitaire = offre_prix_applique($offres, (int) $p['id'], $qte, (int) $p['prix']);
            if ($prixUnitaire < (int) $p['prix']) {            // l'offre acceptée n'est utilisée que si elle est plus avantageuse que la promotion
                $offresUtilisees[] = $offres[(int) $p['id']]['id'];
                $p['prix'] = $prixUnitaire;                    // c'est ce prix qui est enregistré dans la commande
            }
            $ligne = $qte * (int) $p['prix'];
            $sousTotal += $ligne;
            $parBoutique[(int) $p['boutique_id']]['commission_pct'] = (float) $p['commission_pct'];
            // les livreurs Jënd ne sont utilisés que si l'administrateur a activé la fonction ; sinon chaque vendeur livre lui-même
            $parBoutique[(int) $p['boutique_id']]['livraison_par'] = ($p['livraison_par'] === 'jend' && livreurs_jend_actifs()) ? 'jend' : 'vendeur';
            $parBoutique[(int) $p['boutique_id']]['lignes'][] = ['p' => $p, 'qte' => $qte, 'total' => $ligne];
        }

        // Chaque boutique choisit les régions où elle livre : on ne laisse pas passer une commande qu'elle ne peut pas honorer
        foreach ($parBoutique as $bid => $b) {
            if (!boutique_livre_vers((int) $bid, (string) ($zone['region'] ?? ''))) {
                $nom = (string) requete('SELECT nom FROM boutiques WHERE id = ?', [$bid])->fetchColumn();
                throw new RuntimeException('« ' . $nom . ' » ne livre pas à ' . ($zone['region'] ?? 'cette zone') . ' (elle livre à : ' . implode(', ', boutique_regions((int) $bid)) . '). Choisissez une autre zone ou retirez ses produits du panier.');
            }
        }

        // Un vendeur qui doit trop de commissions à Jënd (sur ses ventes en espèces) ne peut plus recevoir de commandes en espèces
        $detteMax = (int) (function_exists('parametre') ? parametre('dette_commission_max', '20000') : 20000);
        if ($methode === 'livraison' && $detteMax > 0) {
            foreach ($parBoutique as $bid => $b) {
                if ($b['livraison_par'] === 'vendeur' && vendeur_gains((int) $bid)['dette'] > $detteMax) {
                    $nom = (string) requete('SELECT nom FROM boutiques WHERE id = ?', [$bid])->fetchColumn();
                    throw new RuntimeException('Le paiement à la livraison n\'est pas disponible pour « ' . $nom . ' » pour le moment. Choisissez un paiement en ligne (Wave, Orange Money, carte).');
                }
            }
        }
        // Chaque boutique livre et facture sa propre livraison, selon SES frais pour cette zone (sinon les frais de référence)
        $propres = frais_boutiques(array_keys($parBoutique));
        $frais = 0;
        foreach ($parBoutique as $bid => $b) {
            $parBoutique[$bid]['frais'] = frais_livraison((int) $bid, $zone, $b['livraison_par'] === 'jend', $propres)['frais'];
            $frais += $parBoutique[$bid]['frais'];
        }
        $fraisService = $methode === 'livraison' ? 0 : frais_service($sousTotal + $frais);     // frais de paiement sécurisé (0 par défaut)
        $total = $sousTotal + $frais + $fraisService;
        // Paiement à la livraison : un acompte est réglé en ligne d'abord (anti-refus et commandes fantaisistes), le reste en espèces à la réception
        $acompte = $methode === 'livraison' ? acompte_calculer($total) : 0;
        if ($acompte > 0 && !in_array($acompteMethode, METHODES_EN_LIGNE, true)) {
            throw new RuntimeException('Choisissez le moyen de paiement de l\'acompte (Wave, Orange Money, Free Money ou carte).');
        }

        // Référence unique : on réessaie dans le cas (très rare) d'une collision
        $reference = null;
        for ($essai = 0; $essai < 5 && $reference === null; $essai++) {
            $ref = 'JND-' . date('ymd') . '-' . strtoupper(bin2hex(random_bytes(2)));
            if (!requete('SELECT 1 FROM commandes WHERE reference = ?', [$ref])->fetch()) {
                $reference = $ref;
            }
        }
        if ($reference === null) {
            throw new RuntimeException('Impossible de créer la commande, réessayez.');
        }

        requete(
            'INSERT INTO commandes (reference, client_id, livraison_nom, livraison_telephone, livraison_zone, livraison_adresse,
                                    sous_total, frais_livraison, frais_service, total, methode_paiement, statut_paiement, statut, acompte, acompte_methode)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
            [$reference, $clientId, $adresse['nom'], $adresse['telephone'], $zone['nom'], $adresse['adresse'],
             $sousTotal, $frais, $fraisService, $total, $methode, 'en_attente', ($methode === 'livraison' && $acompte === 0) ? 'confirmee' : 'en_attente',
             $acompte, $acompte > 0 ? $acompteMethode : null]
        );
        $commandeId = (int) $pdo->lastInsertId();

        // Chaque livraison porte ses propres frais ; ils reviennent au vendeur s'il livre lui-même (à Jënd si c'est un livreur Jënd)
        $rang = 0;
        $acompteRepartit = 0;
        foreach ($parBoutique as $boutiqueId => $b) {
            $partB = (int) $b['frais'];
            $sousTotalB  = array_sum(array_column($b['lignes'], 'total'));
            $commission  = (int) round($sousTotalB * $b['commission_pct'] / 100);
            // l'acompte est réparti au prorata de ce que chaque livraison représente dans le total (le reste d'arrondi va à la première)
            $acompteB = $acompte > 0 ? intdiv($acompte * ($sousTotalB + $partB), max(1, $total)) : 0;
            $acompteRepartit += $acompteB;
            if ($rang === count($parBoutique) - 1 || count($parBoutique) === 1) {
                $acompteB += $acompte - $acompteRepartit;       // la dernière livraison absorbe l'arrondi : la somme est exacte
                $acompteRepartit = $acompte;
            }
            $rang++;
            requete(
                'INSERT INTO commande_boutiques (commande_id, boutique_id, sous_total, commission, net_vendeur, code_livraison, livre_par, frais_part, acompte_part) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)',
                [$commandeId, $boutiqueId, $sousTotalB, $commission, $sousTotalB - $commission, sprintf('%04d', random_int(0, 9999)), $b['livraison_par'], $partB, $acompteB]
            );
            $cbId = (int) $pdo->lastInsertId();

            foreach ($b['lignes'] as $l) {
                requete(
                    'INSERT INTO commande_lignes (commande_boutique_id, produit_id, nom, prix_unitaire, quantite, variante_id, variante_libelle) VALUES (?, ?, ?, ?, ?, ?, ?)',
                    [$cbId, $l['p']['id'], $l['p']['nom'], $l['p']['prix'], $l['qte'], $l['p']['variante_id'], $l['p']['variante_libelle']]
                );
                $maj = requete('UPDATE produits SET stock = stock - ? WHERE id = ? AND stock >= ?', [$l['qte'], $l['p']['id'], $l['qte']]);
                if ($maj->rowCount() !== 1) {
                    throw new RuntimeException('Stock insuffisant pour « ' . $l['p']['nom'] . ' ».');
                }
                if ($l['p']['variante_id'] && requete('UPDATE produit_variantes SET stock = stock - ? WHERE id = ? AND stock >= ?', [$l['qte'], $l['p']['variante_id'], $l['qte']])->rowCount() !== 1) {
                    throw new RuntimeException('Stock insuffisant pour « ' . $l['p']['nom'] . ' » (' . $l['p']['variante_libelle'] . ').');
                }
            }
        }

        foreach ($offresUtilisees as $oid) {            // une offre ne sert qu'une fois
            requete("UPDATE offres SET statut = 'utilisee' WHERE id = ? AND client_id = ? AND statut = 'acceptee'", [$oid, $clientId]);
        }
        requete('INSERT INTO paiements (commande_id, methode, montant, statut) VALUES (?, ?, ?, ?)', [$commandeId, $acompte > 0 ? $acompteMethode : $methode, $acompte > 0 ? $acompte : $total, 'initie']);

        $pdo->commit();
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        if ($e instanceof RuntimeException) {
            throw $e;
        }
        error_log('Jënd — création de commande échouée : ' . $e->getMessage());
        throw new RuntimeException('Une erreur est survenue, votre commande n\'a pas été enregistrée. Réessayez.');
    }

    unset($_SESSION['panier']);
    return $reference;
}

/** Une commande peut être annulée par le client tant qu'elle n'est ni payée ni expédiée. */
function commande_annulable(array $commande, array $sousCommandes): bool
{
    if (!in_array($commande['statut'], ['en_attente', 'confirmee'], true) || $commande['statut_paiement'] === 'paye') {      // avec acompte payé, l'annulation est possible tant que rien n'est préparé (remboursement de l'acompte par l'administrateur)
        return false;
    }
    foreach ($sousCommandes as $sc) {
        if ($sc['statut'] !== 'a_preparer') {
            return false;
        }
    }
    return true;
}

/**
 * Annule la commande d'un client et remet les produits en stock (une seule transaction).
 * @throws RuntimeException message affichable
 */
function commande_annuler(string $reference, int $clientId): void
{
    $pdo = pdo();
    $pdo->beginTransaction();
    try {
        $c = requete('SELECT id, statut, statut_paiement FROM commandes WHERE reference = ? AND client_id = ? FOR UPDATE', [$reference, $clientId])->fetch();
        if (!$c) {
            throw new RuntimeException('Commande introuvable.');
        }
        $sous = requete('SELECT statut FROM commande_boutiques WHERE commande_id = ?', [$c['id']])->fetchAll();
        if (!commande_annulable($c, $sous)) {
            throw new RuntimeException('Cette commande ne peut plus être annulée. Contactez le support.');
        }

        // Remet en stock chaque produit commandé
        stock_restituer('cb.commande_id = ?', [$c['id']]);
        requete("UPDATE commandes SET statut = 'annulee' WHERE id = ?", [$c['id']]);
        requete("UPDATE commande_boutiques SET statut = 'annulee' WHERE commande_id = ?", [$c['id']]);
        requete("UPDATE paiements SET statut = 'echoue' WHERE commande_id = ? AND statut = 'initie'", [$c['id']]);
        $pdo->commit();
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        if ($e instanceof RuntimeException) {
            throw $e;
        }
        error_log('Jënd — annulation échouée : ' . $e->getMessage());
        throw new RuntimeException('Une erreur est survenue, réessayez.');
    }
}
