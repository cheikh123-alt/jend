<?php
declare(strict_types=1);

/**
 * Prévenir le vendeur d'une nouvelle commande à préparer, même s'il n'est pas connecté :
 *  - notification sur son téléphone (includes/push.php) : « 🛍️ Nouvelle commande — 2 × Boubou bazin » ;
 *  - e-mail avec le détail et le lien vers ses commandes ;
 *  - si rien n'est fait après RELANCE_HEURES, la commande apparaît dans Administration → Relances (WhatsApp / appel de l'équipe).
 * Une seule fois par commande : la colonne commande_boutiques.vendeur_prevenu_le est réservée avant l'envoi.
 * Seulement quand le vendeur doit préparer : commande payée, acompte payé, ou paiement à la livraison sans acompte.
 */

const RELANCE_HEURES = 2;                       // commande payée non expédiée depuis… → à relancer par l'équipe

/** Articles d'une sous-commande en texte court : « 2 × Boubou bazin, 1 × Sac en cuir… » */
function prevenir_articles(int $sousCommandeId, int $max = 3): string
{
    $lignes = requete('SELECT nom, quantite, variante_libelle FROM commande_lignes WHERE commande_boutique_id = ? ORDER BY id', [$sousCommandeId])->fetchAll();
    $txt = array_map(fn ($l) => (int) $l['quantite'] . ' × ' . $l['nom'] . ($l['variante_libelle'] ? ' (' . $l['variante_libelle'] . ')' : ''), array_slice($lignes, 0, $max));
    return implode(', ', $txt) . (count($lignes) > $max ? '…' : '');
}

/** Prévient les vendeurs d'une commande (ceux qui ne l'ont pas encore été). Retourne le nombre de vendeurs prévenus. */
function vendeur_prevenir_commande(int $commandeId): int
{
    $sous = requete(
        "SELECT cb.id, cb.sous_total, cb.net_vendeur, cb.frais_part, cb.acompte_part, cb.livre_par, c.reference, c.livraison_zone, c.methode_paiement,
                b.nom AS boutique, b.mode_simple, u.id AS user_id, u.email, u.nom
           FROM commande_boutiques cb JOIN commandes c ON c.id = cb.commande_id
           JOIN boutiques b ON b.id = cb.boutique_id JOIN users u ON u.id = b.user_id
          WHERE cb.commande_id = ? AND cb.vendeur_prevenu_le IS NULL AND cb.statut = 'a_preparer' AND c.statut <> 'annulee' AND " . SQL_ENGAGEE,
        [$commandeId]
    )->fetchAll();
    $n = 0;
    foreach ($sous as $s) {
        // réservation : deux notifications de paiement simultanées ne préviennent qu'une fois
        if (requete('UPDATE commande_boutiques SET vendeur_prevenu_le = NOW() WHERE id = ? AND vendeur_prevenu_le IS NULL', [$s['id']])->rowCount() !== 1) {
            continue;
        }
        $n++;
        $articles = prevenir_articles((int) $s['id']);
        $page = (int) $s['mode_simple'] === 1 ? 'simple/commandes' : 'vendeur/commandes';
        try {
            push_envoyer((int) $s['user_id'], [
                'titre' => '🛍️ Nouvelle commande !',
                'texte' => $articles . ' · ' . $s['livraison_zone'] . ' — touchez pour voir',
                'url'   => $page,
                'tag'   => 'commande-' . $s['id'],
            ]);
        } catch (Throwable $e) {
            error_log('Jënd — notification vendeur : ' . $e->getMessage());
        }
        try {
            $especes = $s['methode_paiement'] === 'livraison' && $s['livre_par'] === 'vendeur';
            $montant = $especes
                ? 'Le client vous paiera ' . fcfa((int) $s['sous_total'] + (int) $s['frais_part'] - (int) $s['acompte_part']) . ' en espèces à la livraison.'
                : 'Vous recevrez ' . fcfa((int) $s['net_vendeur'] + ($s['livre_par'] === 'vendeur' ? (int) $s['frais_part'] : 0)) . ' après la livraison.';
            $test = function_exists('est_test') && est_test();          // site de test : paiement simulé, rien à livrer
            envoyer_email((string) $s['email'], ($test ? '[SITE DE TEST] ' : '') . 'Nouvelle commande à préparer : ' . $s['reference'],
                'Bonjour ' . explode(' ', (string) $s['nom'])[0] . ",\n\n"
                . ($test ? "⚠ SITE DE TEST : ce paiement est SIMULÉ, aucun argent n'a été encaissé. Ne livrez rien.\n\n" : '')
                . "Bonne nouvelle : votre boutique « {$s['boutique']} » a reçu une commande, et elle est payée (ou confirmée par le client).\n\n"
                . "Commande : {$s['reference']}\nArticles : {$articles}\nLivraison : {$s['livraison_zone']}\n{$montant}\n\n"
                . "Préparez-la et indiquez quand elle est envoyée :\n" . app_url($page) . "\n\n"
                . (push_disponible() ? "Astuce : activez les notifications sur votre téléphone (bouton « Être prévenu des commandes » dans votre espace) pour être averti tout de suite, même si Jënd est fermé.\n\n" : '')
                . "— L'équipe Jënd");
        } catch (Throwable $e) {
            error_log('Jënd — e-mail vendeur : ' . $e->getMessage());
        }
    }
    return $n;
}

/**
 * Rattrapage : commandes devenues « à préparer » par un autre chemin (paiement validé à la main par l'administrateur…).
 * Lancé avec les tâches horaires ; seulement les commandes des 2 derniers jours (jamais de vieilles notifications).
 */
function vendeurs_prevenir_en_attente(): int
{
    $ids = requete(
        "SELECT DISTINCT cb.commande_id FROM commande_boutiques cb JOIN commandes c ON c.id = cb.commande_id
          WHERE cb.vendeur_prevenu_le IS NULL AND cb.statut = 'a_preparer' AND c.statut <> 'annulee' AND c.created_at > (NOW() - INTERVAL 2 DAY) AND " . SQL_ENGAGEE . "
          LIMIT 50"
    )->fetchAll(PDO::FETCH_COLUMN);
    $n = 0;
    foreach ($ids as $id) {
        $n += vendeur_prevenir_commande((int) $id);
    }
    return $n;
}

/** SQL : sous-commandes à relancer (alias cb, c) — à préparer, payées, sans action du vendeur depuis RELANCE_HEURES. */
function relances_condition(): string
{
    return "cb.statut = 'a_preparer' AND c.statut <> 'annulee' AND " . SQL_ENGAGEE . "
            AND COALESCE(cb.vendeur_prevenu_le, c.created_at) < (NOW() - INTERVAL " . RELANCE_HEURES . " HOUR)";
}

/** Nombre de commandes à relancer (pastille de l'onglet admin) : celles qui n'ont pas été relancées depuis RELANCE_HEURES. */
function relances_a_faire(): int
{
    return (int) requete("SELECT COUNT(*) FROM commande_boutiques cb JOIN commandes c ON c.id = cb.commande_id
                           WHERE " . relances_condition() . " AND (cb.relance_le IS NULL OR cb.relance_le < (NOW() - INTERVAL " . RELANCE_HEURES . " HOUR))")->fetchColumn();
}

/** Message WhatsApp déjà écrit pour relancer un vendeur. */
function relance_message(array $r): string
{
    return 'Bonjour ' . explode(' ', (string) $r['vendeur'])[0] . ", c'est l'équipe Jënd. Vous avez une commande à préparer ({$r['reference']} : {$r['articles']}). "
         . 'La commande est confirmée. Ouvrez Jënd pour la voir : ' . app_url((int) $r['mode_simple'] === 1 ? 'simple/commandes' : 'vendeur/commandes') . ' — Merci !';
}

/**
 * Bouton du CLIENT « Prévenir le vendeur sur WhatsApp » (page de sa commande) : gratuit, sans API, marche partout.
 * Le client n'a qu'à appuyer sur « Envoyer » dans WhatsApp ; le vendeur reçoit tout de suite un vrai message.
 * Seulement quand le vendeur doit préparer (commande payée ou confirmée) et s'il a donné un numéro WhatsApp public.
 * Retourne le lien wa.me (ou null).
 */
function lien_prevenir_vendeur(array $commande, array $sc): ?string
{
    if ($commande['statut'] === 'annulee' || ($sc['statut'] ?? '') !== 'a_preparer' || !commande_engagee($commande) || empty($sc['contact_whatsapp'])) {
        return null;
    }
    $lien = simple_lien_whatsapp((string) $sc['contact_whatsapp']);
    if ($lien === '') {
        return null;
    }
    $paiement = $commande['statut_paiement'] === 'paye' ? 'déjà payée en ligne' : 'à payer à la livraison';
    if (function_exists('est_test') && est_test()) {
        $paiement .= ' (SITE DE TEST : paiement simulé, ne rien livrer)';
    }
    $texte = 'Bonjour ' . $sc['boutique'] . ' 👋 Je viens de commander sur Jënd : ' . prevenir_articles((int) $sc['id'], 5) . '. '
           . 'Commande ' . $commande['reference'] . ', ' . $paiement . ', livraison : ' . $commande['livraison_zone'] . '. Merci de la préparer ! '
           . 'Voir la commande : ' . app_url((int) ($sc['mode_simple'] ?? 0) === 1 ? 'simple/commandes' : 'vendeur/commandes');
    return $lien . '?text=' . rawurlencode($texte);
}

/** Rappel sur l'accueil du vendeur tant qu'il n'a pas de numéro WhatsApp public (un seul champ, prérempli avec son numéro de paiement). */
function rappel_whatsapp(array $b, bool $grand = false): string
{
    if (!empty($b['contact_whatsapp'])) {
        return '';
    }
    return '<form method="post" action="' . e(url('vendeur/whatsapp')) . '" class="rappel-whatsapp' . ($grand ? ' rappel-whatsapp-grand' : '') . '">' . csrf_champ()
        . '<p><i class="ph-fill ph-whatsapp-logo"></i><span><b>Votre numéro WhatsApp ?</b><small>Vos clients pourront vous prévenir de leurs commandes sur WhatsApp, en un geste.</small></span></p>'
        . '<div><input type="tel" name="contact_whatsapp" value="' . e((string) $b['telephone_paiement']) . '" inputmode="tel" placeholder="77 123 45 67" aria-label="Numéro WhatsApp" required>'
        . '<button class="btn btn-whatsapp" type="submit"><i class="ph ph-check"></i> Enregistrer</button></div></form>';
}

