<?php
declare(strict_types=1);

/**
 * Chiffrement des secrets stockés en base (ex : secret de double authentification).
 * AES-256-GCM (chiffré ET authentifié : toute modification du texte est détectée).
 * La clé vient de APP_KEY (.env). En développement seulement, une clé est générée dans storage/app-key.txt.
 * ⚠ Perdre APP_KEY = perdre les secrets 2FA chiffrés (les utilisateurs devraient refaire leur configuration 2FA).
 */
function app_key(): string
{
    $cle = (string) env('APP_KEY', '');
    if ($cle === '') {
        if (env('APP_ENV', 'prod') !== 'dev') {
            throw new RuntimeException('APP_KEY manquant dans .env');
        }
        $fichier = dirname(__DIR__) . '/storage/app-key.txt';
        if (!is_file($fichier)) {
            file_put_contents($fichier, bin2hex(random_bytes(32)), LOCK_EX);
        }
        $cle = trim((string) file_get_contents($fichier));
    }
    if (strlen($cle) < 32) {
        throw new RuntimeException('APP_KEY trop court (32 caractères minimum)');
    }
    return hash('sha256', $cle, true);
}

function chiffrer(string $clair): string
{
    $iv  = random_bytes(12);
    $tag = '';
    $ct  = openssl_encrypt($clair, 'aes-256-gcm', app_key(), OPENSSL_RAW_DATA, $iv, $tag, '', 16);
    if ($ct === false) {
        throw new RuntimeException('Chiffrement impossible');
    }
    return base64_encode($iv . $tag . $ct);
}

/** Retourne le texte en clair, ou null si les données sont altérées ou la clé incorrecte. */
function dechiffrer(string $chiffre): ?string
{
    $brut = base64_decode($chiffre, true);
    if ($brut === false || strlen($brut) < 29) {
        return null;
    }
    $clair = openssl_decrypt(substr($brut, 28), 'aes-256-gcm', app_key(), OPENSSL_RAW_DATA, substr($brut, 0, 12), substr($brut, 12, 16));
    return $clair === false ? null : $clair;
}
