<?php
declare(strict_types=1);

/**
 * Règlement des commissions par les vendeurs.
 *
 * Quand le client paie EN ESPÈCES au vendeur (paiement à la livraison), Jënd ne touche pas l'argent :
 * sa commission devient une dette du vendeur (vendeur_gains → « dette »). Avec le paiement en ligne, elle est retenue
 * sur les gains suivants ; sans paiement en ligne (ou en attendant), le vendeur la règle lui-même par Wave / Orange Money
 * au numéro de Jënd, et l'administrateur enregistre le règlement (Administration → Commissions dues).
 * Un règlement ne peut jamais dépasser la dette : il ne crée pas de « gain » à verser.
 */

const METHODES_REGLEMENT = ['wave' => 'Wave', 'orange_money' => 'Orange Money', 'free_money' => 'Free Money', 'especes' => 'Espèces (en main propre)', 'autre' => 'Autre'];

/** Numéro Wave / Orange Money de Jënd où les vendeurs envoient leurs commissions (Administration → Commissions dues), ou null. */
function reglement_numero(): ?string
{
    $n = trim((string) parametre('reglement_numero', ''));
    return $n !== '' ? $n : null;
}

/** Total déjà réglé par une boutique. */
function reglements_total(int $boutiqueId): int
{
    return (int) requete('SELECT COALESCE(SUM(montant), 0) FROM reglements_commission WHERE boutique_id = ?', [$boutiqueId])->fetchColumn();
}

/**
 * Enregistre un règlement reçu. Retourne l'id.
 * @throws RuntimeException message affichable
 */
function reglement_enregistrer(int $boutiqueId, int $montant, string $methode, string $reference, ?int $adminId): int
{
    if (!isset(METHODES_REGLEMENT[$methode])) {
        throw new RuntimeException('Moyen de règlement inconnu.');
    }
    $reference = trim(preg_replace('/\s+/u', ' ', $reference));
    if (mb_strlen($reference) > 60) {
        throw new RuntimeException('Référence trop longue (60 caractères maximum).');
    }
    $pdo = pdo();
    $pdo->beginTransaction();
    try {
        if (!requete('SELECT id FROM boutiques WHERE id = ? FOR UPDATE', [$boutiqueId])->fetch()) {
            throw new RuntimeException('Boutique introuvable.');
        }
        $dette = vendeur_gains($boutiqueId)['dette'];
        if ($montant < 1) {
            throw new RuntimeException('Indiquez le montant reçu (en FCFA).');
        }
        if ($montant > $dette) {
            throw new RuntimeException('Montant supérieur à ce que doit ce vendeur (' . fcfa($dette) . '). Vérifiez le transfert reçu.');
        }
        requete('INSERT INTO reglements_commission (boutique_id, montant, methode, reference, admin_id) VALUES (?, ?, ?, ?, ?)',
            [$boutiqueId, $montant, $methode, $reference !== '' ? $reference : null, $adminId]);
        $id = (int) $pdo->lastInsertId();
        $pdo->commit();
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        throw $e instanceof RuntimeException ? $e : new RuntimeException('Le règlement n\'a pas été enregistré.');
    }
    return $id;
}

/**
 * Vendeurs qui doivent une commission à Jënd (ventes payées en espèces), du plus gros montant au plus petit.
 * Seules les boutiques ayant livré au moins une commande payée en espèces sont examinées.
 */
function vendeurs_endettes(): array
{
    $ids = requete("SELECT DISTINCT cb.boutique_id FROM commande_boutiques cb JOIN commandes c ON c.id = cb.commande_id
                     WHERE c.methode_paiement = 'livraison' AND cb.livre_par = 'vendeur' AND cb.statut = 'livree'")->fetchAll(PDO::FETCH_COLUMN);
    $liste = [];
    foreach ($ids as $id) {
        $dette = vendeur_gains((int) $id)['dette'];
        if ($dette <= 0) {
            continue;
        }
        $b = requete('SELECT b.id, b.nom, b.slug, b.mode_simple, b.contact_whatsapp, b.telephone_paiement, u.nom AS vendeur, u.telephone, u.email,
                             (SELECT MAX(created_at) FROM reglements_commission r WHERE r.boutique_id = b.id) AS dernier_reglement
                        FROM boutiques b JOIN users u ON u.id = b.user_id WHERE b.id = ?', [$id])->fetch();
        if ($b) {
            $b['dette'] = $dette;
            $liste[] = $b;
        }
    }
    usort($liste, fn ($a, $b) => $b['dette'] <=> $a['dette']);
    return $liste;
}

/** Nombre de vendeurs qui doivent une commission (pastille de l'onglet admin). Seules les boutiques ayant des ventes en espèces sont examinées. */
function vendeurs_endettes_nombre(): int
{
    return count(vendeurs_endettes());
}

/** Message WhatsApp de l'équipe au vendeur pour lui rappeler sa commission. */
function reglement_message_relance(array $b): string
{
    $numero = reglement_numero();
    return 'Bonjour ' . explode(' ', trim((string) $b['vendeur']))[0] . ", c'est l'équipe Jënd. Merci pour vos ventes ! "
         . 'La commission de Jënd sur vos ventes payées en espèces est de ' . fcfa((int) $b['dette']) . '. '
         . ($numero ? 'Vous pouvez la régler par Wave ou Orange Money au ' . $numero . ', en indiquant « ' . $b['nom'] . ' ». ' : '')
         . 'Le détail est dans votre espace : ' . app_url((int) $b['mode_simple'] === 1 ? 'simple/argent' : 'vendeur/gains') . ' — Merci !';
}

/**
 * Encadré pour le vendeur : combien il doit et comment régler sa commission.
 * $grand : version à gros caractères du mode simple.
 */
function reglement_bloc_vendeur(array $b, int $dette, bool $grand = false): string
{
    if ($dette <= 0) {
        return '';
    }
    $numero = reglement_numero();
    $html = '<section class="reglement-bloc' . ($grand ? ' reglement-bloc-grand' : '') . '">'
          . '<p class="reglement-titre"><i class="ph-fill ph-hand-coins"></i> <span>Commission à régler à Jënd : <b>' . e(fcfa($dette)) . '</b></span></p>'
          . '<p class="petit">Vos clients vous ont payé en espèces : la commission de Jënd sur ces ventes n\'a pas encore été réglée.</p>';
    if ($numero) {
        $texte = 'Bonjour Jënd, je viens de régler ma commission de ' . fcfa($dette) . ' pour la boutique « ' . $b['nom'] . ' ». Référence du transfert : ';
        $wa = simple_lien_whatsapp($numero);
        $html .= '<ol class="reglement-etapes"><li>Envoyez <b>' . e(fcfa($dette)) . '</b> par <b>Wave ou Orange Money</b> au <b>' . e($numero) . '</b> (Jënd).</li>'
               . '<li>Indiquez le nom de votre boutique : <b>« ' . e((string) $b['nom']) . ' »</b>.</li>'
               . '<li>Prévenez Jënd : dès réception, le règlement apparaît ici et votre montant dû baisse.</li></ol>'
               . ($wa ? '<a class="btn btn-whatsapp" href="' . e($wa . '?text=' . rawurlencode($texte)) . '" target="_blank" rel="noopener noreferrer"><i class="ph-fill ph-whatsapp-logo"></i> J\'ai payé : prévenir Jënd</a>' : '');
    } else {
        $html .= '<p class="petit">Elle sera retenue sur vos prochains gains en ligne, ou l\'équipe Jënd vous contactera pour la régler.</p>';
    }
    $plafond = (int) parametre('dette_commission_max', '20000');
    if ($plafond > 0) {
        $html .= '<p class="doux petit">Au-delà de ' . e(fcfa($plafond)) . ' dus, les commandes payées en espèces sont suspendues pour votre boutique jusqu\'au règlement.</p>';
    }
    return $html . '</section>';
}
