<?php
/**
 * Affichage d'une conversation d'aide, identique pour tous : VOS messages à droite (en vert), ceux de l'autre à gauche.
 * Variables : $fil (support_fil), $vueEquipe (bool : la page est vue par l'administrateur), $nomClient (facultatif).
 */
$nomClient = $nomClient ?? 'Client';
?>
<ol class="fil-conversation">
  <?php foreach ($fil as $r): $equipe = $r['auteur'] === 'equipe'; $mien = $vueEquipe ? $equipe : !$equipe; ?>
    <li class="bulle <?= $mien ? 'bulle-moi' : 'bulle-autre' ?>">
      <small><?= e($mien ? 'Vous' : ($equipe ? 'Équipe Jënd' : $nomClient)) ?> · <?= e(date('d/m/Y à H:i', strtotime($r['created_at']))) ?></small>
      <p><?= nl2br(e($r['texte'])) ?></p>
    </li>
  <?php endforeach; ?>
</ol>
