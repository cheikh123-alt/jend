<?php
declare(strict_types=1);

/**
 * Commande sur mesure (tailleurs, artisans).
 *   1. le client décrit ce qu'il veut (modèle, tissu, mesures, budget, date) ;
 *   2. le vendeur répond par un devis (prix + délai) ou refuse ;
 *   3. le client accepte : un produit RÉSERVÉ à ce client est créé au prix du devis, et il le paie par le circuit habituel
 *      (argent conservé par Jënd jusqu'à la réception, code de livraison, signalement possible).
 */

const DEMANDES_PAR_JOUR = 5;                    // par client
const DEVIS_PRIX_MAX = 5_000_000;

const STATUTS_DEMANDE = [
    'envoyee'  => 'Envoyée au vendeur',
    'devis'    => 'Devis reçu',
    'acceptee' => 'Devis accepté',
    'refusee'  => 'Refusée',
    'annulee'  => 'Annulée',
];

/** @throws RuntimeException message affichable. @return string référence de la demande */
function demande_creer(int $clientId, int $boutiqueId, string $description, string $mesures, ?int $budget, ?string $date): string
{
    $b = requete("SELECT b.id, b.nom, b.user_id, b.sur_mesure, u.email FROM boutiques b JOIN users u ON u.id = b.user_id WHERE b.id = ? AND b.statut = 'active'", [$boutiqueId])->fetch();
    if (!$b || (int) $b['sur_mesure'] !== 1) {
        throw new RuntimeException('Cette boutique ne prend pas de commande sur mesure.');
    }
    if ((int) $b['user_id'] === $clientId) {
        throw new RuntimeException('Vous ne pouvez pas commander dans votre propre boutique.');
    }
    $description = trim($description);
    $mesures = trim($mesures);
    if (mb_strlen($description) < 15 || mb_strlen($description) > 2000) {
        throw new RuntimeException('Décrivez votre demande (15 à 2000 caractères) : modèle, tissu, couleur, occasion…');
    }
    if (mb_strlen($mesures) > 1000) {
        throw new RuntimeException('Les mesures sont limitées à 1000 caractères.');
    }
    if ($budget !== null && ($budget < 500 || $budget > DEVIS_PRIX_MAX)) {
        throw new RuntimeException('Budget invalide.');
    }
    if ($date !== null && (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $date) || $date < date('Y-m-d') || $date > date('Y-m-d', strtotime('+1 year')))) {
        throw new RuntimeException('Date souhaitée invalide (elle doit être dans l\'année à venir).');
    }
    if (limite_atteinte('mesure:client:' . $clientId, DEMANDES_PAR_JOUR, 86400)) {
        throw new RuntimeException('Vous avez déjà envoyé plusieurs demandes aujourd\'hui. Réessayez demain.');
    }
    limite_enregistrer('mesure:client:' . $clientId);
    do {
        $ref = 'SM-' . strtoupper(bin2hex(random_bytes(4)));
    } while (requete('SELECT 1 FROM demandes_mesure WHERE reference = ?', [$ref])->fetch());
    requete('INSERT INTO demandes_mesure (reference, boutique_id, client_id, description, mesures, budget, date_souhaitee) VALUES (?, ?, ?, ?, ?, ?, ?)',
        [$ref, $boutiqueId, $clientId, $description, $mesures !== '' ? $mesures : null, $budget, $date]);
    try {
        envoyer_email((string) $b['email'], 'Nouvelle demande sur mesure ' . $ref,
            "Un client vous demande un devis sur mesure.\n\nRépondez avec votre prix et votre délai :\n" . app_url('vendeur/sur-mesure'));
    } catch (Throwable $e) {
        error_log('Jënd — e-mail sur mesure : ' . $e->getMessage());
    }
    return $ref;
}

/** Le vendeur envoie son devis (ou le modifie tant que le client n'a pas répondu). @throws RuntimeException */
function demande_devis(int $id, int $boutiqueId, int $prix, int $delai, string $message): void
{
    $d = requete('SELECT d.*, u.email FROM demandes_mesure d JOIN users u ON u.id = d.client_id WHERE d.id = ? AND d.boutique_id = ?', [$id, $boutiqueId])->fetch();
    if (!$d) {
        throw new RuntimeException('Demande introuvable.');
    }
    if (!in_array($d['statut'], ['envoyee', 'devis'], true)) {
        throw new RuntimeException('Cette demande n\'attend plus de devis.');
    }
    if ($prix < 500 || $prix > DEVIS_PRIX_MAX) {
        throw new RuntimeException('Prix invalide (entre 500 et ' . fcfa(DEVIS_PRIX_MAX) . ').');
    }
    if ($delai < 1 || $delai > 180) {
        throw new RuntimeException('Délai invalide (1 à 180 jours).');
    }
    $message = trim($message);
    if (mb_strlen($message) > 1000) {
        throw new RuntimeException('Message limité à 1000 caractères.');
    }
    requete("UPDATE demandes_mesure SET statut = 'devis', prix = ?, delai_jours = ?, reponse = ? WHERE id = ?", [$prix, $delai, $message !== '' ? $message : null, $id]);
    try {
        envoyer_email((string) $d['email'], 'Votre devis sur mesure ' . $d['reference'],
            "Le vendeur vous propose " . fcfa($prix) . ", prêt en $delai jour(s).\nAcceptez ou refusez ici :\n" . app_url('sur-mesure'));
    } catch (Throwable $e) {
        error_log('Jënd — e-mail sur mesure : ' . $e->getMessage());
    }
}

/** Le vendeur décline la demande. @throws RuntimeException */
function demande_refuser_vendeur(int $id, int $boutiqueId, string $message): void
{
    $n = requete("UPDATE demandes_mesure SET statut = 'refusee', reponse = ? WHERE id = ? AND boutique_id = ? AND statut IN ('envoyee', 'devis')",
        [mb_substr(trim($message), 0, 1000) ?: null, $id, $boutiqueId])->rowCount();
    if ($n !== 1) {
        throw new RuntimeException('Cette demande ne peut plus être refusée.');
    }
}

/**
 * Le client accepte le devis : création du produit réservé (une seule fois). Retourne l'identifiant du produit à payer.
 * @throws RuntimeException
 */
function demande_accepter(int $id, int $clientId, ?int $prixVu = null): int
{
    $pdo = pdo();
    $pdo->beginTransaction();
    try {
        $d = requete('SELECT * FROM demandes_mesure WHERE id = ? AND client_id = ? FOR UPDATE', [$id, $clientId])->fetch();
        if (!$d) {
            throw new RuntimeException('Demande introuvable.');
        }
        if ($d['statut'] === 'acceptee' && $d['produit_id']) {
            $pdo->commit();
            return (int) $d['produit_id'];
        }
        if ($d['statut'] !== 'devis' || !$d['prix']) {
            throw new RuntimeException('Il n\'y a pas de devis à accepter pour cette demande.');
        }
        if ($prixVu !== null && $prixVu !== (int) $d['prix']) {            // le vendeur a changé son devis entre l'affichage et le clic
            throw new RuntimeException('Le vendeur vient de modifier son devis (' . fcfa((int) $d['prix']) . '). Relisez-le avant d\'accepter.');
        }
        if (!requete("SELECT 1 FROM boutiques WHERE id = ? AND statut = 'active'", [$d['boutique_id']])->fetch()) {
            throw new RuntimeException('Cette boutique n\'est plus disponible.');
        }
        $categorie = (int) (requete("SELECT id FROM categories WHERE slug IN ('mode-wax', 'services') ORDER BY FIELD(slug, 'mode-wax', 'services') LIMIT 1")->fetchColumn()
            ?: requete('SELECT MIN(id) FROM categories')->fetchColumn());
        $nom = 'Commande sur mesure ' . $d['reference'];
        $texte = "Commande sur mesure, prête en {$d['delai_jours']} jour(s).\n\nDemande du client :\n{$d['description']}" . ($d['mesures'] ? "\n\nMesures :\n{$d['mesures']}" : '');
        requete("INSERT INTO produits (boutique_id, categorie_id, nom, slug, description, prix, stock, statut, reserve_client_id) VALUES (?, ?, ?, ?, ?, ?, 1, 'publie', ?)",
            [$d['boutique_id'], $categorie, $nom, produit_slug_unique($nom), $texte, (int) $d['prix'], $clientId]);
        $produitId = (int) $pdo->lastInsertId();
        requete("UPDATE demandes_mesure SET statut = 'acceptee', produit_id = ? WHERE id = ?", [$produitId, $id]);
        $pdo->commit();
        return $produitId;
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        if ($e instanceof RuntimeException) {
            throw $e;
        }
        error_log('Jënd — acceptation de devis : ' . $e->getMessage());
        throw new RuntimeException('Une erreur est survenue, réessayez.');
    }
}

/** Le client refuse le devis, ou annule sa demande avant acceptation. @throws RuntimeException */
function demande_fermer_client(int $id, int $clientId, string $action): void
{
    $nouveau = $action === 'refuser' ? 'refusee' : 'annulee';
    $n = requete("UPDATE demandes_mesure SET statut = ? WHERE id = ? AND client_id = ? AND statut IN ('envoyee', 'devis')", [$nouveau, $id, $clientId])->rowCount();
    if ($n !== 1) {
        throw new RuntimeException('Cette demande ne peut plus être modifiée.');
    }
}

/** Demandes qui attendent un devis du vendeur. */
function demandes_a_traiter(int $boutiqueId): int
{
    return (int) requete("SELECT COUNT(*) FROM demandes_mesure WHERE boutique_id = ? AND statut = 'envoyee'", [$boutiqueId])->fetchColumn();
}

/** La commande sur mesure acceptée a-t-elle déjà été commandée (produit réservé épuisé) ? */
function demande_commandee(array $d): bool
{
    return $d['produit_id'] && (int) requete('SELECT stock FROM produits WHERE id = ?', [$d['produit_id']])->fetchColumn() < 1;
}
