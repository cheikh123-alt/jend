<?php
declare(strict_types=1);

/**
 * Boutiques : régions desservies, note moyenne, liens de partage.
 * Régions desservies : une boutique sans ligne dans boutique_regions livre partout (comportement d'origine).
 */

/** Régions choisies par la boutique (vide = toutes). */
function boutique_regions(int $boutiqueId): array
{
    return requete('SELECT region FROM boutique_regions WHERE boutique_id = ? ORDER BY region', [$boutiqueId])->fetchAll(PDO::FETCH_COLUMN);
}

/** La boutique livre-t-elle dans cette ville/région ? */
function boutique_livre_vers(int $boutiqueId, string $region): bool
{
    $r = boutique_regions($boutiqueId);
    return !$r || in_array($region, $r, true);
}

/** Villes et régions proposées par les zones de livraison actives (Touba d'abord). */
function regions_disponibles(): array
{
    $v = requete('SELECT DISTINCT region FROM zones_livraison WHERE actif = 1 ORDER BY region')->fetchAll(PDO::FETCH_COLUMN);
    usort($v, fn ($a, $b) => $a === 'Touba' ? -1 : ($b === 'Touba' ? 1 : strcmp($a, $b)));
    return $v;
}

/** Note moyenne et nombre d'avis sur l'ensemble des produits de la boutique. */
function boutique_note(int $boutiqueId): array
{
    $r = requete('SELECT COALESCE(ROUND(AVG(a.note), 1), 0) AS note, COUNT(a.id) AS nb FROM avis a JOIN produits p ON p.id = a.produit_id WHERE p.boutique_id = ?', [$boutiqueId])->fetch();
    return ['note' => (float) $r['note'], 'nb' => (int) $r['nb']];
}

/** « 4,6 » */
function note_texte(float $note): string
{
    return str_replace('.', ',', number_format($note, 1, '.', ''));
}

/** Lien WhatsApp avec un message prêt à envoyer (le contact choisit lui-même le destinataire). */
function lien_whatsapp_partage(string $texte): string
{
    return 'https://wa.me/?text=' . rawurlencode($texte);
}

/** Bouton « Partager sur WhatsApp ». */
function bouton_whatsapp(string $texte, string $libelle = 'Partager sur WhatsApp'): string
{
    return '<a class="btn btn-whatsapp" href="' . e(lien_whatsapp_partage($texte)) . '" target="_blank" rel="noopener noreferrer"><i class="ph-fill ph-whatsapp-logo"></i> ' . e($libelle) . '</a>';
}

/* ---------- Vidéo du produit ---------- */

/** Sites de vidéo acceptés pour le lien « vidéo du produit ». */
const VIDEO_HOTES = ['tiktok.com', 'youtube.com', 'youtu.be', 'instagram.com', 'facebook.com', 'fb.watch'];

/** Valide un lien de vidéo : https, site connu. Retourne l'adresse nettoyée, '' si vide, ou null si elle est refusée. */
function video_url_valide(string $url): ?string
{
    $url = trim($url);
    if ($url === '') {
        return '';
    }
    // ni espace, ni guillemet, ni barre oblique inversée (un navigateur la lit comme « / » : https://site-pirate\@tiktok.com irait ailleurs)
    if (strlen($url) > 255 || !preg_match('#^https://#i', $url) || preg_match('/[\s<>"\'\\\\]/', $url) || !filter_var($url, FILTER_VALIDATE_URL)) {
        return null;
    }
    // pas d'identifiants ni de port dans l'adresse (le « @ » reste permis dans le chemin : tiktok.com/@compte)
    if (parse_url($url, PHP_URL_USER) !== null || parse_url($url, PHP_URL_PORT) !== null) {
        return null;
    }
    $hote = strtolower((string) parse_url($url, PHP_URL_HOST));
    foreach (VIDEO_HOTES as $h) {
        if ($hote === $h || str_ends_with($hote, '.' . $h)) {
            return $url;
        }
    }
    return null;
}

/* ---------- Parrainage entre vendeurs ---------- */

/** Nombre de jours sans commission offerts au parrain ET au filleul quand la boutique parrainée est validée. */
function parrainage_jours(): int
{
    $j = (int) (function_exists('parametre') ? parametre('parrainage_jours', '30') : 30);
    return max(0, min(365, $j));
}

/** Code de parrainage unique (8 caractères, sans lettres ambiguës). */
function code_parrain_nouveau(): string
{
    do {
        $code = '';
        for ($i = 0; $i < 8; $i++) {
            $code .= 'ABCDEFGHJKMNPQRSTUVWXYZ23456789'[random_int(0, 30)];
        }
    } while (requete('SELECT 1 FROM boutiques WHERE code_parrain = ?', [$code])->fetch());
    return $code;
}

/** La boutique est-elle en période sans commission (parrainage) ? Retourne la date de fin (AAAA-MM-JJ) ou null. */
function commission_gratuite_jusqu(array $boutique): ?string
{
    $d = (string) ($boutique['commission_gratuite_jusqu'] ?? '');
    return ($d !== '' && $d >= date('Y-m-d')) ? $d : null;
}

/**
 * Attribue la récompense de parrainage quand une boutique parrainée est validée : parrain et filleul gagnent
 * parrainage_jours() jours sans commission (ajoutés à leur période en cours). Une seule fois par boutique parrainée.
 */
function parrainage_recompenser(int $boutiqueId): bool
{
    $jours = parrainage_jours();
    $b = requete('SELECT id, parrain_boutique_id, parrainage_recompense FROM boutiques WHERE id = ?', [$boutiqueId])->fetch();
    if (!$b || !$b['parrain_boutique_id'] || (int) $b['parrainage_recompense'] === 1 || $jours < 1) {
        return false;
    }
    if (requete('UPDATE boutiques SET parrainage_recompense = 1 WHERE id = ? AND parrainage_recompense = 0', [$boutiqueId])->rowCount() !== 1) {
        return false;
    }
    foreach ([(int) $b['id'], (int) $b['parrain_boutique_id']] as $id) {
        requete('UPDATE boutiques SET commission_gratuite_jusqu = DATE_ADD(GREATEST(COALESCE(commission_gratuite_jusqu, CURDATE()), CURDATE()), INTERVAL ? DAY) WHERE id = ?', [$jours, $id]);
    }
    return true;
}

/* ---------- Où livrent les vendeurs ---------- */

/**
 * Pour chaque ville/région ayant des zones actives : les boutiques actives qui y livrent, et les frais/délais des zones.
 * Une boutique sans région choisie livre partout. Résultat trié : Touba d'abord, puis par nombre de boutiques.
 * [region => ['boutiques' => [[nom, slug], …], 'zones' => [...], 'frais_min', 'frais_max', 'delai_min', 'delai_max']]
 */
function regions_desservies(): array
{
    static $cache = null;
    if ($cache !== null) {
        return $cache;
    }
    $res = [];
    foreach (requete('SELECT id, nom, region, frais, delai_jours FROM zones_livraison WHERE actif = 1 ORDER BY region, frais, nom')->fetchAll() as $z) {
        $r = &$res[$z['region']];
        $r['zones'][] = $z;
        $r['boutiques'] = [];
        $r['frais_min'] = min($r['frais_min'] ?? PHP_INT_MAX, (int) $z['frais']);
        $r['frais_max'] = max($r['frais_max'] ?? 0, (int) $z['frais']);
        $r['delai_min'] = min($r['delai_min'] ?? PHP_INT_MAX, (int) $z['delai_jours']);
        $r['delai_max'] = max($r['delai_max'] ?? 0, (int) $z['delai_jours']);
        unset($r);
    }
    $choix = [];
    foreach (requete("SELECT br.boutique_id, br.region FROM boutique_regions br JOIN boutiques b ON b.id = br.boutique_id AND b.statut = 'active'")->fetchAll() as $l) {
        $choix[(int) $l['boutique_id']][] = $l['region'];
    }
    foreach (requete("SELECT id, nom, slug FROM boutiques WHERE statut = 'active' ORDER BY nom")->fetchAll() as $b) {
        foreach (array_keys($res) as $region) {
            if (!isset($choix[(int) $b['id']]) || in_array($region, $choix[(int) $b['id']], true)) {
                $res[$region]['boutiques'][] = [$b['nom'], $b['slug'], (int) $b['id']];
            }
        }
    }
    uksort($res, function ($a, $b) use ($res) {
        if ($a === 'Touba' || $b === 'Touba') {
            return $a === 'Touba' ? -1 : 1;
        }
        return [count($res[$b]['boutiques']), $a] <=> [count($res[$a]['boutiques']), $b];
    });
    return $cache = $res;
}

/* ---------- Frais de livraison fixés par chaque boutique ---------- */

const FRAIS_LIVRAISON_MAX = 100000;

/** Frais et délais propres à des boutiques : [boutique_id => [zone_id => ['frais' => int, 'delai' => ?int]]]. */
function frais_boutiques(array $boutiqueIds): array
{
    $ids = array_values(array_unique(array_map('intval', $boutiqueIds)));
    if (!$ids) {
        return [];
    }
    $res = [];
    foreach (requete('SELECT boutique_id, zone_id, frais, delai_jours FROM boutique_frais WHERE boutique_id IN (' . implode(',', array_fill(0, count($ids), '?')) . ')', $ids)->fetchAll() as $l) {
        $res[(int) $l['boutique_id']][(int) $l['zone_id']] = ['frais' => (int) $l['frais'], 'delai' => $l['delai_jours'] !== null ? (int) $l['delai_jours'] : null];
    }
    return $res;
}

/**
 * Frais et délai d'UNE livraison : ceux de la boutique pour cette zone, sinon ceux de référence de la zone.
 * Livrée par un livreur Jënd : toujours les frais de référence (c'est Jënd qui livre et qui les garde).
 */
function frais_livraison(int $boutiqueId, array $zone, bool $parJend = false, ?array $propres = null): array
{
    $propres = $propres ?? frais_boutiques([$boutiqueId]);
    $p = $parJend ? null : ($propres[$boutiqueId][(int) $zone['id']] ?? null);
    return ['frais' => $p ? $p['frais'] : (int) $zone['frais'], 'delai' => $p && $p['delai'] !== null ? $p['delai'] : (int) $zone['delai_jours']];
}

/**
 * Pour un panier : total des frais et délai le plus long, zone par zone (chaque boutique livre et facture sa propre livraison).
 * $boutiques : [boutique_id => livre_par ('vendeur'|'jend')]. Retour : [zone_id => ['frais' => total, 'delai' => max]].
 */
function frais_panier(array $boutiques, array $zones): array
{
    $propres = frais_boutiques(array_keys($boutiques));
    $res = [];
    foreach ($zones as $z) {
        $t = 0; $d = 0;
        foreach ($boutiques as $bid => $mode) {
            $f = frais_livraison((int) $bid, $z, $mode === 'jend', $propres);
            $t += $f['frais'];
            $d = max($d, $f['delai']);
        }
        $res[(int) $z['id']] = ['frais' => $t, 'delai' => $d ?: (int) $z['delai_jours']];
    }
    return $res;
}

/** En dessous de ce nombre de ventes livrées, on n'affiche pas de statistiques (elles ne voudraient rien dire). */
const CONFIANCE_VENTES_MIN = 3;

/**
 * Fiche de confiance d'une boutique, calculée uniquement à partir des vraies livraisons et des vrais signalements
 * (rien n'est saisi par le vendeur) : ventes livrées, délai moyen entre la commande et la réception,
 * part des commandes sans problème confirmé (remboursement ou remplacement accordé par l'équipe), ancienneté.
 */
function boutique_confiance(int $boutiqueId): array
{
    $r = requete(
        "SELECT SUM(cb.statut = 'livree') AS ventes,
                AVG(CASE WHEN cb.statut = 'livree' AND cb.livre_le IS NOT NULL THEN TIMESTAMPDIFF(HOUR, c.created_at, cb.livre_le) END) AS heures,
                SUM(l.statut IN ('rembourse', 'remplace')) AS problemes,
                SUM(cb.statut = 'livree' OR l.id IS NOT NULL) AS base
           FROM commande_boutiques cb JOIN commandes c ON c.id = cb.commande_id LEFT JOIN litiges l ON l.commande_boutique_id = cb.id
          WHERE cb.boutique_id = ?",
        [$boutiqueId]
    )->fetch();
    $ventes = (int) $r['ventes'];
    $base = max(1, (int) $r['base']);
    $depuis = (string) requete('SELECT created_at FROM boutiques WHERE id = ?', [$boutiqueId])->fetchColumn();
    return [
        'ventes'       => $ventes,
        'assez'        => $ventes >= CONFIANCE_VENTES_MIN,
        'delai_heures' => $r['heures'] !== null ? (int) round((float) $r['heures']) : null,
        'sans_probleme' => (int) floor(100 * ($base - (int) $r['problemes']) / $base),
        'depuis'       => $depuis,
    ];
}

/** « 18 h », « 2 jours » */
function delai_texte(int $heures): string
{
    if ($heures < 24) {
        return max(1, $heures) . ' h';
    }
    $j = (int) round($heures / 24);
    return $j . ' jour' . ($j > 1 ? 's' : '');
}

/** Ancienneté lisible : « 3 mois », « 1 an » */
function anciennete_texte(string $depuis): string
{
    $mois = max(0, (int) floor((time() - (int) strtotime($depuis)) / (30 * 86400)));
    if ($mois < 1) {
        return 'moins d\'un mois';
    }
    return $mois < 12 ? $mois . ' mois' : intdiv($mois, 12) . ' an' . (intdiv($mois, 12) > 1 ? 's' : '');
}

/* ---------- Vitrine professionnelle de la boutique ---------- */

const COULEURS_BOUTIQUE = ['terre' => 'Terre cuite', 'vert' => 'Vert', 'safran' => 'Safran', 'encre' => 'Encre'];
const RESEAUX_BOUTIQUE = [            // nom, sites acceptés, icône (écrite en entier : la feuille d'icônes allégée ne garde que les noms présents dans le code)
    'tiktok'    => ['TikTok', ['tiktok.com'], 'ph-tiktok-logo'],
    'instagram' => ['Instagram', ['instagram.com'], 'ph-instagram-logo'],
    'facebook'  => ['Facebook', ['facebook.com', 'fb.com'], 'ph-facebook-logo'],
];

/** Lien de profil sur un réseau social : https, sur le bon site, sans adresse piégée. '' si vide, null si refusé. */
function reseau_url_valide(string $url, string $reseau): ?string
{
    $url = trim($url);
    if ($url === '') {
        return '';
    }
    if (strlen($url) > 255 || str_contains($url, '\\') || !preg_match('#^https://#i', $url)) {
        return null;
    }
    $p = parse_url($url);
    if (!$p || isset($p['user']) || isset($p['pass']) || isset($p['port']) || empty($p['host'])) {
        return null;
    }
    $hote = strtolower($p['host']);
    foreach (RESEAUX_BOUTIQUE[$reseau][1] ?? [] as $h) {
        if ($hote === $h || str_ends_with($hote, '.' . $h)) {
            return $url;
        }
    }
    return null;
}

/** Initiales pour le logo par défaut : « Marché Démo » → « MD ». */
function boutique_initiales(string $nom): string
{
    $mots = preg_split('/[\s\-]+/u', trim($nom)) ?: [];
    $ini = '';
    foreach (array_slice(array_filter($mots, fn ($m) => $m !== ''), 0, 2) as $m) {
        $ini .= mb_strtoupper(mb_substr($m, 0, 1));
    }
    return $ini !== '' ? $ini : 'J';
}

/** Catégories des produits en vente de la boutique, avec le nombre de produits. */
function boutique_categories(int $boutiqueId): array
{
    return requete(
        "SELECT c.id, c.nom, COUNT(*) AS nb FROM produits p JOIN categories c ON c.id = p.categorie_id
          WHERE p.boutique_id = ? AND p.statut = 'publie' AND p.stock > 0 AND p.reserve_client_id IS NULL
          GROUP BY c.id, c.nom ORDER BY nb DESC, c.nom LIMIT 12",
        [$boutiqueId]
    )->fetchAll();
}

/** Derniers avis (avec commentaire) laissés sur les produits de la boutique. */
function boutique_avis(int $boutiqueId, int $limite = 6): array
{
    return requete(
        "SELECT a.note, a.commentaire, a.created_at, p.nom AS produit, p.slug, u.nom AS client FROM avis a
           JOIN produits p ON p.id = a.produit_id JOIN users u ON u.id = a.user_id
          WHERE p.boutique_id = ? AND a.commentaire IS NOT NULL AND a.commentaire <> '' ORDER BY a.created_at DESC LIMIT " . max(1, min(20, $limite)),
        [$boutiqueId]
    )->fetchAll();
}
