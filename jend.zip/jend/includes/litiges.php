<?php
declare(strict_types=1);

/**
 * « Signaler un problème » : litiges entre un client et une livraison (sous-commande).
 * Promesse faite au client : première réponse sous LITIGE_DELAI_REPONSE_HEURES heures, décision et remboursement visibles.
 */

const LITIGE_DELAI_REPONSE_HEURES = 48;
const LITIGE_DELAI_SIGNALEMENT_JOURS = 7;     // après la livraison
const LITIGE_NON_RECU_APRES_JOURS = 2;        // « non reçu » possible si la commande date de plus de 2 jours
const LITIGE_MAX_PAR_JOUR = 5;
const LITIGE_MAX_PHOTOS = 3;

const MOTIFS_LITIGE = [
    'non_recu'     => 'Je n\'ai pas reçu mon colis',
    'non_conforme' => 'Le produit ne correspond pas à l\'annonce',
    'defectueux'   => 'Le produit est défectueux',
    'endommage'    => 'Le colis ou le produit est abîmé',
    'autre'        => 'Autre problème',
];
const STATUTS_LITIGE = [
    'ouvert'    => 'Reçu',
    'en_cours'  => 'En cours d\'examen',
    'rembourse' => 'Remboursement accepté',
    'remplace'  => 'Remplacement accepté',
    'rejete'    => 'Refusé',
];

/** Livraison + commande pour un litige (une seule requête réutilisée partout). */
function litige_livraison(int $cbId): ?array
{
    return requete(
        "SELECT cb.id, cb.statut, cb.sous_total, cb.net_vendeur, cb.livre_le, cb.livre_par, cb.boutique_id, b.nom AS boutique, b.user_id AS vendeur_user_id,
                c.id AS commande_id, c.reference AS commande_ref, c.client_id, c.statut AS statut_commande, c.statut_paiement, c.methode_paiement,
                c.frais_livraison, c.acompte, c.created_at AS commande_le
           FROM commande_boutiques cb JOIN commandes c ON c.id = cb.commande_id JOIN boutiques b ON b.id = cb.boutique_id WHERE cb.id = ?",
        [$cbId]
    )->fetch() ?: null;
}

/** Peut-on signaler un problème sur cette livraison ? Renvoie un message si non, null si oui. */
function litige_impossible(array $l): ?string
{
    if ($l['statut_commande'] === 'annulee' || in_array($l['statut'], ['annulee', 'retournee'], true)) {
        return 'Cette commande est annulée ou déjà retournée.';
    }
    if (!commande_engagee($l)) {
        return 'Cette commande n\'a pas encore été payée.';
    }
    if ($l['statut'] === 'livree') {
        $depuis = time() - (int) strtotime($l['livre_le'] ?? $l['commande_le']);
        if ($depuis > LITIGE_DELAI_SIGNALEMENT_JOURS * 86400) {
            return 'Le délai de ' . LITIGE_DELAI_SIGNALEMENT_JOURS . ' jours après la livraison est dépassé. Contactez-nous directement.';
        }
        return null;
    }
    if (time() - (int) strtotime($l['commande_le']) < LITIGE_NON_RECU_APRES_JOURS * 86400) {
        return 'Votre commande est encore dans les délais de livraison. Si elle n\'arrive pas, vous pourrez la signaler dans ' . LITIGE_NON_RECU_APRES_JOURS . ' jours.';
    }
    return null;
}

/** Le délai de réponse promis est-il dépassé ? */
function litige_en_retard(array $lit): bool
{
    return in_array($lit['statut'], ['ouvert', 'en_cours'], true) && $lit['repondu_le'] === null
        && time() > strtotime($lit['created_at']) + LITIGE_DELAI_REPONSE_HEURES * 3600;
}

function litige_echeance(array $lit): string
{
    return date('d/m/Y H:i', strtotime($lit['created_at']) + LITIGE_DELAI_REPONSE_HEURES * 3600);
}

/**
 * Ouvre un litige. @param array $photos fichiers $_FILES simples. @return string référence du litige
 * @throws RuntimeException message affichable
 */
function litige_creer(int $cbId, int $clientId, string $motif, string $description, array $photos): string
{
    $l = litige_livraison($cbId);
    if (!$l || (int) $l['client_id'] !== $clientId) {
        throw new RuntimeException('Livraison introuvable.');
    }
    if ($msg = litige_impossible($l)) {
        throw new RuntimeException($msg);
    }
    if (requete('SELECT 1 FROM litiges WHERE commande_boutique_id = ?', [$cbId])->fetch()) {
        throw new RuntimeException('Un signalement existe déjà pour cette livraison.');
    }
    if (!isset(MOTIFS_LITIGE[$motif])) {
        throw new RuntimeException('Choisissez le motif du problème.');
    }
    $description = trim($description);
    if (mb_strlen($description) < 20 || mb_strlen($description) > 2000) {
        throw new RuntimeException('Décrivez le problème en 20 à 2000 caractères : plus vous êtes précis, plus vite nous pouvons agir.');
    }
    if (count($photos) > LITIGE_MAX_PHOTOS) {
        throw new RuntimeException('Maximum ' . LITIGE_MAX_PHOTOS . ' photos.');
    }
    if (in_array($motif, ['non_conforme', 'defectueux', 'endommage'], true) && !$photos) {
        throw new RuntimeException('Ajoutez au moins une photo du produit : elle permet de traiter votre demande rapidement.');
    }
    if ((int) requete('SELECT COUNT(*) FROM litiges WHERE client_id = ? AND created_at > (NOW() - INTERVAL 1 DAY)', [$clientId])->fetchColumn() >= LITIGE_MAX_PAR_JOUR) {
        throw new RuntimeException('Trop de signalements aujourd\'hui. Réessayez demain ou contactez-nous.');
    }

    $fichiers = [];
    try {
        foreach ($photos as $f) {
            $fichiers[] = image_enregistrer($f, 'storage/litiges');
        }
        $reference = 'LIT-' . strtoupper(bin2hex(random_bytes(4)));
        $pdo = pdo();
        $pdo->beginTransaction();
        requete('INSERT INTO litiges (reference, commande_boutique_id, client_id, motif, description) VALUES (?, ?, ?, ?, ?)', [$reference, $cbId, $clientId, $motif, $description]);
        $id = (int) $pdo->lastInsertId();
        foreach ($fichiers as $chemin) {
            requete('INSERT INTO litige_photos (litige_id, chemin) VALUES (?, ?)', [$id, $chemin]);
        }
        litige_evenement($id, 'cree', 'client', $description);
        $pdo->commit();
    } catch (Throwable $e) {
        if (isset($pdo) && $pdo->inTransaction()) {
            $pdo->rollBack();
        }
        array_map('image_supprimer', $fichiers);
        if ($e instanceof RuntimeException) {
            throw $e;
        }
        error_log('Jënd — création litige : ' . $e->getMessage());
        throw new RuntimeException('Une erreur est survenue, réessayez.');
    }

    // Prévenir l'équipe et le vendeur (échec d'envoi sans importance : le litige est enregistré)
    $titre = 'Nouveau signalement ' . $reference . ' — commande ' . $l['commande_ref'];
    envoyer_email((string) env('ADMIN_EMAIL', 'admin@jend.local'), $titre,
        "Motif : " . MOTIFS_LITIGE[$motif] . "\nBoutique : {$l['boutique']}\nRépondre avant : " . date('d/m/Y H:i', time() + LITIGE_DELAI_REPONSE_HEURES * 3600) . "\n" . app_url('admin/litiges?id=' . $id));
    $vend = requete('SELECT email FROM users WHERE id = ?', [$l['vendeur_user_id']])->fetchColumn();
    if ($vend) {
        envoyer_email((string) $vend, 'Un client a signalé un problème (' . $l['commande_ref'] . ')',
            "Un client a signalé un problème sur sa livraison ({$l['commande_ref']}) : " . MOTIFS_LITIGE[$motif] . ".\nL'équipe Jënd examine la demande. Les gains de cette livraison sont mis en attente jusqu'à la décision.");
    }
    return $reference;
}

/**
 * Décision de l'administrateur. $action : repondre | rembourser | remplacer | rejeter | confirmer_envoi.
 * Les effets sur l'argent : remboursement accepté ⇒ si le vendeur a déjà été crédité, retenue sur ses gains (si « à sa charge »),
 * sinon la livraison passe « retournée » (le vendeur n'est pas payé).
 * @throws RuntimeException message affichable
 */
function litige_traiter(int $litigeId, string $action, string $message, int $montant = 0, bool $chargeVendeur = true): void
{
    $message = trim($message);
    $pdo = pdo();
    $pdo->beginTransaction();
    try {
        $lit = requete('SELECT * FROM litiges WHERE id = ? FOR UPDATE', [$litigeId])->fetch();
        if (!$lit) {
            throw new RuntimeException('Signalement introuvable.');
        }
        $l = litige_livraison((int) $lit['commande_boutique_id']);
        $clos = in_array($lit['statut'], ['rembourse', 'remplace', 'rejete'], true);

        if ($action === 'confirmer_envoi') {
            if ($lit['statut'] !== 'rembourse' || $lit['rembourse_le'] !== null) {
                throw new RuntimeException('Aucun remboursement en attente d\'envoi pour ce signalement.');
            }
            requete('UPDATE litiges SET rembourse_le = NOW() WHERE id = ?', [$litigeId]);
            litige_evenement($litigeId, 'argent_envoye', 'equipe', null, (int) $lit['montant_rembourse']);
            $sujet = 'Votre remboursement a été envoyé (' . $lit['reference'] . ')';
            $corps = 'Nous avons renvoyé ' . fcfa((int) $lit['montant_rembourse']) . " sur votre moyen de paiement mobile.\n" . app_url('litige/' . $lit['reference']);
        } else {
            if ($clos) {
                throw new RuntimeException('Ce signalement est déjà traité.');
            }
            if (mb_strlen($message) < 5 || mb_strlen($message) > 2000) {
                throw new RuntimeException('Écrivez un message pour le client (5 à 2000 caractères).');
            }
            if ($action === 'repondre') {
                requete("UPDATE litiges SET statut = 'en_cours', reponse_admin = ?, repondu_le = COALESCE(repondu_le, NOW()) WHERE id = ?", [$message, $litigeId]);
                litige_evenement($litigeId, $lit['repondu_le'] ? 'message_equipe' : 'examen', 'equipe', $message);
                $sujet = 'Nous examinons votre signalement ' . $lit['reference'];
            } elseif ($action === 'rembourser') {
                $plafond = (int) $l['sous_total'] + (int) $l['frais_livraison'];
                if ($l['methode_paiement'] === 'livraison' && $l['livre_par'] === 'vendeur') {
                    throw new RuntimeException('Le client a payé en espèces au vendeur, que Jënd ne détient pas : demandez au vendeur de le rembourser directement, ou choisissez « Remplacer » ou « Refuser ».');
                }
                if ($l['statut_paiement'] !== 'paye') {
                    throw new RuntimeException('Aucun paiement encaissé pour cette commande : il n\'y a rien à rembourser.');
                }
                if ($montant < 1 || $montant > $plafond) {
                    throw new RuntimeException('Montant invalide (1 à ' . fcfa($plafond) . ').');
                }
                if ($l['statut'] !== 'livree') {                // pas livré : le vendeur n'est pas payé
                    requete("UPDATE commande_boutiques SET statut = 'retournee' WHERE id = ? AND statut IN ('a_preparer', 'expediee')", [$l['id']]);
                    $chargeVendeur = false;
                }
                requete("UPDATE litiges SET statut = 'rembourse', reponse_admin = ?, montant_rembourse = ?, a_charge_vendeur = ?, repondu_le = COALESCE(repondu_le, NOW()), resolu_le = NOW() WHERE id = ?",
                    [$message, $montant, $chargeVendeur ? 1 : 0, $litigeId]);
                litige_evenement($litigeId, 'rembourse', 'equipe', $message, $montant);
                $sujet = 'Remboursement accepté (' . $lit['reference'] . ')';
            } elseif ($action === 'remplacer') {
                requete("UPDATE litiges SET statut = 'remplace', reponse_admin = ?, repondu_le = COALESCE(repondu_le, NOW()), resolu_le = NOW() WHERE id = ?", [$message, $litigeId]);
                litige_evenement($litigeId, 'remplace', 'equipe', $message);
                $sujet = 'Remplacement accepté (' . $lit['reference'] . ')';
            } elseif ($action === 'rejeter') {
                requete("UPDATE litiges SET statut = 'rejete', reponse_admin = ?, repondu_le = COALESCE(repondu_le, NOW()), resolu_le = NOW() WHERE id = ?", [$message, $litigeId]);
                litige_evenement($litigeId, 'rejete', 'equipe', $message);
                $sujet = 'Réponse à votre signalement ' . $lit['reference'];
            } else {
                throw new RuntimeException('Action inconnue.');
            }
            $corps = $message . "\n\n" . app_url('litige/' . $lit['reference']);
        }
        $pdo->commit();
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        throw $e;
    }
    $email = requete('SELECT email FROM users WHERE id = ?', [$lit['client_id']])->fetchColumn();
    if ($email) {
        envoyer_email((string) $email, $sujet, $corps);
    }
}

/** Libellé et icône de chaque étape de la chronologie. */
const EVENEMENTS_LITIGE = [
    'cree'           => ['Signalement ouvert', 'ph-flag'],
    'message_client' => ['Précision ajoutée par le client', 'ph-chat-circle-text'],
    'examen'         => ['Prise en charge par l\'équipe Jënd', 'ph-magnifying-glass'],
    'message_equipe' => ['Message de l\'équipe Jënd', 'ph-chat-centered-dots'],
    'rembourse'      => ['Décision : remboursement accepté', 'ph-check-circle'],
    'remplace'       => ['Décision : remplacement accepté', 'ph-arrows-clockwise'],
    'rejete'         => ['Décision : signalement refusé', 'ph-x-circle'],
    'argent_envoye'  => ['Remboursement envoyé', 'ph-bank'],
];
const LITIGE_MESSAGES_PAR_JOUR = 10;

function litige_evenement(int $litigeId, string $type, string $auteur, ?string $texte = null, ?int $montant = null): void
{
    requete('INSERT INTO litige_evenements (litige_id, type, auteur, texte, montant) VALUES (?, ?, ?, ?, ?)', [$litigeId, $type, $auteur, $texte, $montant]);
}

/** Chronologie d'un signalement, du plus ancien au plus récent. */
function litige_evenements(int $litigeId): array
{
    return requete('SELECT * FROM litige_evenements WHERE litige_id = ? ORDER BY created_at, id', [$litigeId])->fetchAll();
}

function litige_clos(array $lit): bool
{
    return in_array($lit['statut'], ['rembourse', 'remplace', 'rejete'], true);
}

/** Durée lisible : « 3 h », « 1 j 4 h », « 25 min ». */
function litige_duree(int $secondes): string
{
    $secondes = max(0, $secondes);
    if ($secondes < 3600) {
        return max(1, intdiv($secondes, 60)) . ' min';
    }
    $h = intdiv($secondes, 3600);
    return $h < 24 ? $h . ' h' : intdiv($h, 24) . ' j' . ($h % 24 ? ' ' . ($h % 24) . ' h' : '');
}

/**
 * Engagement de réponse (48 h) : ['etat' => respecte|depasse|en_cours|retard, 'texte' => …, 'pourcent' => temps écoulé].
 */
function litige_engagement(array $lit): array
{
    $debut = (int) strtotime($lit['created_at']);
    $delai = LITIGE_DELAI_REPONSE_HEURES * 3600;
    if ($lit['repondu_le']) {
        $mis = (int) strtotime($lit['repondu_le']) - $debut;
        return ['etat' => $mis <= $delai ? 'respecte' : 'depasse', 'pourcent' => 100,
                'texte' => 'Première réponse en ' . litige_duree($mis) . ($mis <= $delai ? ' (engagement de ' . LITIGE_DELAI_REPONSE_HEURES . ' h respecté)' : ' (au-delà des ' . LITIGE_DELAI_REPONSE_HEURES . ' h promises)')];
    }
    $reste = $debut + $delai - time();
    $pourcent = (int) min(100, max(0, round((time() - $debut) * 100 / $delai)));
    if ($reste <= 0) {
        return ['etat' => 'retard', 'pourcent' => 100, 'texte' => 'Délai de ' . LITIGE_DELAI_REPONSE_HEURES . ' h dépassé de ' . litige_duree(-$reste) . ' : votre dossier est traité en priorité.'];
    }
    return ['etat' => 'en_cours', 'pourcent' => $pourcent, 'texte' => 'Réponse au plus tard le ' . litige_echeance($lit) . ' (encore ' . litige_duree($reste) . ')'];
}

/** Étapes du dossier : [libellé, date, fait|courant|a_venir, icône]. */
function litige_etapes(array $lit): array
{
    $clos = litige_clos($lit);
    $decision = ['rembourse' => 'Remboursement accepté', 'remplace' => 'Remplacement accepté', 'rejete' => 'Signalement refusé'][$lit['statut']] ?? 'Décision';
    $etapes = [
        ['Dossier ouvert', $lit['created_at'], 'fait', 'ph-flag'],
        ['Examen par l\'équipe', $lit['repondu_le'], $lit['repondu_le'] ? 'fait' : 'courant', 'ph-magnifying-glass'],
        [$decision, $lit['resolu_le'], $clos ? 'fait' : ($lit['repondu_le'] ? 'courant' : 'a_venir'), 'ph-scales'],
    ];
    if ($lit['statut'] === 'rembourse') {
        $etapes[] = ['Argent renvoyé', $lit['rembourse_le'], $lit['rembourse_le'] ? 'fait' : 'courant', 'ph-bank'];
    } else {
        $etapes[] = ['Dossier clôturé', $clos ? $lit['resolu_le'] : null, $clos ? 'fait' : 'a_venir', 'ph-seal-check'];
    }
    return $etapes;
}

/** Ce qui va se passer ensuite, expliqué au client. */
function litige_prochaine_etape(array $lit): string
{
    switch ($lit['statut']) {
        case 'ouvert':
            return 'Notre équipe va étudier votre dossier et contacter le vendeur. Vous n\'avez rien à faire : vous pouvez ajouter une précision ci-dessous si besoin.';
        case 'en_cours':
            return 'Nous vérifions les éléments auprès du vendeur. La décision vous sera communiquée ici et par e-mail.';
        case 'rembourse':
            return $lit['rembourse_le'] ? 'Le dossier est clos : l\'argent a été renvoyé sur votre moyen de paiement mobile.'
                : 'Le remboursement va être envoyé sur votre numéro Wave ou Orange Money. Vous serez prévenu dès l\'envoi.';
        case 'remplace':
            return 'Le vendeur vous envoie un produit de remplacement. Le dossier est clos.';
        default:
            return 'Le dossier est clos. Si vous n\'êtes pas d\'accord avec la décision, écrivez-nous depuis la page d\'aide en citant la référence ' . $lit['reference'] . '.';
    }
}

/** Le client ajoute une précision à son dossier tant qu'il est ouvert. @throws RuntimeException message affichable */
function litige_message_client(int $litigeId, int $clientId, string $texte): void
{
    $lit = requete('SELECT * FROM litiges WHERE id = ? AND client_id = ?', [$litigeId, $clientId])->fetch();
    if (!$lit) {
        throw new RuntimeException('Signalement introuvable.');
    }
    if (litige_clos($lit)) {
        throw new RuntimeException('Ce signalement est clos : pour toute question, écrivez-nous depuis la page d\'aide.');
    }
    $texte = trim($texte);
    if (mb_strlen($texte) < 5 || mb_strlen($texte) > 2000) {
        throw new RuntimeException('Écrivez votre message (5 à 2000 caractères).');
    }
    if (limite_atteinte('litige:message:' . $litigeId, LITIGE_MESSAGES_PAR_JOUR, 86400)) {
        throw new RuntimeException('Vous avez envoyé beaucoup de messages aujourd\'hui. Notre équipe les lit : réessayez demain.');
    }
    limite_enregistrer('litige:message:' . $litigeId);
    litige_evenement($litigeId, 'message_client', 'client', $texte);
    try {
        envoyer_email((string) env('ADMIN_EMAIL', 'admin@jend.local'), 'Nouvelle précision sur le signalement ' . $lit['reference'],
            $texte . "\n\n" . app_url('admin/litiges?id=' . $litigeId));
    } catch (Throwable $e) {
        error_log('Jënd — e-mail litige : ' . $e->getMessage());
    }
}
