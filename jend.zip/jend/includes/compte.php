<?php
declare(strict_types=1);

/** Identifiants des produits favoris de l'utilisateur connecté : [produit_id => true]. */
function favoris_ids(): array
{
    static $ids = null;
    if ($ids === null) {
        $ids = [];
        if ($u = utilisateur()) {
            foreach (requete('SELECT produit_id FROM favoris WHERE user_id = ?', [$u['id']])->fetchAll(PDO::FETCH_COLUMN) as $id) {
                $ids[(int) $id] = true;
            }
        }
    }
    return $ids;
}

/** Zones de livraison actives. */
/** Villes où l'on livre (déduites des zones actives) : « Touba », « Touba et Mbacké »... */
/** Villes et régions où au moins une boutique active livre (toutes les villes des zones actives tant qu'il n'y a aucune boutique). */
function villes_couvertes(): array
{
    $r = regions_desservies();
    $avec = array_keys(array_filter($r, fn ($x) => $x['boutiques']));
    $v = $avec ?: array_keys($r);
    sort($v);
    return $v;
}

function villes_livrees(): string
{
    $v = villes_couvertes();
    if (!$v) {
        return 'votre ville';
    }
    if (count($v) >= LIVRAISON_NATIONALE_MIN_VILLES) {
        return 'tout le Sénégal';
    }
    return count($v) === 1 ? $v[0] : implode(', ', array_slice($v, 0, -1)) . ' et ' . end($v);
}

/** À partir de ce nombre de villes/régions actives, le site annonce une livraison « dans tout le Sénégal ». */
const LIVRAISON_NATIONALE_MIN_VILLES = 12;

function livraison_nationale(): bool
{
    return count(villes_couvertes()) >= LIVRAISON_NATIONALE_MIN_VILLES;
}

/** [délai minimum, délai maximum] en jours, parmi les zones actives. */
function delais_livraison(): array
{
    $r = requete('SELECT MIN(delai_jours), MAX(delai_jours) FROM zones_livraison WHERE actif = 1')->fetch(PDO::FETCH_NUM);
    return [(int) ($r[0] ?? 1), (int) ($r[1] ?? 1)];
}

/** Zones regroupées par ville/région : ['Dakar' => [zone, zone…], 'Touba' => […]] (pour les listes déroulantes). */
function zones_par_ville(array $zones): array
{
    $g = [];
    foreach ($zones as $z) {
        $g[$z['region']][] = $z;
    }
    uksort($g, fn ($a, $b) => $a === 'Touba' ? -1 : ($b === 'Touba' ? 1 : strcmp($a, $b)));      // Touba d'abord (là où le site démarre)
    return $g;
}

function zones_actives(): array
{
    return requete('SELECT id, nom, region, frais, delai_jours FROM zones_livraison WHERE actif = 1 ORDER BY region, frais, nom')->fetchAll();
}

/** Onglets de l'espace client. $actif : commandes | adresses | profil | favoris */
function compte_onglets(string $actif): void
{
    $onglets = [
        'commandes' => ['compte',           'ph-package',  'Commandes'],
        'adresses'  => ['compte/adresses',  'ph-map-pin',  'Adresses'],
        'favoris'   => ['favoris',          'ph-heart',    'Favoris'],
        'depense'   => ['depense',          'ph-basket',   'Dépense du mois'],
        'alertes'   => ['alertes',          'ph-bell-ringing', 'Alertes prix'],
        'offres'    => ['offres',           'ph-handshake', 'Mes offres'],
        'mesure'    => ['sur-mesure',       'ph-scissors', 'Sur mesure'],
        'litiges'   => ['litiges',          'ph-chat-circle-text', 'Signalements'],
        'profil'    => ['compte/profil',    'ph-user-gear','Profil'],
        'securite'  => ['compte/securite',  'ph-shield-check', 'Sécurité'],
        'aide'      => ['aide',             'ph-lifebuoy', 'Aide'],
    ];
    $u = utilisateur();
    if (!($u && requete('SELECT 1 FROM demandes_mesure WHERE client_id = ? LIMIT 1', [$u['id']])->fetch()) && $actif !== 'mesure') {
        unset($onglets['mesure']);              // l'onglet « Sur mesure » n'apparaît que si le client a fait une demande
    }
    if ($u && $u['role'] === 'admin') {
        $onglets['admin'] = ['admin', 'ph-crown', 'Administration'];
    }
    if ($u && requete('SELECT 1 FROM boutiques WHERE user_id = ?', [$u['id']])->fetch()) {
        $onglets['vendeur'] = ['vendeur', 'ph-storefront', 'Ma boutique'];
    }
    $notifs = $u ? notifs_client((int) $u['id']) : [];
    echo '<nav class="onglets" aria-label="Espace client">';
    foreach ($onglets as $cle => [$chemin, $icone, $libelle]) {
        printf('<a href="%s"%s><i class="ph %s"></i> %s%s</a>', e(url($chemin)), $cle === $actif ? ' class="actif" aria-current="page"' : '', $icone, e($libelle), pastille_onglet($notifs[$cle] ?? 0, in_array($cle, ['commandes', 'offres', 'mesure'], true)));
    }
    echo '</nav>';
}

/** Le client a-t-il reçu ce produit (sous-commande livrée) ? */
function achat_livre(int $produitId, int $userId): bool
{
    return (bool) requete(
        "SELECT 1 FROM commande_lignes cl
           JOIN commande_boutiques cb ON cb.id = cl.commande_boutique_id AND cb.statut = 'livree'
           JOIN commandes c ON c.id = cb.commande_id
          WHERE cl.produit_id = ? AND c.client_id = ? LIMIT 1",
        [$produitId, $userId]
    )->fetchColumn();
}
