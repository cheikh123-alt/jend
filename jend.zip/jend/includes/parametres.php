<?php
declare(strict_types=1);

/**
 * Paramètres du site que l'administrateur règle dans son espace (Administration → Paramètres).
 * Valeur absente de la base : on prend la valeur par défaut donnée à l'appel (souvent celle du .env), sinon le défaut du code.
 *
 * Fonctionnalités à activer quand le site grandit :
 *  - livreurs_jend  : livraison par des livreurs Jënd (désactivée au départ : chaque vendeur livre lui-même) ;
 *  - acompte_actif / acompte_pourcent / acompte_minimum : acompte pour les commandes payées à la livraison ;
 *  - commission_defaut : commission des NOUVELLES boutiques.
 */
function parametres_charges(bool $recharger = false): array
{
    static $valeurs = null;
    if ($recharger) {
        $valeurs = null;
    }
    if ($valeurs === null) {
        $valeurs = [];
        if (function_exists('requete')) {
            try {
                foreach (requete('SELECT cle, valeur FROM parametres')->fetchAll() as $l) {
                    $valeurs[$l['cle']] = $l['valeur'];
                }
            } catch (Throwable $e) {          // base indisponible ou table pas encore créée (migration 012) : on garde les valeurs par défaut
                $valeurs = [];
            }
        }
    }
    return $valeurs;
}

function parametre(string $cle, ?string $defaut = null): ?string
{
    return parametres_charges()[$cle] ?? $defaut;
}

/** Fonctionnalité activée ? ($defaut : valeur tant que l'administrateur n'a rien réglé) */
function parametre_actif(string $cle, bool $defaut): bool
{
    return parametre($cle, $defaut ? '1' : '0') === '1';
}

function parametre_definir(string $cle, string $valeur): void
{
    requete('INSERT INTO parametres (cle, valeur) VALUES (?, ?) ON DUPLICATE KEY UPDATE valeur = VALUES(valeur)', [$cle, $valeur]);
    parametres_charges(true);
}

/**
 * Annonce d'un changement de commission déjà communiqué aux vendeurs : ['pct' => float, 'le' => 'AAAA-MM-JJ'] ou null.
 * Les vendeurs doivent être prévenus au moins COMMISSION_PREAVIS_JOURS jours avant la date d'entrée en vigueur.
 */
const COMMISSION_PREAVIS_JOURS = 30;
function commission_annonce(): ?array
{
    $pct = parametre('commission_annonce_pct');
    $le = parametre('commission_annonce_le');
    if ($pct === null || $le === null || !is_numeric($pct) || !preg_match('/^\d{4}-\d{2}-\d{2}$/', $le)) {
        return null;
    }
    return ['pct' => (float) $pct, 'le' => $le];
}

/**
 * Applique le taux annoncé quand sa date est arrivée : toutes les boutiques et les nouvelles boutiques passent au nouveau taux,
 * pour les commandes passées à partir de maintenant (les commandes déjà passées gardent leur commission).
 * Appelée avec les tâches horaires (aucune action de l'administrateur nécessaire) et par le bouton « Appliquer ».
 * Retourne le taux appliqué, ou null si rien n'était à appliquer.
 */
function commission_annonce_appliquer(): ?float
{
    $ann = commission_annonce();
    if (!$ann || $ann['le'] > date('Y-m-d')) {
        return null;
    }
    requete('UPDATE boutiques SET commission_pct = ?', [$ann['pct']]);
    parametre_definir('commission_defaut', (string) $ann['pct']);
    parametre_definir('commission_offre_lancement', '0');            // fin de l'offre de lancement
    requete("DELETE FROM parametres WHERE cle IN ('commission_annonce_pct', 'commission_annonce_le')");
    parametres_charges(true);
    $u = function_exists('utilisateur') ? utilisateur() : null;
    requete('INSERT INTO journal_admin (admin_id, action, detail, ip) VALUES (?, ?, ?, ?)',
        [$u['id'] ?? null, 'commission_appliquee', $ann['pct'] . ' % sur toutes les boutiques (annoncé pour le ' . $ann['le'] . ')' . ($u ? '' : ' — automatiquement'), $u ? ip_client() : null]);
    return $ann['pct'];
}

/**
 * Délai (en jours) entre la livraison confirmée et le moment où le gain devient retirable : le temps que le client puisse
 * signaler un problème sans que l'argent soit déjà parti. 3 jours par défaut, réglable de 0 à 30 (Administration → Paramètres).
 */
function delai_retrait_jours(): int
{
    $v = function_exists('parametre') ? parametre('delai_retrait_jours', env('DELAI_RETRAIT_JOURS', '3')) : env('DELAI_RETRAIT_JOURS', '3');
    return is_numeric($v) ? max(0, min(30, (int) $v)) : 3;
}

/** La livraison par des livreurs Jënd est-elle activée ? (non, tant que l'administrateur ne l'a pas décidé) */
/** Paiement à la livraison (espèces) proposé aux clients ? Désactivé par défaut : l'argent passe d'abord par Jënd (paiement en ligne). */
function paiement_livraison_actif(): bool
{
    return parametre_actif('paiement_livraison', false);
}

/**
 * Paiement en ligne proposé (Wave, Orange Money, carte… via PayDunya / PayTech) ? Activé par défaut.
 * L'administrateur peut le couper tant qu'aucun prestataire n'a validé son compte : le site fonctionne alors
 * en « paiement à la livraison uniquement », sans acompte en ligne (Administration → Paramètres).
 */
function paiement_en_ligne_actif(): bool
{
    return parametre_actif('paiement_en_ligne', true);
}

/**
 * Le taux de commission actuel est-il présenté comme une « offre de lancement » (taux réduit pour attirer les premiers vendeurs) ?
 * Activé par défaut ; l'administrateur le coupe quand le site est installé (Paramètres → Commission).
 */
function offre_lancement(): bool
{
    return parametre_actif('commission_offre_lancement', true) && commission_defaut() > 0.0;
}

/**
 * Frais de paiement sécurisé payés par le client sur un paiement en ligne : pourcentage du montant (produits + livraison),
 * avec un minimum. 0 % par défaut (Jënd paie seul les frais du prestataire). Ils reviennent à Jënd, jamais au vendeur.
 */
function frais_service(int $montant): int
{
    $pct = str_replace(',', '.', trim((string) parametre('frais_service_pct', '0')));
    $pct = is_numeric($pct) ? max(0.0, min(10.0, (float) $pct)) : 0.0;
    $fin = (string) parametre('frais_service_fin', '');               // date de fin choisie par l'administrateur (vide = sans fin)
    if ($fin !== '' && preg_match('/^\d{4}-\d{2}-\d{2}$/', $fin) && date('Y-m-d') > $fin) {
        return 0;
    }
    if ($pct <= 0 || $montant <= 0) {
        return 0;
    }
    return max((int) ceil($montant * $pct / 100), max(0, (int) parametre('frais_service_min', '0')));
}

function livreurs_jend_actifs(): bool
{
    return parametre_actif('livreurs_jend', false);
}
