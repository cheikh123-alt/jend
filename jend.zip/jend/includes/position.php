<?php
declare(strict_types=1);

/**
 * « Ma position » : point GPS de livraison, donné par le téléphone du client (ou de son proche, pour un cadeau).
 * Beaucoup d'adresses n'ont ni rue ni numéro : le vendeur ou le livreur ouvre l'itinéraire directement dans son application de cartes.
 */

// Cadre large autour du Sénégal : refuse les positions fantaisistes (0,0, autre continent…)
const POSITION_LAT_MIN = 12.0, POSITION_LAT_MAX = 16.9, POSITION_LNG_MIN = -17.8, POSITION_LNG_MAX = -11.2;

/** Coordonnées valides au Sénégal ? Renvoie [lat, lng] arrondis (6 décimales, ~10 cm), ou null. */
function position_valide(mixed $lat, mixed $lng): ?array
{
    $lat = is_string($lat) ? trim($lat) : $lat;
    $lng = is_string($lng) ? trim($lng) : $lng;
    if (!is_numeric($lat) || !is_numeric($lng)) {
        return null;
    }
    $lat = round((float) $lat, 6);
    $lng = round((float) $lng, 6);
    if ($lat < POSITION_LAT_MIN || $lat > POSITION_LAT_MAX || $lng < POSITION_LNG_MIN || $lng > POSITION_LNG_MAX) {
        return null;
    }
    return [$lat, $lng];
}

/** Lien d'itinéraire (ouvre Google Maps ou l'application de cartes du téléphone). */
function lien_gps(mixed $lat, mixed $lng): string
{
    return 'https://www.google.com/maps/dir/?api=1&destination=' . rawurlencode(sprintf('%.6F,%.6F', (float) $lat, (float) $lng));
}

/** Bouton « Itinéraire » si la commande a une position, sinon chaîne vide. */
function bouton_itineraire(array $c, string $libelle = 'Itinéraire GPS'): string
{
    if ($c['livraison_lat'] === null || $c['livraison_lng'] === null) {
        return '';
    }
    return '<a class="btn btn-contour btn-gps" href="' . e(lien_gps($c['livraison_lat'], $c['livraison_lng'])) . '" target="_blank" rel="noopener noreferrer"><i class="ph ph-navigation-arrow"></i> ' . e($libelle) . '</a>';
}

/** Lien à envoyer au proche (commande cadeau) pour qu'il partage sa position. Crée le jeton au besoin. */
function position_lien_proche(array $c): string
{
    $jeton = $c['position_jeton'] ?? null;
    if (!$jeton) {
        $jeton = bin2hex(random_bytes(16));
        requete('UPDATE commandes SET position_jeton = ? WHERE id = ? AND position_jeton IS NULL', [$jeton, $c['id']]);
        $jeton = (string) requete('SELECT position_jeton FROM commandes WHERE id = ?', [$c['id']])->fetchColumn();
    }
    return app_url('position/' . $jeton);
}

/** La position de cette commande peut-elle encore être changée (pas annulée, pas tout livré) ? */
function position_modifiable(int $commandeId): bool
{
    return (bool) requete(
        "SELECT 1 FROM commandes c WHERE c.id = ? AND c.statut <> 'annulee'
            AND EXISTS (SELECT 1 FROM commande_boutiques cb WHERE cb.commande_id = c.id AND cb.statut IN ('a_preparer', 'expediee'))",
        [$commandeId]
    )->fetch();
}
