<?php
/** @var string $titre */
/** @var string $description */
$titre       = $titre ?? 'Jënd — La marketplace sénégalaise';
$description = $description ?? (paiement_en_ligne_actif()
    ? 'Jënd : achetez et vendez en toute confiance au Sénégal. Wave, Orange Money ou carte' . (paiement_livraison_actif() ? ', ou paiement à la livraison' : '') . '.'
    : 'Jënd : achetez et vendez en toute confiance au Sénégal. Paiement en espèces à la livraison.');
$navCats     = requete('SELECT nom, slug FROM categories WHERE parent_id IS NULL ORDER BY position')->fetchAll();
$nbPanier    = panier_quantite();
$message     = flash_lire();
$moi         = utilisateur();
?>
<!DOCTYPE html>
<html lang="fr"<?= mode_leger() ? ' class="leger"' : '' ?>>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= e($titre) ?></title>
<meta name="description" content="<?= e($description) ?>">
<?php if (est_test() || !empty($robots)): ?><meta name="robots" content="noindex, nofollow"><?php endif; ?>
<meta name="base" content="<?= e(url()) ?>">
<meta name="csrf" content="<?= e(csrf_token()) ?>">
<meta name="connecte" content="<?= $moi ? '1' : '0' ?>">
<?php /* Aucune ressource externe : polices, icônes et bibliothèques sont hébergées dans assets/vendor/ (voir assets/vendor/LICENCES.md) */ ?>
<?php /* Polices les plus utilisées chargées en priorité ; icônes : seulement celles du site (scripts/icones-site.py) */ ?>
<link rel="preload" href="<?= e(url('assets/vendor/fonts/satoshi-400.woff2')) ?>" as="font" type="font/woff2" crossorigin>
<link rel="preload" href="<?= e(url('assets/vendor/fonts/clash-display-600.woff2')) ?>" as="font" type="font/woff2" crossorigin>
<link rel="stylesheet" href="<?= e(asset('vendor/css/fontshare.css')) ?>">
<link rel="stylesheet" href="<?= e(asset('vendor/css/phosphor-site.css')) ?>">
<?php if (!empty($animations) && !mode_leger()): ?><link rel="stylesheet" href="<?= e(asset('vendor/css/splitting.css')) ?>"><?php endif; ?>
<link rel="stylesheet" href="<?= e(asset('css/style.css')) ?>">
<link rel="stylesheet" href="<?= e(asset('css/identite.css')) ?>">
</head>
<body>
<?php if (est_test()): ?>
<div class="bandeau-test" role="note"><i class="ph-fill ph-flask"></i> <b>SITE DE TEST</b> — aucun paiement réel, aucune vraie livraison. Les données peuvent être effacées à tout moment.</div>
<?php endif; ?>

<div class="bandeau">Livraison à <strong><?= e(villes_livrees()) ?></strong> <?= !paiement_en_ligne_actif() ? ' · Paiement en espèces à la livraison' : (paiement_livraison_actif() ? ' · Paiement à la livraison disponible' : ' · Paiement sécurisé en ligne') . ' · Wave &amp; Orange Money acceptés' ?></div>

<header class="entete">
  <div class="wrap">
    <a href="<?= e(url()) ?>" class="logo" aria-label="Jënd, accueil">Jënd<span>.</span></a>
    <form class="recherche" role="search" action="<?= e(url('recherche')) ?>" method="get">
      <i class="ph ph-magnifying-glass" aria-hidden="true"></i>
      <input type="search" name="q" placeholder="Que cherchez-vous ? wax, téléphone, bissap…" aria-label="Rechercher">
      <button type="submit" aria-label="Lancer la recherche"><i class="ph ph-arrow-right"></i></button>
    </form>
    <nav class="actions">
      <a href="<?= e(url($moi ? espace_du_role((string) $moi['role']) : 'connexion')) ?>"><i class="ph ph-user"></i><span><?= $moi ? e(explode(' ', $moi['nom'])[0]) : 'Connexion' ?></span></a>
      <?php if ($moi): [$nbAlertes, $lienAlertes] = notifs_total($moi); ?>
      <a href="<?= e(url($lienAlertes)) ?>" class="cloche<?= $nbAlertes > 0 ? ' cloche-active' : '' ?>" title="<?= $nbAlertes > 0 ? e($nbAlertes . ' chose(s) à faire') : 'Rien à faire' ?>"><i class="ph<?= $nbAlertes > 0 ? '-fill' : '' ?> ph-bell"></i><span>Alertes</span><?php if ($nbAlertes > 0): ?><b class="pastille"><?= $nbAlertes > 99 ? '99+' : $nbAlertes ?></b><?php endif; ?></a>
      <?php endif; ?>
      <a href="<?= e(url('favoris')) ?>"><i class="ph ph-heart"></i><span>Favoris</span></a>
      <a href="<?= e(url('panier')) ?>"><i class="ph ph-shopping-bag"></i><span>Panier</span><b class="pastille"><?= $nbPanier ?></b></a>
      <?php if ($moi): ?>
      <form method="post" action="<?= e(url('deconnexion')) ?>" class="form-deconnexion"><?= csrf_champ() ?>
        <button type="submit" title="Se déconnecter"><i class="ph ph-sign-out"></i><span>Quitter</span></button></form>
      <?php endif; ?>
    </nav>
  </div>
  <div class="nav-cat">
    <div class="wrap">
      <?php foreach ($navCats as $navCat): ?>
        <a href="<?= e(url('categorie/' . $navCat['slug'])) ?>"><?= e($navCat['nom']) ?></a>
      <?php endforeach; ?>
    </div>
  </div>
</header>
<?php if ($message): ?>
  <div class="flash flash-<?= e($message['type']) ?>" role="status"><div class="wrap"><?= e($message['message']) ?>
    <?php if (!empty($message['lien']['url'])): ?> <a class="flash-lien" href="<?= e($message['lien']['url']) ?>"><?= e($message['lien']['texte']) ?> <i class="ph ph-arrow-right"></i></a><?php endif; ?></div></div>
<?php endif; ?>
