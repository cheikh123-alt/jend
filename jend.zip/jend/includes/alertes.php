<?php
declare(strict_types=1);

/**
 * « Prévenez-moi » : le client est averti par e-mail quand le prix d'un produit baisse (prix du vendeur ou promotion de fête)
 * ou quand un produit épuisé revient en stock. Une alerte ne sert qu'une fois : elle est supprimée après l'envoi.
 */

const ALERTES_MAX = 50;              // par client

function alerte_active(int $userId, int $produitId): bool
{
    return (bool) requete('SELECT 1 FROM alertes_produit WHERE user_id = ? AND produit_id = ?', [$userId, $produitId])->fetch();
}

/** Active ou retire l'alerte. @param int $prixVu prix affiché (promotion comprise) @throws RuntimeException @return bool alerte active après l'action */
function alerte_basculer(int $userId, int $produitId, int $prixVu, bool $epuise): bool
{
    if (alerte_active($userId, $produitId)) {
        requete('DELETE FROM alertes_produit WHERE user_id = ? AND produit_id = ?', [$userId, $produitId]);
        return false;
    }
    if ((int) requete('SELECT COUNT(*) FROM alertes_produit WHERE user_id = ?', [$userId])->fetchColumn() >= ALERTES_MAX) {
        throw new RuntimeException('Vous suivez déjà ' . ALERTES_MAX . ' produits : retirez-en quelques-uns dans « Alertes prix ».');
    }
    requete('INSERT INTO alertes_produit (user_id, produit_id, prix_vu, epuise) VALUES (?, ?, ?, ?)', [$userId, $produitId, $prixVu, $epuise ? 1 : 0]);
    return true;
}

/** Envoie les alertes déclenchées pour un produit (après une modification du vendeur ou le début d'une promotion). @return int e-mails envoyés */
function alertes_produit_verifier(int $produitId): int
{
    $p = requete(
        "SELECT p.id, p.nom, p.slug, p.prix, p.stock, " . SQL_PROMO_FETE . " AS promo_pct FROM produits p JOIN boutiques b ON b.id = p.boutique_id AND b.statut = 'active'
          WHERE p.id = ? AND p.statut = 'publie' AND p.reserve_client_id IS NULL",
        [$produitId]
    )->fetch();
    if (!$p || (int) $p['stock'] < 1) {
        return 0;
    }
    $prix = prix_promo((int) $p['prix'], (int) $p['promo_pct']);
    $n = 0;
    foreach (requete('SELECT a.id, a.prix_vu, a.epuise, u.email, u.nom FROM alertes_produit a JOIN users u ON u.id = a.user_id AND u.actif = 1
                       WHERE a.produit_id = ? AND (a.epuise = 1 OR a.prix_vu > ?)', [$produitId, $prix])->fetchAll() as $a) {
        requete('DELETE FROM alertes_produit WHERE id = ?', [$a['id']]);       // une seule fois, même si l'envoi échoue
        $baisse = (int) $a['prix_vu'] > $prix;
        try {
            envoyer_email((string) $a['email'], $baisse ? 'Baisse de prix : « ' . $p['nom'] . ' »' : '« ' . $p['nom'] . ' » est de retour',
                'Bonjour ' . explode(' ', trim((string) $a['nom']))[0] . ",\n\n"
                . ($baisse ? "Le prix de « {$p['nom']} » est passé de " . fcfa((int) $a['prix_vu']) . ' à ' . fcfa($prix) . ((int) $p['promo_pct'] > 0 ? ' (promotion de fête)' : '') . '.'
                           : "« {$p['nom']} » est de nouveau disponible, à " . fcfa($prix) . '.')
                . ($a['epuise'] && $baisse ? ' Il est aussi de nouveau en stock.' : '')
                . "\n\nVoir le produit :\n" . app_url('produit/' . $p['slug']) . "\n\nVous ne recevrez plus d'alerte pour ce produit (vous pouvez la réactiver sur sa page).");
            $n++;
        } catch (Throwable $e) {
            error_log('Jënd — alerte produit : ' . $e->getMessage());
        }
    }
    return $n;
}

/** Promotions de fête qui viennent de commencer : prévient les clients qui suivent ces produits (lancé avec les rappels, une fois par heure). */
function alertes_promotions(): int
{
    $n = 0;
    foreach (requete("SELECT DISTINCT a.produit_id FROM alertes_produit a JOIN produit_fetes pf ON pf.produit_id = a.produit_id AND pf.remise_pct > 0
                        JOIN fetes f ON f.id = pf.fete_id AND f.actif = 1 AND f.vitrine_des <= CURDATE() AND f.date_fete >= CURDATE() LIMIT 200")->fetchAll(PDO::FETCH_COLUMN) as $pid) {
        $n += alertes_produit_verifier((int) $pid);
    }
    return $n;
}
