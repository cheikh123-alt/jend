<?php
declare(strict_types=1);

/** Lit le fichier de configuration et le garde en mémoire (sans toucher aux variables du serveur). */
function env(string $cle, ?string $defaut = null): ?string
{
    static $valeurs = null;

    if ($valeurs === null) {
        // JEND_ENV_FILE : permet de vérifier un autre fichier de configuration (scripts/verifier-production.php, tests).
        $fichier = getenv('JEND_ENV_FILE') ?: env_choisir_fichier(
            dirname(__DIR__),
            PHP_SAPI === 'cli' ? '' : (string) ($_SERVER['HTTP_HOST'] ?? ''),
            PHP_SAPI === 'cli' ? '' : (string) ($_SERVER['REMOTE_ADDR'] ?? '')
        );
        $valeurs = env_lire($fichier);
        if (PHP_SAPI !== 'cli' && !getenv('JEND_ENV_FILE')) {
            $valeurs = env_securiser($valeurs, (string) ($_SERVER['REMOTE_ADDR'] ?? ''));
        }
    }

    return $valeurs[$cle] ?? $defaut;
}

/** Lit un fichier « CLE=valeur » (lignes vides et commentaires ignorés). */
function env_lire(string $fichier): array
{
    $valeurs = [];
    if (is_file($fichier)) {
        foreach (file($fichier, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) as $ligne) {
            $ligne = trim($ligne);
            if ($ligne === '' || $ligne[0] === '#' || strpos($ligne, '=') === false) {
                continue;
            }
            [$k, $v] = explode('=', $ligne, 2);
            $v = preg_replace('/\s+#.*$/', '', $v);   // commentaire en fin de ligne
            $valeurs[trim($k)] = trim($v, " \t\"'");
        }
    }
    return $valeurs;
}

/**
 * Deux fichiers peuvent cohabiter dans le dossier (tous deux protégés par .htaccess) :
 *  - « .env »       : l'ordinateur de développement (XAMPP) ;
 *  - « config.env » : le SERVEUR en ligne.
 * Le même dossier peut donc être envoyé tel quel chez l'hébergeur. config.env est utilisé quand le site est ouvert à son
 * adresse (APP_URL) ou par un visiteur venant d'Internet ; sinon (ordinateur, Wi-Fi local, terminal) c'est .env.
 * Si un seul des deux existe, c'est lui.
 */
function env_choisir_fichier(string $racine, string $hote, string $ip): string
{
    $local = $racine . '/.env';
    $serveur = $racine . '/config.env';
    if (!is_file($serveur)) {
        return $local;
    }
    if (!is_file($local)) {
        return $serveur;
    }
    $hote = strtolower(preg_replace('/:\d+$/', '', $hote));
    $hoteServeur = strtolower((string) parse_url(env_lire($serveur)['APP_URL'] ?? '', PHP_URL_HOST));
    $memeAdresse = $hote !== '' && $hoteServeur !== '' && ($hote === $hoteServeur || $hote === 'www.' . $hoteServeur);
    $visiteurInternet = $ip !== '' && filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE) !== false;
    return ($memeAdresse || $visiteurInternet) ? $serveur : $local;
}

/**
 * Sécurité : le mode « dev » (erreurs techniques affichées) n'est accepté que pour un visiteur de l'ordinateur ou du réseau local.
 * Si un .env de développement se retrouve en ligne par erreur, le site se comporte en production.
 */
function env_securiser(array $valeurs, string $ip): array
{
    if (($valeurs['APP_ENV'] ?? '') === 'dev') {
        $public = $ip !== '' && filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE) !== false;
        if ($public) {
            $valeurs['APP_ENV'] = 'prod';
        }
    }
    return $valeurs;
}
