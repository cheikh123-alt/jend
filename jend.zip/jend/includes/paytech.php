<?php
declare(strict_types=1);

/**
 * Paiement PayTech (https://paytech.sn) : Wave, Orange Money, Free Money, Wizall, cartes… sur la page de paiement de PayTech.
 * Fonctionne À CÔTÉ de PayDunya : l'administrateur choisit le prestataire principal (Administration → Paramètres),
 * l'autre sert de secours automatique si le principal ne répond pas.
 *
 * Sécurité (même principe que PayDunya) : le navigateur du client ne prouve JAMAIS un paiement.
 * Une commande n'est marquée payée que par la notification IPN de PayTech, authentifiée par HMAC-SHA256
 * (clé = API_SECRET, message = « montant|ref_command|API_KEY », méthode recommandée par la documentation PayTech),
 * pour le bon jeton, la bonne commande et le bon montant (paiement_appliquer).
 * Les empreintes SHA-256 des clés (api_key_sha256…) ne suffisent pas : elles sont identiques pour toutes les notifications.
 *
 * Réglages (config.env) : PAYTECH_API_KEY, PAYTECH_API_SECRET (jamais dans le code), PAYTECH_ENV=test|prod.
 * ⚠ Mode test PayTech : d'après leur documentation, une petite somme réelle (100 à 150 F) est débitée à chaque essai.
 */

const PAYTECH_HOTE_AUTORISE = 'paytech.sn';
/** Nos moyens de paiement → libellés « target_payment » de PayTech (le client arrive directement sur le bon moyen). */
const PAYTECH_MOYENS = ['wave' => 'Wave', 'orange_money' => 'Orange Money', 'free_money' => 'Free Money', 'carte' => 'Carte Bancaire'];

function paytech_configure(): bool
{
    return (string) env('PAYTECH_API_KEY', '') !== '' && (string) env('PAYTECH_API_SECRET', '') !== '';
}

function paytech_actif(): bool
{
    return in_array('paytech', prestataires_actifs(), true);
}

function paytech_mode_test(): bool
{
    return !in_array(strtolower(trim((string) env('PAYTECH_ENV', 'test'))), ['prod', 'production', 'live'], true);     // « prod » chez PayTech ; live / production acceptés aussi
}

/** Adresse de l'API. PAYTECH_API_BASE (faux serveur des tests) n'est lu qu'en développement. */
function paytech_base(): string
{
    $autre = (string) env('PAYTECH_API_BASE', '');
    if ($autre !== '' && env('APP_ENV', 'prod') === 'dev') {
        return rtrim($autre, '/');
    }
    return 'https://paytech.sn/api';
}

/**
 * Appel de l'API PayTech (depuis le serveur uniquement : les clés ne passent jamais par le navigateur).
 * @throws RuntimeException message sûr (jamais les clés ni la réponse brute)
 */
function paytech_requete(string $methode, string $chemin, ?array $champs = null): array
{
    if (!paytech_configure()) {
        throw new RuntimeException('PayTech n\'est pas configuré (clés manquantes dans config.env).');
    }
    $url = paytech_base() . '/' . ltrim($chemin, '/');
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_CUSTOMREQUEST => $methode, CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 20, CURLOPT_CONNECTTIMEOUT => 8,
        CURLOPT_FOLLOWLOCATION => false,                       // certificat TOUJOURS vérifié (l'exemple de PayTech le désactive : pas ici)
        CURLOPT_PROTOCOLS => str_starts_with($url, 'http://') ? (CURLPROTO_HTTP | CURLPROTO_HTTPS) : CURLPROTO_HTTPS,
        CURLOPT_HTTPHEADER => ['Accept: application/json', 'Content-Type: application/x-www-form-urlencoded',
            'API_KEY: ' . env('PAYTECH_API_KEY'), 'API_SECRET: ' . env('PAYTECH_API_SECRET')],
    ] + ($champs !== null ? [CURLOPT_POSTFIELDS => http_build_query($champs)] : []));
    $reponse = curl_exec($ch);
    $code = (int) curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
    curl_close($ch);
    if ($reponse === false || $code === 0) {
        error_log('Jënd — PayTech injoignable (' . $methode . ' ' . parse_url($url, PHP_URL_PATH) . ')');
        throw new RuntimeException('serveur PayTech injoignable depuis cet hébergement (connexion sortante bloquée ?)');
    }
    $data = json_decode((string) $reponse, true);
    if (!is_array($data)) {
        error_log('Jënd — PayTech : réponse illisible (HTTP ' . $code . ')');
        throw new RuntimeException('Réponse invalide du service de paiement.');
    }
    return $data;
}

/** Demande de paiement PayTech pour la commande (total ou acompte) ; renvoie l'adresse de leur page de paiement. */
function paytech_initier(array $commande): string
{
    $montant = commande_a_payer($commande);
    $ref = (string) $commande['reference'];
    $acompte = commande_a_acompte($commande);
    $refTentative = $ref . '-' . strtoupper(bin2hex(random_bytes(3)));       // une référence unique par tentative (exigé par PayTech)
    $retour = app_url('paiement/retour/' . $ref);
    $moyen = PAYTECH_MOYENS[(string) commande_methode_en_ligne($commande)] ?? '';
    $rep = paytech_requete('POST', 'payment/request-payment', [
        'item_name'    => 'Commande ' . $ref . ($acompte ? ' (acompte)' : ''),
        'item_price'   => $montant,
        'currency'     => 'XOF',
        'ref_command'  => $refTentative,
        'command_name' => 'Jënd — commande ' . $ref . ($acompte ? ' (acompte)' : ''),
        'env'          => paytech_mode_test() ? 'test' : 'prod',
        'ipn_url'      => app_url('paiement/webhook'),
        'success_url'  => $retour,
        'cancel_url'   => $retour,
        'target_payment' => $moyen,
        'custom_field' => json_encode(['commande' => $ref]),
    ]);
    $token = (string) ($rep['token'] ?? '');
    $page = (string) ($rep['redirect_url'] ?? ($rep['redirectUrl'] ?? ''));
    if ((int) ($rep['success'] ?? 0) !== 1 || !preg_match('/^[A-Za-z0-9_-]{6,100}$/', $token)) {
        error_log('Jënd — PayTech a refusé la demande de paiement');
        $raison = is_array($rep['errors'] ?? null) ? implode(', ', array_map('strval', $rep['errors'])) : (string) ($rep['message'] ?? '');
        throw new RuntimeException('demande refusée par PayTech en mode ' . (paytech_mode_test() ? 'TEST' : 'RÉEL (prod)') . ($raison !== '' ? ' (' . mb_substr(strip_tags($raison), 0, 120) . ')' : '') . ' — clés (API_KEY / API_SECRET inversées ?) ou compte non activé');
    }
    $hote = (string) parse_url($page, PHP_URL_HOST);
    $hoteOk = $hote === PAYTECH_HOTE_AUTORISE || str_ends_with($hote, '.' . PAYTECH_HOTE_AUTORISE);
    if (!(preg_match('#^https://#', $page) && $hoteOk) && !(env('APP_ENV', 'prod') === 'dev' && env('PAYTECH_API_BASE', '') !== '' && str_starts_with($page, 'http://127.0.0.1'))) {
        error_log('Jënd — PayTech : adresse de paiement inattendue (' . $hote . ')');
        throw new RuntimeException('Adresse de paiement invalide.');
    }

    $pdo = pdo();
    $pdo->beginTransaction();
    try {
        requete("UPDATE paiements SET statut = 'echoue' WHERE commande_id = ? AND statut = 'initie' AND reference_externe IS NOT NULL", [$commande['id']]);
        $reutilise = requete(
            "UPDATE paiements SET fournisseur = 'paytech', reference_externe = ?, methode = ?, montant = ? WHERE commande_id = ? AND statut = 'initie' AND reference_externe IS NULL LIMIT 1",
            [$token, commande_methode_en_ligne($commande), $montant, $commande['id']]
        )->rowCount();
        if ($reutilise === 0) {
            requete("INSERT INTO paiements (commande_id, methode, montant, statut, fournisseur, reference_externe) VALUES (?, ?, ?, 'initie', 'paytech', ?)",
                [$commande['id'], commande_methode_en_ligne($commande), $montant, $token]);
        }
        $pdo->commit();
    } catch (Throwable $e) {
        $pdo->rollBack();
        throw $e;
    }
    return $page;
}

/** Est-ce une notification PayTech ? (champ type_event, en formulaire ou en JSON) */
function paytech_est_notification(array $donnees): bool
{
    return isset($donnees['type_event'], $donnees['token']) && is_string($donnees['type_event']);
}

/**
 * Notification IPN de PayTech. Retourne [code HTTP, message].
 * Contrôles : HMAC-SHA256 valide, jeton connu et lié à PayTech, référence de commande identique, montant identique (paiement_appliquer).
 */
function paytech_notification(array $d): array
{
    if (!paytech_configure()) {
        return [400, 'PayTech non configuré'];
    }
    $montantTexte = (string) ($d['final_item_price'] ?? ($d['item_price'] ?? ''));
    $refTentative = (string) ($d['ref_command'] ?? '');
    $attendu = hash_hmac('sha256', $montantTexte . '|' . $refTentative . '|' . env('PAYTECH_API_KEY'), (string) env('PAYTECH_API_SECRET'));
    if (!hash_equals($attendu, strtolower((string) ($d['hmac_compute'] ?? '')))) {
        error_log('Jënd — IPN PayTech : signature HMAC invalide ou absente');
        return [401, 'Signature invalide'];
    }
    $token = (string) $d['token'];
    $p = requete('SELECT p.id, p.fournisseur, c.reference FROM paiements p JOIN commandes c ON c.id = p.commande_id WHERE p.reference_externe = ?', [$token])->fetch();
    if (!$p || $p['fournisseur'] !== 'paytech') {
        return [404, 'Paiement inconnu'];
    }
    if (!str_starts_with($refTentative, $p['reference'] . '-')) {
        alerter('paytech-commande:' . $token, 'PayTech : notification non conforme', 'Le paiement ' . $token . ' porte la référence « ' . $refTentative . ' » mais est lié à la commande ' . $p['reference'] . '. Vérifiez chez PayTech.');
        return [400, 'Commande incohérente'];
    }
    $statut = match ((string) $d['type_event']) {
        'sale_complete' => 'reussi',
        'sale_canceled' => 'echoue',
        default => null,
    };
    if ($statut === null) {
        return [200, 'Ignoré'];
    }
    if (!preg_match('/^\d+(\.0+)?$/', $montantTexte)) {
        return [400, 'Montant illisible'];
    }
    $brut = json_encode(array_diff_key($d, array_flip(['api_key_sha256', 'api_secret_sha256', 'hmac_compute', 'client_phone'])), JSON_UNESCAPED_UNICODE) ?: '{}';
    return paiement_appliquer($token, $statut, (int) $montantTexte, $brut);
}
