<?php
declare(strict_types=1);

/**
 * Charge le panier (session) avec les données à jour de la base.
 * Retire les produits devenus indisponibles et plafonne les quantités au stock.
 * Retourne ['lignes' => [...], 'sous_total' => int, 'ajuste' => bool]
 */
function panier_charger(): array
{
    $panier = $_SESSION['panier'] ?? [];
    if (!$panier) {
        return ['lignes' => [], 'sous_total' => 0, 'ajuste' => false];
    }

    $ids = array_values(array_unique(array_map(fn ($c) => panier_cle_lire($c)[0], array_keys($panier))));
    $in  = implode(',', array_fill(0, count($ids), '?'));
    $rows = requete(
        "SELECT p.id, p.nom, p.slug, p.prix, p.stock, p.boutique_id, p.option_type, b.nom AS boutique, " . SQL_PROMO_FETE . " AS promo_pct,
                COALESCE(c.icone, pc.icone) AS icone,
                (SELECT chemin FROM produit_images i WHERE i.produit_id = p.id ORDER BY i.position LIMIT 1) AS image
           FROM produits p
           JOIN boutiques b ON b.id = p.boutique_id AND b.statut = 'active'
           JOIN categories c ON c.id = p.categorie_id
           LEFT JOIN categories pc ON pc.id = c.parent_id
          WHERE p.id IN ($in) AND p.statut = 'publie' AND (p.reserve_client_id IS NULL OR p.reserve_client_id = " . (int) ($_SESSION['user_id'] ?? 0) . ")",
        $ids
    )->fetchAll();

    $parId = [];
    foreach ($rows as $r) {
        $parId[(int) $r['id']] = $r;
    }
    // Tailles / pointures des produits du panier
    $variantes = [];
    $avecTailles = [];
    foreach (requete("SELECT id, produit_id, libelle, stock FROM produit_variantes WHERE produit_id IN ($in)", $ids)->fetchAll() as $v) {
        $variantes[(int) $v['id']] = $v;
        $avecTailles[(int) $v['produit_id']] = true;
    }

    // Prix négociés (« faire une offre ») : relus en base pour le client connecté, jamais dans le navigateur
    $offres = (function_exists('offres_valides') && !empty($_SESSION['user_id'])) ? offres_valides((int) $_SESSION['user_id']) : [];

    $lignes = [];
    $propre = [];
    $ajuste = false;
    $total  = 0;

    foreach ($panier as $cle => $qte) {
        [$id, $vid] = panier_cle_lire($cle);
        $p  = $parId[$id] ?? null;
        $v  = $vid ? ($variantes[$vid] ?? null) : null;
        // produit retiré ou épuisé ; taille retirée par le vendeur ; ou produit qui a maintenant des tailles sans qu'on en ait choisi une
        if (!$p || ($vid && (!$v || (int) $v['produit_id'] !== $id)) || (!$vid && isset($avecTailles[$id]))) {
            $ajuste = true;
            continue;
        }
        if ($v) {
            $p['stock'] = (int) $v['stock'];
            $p['variante_id'] = (int) $v['id'];
            $p['variante_libelle'] = option_libelle($p['option_type']) . ' : ' . $v['libelle'];
        } else {
            $p['variante_id'] = null;
            $p['variante_libelle'] = null;
        }
        $p['cle'] = panier_cle($id, $vid);
        if ((int) $p['stock'] < 1) {
            $ajuste = true;
            continue;
        }
        $q = min((int) $qte, (int) $p['stock'], 10);
        if ($q !== (int) $qte) {
            $ajuste = true;
        }
        $p['quantite']   = $q;
        $p['prix_affiche'] = (int) $p['prix'];
        $promo = prix_promo((int) $p['prix'], (int) $p['promo_pct']);          // promotion de fête en cours
        // prix négocié s'il y a une offre acceptée, sauf si la promotion est plus avantageuse
        $p['prix']       = min($promo, $offres ? offre_prix_applique($offres, $id, $q, $promo) : $promo);
        $p['promo_fete'] = (int) $p['promo_pct'] > 0 && $p['prix'] === $promo;           // le prix vient de la promotion (et non d'une offre)
        $p['offre_max']  = isset($offres[$id]) ? $offres[$id]['quantite'] : 0;
        $p['total']      = $q * (int) $p['prix'];
        $total          += $p['total'];
        $lignes[]        = $p;
        $propre[$p['cle']] = $q;
    }

    $_SESSION['panier'] = $propre;
    return ['lignes' => $lignes, 'sous_total' => $total, 'ajuste' => $ajuste];
}

const MOYENS_PAIEMENT = [
    'wave'         => ['Wave',                  'ph-waves',       'Paiement mobile instantané'],
    'orange_money' => ['Orange Money',          'ph-device-mobile', 'Paiement via votre compte Orange Money'],
    'free_money'   => ['Free Money',            'ph-device-mobile', 'Paiement via votre compte Free Money'],
    'carte'        => ['Carte bancaire',        'ph-credit-card', 'Visa ou Mastercard'],
    'livraison'    => ['Paiement à la livraison', 'ph-hand-coins',  'Vous payez en espèces au livreur'],
];

const STATUTS_COMMANDE = [
    'en_attente' => 'En attente',
    'confirmee'  => 'Confirmée',
    'annulee'    => 'Annulée',
    'terminee'   => 'Terminée',
];

const STATUTS_PAIEMENT = [
    'en_attente' => 'Paiement en attente',
    'acompte'    => 'Acompte payé',
    'paye'       => 'Payée',
    'echoue'     => 'Paiement échoué',
    'rembourse'  => 'Remboursée',
];

const STATUTS_SOUS_COMMANDE = [
    'a_preparer' => 'En préparation',
    'expediee'   => 'Expédiée',
    'livree'     => 'Livrée',
    'annulee'    => 'Annulée',
    'retournee'  => 'Retournée',
];
