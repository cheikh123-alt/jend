<?php
declare(strict_types=1);

/**
 * Situation de trésorerie : où est l'argent encaissé en ligne, à qui il revient, et ce qu'il reste à Jënd.
 *
 *   encaissé en ligne (paiements réussis, hors espèces)
 *   − remboursé aux clients − versé aux vendeurs                  = solde théorique du compte de paiement, AVANT frais du prestataire
 *   ce que Jënd doit encore : vendeurs (gains retirables, bientôt retirables, bloqués) + retraits demandés
 *                             + commandes payées pas encore livrées + remboursements à envoyer aux clients
 *   reste à Jënd (commissions, frais de livraison Jënd) = théorique − dettes
 * Le solde RÉEL lu chez le prestataire (saisi par l'admin) est inférieur de ce que le prestataire a retenu en frais.
 * Non couverts : espèces encaissées par les vendeurs ou les livreurs (elles ne passent pas par le compte de paiement).
 */
function tresorerie_calculer(): array
{
    $n = fn (string $sql, array $p = []) => (int) requete($sql, $p)->fetchColumn();
    $r = [];
    $r['encaisse'] = $n("SELECT COALESCE(SUM(montant), 0) FROM paiements WHERE statut IN ('reussi', 'rembourse') AND methode <> 'livraison'");
    $r['rembourse_commandes'] = $n("SELECT COALESCE(SUM(montant), 0) FROM paiements WHERE statut = 'rembourse' AND methode <> 'livraison'");
    $r['rembourse_litiges'] = $n("SELECT COALESCE(SUM(montant_rembourse), 0) FROM litiges WHERE statut = 'rembourse' AND rembourse_le IS NOT NULL");
    $r['rembourse'] = $r['rembourse_commandes'] + $r['rembourse_litiges'];
    $r['verse_vendeurs'] = $n("SELECT COALESCE(SUM(montant), 0) FROM retraits WHERE statut = 'paye'");
    $r['theorique'] = $r['encaisse'] - $r['rembourse'] - $r['verse_vendeurs'];

    $r['vendeurs_retirable'] = $r['vendeurs_delai'] = $r['vendeurs_bloque'] = 0;
    foreach (requete('SELECT id FROM boutiques')->fetchAll(PDO::FETCH_COLUMN) as $id) {
        $g = vendeur_gains((int) $id);
        $r['vendeurs_retirable'] += $g['solde'];
        $r['vendeurs_delai'] += $g['en_delai'];
        $r['vendeurs_bloque'] += $g['bloque'];
    }
    $r['retraits_demandes'] = $n("SELECT COALESCE(SUM(montant), 0) FROM retraits WHERE statut = 'demande'");
    $r['en_cours'] = $n(
        "SELECT COALESCE(SUM(IF(c.methode_paiement = 'livraison', cb.acompte_part, cb.sous_total + cb.frais_part)), 0)
           FROM commande_boutiques cb JOIN commandes c ON c.id = cb.commande_id
          WHERE cb.statut IN ('a_preparer', 'expediee') AND c.statut <> 'annulee' AND c.statut_paiement IN ('paye', 'acompte')"
    );
    $r['clients_annulees'] = $n("SELECT COALESCE(SUM(p.montant), 0) FROM paiements p JOIN commandes c ON c.id = p.commande_id WHERE c.statut = 'annulee' AND c.statut_paiement IN ('paye', 'acompte') AND p.statut = 'reussi' AND p.methode <> 'livraison'");
    $r['clients_litiges'] = $n("SELECT COALESCE(SUM(montant_rembourse), 0) FROM litiges WHERE statut = 'rembourse' AND rembourse_le IS NULL");
    $r['clients_a_rembourser'] = $r['clients_annulees'] + $r['clients_litiges'];
    $r['dettes'] = $r['vendeurs_retirable'] + $r['vendeurs_delai'] + $r['vendeurs_bloque'] + $r['retraits_demandes'] + $r['en_cours'] + $r['clients_a_rembourser'];
    $r['reste_jend'] = $r['theorique'] - $r['dettes'];
    // Hors compte de paiement : à récupérer en main propre / à retenir plus tard
    $r['especes_livreurs'] = array_sum(array_column(livreur_especes(), 'a_remettre'));
    $r['commissions_reglees'] = $n('SELECT COALESCE(SUM(montant), 0) FROM reglements_commission');   // reçues sur le numéro de Jënd (hors compte de paiement)
    $r['dettes_vendeurs'] = 0;
    foreach (requete('SELECT id FROM boutiques')->fetchAll() as $b) {
        $r['dettes_vendeurs'] += vendeur_gains((int) $b['id'])['dette'];
    }

    $reel = parametre('tresorerie_solde_reel');
    $r['reel'] = ($reel !== null && ctype_digit($reel)) ? (int) $reel : null;
    $r['reel_le'] = parametre('tresorerie_solde_reel_le');
    if ($r['reel'] !== null) {
        $r['frais'] = $r['theorique'] - $r['reel'];                                      // ce que le prestataire a retenu (si positif)
        $r['frais_pct'] = $r['encaisse'] > 0 ? round($r['frais'] / $r['encaisse'] * 100, 2) : null;
        $r['reste_reel'] = $r['reel'] - $r['dettes'];                                    // négatif : il faut ajouter de l'argent pour pouvoir payer tout le monde
    }
    return $r;
}
