<footer class="pied">
  <div class="tresse" aria-hidden="true"></div>
  <div class="wrap">
    <div class="grille">
      <div>
        <a href="<?= e(url()) ?>" class="logo">Jënd<span>.</span></a>
        <p>La marketplace sénégalaise où l'on achète et vend en confiance.</p>
      </div>
      <div><h4>Acheter</h4><ul><li><a href="<?= e(url('categories')) ?>">Catégories</a></li><li><a href="<?= e(url('compte')) ?>">Suivre ma commande</a></li><li><a href="<?= e(url('livraison-retours')) ?>">Livraison et retours</a></li><li><a href="<?= e(url('envoyer-au-pays')) ?>">Envoyer à ma famille</a></li></ul></div>
      <div><h4>Vendre</h4><ul><li><a href="<?= e(url('vendre')) ?>">Ouvrir une boutique</a></li><li><a href="<?= e(url('frais-commissions')) ?>">Frais et commissions</a></li><li><a href="<?= e(url('paiements-vendeurs')) ?>">Paiements et reversements</a></li><li><a href="<?= e(url('conditions-vendeur')) ?>">Conditions vendeurs</a></li></ul></div>
      <div><h4>Jënd</h4><ul><li><a href="<?= e(url('a-propos')) ?>">À propos</a></li><li><a href="<?= e(url('contact')) ?>">Aide et contact</a></li><li><a href="<?= e(url('cgu')) ?>">Conditions d'utilisation</a></li><li><a href="<?= e(url('cgv')) ?>">Conditions de vente</a></li><li><a href="<?= e(url('confidentialite')) ?>">Confidentialité</a></li><li><a href="<?= e(url('mentions-legales')) ?>">Mentions légales</a></li></ul></div>
    </div>
    <form method="post" action="<?= e(url('mode-leger')) ?>" class="mode-leger-form"><?= csrf_champ() ?>
      <input type="hidden" name="retour" value="<?= e($_SERVER['REQUEST_URI'] ?? '') ?>">
      <button type="submit" class="lien"><i class="ph ph-cell-signal-low"></i> Économie de données : <b><?= mode_leger() ? 'activée' : 'désactivée' ?></b> (<?= mode_leger() ? 'désactiver' : 'activer pour un petit forfait' ?>)</button>
    </form>
    <div class="bas"><span>© <?= date('Y') ?> Jënd. Fait au Sénégal.</span><span>Tous droits réservés</span></div>
    <p class="pied-geant" aria-hidden="true">Jënd.</p>
  </div>
</footer>

<?php if (!empty($aideFlottante)):
    $numAide = preg_replace('/\D/', '', (string) env('CONTACT_WHATSAPP', ''));
    $lienAide = $numAide !== '' ? 'https://wa.me/' . $numAide . '?text=' . rawurlencode('Bonjour Jënd, j\'ai une question avant de commander (' . app_url(ltrim(substr((string) parse_url($_SERVER['REQUEST_URI'] ?? '', PHP_URL_PATH), strlen(base_path())), '/')) . ')') : url('aide'); ?>
<a class="aide-flottante" href="<?= e($lienAide) ?>"<?= $numAide !== '' ? ' target="_blank" rel="noopener noreferrer"' : '' ?>><i class="ph-fill <?= $numAide !== '' ? 'ph-whatsapp-logo' : 'ph-lifebuoy' ?>"></i><span>Besoin d'aide ?</span></a>
<?php endif; ?>
<?php if (!empty($animations) && !mode_leger()):            // animations : page d'accueil seulement (les autres pages restent légères et rapides) ?>
<script src="<?= e(asset('vendor/js/gsap.min.js')) ?>" defer></script>
<script src="<?= e(asset('vendor/js/ScrollTrigger.min.js')) ?>" defer></script>
<script src="<?= e(asset('vendor/js/splitting.min.js')) ?>" defer></script>
<?php endif; ?>
<script src="<?= e(asset('js/main.js')) ?>" defer></script>
<?php foreach ($scripts_extra ?? [] as $fichierJs): ?><script src="<?= e(asset($fichierJs)) ?>" defer></script><?php endforeach; ?>
</body>
</html>
