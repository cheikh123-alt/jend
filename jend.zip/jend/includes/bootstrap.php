<?php
declare(strict_types=1);

require_once __DIR__ . '/env.php';
require_once __DIR__ . '/helpers.php';
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/catalogue.php';
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/panier.php';
require_once __DIR__ . '/commandes.php';
require_once __DIR__ . '/mail.php';
require_once __DIR__ . '/paiement.php';
require_once __DIR__ . '/images.php';
require_once __DIR__ . '/vendeur.php';
require_once __DIR__ . '/compte.php';
require_once __DIR__ . '/securite.php';
require_once __DIR__ . '/crypto.php';
require_once __DIR__ . '/totp.php';
require_once __DIR__ . '/parametres.php';
require_once __DIR__ . '/paydunya.php';
require_once __DIR__ . '/paytech.php';
require_once __DIR__ . '/unitech.php';
require_once __DIR__ . '/tresorerie.php';
require_once __DIR__ . '/legal.php';
require_once __DIR__ . '/livreur.php';
require_once __DIR__ . '/litiges.php';
require_once __DIR__ . '/suivi.php';
require_once __DIR__ . '/tableau.php';
require_once __DIR__ . '/boutiques.php';
require_once __DIR__ . '/offres.php';
require_once __DIR__ . '/mesure.php';
require_once __DIR__ . '/support.php';
require_once __DIR__ . '/fetes.php';
require_once __DIR__ . '/position.php';
require_once __DIR__ . '/depense.php';
require_once __DIR__ . '/voix.php';
require_once __DIR__ . '/alertes.php';
require_once __DIR__ . '/variantes.php';
require_once __DIR__ . '/versements.php';
require_once __DIR__ . '/marketing.php';
require_once __DIR__ . '/qrcode.php';
require_once __DIR__ . '/simple.php';
require_once __DIR__ . '/push.php';
require_once __DIR__ . '/prevenir.php';
require_once __DIR__ . '/reglements.php';

date_default_timezone_set('Africa/Dakar');

// Seules les méthodes GET, HEAD et POST sont utilisées par le site : TRACE, PUT, DELETE… sont refusées.
if (!in_array($_SERVER['REQUEST_METHOD'] ?? 'GET', ['GET', 'HEAD', 'POST'], true)) {
    http_response_code(405);
    header('Allow: GET, HEAD, POST');
    exit;
}

$prod = env('APP_ENV', 'prod') !== 'dev';      // tout ce qui n'est pas explicitement « dev » est traité comme la production
ini_set('display_errors', $prod ? '0' : '1');
error_reporting(E_ALL);

// Erreurs : jamais de détails techniques au visiteur en production, mais tout est écrit dans le journal du serveur
set_exception_handler(function (Throwable $e) use ($prod): void {
    error_log('Jënd — exception non gérée : ' . get_class($e) . ' : ' . $e->getMessage() . ' (' . $e->getFile() . ':' . $e->getLine() . ')');
    if ($prod) {
        alerter('exception', 'Erreur interne (500) sur le site', get_class($e) . ' : ' . $e->getMessage() . "\n" . basename($e->getFile()) . ':' . $e->getLine());
        // Site de TEST : une explication utile pour l'installation (jamais de requête, de chemin ni d'identifiant)
        $aide = env('APP_ENV') === 'test' ? erreur_installation($e) : null;
        page_erreur(500, 'Un souci de notre côté', $aide ?? 'Une erreur est survenue. Réessayez dans un instant.');
    } else {
        page_erreur(500, 'Erreur (mode développement)', get_class($e) . ' : ' . $e->getMessage() . ' — ' . basename($e->getFile()) . ':' . $e->getLine());
    }
});
register_shutdown_function(function () use ($prod): void {
    $err = error_get_last();
    if ($err && in_array($err['type'], [E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR], true) && $prod && !headers_sent()) {
        alerter('erreur-fatale', 'Erreur fatale sur le site', $err['message'] . "\n" . basename($err['file']) . ':' . $err['line']);
        page_erreur(500, 'Un souci de notre côté', 'Une erreur est survenue. Réessayez dans un instant.');
    }
});

// En production : tout passe en HTTPS (adresse officielle lue dans APP_URL, jamais dans l'en-tête Host du visiteur)
$https = est_https();
if ($prod && !$https && PHP_SAPI !== 'cli' && env('FORCE_HTTPS') !== '0') {   // FORCE_HTTPS=0 : à n'utiliser que si l'hébergeur n'indique pas le HTTPS à PHP (sinon boucle de redirections)
    $officiel = parse_url((string) env('APP_URL', ''));
    if (($officiel['scheme'] ?? '') === 'https' && !empty($officiel['host'])) {
        $uri = preg_replace('/[\r\n]/', '', (string) ($_SERVER['REQUEST_URI'] ?? '/'));
        header('Location: https://' . $officiel['host'] . (isset($officiel['port']) ? ':' . $officiel['port'] : '') . $uri, true, 301);
        exit;
    }
}

envoyer_entetes_securite($prod);

// Session : cookie inaccessible au JavaScript, HTTPS uniquement quand disponible, identifiants imposés par le serveur
ini_set('session.use_strict_mode', '1');       // refuse un identifiant de session inventé par un attaquant
ini_set('session.use_only_cookies', '1');
ini_set('session.use_trans_sid', '0');
session_set_cookie_params([
    'lifetime' => 0,
    'path'     => '/',
    'secure'   => $https,
    'httponly' => true,
    'samesite' => 'Lax',
]);
session_name($https ? '__Host-jend_session' : 'jend_session');   // préfixe __Host- : le navigateur lie le cookie à ce domaine exact
session_start();
source_memoriser();                            // marketing : canal d'arrivée du visiteur (WhatsApp, TikTok, affiche…)

// Les pages d'un utilisateur connecté ne doivent pas rester en cache (bouton « retour » sur un ordinateur partagé)
if (!empty($_SESSION['user_id'])) {
    header('Cache-Control: no-store');
}
