<?php
declare(strict_types=1);

/**
 * « Mode simple » de l'espace vendeur : pour les vendeurs qui lisent peu ou découvrent Internet.
 * Photo, prix en chiffres, voix ; grands boutons avec images ; aide audio sur chaque écran.
 * Ce n'est qu'une autre façon d'afficher le même espace : mêmes produits, mêmes commandes, mêmes versements,
 * mêmes fonctions (image_enregistrer, voix_enregistrer, sous_commande_avancer…). Le vendeur peut passer d'un mode à l'autre à tout moment.
 */

const SIMPLE_AIDE_DOSSIER = 'assets/audio/aide';      // messages d'aide enregistrés (wolof…) : <page>.mp3, .m4a, .ogg ou .webm

/** Le vendeur utilise-t-il le mode simple ? */
function simple_actif(array $boutique): bool
{
    return (int) ($boutique['mode_simple'] ?? 0) === 1;
}

/** Accès aux pages du mode simple : un vendeur connecté (mêmes règles que l'espace complet). */
function exiger_vendeur_simple(): array
{
    return exiger_vendeur();
}

/**
 * Bouton « Écouter l'explication » : n'apparaît que si le message audio de cette page a été enregistré
 * (par l'équipe Jënd, en wolof par exemple) et déposé dans assets/audio/aide/. Sinon rien n'est affiché.
 */
function simple_aide(string $page): string
{
    if (!preg_match('/^[a-z-]+$/', $page)) {
        return '';
    }
    foreach (['mp3', 'm4a', 'ogg', 'webm'] as $ext) {
        $chemin = SIMPLE_AIDE_DOSSIER . '/' . $page . '.' . $ext;
        if (is_file(dirname(__DIR__) . '/' . $chemin)) {
            return '<div class="simple-aide"><button type="button" class="simple-aide-btn" data-aide="aide-' . e($page) . '"><i class="ph-fill ph-speaker-high"></i> <span>Écouter</span></button>'
                 . '<audio id="aide-' . e($page) . '" preload="none" src="' . e(asset(substr($chemin, strlen('assets/')))) . '"></audio></div>';
        }
    }
    return '';
}

/** En-tête commun des pages simples : retour à l'accueil simple (grande flèche), titre, aide audio. */
function simple_entete(string $titre, string $page, bool $retour = true): void
{
    echo '<header class="simple-entete">';
    if ($retour) {
        echo '<a class="simple-retour" href="' . e(url('simple')) . '" aria-label="Retour à l\'accueil"><i class="ph ph-arrow-left"></i></a>';
    }
    echo '<h1>' . e($titre) . '</h1>' . simple_aide($page) . '</header>';
}

/** Lit un nombre tapé avec des espaces ou des points (« 5 000 », « 5.000 ») : seulement les chiffres. */
function simple_nombre(string $saisie): ?int
{
    $chiffres = preg_replace('/\D/', '', $saisie);
    return ($chiffres === '' || strlen($chiffres) > 9) ? null : (int) $chiffres;
}

/** Catégories proposées en grandes cartes (catégories principales, avec leur icône). */
function simple_categories(): array
{
    return requete('SELECT id, nom, icone FROM categories WHERE parent_id IS NULL ORDER BY position, nom')->fetchAll();
}

/**
 * Crée un produit en mode simple : catégorie, prix, quantité, photos, voix (le nom est facultatif).
 * Sans nom, le produit s'appelle comme sa catégorie suivie du nom de la boutique (modifiable plus tard, en mode complet ou par l'équipe).
 * Le produit est mis en vente aussitôt (il reste invisible tant que la boutique n'est pas validée).
 * @throws RuntimeException message affichable
 */
function simple_produit_creer(array $boutique, int $categorieId, ?int $prix, ?int $stock, string $nom, array $photos, ?array $voix): int
{
    $categorie = requete('SELECT id, nom FROM categories WHERE id = ?', [$categorieId])->fetch();
    if (!$categorie) {
        throw new RuntimeException('Choisissez ce que vous vendez (touchez une image).');
    }
    if ($prix === null || $prix < 100 || $prix > 100000000) {
        throw new RuntimeException('Écrivez le prix en chiffres (100 FCFA minimum).');
    }
    if ($stock === null || $stock < 1 || $stock > 100000) {
        throw new RuntimeException('Indiquez combien vous en avez (1 ou plus).');
    }
    if (!$photos) {
        throw new RuntimeException('Ajoutez au moins une photo du produit.');
    }
    if (count($photos) > IMAGES_PAR_PRODUIT) {
        throw new RuntimeException('Maximum ' . IMAGES_PAR_PRODUIT . ' photos par produit.');
    }
    $nom = trim(preg_replace('/\s+/u', ' ', $nom));
    if ($nom === '' || mb_strlen($nom) < 3) {
        $nom = $categorie['nom'] . ' — ' . $boutique['nom'];
    }
    $nom = mb_substr($nom, 0, 190);

    $enregistrees = [];
    $nouvelleVoix = null;
    try {
        foreach ($photos as $f) {
            $enregistrees[] = image_enregistrer($f);
        }
        $nouvelleVoix = $voix ? voix_enregistrer($voix) : null;
    } catch (RuntimeException $e) {
        array_map('image_supprimer', $enregistrees);
        throw $e;
    }

    $pdo = pdo();
    $pdo->beginTransaction();
    try {
        requete("INSERT INTO produits (boutique_id, categorie_id, nom, slug, prix, stock, statut, voix_chemin) VALUES (?, ?, ?, ?, ?, ?, 'publie', ?)",
            [$boutique['id'], $categorieId, $nom, produit_slug_unique($nom), $prix, $stock, $nouvelleVoix]);
        $id = (int) $pdo->lastInsertId();
        foreach ($enregistrees as $pos => $chemin) {
            requete('INSERT INTO produit_images (produit_id, chemin, position) VALUES (?, ?, ?)', [$id, $chemin, $pos]);
        }
        $pdo->commit();
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        array_map('image_supprimer', $enregistrees);
        voix_supprimer($nouvelleVoix);
        error_log('Jënd — produit (mode simple) : ' . $e->getMessage());
        throw new RuntimeException('Le produit n\'a pas été enregistré. Réessayez.');
    }
    return $id;
}

/**
 * Boutons « + » / « − » du stock et « retirer / remettre en vente » (mode simple).
 * Les produits avec tailles ou pointures se gèrent dans le mode complet (stock taille par taille).
 * @throws RuntimeException message affichable
 */
function simple_produit_action(int $boutiqueId, int $produitId, string $action): string
{
    $p = requete('SELECT id, stock, statut, (SELECT COUNT(*) FROM produit_variantes v WHERE v.produit_id = produits.id) AS nb_tailles
                    FROM produits WHERE id = ? AND boutique_id = ? AND reserve_client_id IS NULL', [$produitId, $boutiqueId])->fetch();
    if (!$p) {
        throw new RuntimeException('Produit introuvable.');
    }
    switch ($action) {
        case 'plus':
        case 'moins':
            if ((int) $p['nb_tailles'] > 0) {
                throw new RuntimeException('Ce produit a des tailles : changez le stock dans le mode complet.');
            }
            requete('UPDATE produits SET stock = GREATEST(0, LEAST(100000, stock + ?)) WHERE id = ? AND boutique_id = ?', [$action === 'plus' ? 1 : -1, $produitId, $boutiqueId]);
            alertes_produit_verifier($produitId);          // « Prévenez-moi » : retour en stock
            return $action === 'plus' ? 'Un de plus.' : 'Un de moins.';
        case 'retirer':
            requete("UPDATE produits SET statut = 'archive' WHERE id = ? AND boutique_id = ?", [$produitId, $boutiqueId]);
            return 'Produit retiré de la vente.';
        case 'vendre':
            requete("UPDATE produits SET statut = 'publie' WHERE id = ? AND boutique_id = ?", [$produitId, $boutiqueId]);
            alertes_produit_verifier($produitId);
            return 'Produit remis en vente.';
    }
    throw new RuntimeException('Action inconnue.');
}

/** Change le mode de l'espace vendeur (simple ou complet). */
function simple_mode_changer(int $boutiqueId, bool $simple): void
{
    requete('UPDATE boutiques SET mode_simple = ? WHERE id = ?', [$simple ? 1 : 0, $boutiqueId]);
}

/** Numéro masqué pour l'affichage : « 77 •• •• 45 67 ». */
function simple_numero_masque(?string $tel): string
{
    $c = preg_replace('/\D/', '', (string) $tel);
    if (strlen($c) < 9) {
        return '';
    }
    $c = substr($c, -9);
    return substr($c, 0, 2) . ' •• •• ' . substr($c, 5, 2) . ' ' . substr($c, 7, 2);
}

/** Lien WhatsApp vers un numéro sénégalais (le client, pour le vendeur). */
function simple_lien_whatsapp(?string $tel): string
{
    $c = preg_replace('/\D/', '', (string) $tel);
    if (strlen($c) === 9) {
        $c = '221' . $c;
    }
    return strlen($c) >= 11 ? 'https://wa.me/' . $c : '';
}
