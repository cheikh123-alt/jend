<?php
declare(strict_types=1);

const RETRAIT_MINIMUM = 5000;   // FCFA
const RETRAIT_DELAI_CHANGEMENT_HEURES = 48;   // retraits suspendus après un changement du numéro de paiement

/** Accès réservé aux vendeurs. Retourne [utilisateur, boutique]. */
function exiger_vendeur(): array
{
    $u = exiger_connexion();
    $b = requete('SELECT * FROM boutiques WHERE user_id = ?', [$u['id']])->fetch();
    if (!$b) {
        flash('Créez d\'abord votre boutique.', 'erreur');
        rediriger('vendre');
    }
    return [$u, $b];
}

/** Accès réservé à l'administrateur. */
function exiger_admin(): array
{
    $u = exiger_connexion();
    if ($u['role'] !== 'admin') {
        http_response_code(404);          // on ne révèle pas l'existence de l'espace admin
        require __DIR__ . '/../pages/404.php';
        exit;
    }
    // Restriction par adresse IP (ADMIN_IPS dans .env) : tout autre visiteur voit une page 404, même avec le bon mot de passe
    if (!ip_dans_liste(ip_client(), env('ADMIN_IPS'))) {
        error_log('Jënd [sécurité] accès admin refusé (IP non autorisée) : ' . ip_client());
        http_response_code(404);
        require __DIR__ . '/../pages/404.php';
        exit;
    }
    // Double authentification obligatoire pour l'admin (par défaut en production)
    $obligatoire = (string) (env('ADMIN_2FA_OBLIGATOIRE') ?? (env('APP_ENV', 'prod') === 'dev' ? '0' : '1'));
    if ($obligatoire === '1' && (int) $u['totp_actif'] !== 1) {
        flash('Pour accéder à l\'administration, activez d\'abord la double authentification.', 'erreur');
        rediriger('compte/securite');
    }
    return $u;
}

function vendeur_onglets(string $actif): void
{
    $onglets = [
        'accueil'   => ['vendeur',           'ph-gauge',        'Tableau de bord'],
        'produits'  => ['vendeur/produits',  'ph-package',      'Produits'],
        'commandes' => ['vendeur/commandes', 'ph-truck',        'Commandes'],
        'offres'    => ['vendeur/offres',    'ph-handshake',    'Offres'],
        'mesure'    => ['vendeur/sur-mesure', 'ph-scissors',    'Sur mesure'],
        'fetes'     => ['vendeur/fetes',     'ph-confetti',     'Spécial fêtes'],
        'kit'       => ['vendeur/kit',       'ph-megaphone',    'Promouvoir'],
        'statut'    => ['vendeur/statut',    'ph-image',        'Images statut'],
        'gains'     => ['vendeur/gains',     'ph-coins',        'Gains'],
        'boutique'  => ['vendeur/boutique',  'ph-storefront',   'Boutique'],
        'profil'    => ['vendeur/profil',    'ph-user-gear',    'Mon profil'],
    ];
    echo '<nav class="onglets" aria-label="Espace vendeur">';
    $uo = utilisateur();
    $bo = $uo ? requete('SELECT id, sur_mesure FROM boutiques WHERE user_id = ?', [$uo['id']])->fetch() : null;
    if (!$bo || ((int) $bo['sur_mesure'] !== 1 && $actif !== 'mesure')) {
        unset($onglets['mesure']);
    }
    if ($actif !== 'fetes' && !fetes_a_venir()) {          // l'onglet n'apparaît que si une fête est programmée
        unset($onglets['fetes']);
    }
    $notifs = $bo ? notifs_vendeur((int) $bo['id']) : [];
    foreach ($onglets as $cle => [$chemin, $icone, $libelle]) {
        $pastille = pastille_onglet($notifs[$cle] ?? 0, $cle !== 'produits');
        printf('<a href="%s"%s><i class="ph %s"></i> %s%s</a>', e(url($chemin)), $cle === $actif ? ' class="actif" aria-current="page"' : '', $icone, e($libelle), $pastille);
    }
    echo '</nav>';
    commission_bandeau();
}

/**
 * Rappel de la commission de Jënd, affiché sur toutes les pages de l'espace vendeur : taux de la boutique + annonce d'un changement.
 * Le taux peut évoluer (préavis de 30 jours) : c'est ici que le vendeur le retrouve en permanence.
 */
function commission_bandeau(): void
{
    $u = utilisateur();
    $b = $u ? requete('SELECT commission_pct, commission_gratuite_jusqu FROM boutiques WHERE user_id = ?', [$u['id']])->fetch() : null;
    if (!$b) {
        return;
    }
    $pct = (float) $b['commission_pct'];
    echo '<p class="bandeau-commission"><i class="ph ph-percent"></i> <span>' . ($pct > 0 && offre_lancement() ? '<b>Offre de lancement</b> · ' : '') . 'Commission de Jënd : <b>' . e(commission_texte($pct)) . ' %</b> '
       . ($pct > 0 ? 'sur le prix des produits livrés et payés' : '(aucune commission pour le moment)')
       . ' · le taux peut évoluer, avec <b>' . COMMISSION_PREAVIS_JOURS . ' jours de préavis</b> · <a class="lien" href="' . e(url('frais-commissions')) . '">Détails</a></span></p>';
    if ($gratuit = commission_gratuite_jusqu($b)) {
        echo '<p class="alerte alerte-info"><i class="ph ph-gift"></i> <span><b>Parrainage : aucune commission jusqu\'au ' . e(date('d/m/Y', strtotime($gratuit))) . '</b> sur vos nouvelles commandes.</span></p>';
    }
    if ($ann = commission_annonce()) {
        echo '<p class="alerte alerte-info"><i class="ph ph-megaphone"></i> <span><b>Annonce :</b> à partir du <b>' . e(date('d/m/Y', strtotime($ann['le']))) . '</b>, la commission sera de <b>'
           . e(commission_texte($ann['pct'])) . ' %</b> sur les commandes passées à partir de cette date. Les commandes passées avant ne sont pas concernées.</span></p>';
    }
}

function admin_onglets(string $actif): void
{
    $onglets = [
        'accueil'    => ['admin',            'ph-gauge',      'Tableau de bord'],
        'croissance' => ['admin/croissance', 'ph-chart-line-up', 'Croissance'],
        'boutiques'  => ['admin/boutiques',  'ph-storefront', 'Boutiques'],
        'produits'   => ['admin/produits',   'ph-package',    'Produits'],
        'commandes'  => ['admin/commandes',  'ph-receipt',    'Commandes'],
        'relances'   => ['admin/relances',   'ph-bell-ringing', 'Relances'],
        'commissions' => ['admin/commissions', 'ph-hand-coins', 'Commissions dues'],
        'retraits'   => ['admin/retraits',   'ph-bank',       'Retraits'],
        'categories' => ['admin/categories', 'ph-tag',        'Catégories'],
        'zones'      => ['admin/zones',      'ph-map-pin',    'Zones'],
        'courses'    => ['admin/courses',    'ph-truck',      'Courses'],
        'offres'     => ['admin/offres',     'ph-handshake',  'Offres'],
        'litiges'    => ['admin/litiges',    'ph-chat-circle-text', 'Signalements'],
        'messages'   => ['admin/messages',   'ph-tray',       'Messages'],
        'fetes'      => ['admin/fetes',      'ph-confetti',   'Fêtes'],
        'livreurs'   => ['admin/livreurs',   'ph-motorcycle', 'Livreurs'],
        'caisse'     => ['admin/caisse',     'ph-hand-coins', 'Caisse'],
        'journal'    => ['admin/journal',    'ph-scroll',     'Journal'],
        'tresorerie' => ['admin/tresorerie', 'ph-vault',      'Trésorerie'],
        'parametres' => ['admin/parametres', 'ph-sliders',    'Paramètres'],
    ];
    if (!livreurs_jend_actifs()) {          // fonctionnalité à activer plus tard (Administration → Paramètres)
        unset($onglets['courses'], $onglets['livreurs'], $onglets['caisse']);
    }
    // pastilles : ce qui attend une action (signalements en rouge si le délai promis de 48 h est dépassé)
    $notifs = notifs_admin();
    echo '<nav class="onglets" aria-label="Administration">';
    foreach ($onglets as $cle => [$chemin, $icone, $libelle]) {
        $pastille = pastille_onglet($notifs[$cle] ?? 0, $cle === 'litiges' ? $notifs['litiges_retard'] > 0 : in_array($cle, ['boutiques', 'commandes', 'messages', 'courses', 'relances'], true));
        printf('<a href="%s"%s><i class="ph %s"></i> %s%s</a>', e(url($chemin)), $cle === $actif ? ' class="actif" aria-current="page"' : '', $icone, e($libelle), $pastille);
    }
    echo '</nav>';
}

/**
 * Calcule les gains d'une boutique. Trois cas, selon le moyen de paiement et QUI livre :
 *  A. paiement en ligne (Jënd a encaissé) : le vendeur gagne le prix des produits − commission,
 *     + le frais de livraison s'il a livré lui-même ;
 *  B. paiement à la livraison, livré par un livreur Jënd (qui encaisse pour Jënd) : prix − commission ;
 *  C. paiement à la livraison, livré par le vendeur : il encaisse lui-même le reste en espèces (produits + frais − acompte). Jënd lui doit
 *     seulement l'acompte qu'elle a reçu en ligne, et le vendeur doit à Jënd la commission (retenue sur son solde).
 * Valeurs renvoyées (FCFA) :
 *  - brut / commission / net : toutes les livraisons livrées et réglées (net = ce que le vendeur gagne, frais de livraison compris) ;
 *  - frais_livraison : frais gagnés en livrant lui-même ; especes : argent déjà encaissé par le vendeur (cas C) ;
 *  - a_reverser : commissions dues à Jënd sur ces espèces ;
 *  - bloque : gains en litige ; rembourse : remboursements clients retenus ;
 *  - en_delai : gains des livraisons trop récentes (délai avant retrait, par défaut 3 jours) ;
 *  - dette : ce que le vendeur doit à Jënd quand ses retenues dépassent ses gains (reportée sur ses prochains gains,
 *    ou réglée par le vendeur : « regle », voir includes/reglements.php) ;
 *  - solde disponible = (cas A + B) − gains en délai − commissions à reverser − retraits − litiges − remboursements (jamais négatif).
 */
function vendeur_gains(int $boutiqueId): array
{
    $delai = delai_retrait_jours();
    $hors = "(cb.livre_le IS NULL OR cb.livre_le <= (NOW() - INTERVAL $delai DAY))";       // gain devenu retirable (délai écoulé)
    $reglee = "cb.statut = 'livree' AND (c.statut_paiement = 'paye' OR (c.methode_paiement = 'livraison' AND cb.livre_par = 'vendeur'))";
    $especeVendeur = "(c.methode_paiement = 'livraison' AND cb.livre_par = 'vendeur')";
    $g = requete(
        "SELECT COALESCE(SUM(cb.sous_total), 0) AS brut,
                COALESCE(SUM(cb.commission), 0) AS commission,
                COALESCE(SUM(cb.net_vendeur + IF(cb.livre_par = 'vendeur', cb.frais_part, 0)), 0) AS net,
                COALESCE(SUM(IF(cb.livre_par = 'vendeur', cb.frais_part, 0)), 0) AS frais_livraison,
                COALESCE(SUM(IF($especeVendeur, cb.sous_total + cb.frais_part - cb.acompte_part, 0)), 0) AS especes,
                COALESCE(SUM(IF($especeVendeur, cb.commission, 0)), 0) AS a_reverser,
                COALESCE(SUM(IF($especeVendeur, cb.acompte_part, cb.net_vendeur + IF(cb.livre_par = 'vendeur', cb.frais_part, 0))), 0) AS credit,
                COALESCE(SUM(IF($hors, 0, IF($especeVendeur, cb.acompte_part, cb.net_vendeur + IF(cb.livre_par = 'vendeur', cb.frais_part, 0)))), 0) AS en_delai
           FROM commande_boutiques cb JOIN commandes c ON c.id = cb.commande_id
          WHERE cb.boutique_id = ? AND $reglee",
        [$boutiqueId]
    )->fetch();
    // Acompte conservé quand le client était absent ou a refusé : il indemnise le vendeur qui devait livrer (Jënd le garde si ce sont ses livreurs)
    $g['acompte_acquis'] = (int) requete("SELECT COALESCE(SUM(acompte_part), 0) FROM commande_boutiques WHERE boutique_id = ? AND statut = 'retournee' AND acompte_acquis = 1 AND livre_par = 'vendeur'", [$boutiqueId])->fetchColumn();
    $g['credit'] += $g['acompte_acquis'];
    $retire = (int) requete("SELECT COALESCE(SUM(montant), 0) FROM retraits WHERE boutique_id = ? AND statut IN ('demande', 'paye')", [$boutiqueId])->fetchColumn();
    // Argent en litige : mis de côté tant que le signalement n'est pas tranché ; remboursements retenus sur le vendeur
    // (les espèces remises directement au vendeur ne sont pas concernées : Jënd ne les détient pas)
    $g['bloque'] = (int) requete(
        "SELECT COALESCE(SUM(cb.net_vendeur + IF(cb.livre_par = 'vendeur', cb.frais_part, 0)), 0) FROM litiges l JOIN commande_boutiques cb ON cb.id = l.commande_boutique_id JOIN commandes c ON c.id = cb.commande_id
          WHERE cb.boutique_id = ? AND $reglee AND $hors AND NOT $especeVendeur AND l.statut IN ('ouvert', 'en_cours')", [$boutiqueId])->fetchColumn();
    $g['rembourse'] = (int) requete(
        "SELECT COALESCE(SUM(l.montant_rembourse), 0) FROM litiges l JOIN commande_boutiques cb ON cb.id = l.commande_boutique_id JOIN commandes c ON c.id = cb.commande_id
          WHERE cb.boutique_id = ? AND cb.statut = 'livree' AND $hors AND NOT $especeVendeur AND l.statut = 'rembourse' AND l.a_charge_vendeur = 1", [$boutiqueId])->fetchColumn();
    $g['retire'] = $retire;
    $g['delai'] = $delai;
    // Commissions sur les ventes en espèces déjà réglées par le vendeur (Wave / Orange Money au numéro de Jënd) : elles réduisent sa dette
    $g['regle'] = function_exists('reglements_total') ? reglements_total($boutiqueId) : 0;
    $net = (int) $g['credit'] - (int) $g['en_delai'] - (int) $g['a_reverser'] - $retire - $g['bloque'] - $g['rembourse'] + $g['regle'];
    $g['solde'] = max(0, $net);
    $g['dette'] = max(0, -$net);          // ce que le vendeur doit à Jënd (commissions sur ses espèces, remboursements retenus) : se rembourse tout seul sur ses prochains gains
    return array_map('intval', $g);
}

/** Transitions autorisées pour une sous-commande. */
const TRANSITIONS_SOUS_COMMANDE = ['a_preparer' => 'expediee', 'expediee' => 'livree'];

/**
 * Fait avancer une sous-commande (expédiée, puis livrée) pour la boutique donnée.
 * @throws RuntimeException message affichable
 */
function sous_commande_avancer(int $sousCommandeId, int $boutiqueId, ?string $numeroSuivi, ?string $code = null, bool $parLivreur = false, bool $parClient = false): void
{
    // Livraison : le vendeur doit saisir le code que le CLIENT lui donne à la réception (preuve que le colis est arrivé).
    // Fait AVANT la transaction : un essai raté doit rester enregistré même si la transaction est annulée.
    // (le client qui confirme LUI-MÊME avoir reçu son colis n'a pas besoin du code : $parClient, déjà vérifié par livraison_confirmer_par_client)
    $avant = $parClient ? null : requete('SELECT statut, code_livraison, livreur_id, livre_par FROM commande_boutiques WHERE id = ? AND boutique_id = ?', [$sousCommandeId, $boutiqueId])->fetch();
    if ($avant && $avant['statut'] === 'expediee' && $avant['livre_par'] === 'jend' && !$parLivreur) {
        throw new RuntimeException('Cette livraison est assurée par les livreurs Jënd : c\'est le livreur qui la confirme avec le code du client.');
    }
    if ($avant && $avant['statut'] === 'expediee' && $avant['livreur_id'] !== null && !$parLivreur) {
        throw new RuntimeException('Un livreur est affecté à cette commande : c\'est lui qui confirme la livraison avec le code du client.');
    }
    if ($avant && $avant['statut'] === 'expediee' && $avant['code_livraison'] !== null) {
        $cle = 'livraison:' . $sousCommandeId;
        if (limite_atteinte($cle . ':jour', 15, 86400)) {
            alerter('code-livraison-jour:' . $sousCommandeId, 'Code de livraison : verrouillé 24 h', 'Plus de 15 codes erronés en 24 h pour la sous-commande n° ' . $sousCommandeId . ' : possible tentative de fraude. Contactez le client et vérifiez la livraison.');
            throw new RuntimeException('Livraison verrouillée pour 24 h après trop d\'essais. Contactez l\'assistance Jënd.');
        }
        if (limite_atteinte($cle, 5, 900)) {
            alerter('code-livraison:' . $sousCommandeId, 'Code de livraison : trop d\'essais', 'Plusieurs codes de livraison erronés ont été saisis pour la sous-commande n° ' . $sousCommandeId . '.');
            throw new RuntimeException('Trop d\'essais pour ce code de livraison. Réessayez dans 15 minutes.');
        }
        if (!hash_equals((string) $avant['code_livraison'], preg_replace('/\D/', '', (string) $code))) {
            limite_enregistrer($cle);
            limite_enregistrer($cle . ':jour');
            throw new RuntimeException('Code de livraison incorrect : demandez-le au client lors de la remise du colis.');
        }
    }

    $pdo = pdo();
    $pdo->beginTransaction();
    try {
        $sc = requete(
            'SELECT cb.id, cb.statut, cb.commande_id, c.statut AS statut_commande, c.statut_paiement, c.methode_paiement, c.acompte
               FROM commande_boutiques cb JOIN commandes c ON c.id = cb.commande_id
              WHERE cb.id = ? AND cb.boutique_id = ? FOR UPDATE',
            [$sousCommandeId, $boutiqueId]
        )->fetch();
        if (!$sc) {
            throw new RuntimeException('Commande introuvable.');
        }
        $suivant = TRANSITIONS_SOUS_COMMANDE[$sc['statut']] ?? null;
        if (!$suivant) {
            throw new RuntimeException('Cette commande ne peut plus avancer.');
        }
        if ($sc['statut_commande'] === 'annulee') {
            throw new RuntimeException('Cette commande a été annulée.');
        }
        if (!commande_engagee($sc)) {
            throw new RuntimeException('Le client n\'a pas encore payé' . ($sc['methode_paiement'] === 'livraison' ? ' son acompte' : '') . ' : attendez la confirmation du paiement.');
        }

        if ($suivant === 'expediee' && $numeroSuivi !== null && $numeroSuivi !== '') {
            requete('UPDATE commande_boutiques SET statut = ?, numero_suivi = ? WHERE id = ?', [$suivant, mb_substr($numeroSuivi, 0, 60), $sc['id']]);
        } else {
            requete('UPDATE commande_boutiques SET statut = ? WHERE id = ?', [$suivant, $sc['id']]);
        }

        if ($suivant === 'livree') {
            requete('UPDATE commande_boutiques SET livre_le = NOW() WHERE id = ?', [$sc['id']]);
            $reste = (int) requete("SELECT COUNT(*) FROM commande_boutiques WHERE commande_id = ? AND statut NOT IN ('livree', 'annulee')", [$sc['commande_id']])->fetchColumn();
            if ($reste === 0) {
                requete("UPDATE commandes SET statut = 'terminee' WHERE id = ?", [$sc['commande_id']]);
                if ($sc['methode_paiement'] === 'livraison') {          // l'argent est encaissé par le livreur à la remise
                    requete("UPDATE commandes SET statut_paiement = 'paye' WHERE id = ?", [$sc['commande_id']]);
                    requete("UPDATE paiements SET statut = 'reussi' WHERE commande_id = ? AND statut = 'initie'", [$sc['commande_id']]);
                }
            }
        }
        $pdo->commit();
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        if ($e instanceof RuntimeException) {
            throw $e;
        }
        error_log('Jënd — avancement sous-commande : ' . $e->getMessage());
        throw new RuntimeException('Une erreur est survenue, réessayez.');
    }
    if ($suivant === 'livree') {
        try {
            suivi_prevenir_client((int) $sc['commande_id'], 'livre');       // « livraison confirmée » + rappel du droit de signaler un problème
        } catch (Throwable $e) {
            error_log('Jënd — e-mail livraison : ' . $e->getMessage());
        }
    }
}

/**
 * Le CLIENT confirme lui-même avoir reçu son colis (bouton « J'ai bien reçu ma commande ») : même effet que la saisie du code.
 * Réservé aux livraisons assurées par le vendeur et déjà expédiées ; pour un livreur Jënd, c'est le livreur qui confirme avec le code.
 * @throws RuntimeException message affichable
 */
function livraison_confirmer_par_client(int $sousCommandeId, int $clientId): void
{
    $sc = requete(
        'SELECT cb.boutique_id, cb.statut, cb.livre_par, cb.livreur_id, c.client_id
           FROM commande_boutiques cb JOIN commandes c ON c.id = cb.commande_id WHERE cb.id = ?',
        [$sousCommandeId]
    )->fetch();
    if (!$sc || (int) $sc['client_id'] !== $clientId) {
        throw new RuntimeException('Livraison introuvable.');
    }
    if ($sc['statut'] === 'livree') {
        throw new RuntimeException('Cette livraison est déjà confirmée.');
    }
    if ($sc['statut'] !== 'expediee') {
        throw new RuntimeException('Le vendeur n\'a pas encore expédié ce colis : vous pourrez confirmer la réception ensuite.');
    }
    if ($sc['livre_par'] !== 'vendeur' || $sc['livreur_id'] !== null) {
        throw new RuntimeException('Cette livraison est assurée par un livreur Jënd : donnez-lui le code à la remise du colis.');
    }
    sous_commande_avancer($sousCommandeId, (int) $sc['boutique_id'], null, null, false, true);
}

/** Slug unique pour un produit : pagne-wax, pagne-wax-2, pagne-wax-3… */
function produit_slug_unique(string $nom, int $ignorerId = 0): string
{
    $base = slugify($nom);
    $slug = $base;
    for ($i = 2; requete('SELECT 1 FROM produits WHERE slug = ? AND id <> ?', [$slug, $ignorerId])->fetch(); $i++) {
        $slug = $base . '-' . $i;
    }
    return $slug;
}

/** Catégories sous forme d'arbre : [ ['id'=>, 'nom'=>, 'enfants'=>[…]], … ] */
function categories_arbre(): array
{
    $tout = requete('SELECT id, parent_id, nom FROM categories ORDER BY position, nom')->fetchAll();
    $arbre = [];
    foreach ($tout as $c) {
        if ($c['parent_id'] === null) {
            $arbre[(int) $c['id']] = ['id' => (int) $c['id'], 'nom' => $c['nom'], 'enfants' => []];
        }
    }
    foreach ($tout as $c) {
        if ($c['parent_id'] !== null && isset($arbre[(int) $c['parent_id']])) {
            $arbre[(int) $c['parent_id']]['enfants'][] = ['id' => (int) $c['id'], 'nom' => $c['nom']];
        }
    }
    return array_values($arbre);
}

/** Pour les pages admin en POST : refuse la requête si le jeton CSRF est invalide. */
function post_verifie(string $retour): bool
{
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        return false;
    }
    if (!csrf_valide($_POST['csrf'] ?? null)) {
        flash('Session expirée, merci de réessayer.', 'erreur');
        rediriger($retour);
    }
    return true;
}
