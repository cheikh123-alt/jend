<?php
declare(strict_types=1);

/**
 * Aide et contact : un client, un vendeur ou un visiteur écrit à l'équipe Jënd ; l'administrateur répond depuis « Messages ».
 * (Les problèmes de livraison passent par les signalements, qui ont leur propre circuit de remboursement.)
 */

const SUJETS_SUPPORT = [
    'commande'  => 'Une commande ou une livraison',
    'paiement'  => 'Un paiement ou un remboursement',
    'compte'    => 'Mon compte (connexion, mot de passe…)',
    'boutique'  => 'Ma boutique (vendeur)',
    'technique' => 'Un problème sur le site (page, bouton…)',
    'autre'     => 'Autre question',
];
const STATUTS_SUPPORT = ['nouveau' => 'En attente de l\'équipe', 'en_cours' => 'L\'équipe vous a répondu', 'resolu' => 'Clos'];
const SUPPORT_DELAI_HEURES = 48;

/** @throws RuntimeException message affichable. @return string référence */
function support_envoyer(?array $u, string $nom, string $email, string $tel, string $sujet, string $commande, string $message): string
{
    $nom = trim($nom); $email = trim($email); $message = trim($message); $commande = strtoupper(trim($commande));
    if ($u) {
        $nom = (string) $u['nom']; $email = (string) $u['email'];
    }
    if (mb_strlen($nom) < 2 || mb_strlen($nom) > 120) {
        throw new RuntimeException('Indiquez votre nom.');
    }
    if (!filter_var($email, FILTER_VALIDATE_EMAIL) || mb_strlen($email) > 190) {
        throw new RuntimeException('Adresse e-mail invalide : c\'est là que nous vous répondrons.');
    }
    $telOk = trim($tel) === '' ? null : telephone_valide($tel);
    if (trim($tel) !== '' && $telOk === null) {
        throw new RuntimeException('Numéro de téléphone invalide (ex : 77 123 45 67), ou laissez vide.');
    }
    if (!isset(SUJETS_SUPPORT[$sujet])) {
        throw new RuntimeException('Choisissez le sujet de votre message.');
    }
    if ($commande !== '' && !preg_match('/^[A-Z0-9-]{4,20}$/', $commande)) {
        throw new RuntimeException('Numéro de commande invalide (ex : JND-261012-A4F2), ou laissez vide.');
    }
    if (mb_strlen($message) < 10 || mb_strlen($message) > 3000) {
        throw new RuntimeException('Décrivez votre demande (10 à 3000 caractères).');
    }
    $cle = $u ? 'support:user:' . $u['id'] : 'support:ip:' . ip_client();
    if (limite_atteinte($cle, $u ? 6 : 3, 3600)) {
        throw new RuntimeException('Vous nous avez déjà écrit plusieurs fois : nous vous répondons au plus vite. Réessayez dans une heure si besoin.');
    }
    limite_enregistrer($cle);
    do {
        $ref = 'AIDE-' . strtoupper(bin2hex(random_bytes(4)));
    } while (requete('SELECT 1 FROM messages_support WHERE reference = ?', [$ref])->fetch());
    requete('INSERT INTO messages_support (reference, user_id, nom, email, telephone, sujet, commande_ref, message) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
        [$ref, $u['id'] ?? null, $nom, $email, $telOk, $sujet, $commande !== '' ? $commande : null, $message]);
    $id = (int) pdo()->lastInsertId();
    $lienSuivi = support_lien_suivi($id);
    try {
        $admin = (string) (env('ALERT_EMAIL') ?: env('ADMIN_EMAIL'));
        if ($admin !== '') {
            envoyer_email($admin, 'Nouveau message ' . $ref . ' : ' . SUJETS_SUPPORT[$sujet], "De : $nom <$email>" . ($telOk ? " · $telOk" : '') . "\n\n$message\n\nRépondre : " . app_url('admin/messages'));
        }
        envoyer_email($email, 'Nous avons bien reçu votre message ' . $ref, "Bonjour,\n\nVotre message est bien arrivé (référence $ref). Nous vous répondons sous " . SUPPORT_DELAI_HEURES . " heures.\nSuivez la conversation et répondez ici :\n$lienSuivi\n\n— L'équipe Jënd");
    } catch (Throwable $e) {
        error_log('Jënd — e-mail support : ' . $e->getMessage());
    }
    return $ref;
}

/**
 * Adresse où suivre la conversation : l'espace « Aide » pour un utilisateur connecté, sinon un lien secret.
 * Pour un visiteur, un nouveau lien est créé à chaque e-mail (seule son empreinte est gardée) : le lien du DERNIER e-mail est le bon.
 */
function support_lien_suivi(int $id): string
{
    $m = requete('SELECT user_id, reference FROM messages_support WHERE id = ?', [$id])->fetch();
    if ($m && $m['user_id']) {
        return app_url('aide/' . $m['reference']);
    }
    $jeton = bin2hex(random_bytes(32));
    requete('UPDATE messages_support SET jeton_hash = ? WHERE id = ?', [hash('sha256', $jeton), $id]);
    return app_url('aide/suivi/' . $jeton);
}

/** La conversation : le message de départ puis les réponses, dans l'ordre. */
function support_fil(array $m): array
{
    $fil = [['auteur' => 'client', 'texte' => $m['message'], 'created_at' => $m['created_at']]];
    foreach (requete('SELECT auteur, texte, created_at FROM messages_support_reponses WHERE message_id = ? ORDER BY id', [$m['id']])->fetchAll() as $r) {
        $fil[] = $r;
    }
    return $fil;
}

/**
 * Ajoute un message à la conversation. $auteur : 'equipe' (administrateur) ou 'client'.
 * L'équipe répond → « en attente du client » ; le client répond → retour « à traiter ». Une conversation close ne reçoit plus de message.
 * @throws RuntimeException
 */
function support_ajouter(int $id, string $auteur, string $texte, ?int $userId = null): void
{
    $m = requete('SELECT * FROM messages_support WHERE id = ?', [$id])->fetch();
    if (!$m) {
        throw new RuntimeException('Conversation introuvable.');
    }
    if ($m['statut'] === 'resolu') {
        throw new RuntimeException($auteur === 'client' ? 'Cette conversation est close. Si le problème revient, écrivez-nous un nouveau message.' : 'Conversation close : rouvrez-la pour répondre.');
    }
    $texte = trim($texte);
    if (mb_strlen($texte) < 2 || mb_strlen($texte) > 3000) {
        throw new RuntimeException('Écrivez votre message (3000 caractères maximum).');
    }
    if ($auteur === 'client') {
        $cle = 'support-fil:' . $id;
        if (limite_atteinte($cle, 15, 3600)) {
            throw new RuntimeException('Vous avez envoyé beaucoup de messages : patientez un peu, nous vous répondons.');
        }
        limite_enregistrer($cle);
    }
    requete('INSERT INTO messages_support_reponses (message_id, auteur, user_id, texte) VALUES (?, ?, ?, ?)', [$id, $auteur === 'equipe' ? 'equipe' : 'client', $userId, $texte]);
    if ($auteur === 'equipe') {
        requete("UPDATE messages_support SET statut = 'en_cours', repondu_le = NOW() WHERE id = ?", [$id]);
        envoyer_email((string) $m['email'], 'Réponse à votre message ' . $m['reference'],
            'Bonjour ' . explode(' ', (string) $m['nom'])[0] . ",\n\n$texte\n\n— L'équipe Jënd\n\nVous pouvez nous répondre dans la même conversation :\n" . support_lien_suivi($id));
    } else {
        requete("UPDATE messages_support SET statut = 'nouveau' WHERE id = ?", [$id]);
        $admin = (string) (env('ALERT_EMAIL') ?: env('ADMIN_EMAIL'));
        if ($admin !== '') {
            envoyer_email($admin, 'Nouvelle réponse dans ' . $m['reference'], "{$m['nom']} a répondu :\n\n$texte\n\nConversation : " . app_url('admin/messages'));
        }
    }
}

/** L'administrateur clôt la conversation une fois tout réglé (ou la rouvre). */
function support_clore(int $id, bool $clore): void
{
    requete('UPDATE messages_support SET statut = ? WHERE id = ?', [$clore ? 'resolu' : 'en_cours', $id]);
    if ($clore && ($m = requete('SELECT email, nom, reference FROM messages_support WHERE id = ?', [$id])->fetch())) {
        envoyer_email((string) $m['email'], 'Conversation ' . $m['reference'] . ' close',
            'Bonjour ' . explode(' ', (string) $m['nom'])[0] . ",\n\nNous avons clos votre demande {$m['reference']} : le problème est réglé. Si besoin, écrivez-nous un nouveau message depuis « Aide et contact ».\n\n— L'équipe Jënd");
    }
}

function support_a_traiter(): int
{
    return (int) requete("SELECT COUNT(*) FROM messages_support WHERE statut = 'nouveau'")->fetchColumn();
}
