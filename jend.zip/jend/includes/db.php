<?php
declare(strict_types=1);

/** Connexion PDO unique, réutilisée pendant toute la requête. */
function pdo(): PDO
{
    static $pdo = null;
    if ($pdo !== null) {
        return $pdo;
    }

    $dsn = sprintf(
        'mysql:host=%s;port=%s;dbname=%s;charset=utf8mb4',
        env('DB_HOST', '127.0.0.1'),
        env('DB_PORT', '3306'),
        env('DB_NAME', 'jend')
    );

    try {
        $pdo = new PDO($dsn, env('DB_USER', 'root'), env('DB_PASS', ''), [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,   // vraies requêtes préparées : protège des injections SQL
        ]);
    } catch (PDOException $e) {
        error_log('Jënd — connexion BDD impossible : ' . $e->getMessage());
        http_response_code(500);
        if (env('APP_ENV') === 'dev') {
            exit('Connexion à la base impossible : ' . htmlspecialchars($e->getMessage()));
        }
        if (env('APP_ENV') === 'test') {          // site de test : la CAUSE, sans aucun identifiant ni mot de passe
            header('Content-Type: text/plain; charset=UTF-8');
            exit("Site de test — connexion à la base impossible.\nCause probable : " . db_cause_erreur($e) . "\nCorrigez le fichier .env (à côté de index.php), puis rechargez la page.");
        }
        exit('Service momentanément indisponible.');
    }

    return $pdo;
}

/** Raccourci : exécute une requête préparée et renvoie le statement. */
function requete(string $sql, array $params = []): PDOStatement
{
    $st = pdo()->prepare($sql);
    $st->execute($params);
    return $st;
}

/** Explication courte d'un échec de connexion MySQL, sans rien révéler (ni nom d'utilisateur, ni mot de passe, ni hôte). */
function db_cause_erreur(PDOException $e): string
{
    $m = $e->getMessage();
    if (str_contains($m, '[1045]') || stripos($m, 'Access denied') !== false) {
        return 'utilisateur ou mot de passe refusé (DB_USER / DB_PASS). Sur InfinityFree, DB_PASS est le mot de passe du compte d\'hébergement (panneau → Account → Password → Show).';
    }
    if (str_contains($m, '[1049]') || stripos($m, 'Unknown database') !== false) {
        return 'cette base n\'existe pas (DB_NAME). Copiez le nom complet depuis « MySQL Databases » (avec le préfixe if0_…_).';
    }
    if (str_contains($m, '[1044]')) {
        return 'cet utilisateur n\'a pas le droit d\'utiliser cette base (DB_USER / DB_NAME ne vont pas ensemble).';
    }
    if (str_contains($m, '[2002]') || str_contains($m, '[2005]') || stripos($m, 'getaddrinfo') !== false || stripos($m, 'timed out') !== false) {
        return 'serveur de base introuvable ou injoignable (DB_HOST). Sur InfinityFree, ce n\'est pas « localhost » : copiez « MySQL Hostname » (sqlXXX.infinityfree.com).';
    }
    if (!is_file(dirname(__DIR__) . '/.env')) {
        return 'le fichier .env est introuvable : il doit s\'appeler exactement « .env » et être à côté de index.php.';
    }
    return 'erreur inattendue (code ' . (int) $e->getCode() . ').';
}

/** Site de test : explication d'une erreur due à une installation incomplète de la base, ou null. */
function erreur_installation(Throwable $e): ?string
{
    if (!$e instanceof PDOException) {
        return null;
    }
    $etat = (string) ($e->errorInfo[0] ?? $e->getCode());
    if ($etat === '42S02') {
        return 'Site de test : des tables manquent dans la base. Importez jend-installation.sql (version récente, 38 tables) dans phpMyAdmin, dans une base vide.';
    }
    if ($etat === '42S22') {
        return 'Site de test : la base n\'est pas à jour (une colonne manque). Videz la base puis importez le jend-installation.sql récent, ou importez les migrations manquantes dans l\'ordre.';
    }
    return null;
}

