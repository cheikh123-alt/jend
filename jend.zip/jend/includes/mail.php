<?php
declare(strict_types=1);

/** Adresse publique du site (définie dans .env), utilisée dans les liens des e-mails. */
function app_url(string $chemin = ''): string
{
    return rtrim((string) env('APP_URL', 'http://localhost'), '/') . '/' . ltrim($chemin, '/');
}

/** Nom de domaine du site (sert à l'expéditeur par défaut et à l'identification SMTP). */
function app_domaine(): string
{
    $h = parse_url((string) env('APP_URL', ''), PHP_URL_HOST);
    return is_string($h) && $h !== '' ? $h : 'localhost';
}

/**
 * Envoie un e-mail texte. Mode choisi par MAIL_DRIVER (.env) :
 *   log  : écrit le message dans storage/emails.log, rien n'est envoyé (défaut en développement) ;
 *   mail : fonction mail() de PHP, pour les hébergements qui fournissent l'envoi (défaut en production) ;
 *   smtp : envoi via un serveur SMTP (Brevo, Mailjet, SendGrid, votre hébergeur…) avec SMTP_* dans .env.
 */
function envoyer_email(string $destinataire, string $sujet, string $corps): bool
{
    // Empêche l'injection d'en-têtes (retours à la ligne dans l'adresse ou le sujet)
    if (preg_match('/[\r\n]/', $destinataire . $sujet) || !filter_var($destinataire, FILTER_VALIDATE_EMAIL)) {
        return false;
    }

    $driver = (string) (env('MAIL_DRIVER') ?: (env('APP_ENV', 'prod') === 'dev' ? 'log' : 'mail'));
    $domaine = app_domaine();
    $from = (string) (env('MAIL_FROM') ?: 'no-reply@' . (str_contains($domaine, '.') ? $domaine : 'jend.local'));   // « localhost » n'est pas un domaine valide
    $nom  = preg_replace('/[\r\n"<>]/', '', (string) (env('MAIL_FROM_NAME') ?: 'Jënd'));
    if ($driver !== 'log' && !filter_var($from, FILTER_VALIDATE_EMAIL)) {
        error_log('Jënd — MAIL_FROM invalide : ' . $from);
        return false;
    }

    if ($driver === 'log') {
        $entree = '[' . date('Y-m-d H:i:s') . "] À : $destinataire\nSujet : $sujet\n$corps\n" . str_repeat('-', 60) . "\n";
        return file_put_contents(dirname(__DIR__) . '/storage/emails.log', $entree, FILE_APPEND | LOCK_EX) !== false;
    }
    if ($driver === 'smtp') {
        return smtp_envoyer($destinataire, $sujet, $corps, $from, $nom);
    }
    $entetes = 'From: =?UTF-8?B?' . base64_encode($nom) . "?= <$from>\r\nContent-Type: text/plain; charset=UTF-8";
    return mail($destinataire, '=?UTF-8?B?' . base64_encode($sujet) . '?=', $corps, $entetes);
}

/**
 * Client SMTP minimal (SSL direct sur le port 465, ou STARTTLS sur le 587), authentification AUTH LOGIN.
 * Le certificat du serveur est TOUJOURS vérifié. Sans chiffrement (SMTP_SECURE=none), l'envoi avec identifiants
 * n'est accepté qu'en développement : on n'envoie jamais un mot de passe en clair sur Internet.
 */
function smtp_envoyer(string $a, string $sujet, string $corps, string $from, string $nomFrom): bool
{
    $hote = (string) env('SMTP_HOST', '');
    $port = (int) (env('SMTP_PORT') ?: 587);
    $secu = (string) (env('SMTP_SECURE') ?: 'tls');            // ssl | tls | none
    $user = (string) env('SMTP_USER', '');
    $pass = (string) env('SMTP_PASS', '');
    $dev  = env('APP_ENV', 'prod') === 'dev';

    if ($hote === '' || !in_array($secu, ['ssl', 'tls', 'none'], true)) {
        error_log('Jënd — SMTP mal configuré (SMTP_HOST / SMTP_SECURE)');
        return false;
    }
    if ($secu === 'none' && $user !== '' && !$dev) {
        error_log('Jënd — SMTP refusé : identifiants sans chiffrement en production');
        return false;
    }

    $contexte = stream_context_create(['ssl' => ['verify_peer' => true, 'verify_peer_name' => true, 'peer_name' => $hote]]);
    $fp = @stream_socket_client(($secu === 'ssl' ? 'ssl://' : 'tcp://') . $hote . ':' . $port, $errno, $errstr, 10, STREAM_CLIENT_CONNECT, $contexte);
    if (!$fp) {
        error_log("Jënd — SMTP : connexion impossible à $hote:$port ($errstr)");
        return false;
    }
    stream_set_timeout($fp, 10);

    $lire = function () use ($fp): array {
        $texte = '';
        while (($l = fgets($fp, 1024)) !== false) {
            $texte .= $l;
            if (strlen($l) < 4 || $l[3] === ' ') {      // dernière ligne d'une réponse (« 250 » + espace)
                break;
            }
        }
        return [(int) substr($texte, 0, 3), trim($texte)];
    };
    // $libelle : texte du journal d'erreurs. On n'y recopie JAMAIS la commande, qui peut contenir un mot de passe.
    $cmd = function (string $ligne, array $attendus, string $libelle) use ($fp, $lire): void {
        fwrite($fp, $ligne . "\r\n");
        [$code, $texte] = $lire();
        if (!in_array($code, $attendus, true)) {
            throw new RuntimeException("$libelle → $texte");
        }
    };

    try {
        [$code, $texte] = $lire();
        if ($code !== 220) {
            throw new RuntimeException("accueil → $texte");
        }
        $moi = app_domaine();
        $cmd("EHLO $moi", [250], 'EHLO');
        if ($secu === 'tls') {
            $cmd('STARTTLS', [220], 'STARTTLS');
            if (stream_socket_enable_crypto($fp, true, STREAM_CRYPTO_METHOD_TLS_CLIENT) !== true) {
                throw new RuntimeException('négociation TLS refusée (certificat invalide ?)');
            }
            $cmd("EHLO $moi", [250], 'EHLO (TLS)');
        }
        if ($user !== '') {
            $cmd('AUTH LOGIN', [334], 'AUTH');
            $cmd(base64_encode($user), [334], 'AUTH (identifiant)');
            $cmd(base64_encode($pass), [235], 'AUTH (identifiants refusés)');
        }
        $cmd("MAIL FROM:<$from>", [250], 'MAIL FROM');
        $cmd("RCPT TO:<$a>", [250, 251], 'RCPT TO');
        $cmd('DATA', [354], 'DATA');

        $message = implode("\r\n", [
            'Date: ' . date('r'),
            'From: =?UTF-8?B?' . base64_encode($nomFrom) . "?= <$from>",
            "To: <$a>",
            'Subject: =?UTF-8?B?' . base64_encode($sujet) . '?=',
            'Message-ID: <' . bin2hex(random_bytes(12)) . '@' . app_domaine() . '>',
            'MIME-Version: 1.0',
            'Content-Type: text/plain; charset=UTF-8',
            'Content-Transfer-Encoding: base64',
            '',
            rtrim(chunk_split(base64_encode($corps), 76, "\r\n")),   // base64 : pas de ligne trop longue, pas de « . » isolé
        ]);
        $cmd($message . "\r\n.", [250], 'envoi du message');
        @fwrite($fp, "QUIT\r\n");
        return true;
    } catch (Throwable $e) {
        error_log('Jënd — SMTP : ' . $e->getMessage());
        return false;
    } finally {
        @fclose($fp);
    }
}
