<?php
declare(strict_types=1);

/** Utilisateur connecté (ou null). Chargé une seule fois par requête. */
function utilisateur(): ?array
{
    static $u = false;
    if ($u === false) {
        $u = null;
        if (!empty($_SESSION['user_id'])) {
            $u = requete('SELECT id, nom, email, telephone, role, session_version, totp_actif, email_verifie FROM users WHERE id = ? AND actif = 1', [$_SESSION['user_id']])->fetch() ?: null;
            if (!$u) {
                unset($_SESSION['user_id']);
            } elseif (isset($_SESSION['sv']) && (int) $_SESSION['sv'] !== (int) $u['session_version']) {
                // Le mot de passe a été changé depuis une autre session : celle-ci est coupée
                unset($_SESSION['user_id'], $_SESSION['t_activite'], $_SESSION['sv']);
                flash('Votre mot de passe a été modifié : reconnectez-vous.', 'erreur');
                $u = null;
            } else {
                $_SESSION['sv'] = (int) $u['session_version'];
                // Déconnexion automatique après inactivité : 30 min pour l'admin, 2 h pour les autres (réglable par .env)
                $limite = (int) (env('SESSION_INACTIVITE_SECONDES') ?: ($u['role'] === 'admin' ? 1800 : 7200));
                if (time() - (int) ($_SESSION['t_activite'] ?? time()) > $limite) {
                    unset($_SESSION['user_id'], $_SESSION['t_activite']);
                    flash('Votre session a expiré par sécurité. Reconnectez-vous.', 'erreur');
                    $u = null;
                } else {
                    $_SESSION['t_activite'] = time();
                }
            }
        }
    }
    return $u;
}

/** Page d'accueil de l'espace d'un utilisateur selon son rôle : administrateur et vendeur arrivent directement sur leur tableau de bord. */
function espace_du_role(string $role): string
{
    return match ($role) {
        'admin' => 'admin',
        'vendeur' => 'vendeur',
        'livreur' => 'livreur',
        default => 'compte',
    };
}

/** Ouvre la session d'un utilisateur. On change l'identifiant de session pour empêcher le vol de session. */
function connecter(int $id): void
{
    session_regenerate_id(true);
    $_SESSION['user_id'] = $id;
    $_SESSION['t_activite'] = time();
    $_SESSION['sv'] = (int) requete('SELECT session_version FROM users WHERE id = ?', [$id])->fetchColumn();
    unset($_SESSION['2fa']);
}

/**
 * Coupe TOUTES les sessions ouvertes d'un utilisateur (à appeler quand son mot de passe change).
 * La session en cours (si c'est la sienne) reste ouverte.
 */
function invalider_sessions(int $userId): void
{
    requete('UPDATE users SET session_version = session_version + 1 WHERE id = ?', [$userId]);
    if ((int) ($_SESSION['user_id'] ?? 0) === $userId) {
        $_SESSION['sv'] = (int) requete('SELECT session_version FROM users WHERE id = ?', [$userId])->fetchColumn();
    }
}

function deconnecter(): void
{
    $_SESSION = [];
    if (ini_get('session.use_cookies')) {
        $c = session_get_cookie_params();
        setcookie(session_name(), '', time() - 3600, $c['path'], $c['domain'] ?? '', (bool) $c['secure'], (bool) $c['httponly']);
    }
    session_destroy();
}

/** Redirige vers la page de connexion si personne n'est connecté. */
function exiger_connexion(): array
{
    $u = utilisateur();
    if (!$u) {
        if (empty($_SESSION['flash'])) {         // ne pas écraser « votre session a expiré »
            flash('Connectez-vous pour continuer.', 'erreur');
        }
        rediriger('connexion?retour=' . urlencode($_SERVER['REQUEST_URI'] ?? ''));
    }
    return $u;
}

/**
 * Empreinte factice vérifiée quand l'e-mail n'existe pas. Elle est créée avec le MÊME réglage que les vrais mots de passe
 * (PASSWORD_DEFAULT du serveur) : une empreinte codée en dur avec un autre coût répondrait plus vite ou plus lentement
 * et révélerait quels e-mails ont un compte. Gardée en base, régénérée si le réglage du serveur change.
 */
function faux_hash(): string
{
    $h = function_exists('parametre') ? (string) parametre('auth_faux_hash', '') : '';
    if ($h === '' || password_needs_rehash($h, PASSWORD_DEFAULT)) {
        $h = password_hash(bin2hex(random_bytes(16)), PASSWORD_DEFAULT);
        if (function_exists('parametre_definir')) {
            parametre_definir('auth_faux_hash', $h);
        }
    }
    return $h;
}

/**
 * Vérifie l'e-mail et le mot de passe avec toutes les protections (limites par IP et par e-mail, temps de réponse constant,
 * double authentification). En cas de succès : redirige et termine le script. Sinon : renvoie le message d'erreur à afficher.
 * Partagée par la connexion de la boutique et celle de l'appli livreur.
 */
function tenter_connexion(string $email, string $motDePasse, string $retour, string $parDefaut): ?string
{
    if (limite_atteinte('login:ip:' . ip_client(), limite_param('LIMITE_CONNEXION_IP', 20), 900) || limite_atteinte('login:email:' . cle_email($email), limite_param('LIMITE_CONNEXION_EMAIL', 5), 900)) {
        error_log('Jënd [sécurité] connexion bloquée (trop de tentatives) ip=' . ip_client());
        alerter('blocage-connexion', 'Tentatives de connexion bloquées', 'Une adresse IP (' . ip_client() . ') a dépassé la limite de tentatives de connexion. Possible attaque par force brute.');
        return 'Trop de tentatives. Réessayez dans 15 minutes.';
    }
    $u = requete('SELECT id, mot_de_passe, actif, totp_actif, role FROM users WHERE email = ?', [$email])->fetch();
    // On vérifie toujours un hash, même si l'e-mail n'existe pas, pour que le temps de réponse ne révèle rien.
    $hash = $u['mot_de_passe'] ?? faux_hash();
    if (password_verify($motDePasse, $hash) && $u && (int) $u['actif'] === 1) {
        limite_effacer('login:email:' . cle_email($email));
        if (password_needs_rehash($hash, PASSWORD_DEFAULT)) {          // le serveur a durci son réglage (ex. nouvelle version de PHP) : on met l'empreinte à niveau
            requete('UPDATE users SET mot_de_passe = ? WHERE id = ?', [password_hash($motDePasse, PASSWORD_DEFAULT), $u['id']]);
        }
        if ((int) $u['totp_actif'] === 1) {
            // Mot de passe correct, mais ce compte est protégé par la double authentification : 2e étape obligatoire
            session_regenerate_id(true);
            $_SESSION['2fa'] = ['id' => (int) $u['id'], 't' => time(), 'retour' => $retour];
            rediriger('connexion/2fa');
        }
        connecter((int) $u['id']);
        // sans page demandée : le vendeur et l'administrateur arrivent directement sur leur espace (ils n'achètent pas eux-mêmes)
        header('Location: ' . retour_sur($retour ?: ($u['role'] === 'client' ? $parDefaut : url(espace_du_role((string) $u['role'])))));
        exit;
    }
    limite_enregistrer('login:ip:' . ip_client());
    limite_enregistrer('login:email:' . cle_email($email));
    return 'E-mail ou mot de passe incorrect.';
}

/* ---------- Confirmation de l'adresse e-mail ---------- */

const EMAIL_JETON_HEURES = 48;

/** La confirmation de l'e-mail est-elle exigée ? (réglable par l'administrateur, utile si l'hébergeur n'envoie pas d'e-mails) */
function verification_email_active(): bool
{
    return !function_exists('parametre_actif') || parametre_actif('verification_email', true);
}

/** Envoie (ou renvoie) le lien de confirmation. Le lien ne contient qu'un jeton aléatoire ; seule son empreinte est gardée. */
function email_confirmation_envoyer(int $userId): bool
{
    $u = requete('SELECT email, nom FROM users WHERE id = ? AND email_verifie = 0', [$userId])->fetch();
    if (!$u) {
        return false;
    }
    $jeton = bin2hex(random_bytes(32));
    requete('UPDATE users SET email_jeton_hash = ?, email_jeton_expire = DATE_ADD(NOW(), INTERVAL ' . EMAIL_JETON_HEURES . ' HOUR) WHERE id = ?', [hash('sha256', $jeton), $userId]);
    return envoyer_email((string) $u['email'], 'Confirmez votre adresse e-mail — Jënd',
        'Bonjour ' . explode(' ', (string) $u['nom'])[0] . ",\n\nPour activer votre compte Jënd, confirmez votre adresse e-mail en ouvrant ce lien (valable " . EMAIL_JETON_HEURES . " heures) :\n"
        . app_url('confirmer-email/' . $jeton) . "\n\nSi vous n'avez pas créé de compte sur Jënd, ignorez ce message.");
}

/** Le compte connecté doit avoir confirmé son e-mail (pour commander, ouvrir une boutique, négocier…). Sinon : retour au compte avec le bandeau. */
function exiger_email_confirme(array $u): void
{
    if (verification_email_active() && (int) ($u['email_verifie'] ?? 1) === 0) {
        flash('Confirmez d\'abord votre adresse e-mail : ouvrez le lien que nous vous avons envoyé (vous pouvez le renvoyer ci-dessous).', 'erreur');
        rediriger('compte');
    }
}

/** Numéro sénégalais : "77 123 45 67", "+221771234567"… => "+221771234567" ou null si invalide. */
function telephone_valide(string $tel): ?string
{
    $tel = preg_replace('/[\s.\-]/', '', $tel);
    if (preg_match('/^(?:\+?221)?(7[05678]\d{7})$/', $tel, $m)) {
        return '+221' . $m[1];
    }
    return null;
}
