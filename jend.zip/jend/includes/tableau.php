<?php
declare(strict_types=1);

/**
 * Éléments communs des tableaux de bord (client, vendeur, administrateur) :
 * « À faire maintenant » (ce qui demande une action), indicateurs, listes récentes.
 * Tout est échappé ici ; les pages ne passent que du texte brut.
 */

/** Salutation selon l'heure (Africa/Dakar). */
function tb_salutation(): string
{
    $h = (int) date('G');
    return $h < 5 ? 'Bonsoir' : ($h < 18 ? 'Bonjour' : 'Bonsoir');
}

/** « lundi 12 octobre » */
function tb_date_longue(): string
{
    $jours = ['dimanche', 'lundi', 'mardi', 'mercredi', 'jeudi', 'vendredi', 'samedi'];
    $mois = ['', 'janvier', 'février', 'mars', 'avril', 'mai', 'juin', 'juillet', 'août', 'septembre', 'octobre', 'novembre', 'décembre'];
    return $jours[(int) date('w')] . ' ' . (int) date('j') . ' ' . $mois[(int) date('n')];
}

/**
 * Une ligne « à faire » : icône, nombre, libellé, lien. $ton : urgent (rouge) | normal (safran) | info (vert).
 * Les actions sans rien à traiter ne s'affichent pas : voir tb_a_faire().
 */
function tb_action(string $icone, string $libelle, int $nombre, string $chemin, string $ton = 'normal', string $detail = '', string $bouton = 'Voir'): array
{
    return ['icone' => $icone, 'libelle' => $libelle, 'nombre' => $nombre, 'chemin' => $chemin, 'ton' => $ton, 'detail' => $detail, 'bouton' => $bouton];
}

/** Bloc « À faire maintenant » : n'affiche que les actions dont le nombre est > 0 ; sinon un message « tout est à jour ». */
function tb_a_faire(array $actions, string $messageVide = 'Tout est à jour : rien à faire pour le moment.'): void
{
    $actions = array_values(array_filter($actions, fn ($a) => $a['nombre'] > 0));
    echo '<section class="tb-bloc" aria-labelledby="tb-afaire"><h2 id="tb-afaire" class="tb-titre"><i class="ph-fill ph-lightning"></i> À faire maintenant</h2>';
    if (!$actions) {
        echo '<p class="tb-ok"><i class="ph-fill ph-check-circle"></i> ' . e($messageVide) . '</p></section>';
        return;
    }
    echo '<ul class="tb-actions">';
    foreach ($actions as $a) {
        echo '<li class="tb-action tb-' . e($a['ton']) . '"><span class="tb-action-icone"><i class="ph-fill ' . e($a['icone']) . '"></i></span>'
           . '<span class="tb-action-texte"><b>' . (int) $a['nombre'] . ' · ' . e($a['libelle']) . '</b>'
           . ($a['detail'] !== '' ? '<small>' . e($a['detail']) . '</small>' : '') . '</span>'
           . '<a class="tb-action-lien" href="' . e(url($a['chemin'])) . '">' . e($a['bouton']) . ' <i class="ph ph-arrow-right"></i></a></li>';
    }
    echo '</ul></section>';
}

/** Une carte d'indicateur. */
function tb_kpi(string $icone, string $libelle, string $valeur, string $aide = '', string $chemin = '', bool $fort = false): string
{
    $html = '<div class="tb-kpi' . ($fort ? ' tb-kpi-fort' : '') . '"><span class="tb-kpi-icone"><i class="ph ' . e($icone) . '"></i></span>'
          . '<span class="tb-kpi-libelle">' . e($libelle) . '</span><b class="tb-kpi-valeur">' . e($valeur) . '</b>'
          . ($aide !== '' ? '<small>' . e($aide) . '</small>' : '');
    if ($chemin !== '') {
        $html .= '<a class="tb-kpi-lien" href="' . e(url($chemin)) . '" aria-label="' . e($libelle) . '"></a>';
    }
    return $html . '</div>';
}

/** Barre de progression d'une commande côté client : [libellé, atteint ?]. */
function tb_progression(int $etape): string
{
    $noms = ['Commande passée', 'Payée', 'Expédiée', 'Livrée'];
    $html = '<ol class="tb-prog" aria-label="Avancement de la commande">';
    foreach ($noms as $i => $nom) {
        $classe = $i + 1 < $etape ? 'fait' : ($i + 1 === $etape ? 'courant' : 'avenir');
        $html .= '<li class="tb-prog-' . $classe . '"><span></span><small>' . e($nom) . '</small></li>';
    }
    return $html . '</ol>';
}

/** Étape (1 à 4) d'une commande d'après ses statuts. */
function tb_etape_commande(array $c): int
{
    if ($c['statut'] === 'terminee' || ((int) $c['nb'] > 0 && (int) $c['nb_liv'] === (int) $c['nb'])) {
        return 4;
    }
    if ((int) $c['nb_exp'] > 0 || (int) $c['nb_liv'] > 0) {
        return 3;
    }
    return in_array($c['statut_paiement'], ['paye', 'acompte'], true) ? 2 : 1;
}

/* =====================================================================
   Notifications : pastilles sur les onglets des espaces client, vendeur, administrateur,
   et cloche dans l'en-tête (total de ce qui attend une action). Calculées une fois par page.
   ===================================================================== */

/** Pastille d'onglet (rouge si $urgent). */
function pastille_onglet(int $n, bool $urgent = false): string
{
    return $n > 0 ? ' <b class="pastille-onglet' . ($urgent ? ' en-retard' : '') . '" aria-label="' . $n . ' à traiter">' . ($n > 99 ? '99+' : $n) . '</b>' : '';
}

/** Ce qui attend le client : [onglet => nombre]. */
function notifs_client(int $uid): array
{
    static $cache = [];
    if (isset($cache[$uid])) {
        return $cache[$uid];
    }
    $n = fn (string $sql) => (int) requete($sql, [$uid])->fetchColumn();
    return $cache[$uid] = [
        'commandes' => $n('SELECT COUNT(*) FROM commandes c WHERE c.client_id = ? AND ' . SQL_EN_ATTENTE_PAIEMENT)
                     + $n("SELECT COUNT(DISTINCT c.id) FROM commandes c JOIN commande_boutiques cb ON cb.commande_id = c.id WHERE c.client_id = ? AND cb.statut = 'expediee' AND c.statut <> 'annulee'"),
        'offres'    => $n("SELECT COUNT(*) FROM offres WHERE client_id = ? AND statut IN ('acceptee', 'contre') AND expire_le > NOW()"),
        'mesure'    => $n("SELECT COUNT(*) FROM demandes_mesure WHERE client_id = ? AND statut = 'devis'"),
        'litiges'   => $n("SELECT COUNT(*) FROM litiges WHERE client_id = ? AND statut = 'en_cours' AND repondu_le IS NOT NULL"),
        'aide'      => $n("SELECT COUNT(*) FROM messages_support WHERE user_id = ? AND statut = 'en_cours'"),
    ];
}

/** Ce qui attend le vendeur : [onglet => nombre]. */
function notifs_vendeur(int $boutiqueId): array
{
    static $cache = [];
    if (isset($cache[$boutiqueId])) {
        return $cache[$boutiqueId];
    }
    $n = fn (string $sql) => (int) requete($sql, [$boutiqueId])->fetchColumn();
    return $cache[$boutiqueId] = [
        'commandes' => $n("SELECT COUNT(*) FROM commande_boutiques cb JOIN commandes c ON c.id = cb.commande_id WHERE cb.boutique_id = ? AND cb.statut = 'a_preparer' AND c.statut <> 'annulee' AND " . SQL_ENGAGEE)
                     + $n("SELECT COUNT(*) FROM commande_boutiques cb JOIN commandes c ON c.id = cb.commande_id WHERE cb.boutique_id = ? AND cb.statut = 'expediee' AND c.statut <> 'annulee' AND cb.livre_par = 'vendeur' AND cb.livreur_id IS NULL"),
        'offres'    => $n("SELECT COUNT(*) FROM offres WHERE boutique_id = ? AND statut = 'en_attente' AND expire_le > NOW()"),
        'mesure'    => $n("SELECT COUNT(*) FROM demandes_mesure d JOIN boutiques b ON b.id = d.boutique_id WHERE d.boutique_id = ? AND b.sur_mesure = 1 AND d.statut = 'envoyee'"),
        'produits'  => $n("SELECT COUNT(*) FROM produits WHERE boutique_id = ? AND statut = 'publie' AND reserve_client_id IS NULL AND stock <= 5"),
    ];
}

/** Ce qui attend l'administrateur : [onglet => nombre] (+ 'litiges_retard' pour la couleur). */
function notifs_admin(): array
{
    static $cache = null;
    if ($cache !== null) {
        return $cache;
    }
    $n = fn (string $sql) => (int) requete($sql)->fetchColumn();
    return $cache = [
        'boutiques' => $n("SELECT COUNT(*) FROM boutiques WHERE statut = 'en_attente'"),
        'commandes' => $n("SELECT COUNT(*) FROM commandes WHERE statut = 'annulee' AND statut_paiement = 'paye'")
                     + (paydunya_actif() ? $n("SELECT COUNT(DISTINCT commande_id) FROM paiements WHERE fournisseur = 'paydunya' AND statut = 'initie' AND reference_externe IS NOT NULL AND created_at > (NOW() - INTERVAL 3 DAY)") : 0),
        'retraits'  => $n("SELECT COUNT(*) FROM retraits WHERE statut = 'demande'"),
        'courses'   => livreurs_jend_actifs() ? $n("SELECT COUNT(*) FROM commande_boutiques cb JOIN commandes c ON c.id = cb.commande_id WHERE cb.livre_par = 'jend' AND cb.statut IN ('a_preparer', 'expediee') AND cb.livreur_id IS NULL AND c.statut <> 'annulee' AND " . SQL_ENGAGEE) : 0,
        'litiges'   => $n("SELECT COUNT(*) FROM litiges WHERE statut IN ('ouvert', 'en_cours')"),
        'litiges_retard' => $n("SELECT COUNT(*) FROM litiges WHERE statut IN ('ouvert', 'en_cours') AND repondu_le IS NULL AND created_at < (NOW() - INTERVAL " . LITIGE_DELAI_REPONSE_HEURES . " HOUR)"),
        'messages'  => support_a_traiter(),
        'relances'  => function_exists('relances_a_faire') ? relances_a_faire() : 0,
        'commissions' => function_exists('vendeurs_endettes_nombre') ? vendeurs_endettes_nombre() : 0,
    ];
}

/** Total pour la cloche de l'en-tête, selon le rôle (un vendeur ou un admin a aussi ses alertes de client). Retourne [total, lien]. */
function notifs_total(array $u): array
{
    $total = array_sum(notifs_client((int) $u['id']));
    if ($u['role'] === 'admin') {
        $a = notifs_admin();
        unset($a['litiges_retard']);
        $total += array_sum($a);
    }
    $b = requete('SELECT id FROM boutiques WHERE user_id = ?', [$u['id']])->fetch();
    if ($b) {
        $total += array_sum(notifs_vendeur((int) $b['id']));
    }
    return [$total, espace_du_role((string) $u['role'])];
}
