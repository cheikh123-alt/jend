<?php
declare(strict_types=1);

/**
 * « Faire une offre » (waxale) : le client propose un prix pour un produit ; le vendeur accepte, refuse ou contre-propose.
 * Une offre acceptée donne à CE client le prix convenu, pour la quantité convenue, pendant OFFRE_VALIDITE_ACHAT_HEURES.
 * Le prix convenu n'est jamais lu dans le navigateur : il est relu en base au moment du panier et de la commande.
 */

const OFFRE_MIN_POURCENT = 50;                 // on ne peut pas proposer moins de la moitié du prix affiché
const OFFRE_REPONSE_HEURES = 72;               // sans réponse du vendeur, l'offre tombe
const OFFRE_VALIDITE_ACHAT_HEURES = 48;        // après accord, le client a 48 h pour acheter à ce prix
const OFFRES_PAR_JOUR = 8;                     // par client (évite le harcèlement des vendeurs)

const STATUTS_OFFRE = [
    'en_attente' => 'En attente du vendeur',
    'contre'     => 'Contre-proposition',
    'acceptee'   => 'Acceptée',
    'refusee'    => 'Refusée',
    'utilisee'   => 'Utilisée',
    'annulee'    => 'Annulée',
];

/** Prix plancher d'une offre pour un produit. */
function offre_prix_minimum(int $prix): int
{
    return (int) ceil($prix * OFFRE_MIN_POURCENT / 100);
}

/** Libellé d'une offre en tenant compte de l'expiration. */
function offre_libelle(array $o): string
{
    if (in_array($o['statut'], ['en_attente', 'contre', 'acceptee'], true) && strtotime((string) $o['expire_le']) < time()) {
        return 'Expirée';
    }
    return STATUTS_OFFRE[$o['statut']] ?? $o['statut'];
}

function offre_expiree(array $o): bool
{
    return strtotime((string) $o['expire_le']) < time();
}

/**
 * Le client propose un prix. @throws RuntimeException message affichable
 */
function offre_creer(int $clientId, int $produitId, int $prix, int $quantite): int
{
    $p = requete(
        "SELECT p.id, p.nom, p.prix, p.stock, p.boutique_id, " . SQL_PROMO_FETE . " AS promo_pct, b.user_id AS vendeur_id, b.offres_actives, b.nom AS boutique, u.email AS vendeur_email
           FROM produits p JOIN boutiques b ON b.id = p.boutique_id AND b.statut = 'active' JOIN users u ON u.id = b.user_id
          WHERE p.id = ? AND p.statut = 'publie' AND p.reserve_client_id IS NULL",
        [$produitId]
    )->fetch();
    if (!$p || (int) $p['stock'] < 1) {
        throw new RuntimeException('Ce produit n\'est plus disponible.');
    }
    if ((int) $p['promo_pct'] > 0) {
        throw new RuntimeException('Ce produit est déjà en promotion pour la fête : profitez du prix affiché.');
    }
    if ((int) $p['offres_actives'] !== 1) {
        throw new RuntimeException('Cette boutique n\'accepte pas les propositions de prix.');
    }
    if ((int) $p['vendeur_id'] === $clientId) {
        throw new RuntimeException('Vous ne pouvez pas faire une offre sur votre propre produit.');
    }
    $quantite = max(1, min(10, $quantite, (int) $p['stock']));
    $min = offre_prix_minimum((int) $p['prix']);
    if ($prix < $min || $prix >= (int) $p['prix']) {
        throw new RuntimeException('Proposez un prix entre ' . fcfa($min) . ' et ' . fcfa((int) $p['prix'] - 1) . '.');
    }
    if (requete("SELECT 1 FROM offres WHERE client_id = ? AND produit_id = ? AND statut IN ('en_attente', 'contre', 'acceptee') AND expire_le > NOW()", [$clientId, $produitId])->fetch()) {
        throw new RuntimeException('Vous avez déjà une offre en cours sur ce produit : suivez-la dans « Mes offres ».');
    }
    if (limite_atteinte('offre:client:' . $clientId, OFFRES_PAR_JOUR, 86400)) {
        throw new RuntimeException('Vous avez fait beaucoup d\'offres aujourd\'hui. Réessayez demain.');
    }
    limite_enregistrer('offre:client:' . $clientId);
    requete(
        'INSERT INTO offres (produit_id, boutique_id, client_id, quantite, prix_initial, prix_propose, expire_le) VALUES (?, ?, ?, ?, ?, ?, DATE_ADD(NOW(), INTERVAL ' . OFFRE_REPONSE_HEURES . ' HOUR))',
        [$produitId, $p['boutique_id'], $clientId, $quantite, $p['prix'], $prix]
    );
    $id = (int) pdo()->lastInsertId();
    try {
        envoyer_email((string) $p['vendeur_email'], 'Nouvelle offre sur « ' . $p['nom'] . ' »',
            "Un client propose " . fcfa($prix) . " (au lieu de " . fcfa((int) $p['prix']) . ") pour « {$p['nom']} », quantité : $quantite.\n\n"
            . "Répondez sous " . OFFRE_REPONSE_HEURES . " heures (accepter, refuser ou contre-proposer) :\n" . app_url('vendeur/offres'));
    } catch (Throwable $e) {
        error_log('Jënd — e-mail offre : ' . $e->getMessage());
    }
    return $id;
}

/**
 * Réponse du vendeur : accepter | refuser | contre (avec un prix). @throws RuntimeException message affichable
 */
function offre_repondre_vendeur(int $offreId, int $boutiqueId, string $action, int $contre = 0): void
{
    $o = requete(
        'SELECT o.*, p.nom AS produit, p.prix AS prix_actuel, u.email AS client_email FROM offres o JOIN produits p ON p.id = o.produit_id JOIN users u ON u.id = o.client_id
          WHERE o.id = ? AND o.boutique_id = ?',
        [$offreId, $boutiqueId]
    )->fetch();
    if (!$o) {
        throw new RuntimeException('Offre introuvable.');
    }
    if ($o['statut'] !== 'en_attente' || offre_expiree($o)) {
        throw new RuntimeException('Cette offre n\'attend plus de réponse.');
    }
    $delai = 'DATE_ADD(NOW(), INTERVAL ' . OFFRE_VALIDITE_ACHAT_HEURES . ' HOUR)';
    if ($action === 'accepter') {
        $n = requete("UPDATE offres SET statut = 'acceptee', prix_final = prix_propose, expire_le = $delai WHERE id = ? AND statut = 'en_attente'", [$offreId])->rowCount();
        $msg = "Bonne nouvelle : le vendeur accepte votre prix de " . fcfa((int) $o['prix_propose']) . " pour « {$o['produit']} ».\nVous avez " . OFFRE_VALIDITE_ACHAT_HEURES . " heures pour l'acheter à ce prix :\n" . app_url('offres');
    } elseif ($action === 'refuser') {
        $n = requete("UPDATE offres SET statut = 'refusee' WHERE id = ? AND statut = 'en_attente'", [$offreId])->rowCount();
        $msg = "Le vendeur n'a pas retenu votre offre pour « {$o['produit']} ». Vous pouvez l'acheter au prix affiché ou proposer un autre prix :\n" . app_url('offres');
    } elseif ($action === 'contre') {
        if ($contre <= (int) $o['prix_propose'] || $contre > (int) $o['prix_actuel']) {
            throw new RuntimeException('Votre contre-proposition doit être supérieure à l\'offre du client (' . fcfa((int) $o['prix_propose']) . ') et ne pas dépasser le prix affiché (' . fcfa((int) $o['prix_actuel']) . ').');
        }
        $n = requete("UPDATE offres SET statut = 'contre', contre_prix = ?, expire_le = $delai WHERE id = ? AND statut = 'en_attente'", [$contre, $offreId])->rowCount();
        $msg = "Le vendeur vous propose " . fcfa($contre) . " pour « {$o['produit']} » (votre offre : " . fcfa((int) $o['prix_propose']) . ").\nAcceptez ou refusez sous " . OFFRE_VALIDITE_ACHAT_HEURES . " heures :\n" . app_url('offres');
    } else {
        throw new RuntimeException('Action inconnue.');
    }
    if ($n !== 1) {
        throw new RuntimeException('Cette offre vient d\'être traitée.');
    }
    try {
        envoyer_email((string) $o['client_email'], 'Votre offre sur « ' . $o['produit'] . ' »', $msg);
    } catch (Throwable $e) {
        error_log('Jënd — e-mail offre : ' . $e->getMessage());
    }
}

/**
 * Réponse du client à une contre-proposition (accepter | refuser), ou annulation de son offre en attente (annuler).
 * @throws RuntimeException message affichable
 */
function offre_repondre_client(int $offreId, int $clientId, string $action): void
{
    $o = requete('SELECT * FROM offres WHERE id = ? AND client_id = ?', [$offreId, $clientId])->fetch();
    if (!$o) {
        throw new RuntimeException('Offre introuvable.');
    }
    if ($action === 'annuler') {
        if (!in_array($o['statut'], ['en_attente', 'contre', 'acceptee'], true)) {
            throw new RuntimeException('Cette offre ne peut plus être annulée.');
        }
        requete("UPDATE offres SET statut = 'annulee' WHERE id = ?", [$offreId]);
        return;
    }
    if ($o['statut'] !== 'contre' || offre_expiree($o)) {
        throw new RuntimeException('Cette contre-proposition n\'est plus valable.');
    }
    if ($action === 'accepter') {
        requete("UPDATE offres SET statut = 'acceptee', prix_final = contre_prix, expire_le = DATE_ADD(NOW(), INTERVAL " . OFFRE_VALIDITE_ACHAT_HEURES . " HOUR) WHERE id = ? AND statut = 'contre'", [$offreId]);
    } elseif ($action === 'refuser') {
        requete("UPDATE offres SET statut = 'refusee' WHERE id = ? AND statut = 'contre'", [$offreId]);
    } else {
        throw new RuntimeException('Action inconnue.');
    }
}

/**
 * Offres acceptées et encore valables d'un client : [produit_id => ['id', 'prix', 'quantite']].
 * C'est la seule source du prix négocié (panier et commande).
 */
function offres_valides(int $clientId): array
{
    $res = [];
    foreach (requete(
        "SELECT o.id, o.produit_id, o.prix_final, o.quantite FROM offres o JOIN produits p ON p.id = o.produit_id
          WHERE o.client_id = ? AND o.statut = 'acceptee' AND o.expire_le > NOW() AND o.prix_final IS NOT NULL AND o.prix_final < p.prix
          ORDER BY o.id",
        [$clientId]
    )->fetchAll() as $o) {
        $res[(int) $o['produit_id']] = ['id' => (int) $o['id'], 'prix' => (int) $o['prix_final'], 'quantite' => (int) $o['quantite']];
    }
    return $res;
}

/** Prix unitaire à appliquer : le prix négocié si le client a une offre acceptée et ne dépasse pas la quantité convenue, sinon le prix affiché. */
function offre_prix_applique(array $offres, int $produitId, int $quantite, int $prixAffiche): int
{
    $o = $offres[$produitId] ?? null;
    return ($o && $quantite <= $o['quantite']) ? $o['prix'] : $prixAffiche;
}

/** Nombre d'offres qui attendent la réponse du vendeur. */
function offres_a_traiter(int $boutiqueId): int
{
    return (int) requete("SELECT COUNT(*) FROM offres WHERE boutique_id = ? AND statut = 'en_attente' AND expire_le > NOW()", [$boutiqueId])->fetchColumn();
}
