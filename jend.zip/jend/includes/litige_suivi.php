<?php
/**
 * Suivi d'un signalement, identique pour le client et pour l'équipe : étapes du dossier, engagement de réponse et chronologie.
 * Variables : $lit (ligne litiges), $evenements (litige_evenements), $vueEquipe (bool), $nomClient (facultatif),
 *             $partie : 'avancement', 'chronologie' ou null (les deux).
 */
$nomClient = $nomClient ?? 'Client';
$partie = $partie ?? null;
$engagement = litige_engagement($lit);
?>
<?php if ($partie !== 'chronologie'): ?>
<section class="lit-avancement" aria-label="Avancement du dossier">
  <ol class="lit-etapes">
    <?php foreach (litige_etapes($lit) as $i => [$libelle, $quand, $etat, $icone]): ?>
      <li class="lit-etape lit-etape-<?= e($etat) ?>"<?= $etat === 'courant' ? ' aria-current="step"' : '' ?>>
        <span class="lit-etape-rond"><i class="ph <?= e($etat === 'fait' ? 'ph-check' : $icone) ?>" aria-hidden="true"></i></span>
        <span class="lit-etape-texte"><b><?= e($libelle) ?></b>
          <small><?= $quand ? e(date('d/m/Y · H:i', strtotime($quand))) : ($etat === 'courant' ? 'En cours' : 'À venir') ?></small></span>
      </li>
    <?php endforeach; ?>
  </ol>
  <div class="lit-engagement lit-engagement-<?= e($engagement['etat']) ?>">
    <i class="ph <?= e(['respecte' => 'ph-seal-check', 'depasse' => 'ph-clock-countdown', 'en_cours' => 'ph-timer', 'retard' => 'ph-warning-circle'][$engagement['etat']]) ?>" aria-hidden="true"></i>
    <div>
      <b>Engagement de réponse sous <?= LITIGE_DELAI_REPONSE_HEURES ?> h</b>
      <span><?= e($engagement['texte']) ?></span>
      <?php if ($engagement['etat'] === 'en_cours'): ?>
        <progress class="lit-jauge" max="100" value="<?= (int) $engagement['pourcent'] ?>" aria-label="Temps écoulé sur le délai promis"><?= (int) $engagement['pourcent'] ?> %</progress>
      <?php endif; ?>
    </div>
  </div>
</section>
<?php endif; ?>
<?php if ($partie !== 'avancement'): ?>
<section class="lit-chrono-bloc" aria-labelledby="titre-chrono">
  <h2 class="sous-titre" id="titre-chrono">Historique du dossier</h2>
  <ol class="lit-chrono">
    <?php foreach (array_reverse($evenements) as $ev):
      [$libelle, $icone] = EVENEMENTS_LITIGE[$ev['type']] ?? ['Mise à jour', 'ph-info'];
      $equipe = $ev['auteur'] === 'equipe';
      $qui = $equipe ? 'Équipe Jënd' : ($ev['auteur'] === 'client' ? ($vueEquipe ? $nomClient : 'Vous') : 'Jënd');
      $ton = in_array($ev['type'], ['rembourse', 'remplace', 'argent_envoye'], true) ? 'positif' : ($ev['type'] === 'rejete' ? 'negatif' : ($equipe ? 'equipe' : 'client')); ?>
      <li class="lit-evt lit-evt-<?= e($ton) ?>">
        <span class="lit-evt-icone"><i class="ph <?= e($icone) ?>" aria-hidden="true"></i></span>
        <div class="lit-evt-corps">
          <p class="lit-evt-titre"><b><?= e($libelle) ?></b>
            <time datetime="<?= e(date('c', strtotime($ev['created_at']))) ?>"><?= e(date('d/m/Y à H:i', strtotime($ev['created_at']))) ?></time></p>
          <small class="lit-evt-auteur"><?= e($qui) ?></small>
          <?php if ($ev['montant']): ?><p class="lit-evt-montant"><?= e(fcfa((int) $ev['montant'])) ?></p><?php endif; ?>
          <?php if ($ev['texte'] !== null && $ev['texte'] !== ''): ?><div class="lit-evt-texte"><?= nl2br(e($ev['texte'])) ?></div><?php endif; ?>
        </div>
      </li>
    <?php endforeach; ?>
  </ol>
</section>
<?php endif; ?>
