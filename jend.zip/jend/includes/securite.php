<?php
declare(strict_types=1);

/** La requête est-elle arrivée en HTTPS ? (derrière un proxy de confiance : en-tête X-Forwarded-Proto) */
function est_https(): bool
{
    if (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') {
        return true;
    }
    return env('TRUSTED_PROXY') === '1' && strtolower((string) ($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '')) === 'https';
}

/**
 * Adresse IP du visiteur.
 * On ne croit X-Forwarded-For QUE si TRUSTED_PROXY=1 (sinon n'importe qui pourrait se fabriquer une IP et
 * contourner les limites). Derrière un proxy de confiance, la dernière valeur est celle ajoutée par ce proxy.
 */
function ip_client(): string
{
    $ip = (string) ($_SERVER['REMOTE_ADDR'] ?? '0.0.0.0');
    if (env('TRUSTED_PROXY') === '1' && !empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        $liste = array_map('trim', explode(',', (string) $_SERVER['HTTP_X_FORWARDED_FOR']));
        $candidate = end($liste);
        if (filter_var($candidate, FILTER_VALIDATE_IP)) {
            $ip = $candidate;
        }
    }
    return substr($ip, 0, 45);
}

/* ---------- Limitation des tentatives (anti force-brute, anti-spam) ---------- */

/** Empreinte d'une adresse e-mail pour les clés de limite (on ne stocke pas l'adresse en clair). */
function cle_email(string $email): string
{
    return substr(sha1(mb_strtolower(trim($email))), 0, 20);
}

/** Y a-t-il déjà $max événements « $cle » pendant les $fenetre dernières secondes ? */
function limite_atteinte(string $cle, int $max, int $fenetre): bool
{
    $n = (int) requete(
        'SELECT COUNT(*) FROM limites WHERE cle = ? AND created_at > DATE_SUB(NOW(), INTERVAL ? SECOND)',
        [substr($cle, 0, 120), $fenetre]
    )->fetchColumn();
    return $n >= $max;
}

function limite_enregistrer(string $cle): void
{
    requete('INSERT INTO limites (cle) VALUES (?)', [substr($cle, 0, 120)]);
    if (random_int(1, 100) === 1) {                     // ménage : on garde 1 jour d'historique
        requete('DELETE FROM limites WHERE created_at < DATE_SUB(NOW(), INTERVAL 1 DAY)');
    }
}

function limite_effacer(string $cle): void
{
    requete('DELETE FROM limites WHERE cle = ?', [substr($cle, 0, 120)]);
}

/* ---------- Journal des actions de l'administrateur ---------- */

function journaliser(string $action, string $detail = ''): void
{
    $u = utilisateur();
    requete(
        'INSERT INTO journal_admin (admin_id, action, detail, ip) VALUES (?, ?, ?, ?)',
        [$u['id'] ?? null, mb_substr($action, 0, 60), mb_substr($detail, 0, 255), ip_client()]
    );
}

/* ---------- En-têtes de sécurité ---------- */

/**
 * Politique de sécurité de contenu (CSP) : le navigateur refuse tout script, style, police ou formulaire
 * qui ne vient pas de CE site. Plus aucun service externe (CDN) : les bibliothèques sont dans assets/vendor/.
 * CSP_FORM_ACTION (.env) : domaines supplémentaires où un formulaire peut envoyer le client
 * (ex : la page de paiement d'un agrégateur, quand on quittera la simulation).
 */
function csp_politique(): string
{
    $formulaires = trim("'self' " . trim((string) env('CSP_FORM_ACTION', '')));
    if (function_exists('paydunya_actif') && paydunya_actif()) {
        $formulaires .= ' https://app.paydunya.com https://paydunya.com';          // redirection du client vers la page de paiement PayDunya
    }
    if (function_exists('paytech_actif') && paytech_actif()) {
        $formulaires .= ' https://paytech.sn';                                      // page de paiement PayTech
    }
    return implode('; ', [
        "default-src 'self'",
        "script-src 'self'",
        "style-src 'self'",
        "font-src 'self'",
        "img-src 'self' blob:",                                 // blob: aperçu des images de statut dessinées dans le navigateur
        "connect-src 'self'",
        "object-src 'none'",
        "base-uri 'self'",
        "form-action $formulaires",
        "frame-ancestors 'self'",
    ]);
}

function envoyer_entetes_securite(bool $prod): void
{
    header_remove('X-Powered-By');                 // ne pas annoncer la version de PHP
    header('X-Content-Type-Options: nosniff');
    header('X-Frame-Options: SAMEORIGIN');
    header('Referrer-Policy: strict-origin-when-cross-origin');
    header('Permissions-Policy: camera=(), microphone=(self), geolocation=(self), payment=(), usb=()');      // position de livraison et description vocale : ce site seulement
    header('Cross-Origin-Opener-Policy: same-origin');
    header('Content-Security-Policy: ' . csp_politique());
    if (est_test()) {
        header('X-Robots-Tag: noindex, nofollow');       // un site de test ne doit jamais apparaître dans Google
    }
    if ($prod && est_https()) {
        header('Strict-Transport-Security: max-age=31536000; includeSubDomains');
    }
}

/* ---------- Page d'erreur (sans dépendance : fonctionne même si la base est en panne) ---------- */

function page_erreur(int $code, string $titre, string $message): void
{
    if (!headers_sent()) {
        http_response_code($code);
        header('Content-Type: text/html; charset=UTF-8');
    }
    echo '<!DOCTYPE html><html lang="fr"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1">'
       . '<title>' . htmlspecialchars($titre) . ' — Jënd</title>'
       . '<style>body{margin:0;min-height:100vh;display:grid;place-items:center;background:#FAF3E7;color:#1B1410;font-family:system-ui,sans-serif;text-align:center;padding:1rem}'
       . 'h1{font-size:2.4rem;margin:.2em 0;color:#C2471F}p{color:#6B5E52;max-width:34ch;margin:0 auto 1.4rem}a{color:#fff;background:#C2471F;padding:.8rem 1.4rem;border-radius:99px;text-decoration:none;font-weight:700}</style></head>'
       . '<body><main><h1>' . htmlspecialchars($titre) . '</h1><p>' . htmlspecialchars($message) . '</p><a href="/">Retour à l\'accueil</a></main></body></html>';
}

/* ---------- Réglages de seuils (modifiables dans .env) ---------- */

function limite_param(string $cle, int $defaut): int
{
    $v = (int) env($cle);
    return $v > 0 ? $v : $defaut;
}

/** L'adresse IP est-elle dans la liste (« 1.2.3.4, 10.0.0.0/8 ») ? Liste vide = personne n'est exclu. */
function ip_dans_liste(string $ip, ?string $liste): bool
{
    $liste = trim((string) $liste);
    if ($liste === '') {
        return true;
    }
    foreach (preg_split('/[\s,;]+/', $liste, -1, PREG_SPLIT_NO_EMPTY) as $entree) {
        if (strpos($entree, '/') === false) {
            if ($entree === $ip) {
                return true;
            }
            continue;
        }
        [$reseau, $bits] = explode('/', $entree, 2);
        $a = @inet_pton($ip);
        $b = @inet_pton($reseau);
        $n = (int) $bits;
        if ($a === false || $b === false || strlen($a) !== strlen($b) || $n < 0 || $n > strlen($a) * 8) {
            continue;
        }
        $octets = intdiv($n, 8);
        $reste = $n % 8;
        if (substr($a, 0, $octets) !== substr($b, 0, $octets)) {
            continue;
        }
        if ($reste === 0 || ((ord($a[$octets]) ^ ord($b[$octets])) >> (8 - $reste)) === 0) {
            return true;
        }
    }
    return false;
}

/* ---------- Alertes par e-mail à l'administrateur ---------- */

/**
 * Prévient l'administrateur (ALERT_EMAIL, sinon ADMIN_EMAIL) d'un événement grave.
 * Anti-déluge : au plus UN e-mail par « type » et par heure. Ne lève jamais d'erreur (utilisable même quand la base est en panne).
 */
function alerter(string $type, string $sujet, string $detail = ''): void
{
    try {
        $fichier = dirname(__DIR__) . '/storage/alerte-' . sha1($type) . '.txt';
        if (is_file($fichier) && time() - (int) filemtime($fichier) < 3600) {
            return;
        }
        @file_put_contents($fichier, $type);
        $dest = (string) (env('ALERT_EMAIL') ?: env('ADMIN_EMAIL'));
        if ($dest === '') {
            return;
        }
        envoyer_email($dest, '[Jënd] ' . $sujet, $detail . "\n\nDate : " . date('c') . "\nSite : " . app_domaine());
    } catch (Throwable $e) {
        error_log('Jënd — alerte non envoyée : ' . $e->getMessage());
    }
}
