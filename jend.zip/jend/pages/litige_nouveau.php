<?php
/** « Signaler un problème » sur une livraison. $parametre = identifiant de la livraison (commande_boutiques.id). */
$u = exiger_connexion();
$l = litige_livraison((int) $parametre);
if (!$l || (int) $l['client_id'] !== (int) $u['id']) {          // on ne signale que SES livraisons
    http_response_code(404);
    require __DIR__ . '/404.php';
    return;
}
$deja = requete('SELECT reference FROM litiges WHERE commande_boutique_id = ?', [$l['id']])->fetchColumn();
if ($deja) {
    rediriger('litige/' . $deja);
}
$raison = litige_impossible($l);
$erreurs = [];
$v = ['motif' => '', 'description' => ''];
if (!$raison && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $v['motif'] = (string) ($_POST['motif'] ?? '');
    $v['description'] = (string) ($_POST['description'] ?? '');
    if (!csrf_valide($_POST['csrf'] ?? null)) {
        $erreurs[] = 'Session expirée, merci de réessayer.';
    } else {
        try {
            $ref = litige_creer((int) $l['id'], (int) $u['id'], $v['motif'], $v['description'], fichiers_envoyes('photos'));
            flash('Signalement envoyé. Nous vous répondons avant le ' . litige_echeance(['created_at' => date('Y-m-d H:i:s')]) . '.');
            rediriger('litige/' . $ref);
        } catch (RuntimeException $e) {
            $erreurs[] = $e->getMessage();
        }
    }
}
$titre = 'Signaler un problème — Jënd';
require __DIR__ . '/../includes/header.php';
?>
<main class="page">
  <div class="wrap wrap-moyen">
    <nav class="fil" aria-label="Fil d'Ariane"><a href="<?= e(url('compte')) ?>">Mon compte</a> / <a href="<?= e(url('commande/' . $l['commande_ref'])) ?>"><?= e($l['commande_ref']) ?></a> / <span>Signaler un problème</span></nav>
    <h1 class="titre-page">Signaler un problème</h1>
    <p class="doux">Livraison de <b><?= e($l['boutique']) ?></b> · commande <?= e($l['commande_ref']) ?></p>
    <?php if ($raison): ?>
      <p class="alerte alerte-info"><i class="ph ph-info"></i> <?= e($raison) ?></p>
    <?php else: ?>
      <p class="alerte alerte-info"><i class="ph ph-clock"></i> <span>Notre équipe vous répond <b>sous <?= LITIGE_DELAI_REPONSE_HEURES ?> h</b>. L'argent reste protégé pendant l'examen de votre demande.</span></p>
      <form method="post" enctype="multipart/form-data" class="formulaire formulaire-large" novalidate>
        <?= csrf_champ() ?>
        <?php foreach ($erreurs as $er): ?><p class="alerte" role="alert"><?= e($er) ?></p><?php endforeach; ?>
        <label class="champ"><span>Que s'est-il passé ?</span>
          <select name="motif" required>
            <option value="">— Choisissez —</option>
            <?php foreach (MOTIFS_LITIGE as $cle => $libelle): ?><option value="<?= e($cle) ?>" <?= $v['motif'] === $cle ? 'selected' : '' ?>><?= e($libelle) ?></option><?php endforeach; ?>
          </select></label>
        <label class="champ"><span>Décrivez le problème (20 caractères minimum)</span>
          <textarea name="description" rows="5" maxlength="2000" required><?= e($v['description']) ?></textarea></label>
        <label class="champ"><span>Photos (jusqu'à <?= LITIGE_MAX_PHOTOS ?>, JPEG ou PNG) — obligatoires si le produit est abîmé, défectueux ou différent</span>
          <input type="file" name="photos[]" accept="image/jpeg,image/png" multiple></label>
        <button class="btn btn-primaire" type="submit">Envoyer mon signalement</button>
      </form>
    <?php endif; ?>
  </div>
</main>
<?php require __DIR__ . '/../includes/footer.php'; ?>
