<?php
/** $parametre = jeton reçu par e-mail. */
$titre = 'Nouveau mot de passe — Jënd';
$hash = hash('sha256', $parametre);
$demande = requete('SELECT id, user_id FROM reinitialisations_mdp WHERE token_hash = ? AND expire_le > NOW()', [$hash])->fetch();
$erreurs = [];

if ($demande && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $mdp = (string) ($_POST['mot_de_passe'] ?? '');
    if (!csrf_valide($_POST['csrf'] ?? null)) {
        $erreurs[] = 'Session expirée, merci de réessayer.';
    }
    if ($demande && ($msg = mot_de_passe_faible($mdp, (string) requete('SELECT email FROM users WHERE id = ?', [$demande['user_id']])->fetchColumn()))) {
        $erreurs[] = $msg;
    }
    if ($mdp !== (string) ($_POST['mot_de_passe2'] ?? '')) {
        $erreurs[] = 'Les deux mots de passe ne correspondent pas.';
    }
    if (!$erreurs) {
        requete('UPDATE users SET mot_de_passe = ?, mdp_provisoire = 0, email_verifie = 1 WHERE id = ?', [password_hash($mdp, PASSWORD_DEFAULT), $demande['user_id']]);
        requete('DELETE FROM reinitialisations_mdp WHERE user_id = ?', [$demande['user_id']]);
        invalider_sessions((int) $demande['user_id']);   // toute session volée avant la réinitialisation est coupée   // le lien ne sert qu'une fois
        flash('Mot de passe modifié. Vous pouvez vous connecter.');
        rediriger('connexion');
    }
}
require __DIR__ . '/../includes/header.php';
?>
<main class="page">
  <div class="wrap wrap-etroit">
    <h1 class="titre-page">Nouveau mot de passe</h1>
    <?php if (!$demande): ?>
      <p class="alerte" role="alert">Ce lien est invalide ou a expiré.</p>
      <a class="btn btn-primaire" href="<?= e(url('mot-de-passe-oublie')) ?>">Demander un nouveau lien</a>
    <?php else: ?>
      <form method="post" class="formulaire" novalidate>
        <?= csrf_champ() ?>
        <?php foreach ($erreurs as $er): ?><p class="alerte" role="alert"><?= e($er) ?></p><?php endforeach; ?>
        <label class="champ"><span>Nouveau mot de passe (8 caractères minimum)</span><input type="password" name="mot_de_passe" autocomplete="new-password" required autofocus></label>
        <label class="champ"><span>Confirmer</span><input type="password" name="mot_de_passe2" autocomplete="new-password" required></label>
        <button class="btn btn-primaire" type="submit">Enregistrer</button>
      </form>
    <?php endif; ?>
  </div>
</main>
<?php require __DIR__ . '/../includes/footer.php'; ?>
