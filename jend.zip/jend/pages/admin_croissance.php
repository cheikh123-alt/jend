<?php
/**
 * Tableau de bord « Croissance » : les chiffres à suivre chaque semaine (vendeurs, commandes, volume, fidélité, satisfaction)
 * et les canaux qui amènent vraiment des clients (WhatsApp, TikTok, affiche QR, lien de paiement…).
 */
exiger_admin();
$n = fn (string $sql, array $p = []) => (int) requete($sql, $p)->fetchColumn();
$payee = "c.statut_paiement = 'paye' AND c.statut <> 'annulee'";

// 1. Les 30 derniers jours, comparés aux 30 précédents
$periode = function (int $debut, int $fin) use ($n, $payee): array {
    $b = "c.created_at >= NOW() - INTERVAL $debut DAY AND c.created_at < NOW() - INTERVAL $fin DAY";
    return [
        'commandes' => $n("SELECT COUNT(*) FROM commandes c WHERE $payee AND $b"),
        'volume'    => $n("SELECT COALESCE(SUM(c.sous_total), 0) FROM commandes c WHERE $payee AND $b"),
        'clients'   => $n("SELECT COUNT(*) FROM users c WHERE c.role = 'client' AND $b"),
        'vendeurs'  => $n("SELECT COUNT(*) FROM boutiques c WHERE $b"),
    ];
};
$actuel = $periode(30, 0);
$avant = $periode(60, 30);
$evolution = fn (int $a, int $b): string => $b === 0 ? ($a > 0 ? 'nouveau' : '—') : (($a >= $b ? '+' : '') . round(($a - $b) * 100 / $b) . ' %');

// 2. Fidélité et satisfaction (depuis le début)
$acheteurs = $n("SELECT COUNT(DISTINCT c.client_id) FROM commandes c WHERE $payee");
$fideles = $n("SELECT COUNT(*) FROM (SELECT c.client_id FROM commandes c WHERE $payee GROUP BY c.client_id HAVING COUNT(*) >= 2) t");
$livrees = $n("SELECT COUNT(*) FROM commande_boutiques WHERE statut = 'livree'");
$problemes = $n("SELECT COUNT(*) FROM litiges WHERE statut IN ('rembourse', 'remplace')");
$boutiquesActives = $n("SELECT COUNT(*) FROM boutiques WHERE statut = 'active'");
$boutiquesPretes = $n("SELECT COUNT(*) FROM (SELECT p.boutique_id FROM produits p JOIN boutiques b ON b.id = p.boutique_id AND b.statut = 'active'
                        WHERE p.statut = 'publie' AND EXISTS (SELECT 1 FROM produit_images i WHERE i.produit_id = p.id) GROUP BY p.boutique_id HAVING COUNT(*) >= 5) t");
$sansPhoto = $n("SELECT COUNT(*) FROM produits p WHERE p.statut = 'publie' AND p.reserve_client_id IS NULL AND NOT EXISTS (SELECT 1 FROM produit_images i WHERE i.produit_id = p.id)");

// 3. Les 8 dernières semaines (du lundi au dimanche)
$semaines = [];
$lundi = strtotime('monday this week');
for ($k = 7; $k >= 0; $k--) {
    $d = date('Y-m-d', strtotime("-$k week", $lundi));
    $f = date('Y-m-d', strtotime($d . ' +7 days'));
    $semaines[] = [
        'debut'     => $d,
        'commandes' => $n("SELECT COUNT(*) FROM commandes c WHERE $payee AND c.created_at >= ? AND c.created_at < ?", [$d, $f]),
        'volume'    => $n("SELECT COALESCE(SUM(c.sous_total), 0) FROM commandes c WHERE $payee AND c.created_at >= ? AND c.created_at < ?", [$d, $f]),
        'livrees'   => $n("SELECT COUNT(*) FROM commande_boutiques WHERE statut = 'livree' AND livre_le >= ? AND livre_le < ?", [$d, $f]),
        'actifs'    => $n("SELECT COUNT(DISTINCT boutique_id) FROM commande_boutiques WHERE statut = 'livree' AND livre_le >= ? AND livre_le < ?", [$d, $f]),
        'vendeurs'  => $n("SELECT COUNT(*) FROM boutiques WHERE created_at >= ? AND created_at < ?", [$d, $f]),
        'clients'   => $n("SELECT COUNT(*) FROM users WHERE role = 'client' AND created_at >= ? AND created_at < ?", [$d, $f]),
    ];
}
$maxVolume = max(1, max(array_column($semaines, 'volume')));

// 4. Canaux (30 derniers jours)
$canaux = [];
foreach (requete("SELECT COALESCE(c.source, 'direct') AS s, COUNT(*) AS nb, COALESCE(SUM(c.sous_total), 0) AS volume FROM commandes c
                   WHERE $payee AND c.created_at >= NOW() - INTERVAL 30 DAY GROUP BY s ORDER BY nb DESC")->fetchAll() as $r) {
    $canaux[$r['s']] = ['commandes' => (int) $r['nb'], 'volume' => (int) $r['volume'], 'inscrits' => 0];
}
foreach (requete("SELECT COALESCE(source, 'direct') AS s, COUNT(*) AS nb FROM users WHERE created_at >= NOW() - INTERVAL 30 DAY AND role IN ('client', 'vendeur') GROUP BY s")->fetchAll() as $r) {
    $canaux[$r['s']] = ($canaux[$r['s']] ?? ['commandes' => 0, 'volume' => 0]) + ['inscrits' => 0];
    $canaux[$r['s']]['inscrits'] = (int) $r['nb'];
}
uasort($canaux, fn ($a, $b) => [$b['commandes'], $b['inscrits']] <=> [$a['commandes'], $a['inscrits']]);
$maxCanal = max([1, ...array_values(array_map(fn ($c) => $c['commandes'], $canaux))]);

$titre = 'Croissance — Administration';
require __DIR__ . '/../includes/header.php';
?>
<main class="page">
  <div class="wrap">
    <nav class="fil" aria-label="Fil d'Ariane"><a href="<?= e(url()) ?>">Accueil</a> / <a href="<?= e(url('admin')) ?>">Administration</a> / <span>Croissance</span></nav>
    <h1 class="titre-page">Administration</h1>
    <?php admin_onglets('croissance'); ?>
    <p class="doux">Les chiffres à regarder chaque semaine. Seules les commandes <b>payées</b> comptent (les commandes jamais payées sont ignorées).</p>

    <h2 class="sous-titre">Les 30 derniers jours</h2>
    <div class="tb-kpis croissance-kpis">
      <?php foreach ([['Commandes payées', $actuel['commandes'], $avant['commandes'], false], ['Volume vendu', $actuel['volume'], $avant['volume'], true],
                      ['Nouveaux clients', $actuel['clients'], $avant['clients'], false], ['Nouvelles boutiques', $actuel['vendeurs'], $avant['vendeurs'], false]] as [$lib, $a, $p, $argent]): ?>
        <div class="croissance-kpi"><span><?= e($lib) ?></span><b><?= $argent ? e(fcfa($a)) : $a ?></b>
          <small class="<?= $a >= $p ? 'hausse' : 'baisse' ?>"><?= e($evolution($a, $p)) ?> par rapport aux 30 jours d'avant</small></div>
      <?php endforeach; ?>
    </div>

    <div class="croissance-deux">
      <section class="croissance-carte">
        <h2><i class="ph ph-heart"></i> Fidélité et satisfaction</h2>
        <dl class="croissance-liste">
          <div><dt>Clients qui ont recommandé</dt><dd><?= $acheteurs ? round($fideles * 100 / $acheteurs) : 0 ?> %<small><?= $fideles ?> sur <?= $acheteurs ?> acheteurs</small></dd></div>
          <div><dt>Livraisons sans problème confirmé</dt><dd><?= $livrees ? max(0, 100 - (int) round($problemes * 100 / $livrees)) : 100 ?> %<small><?= $problemes ?> remboursement(s) ou remplacement(s) sur <?= $livrees ?> livraisons</small></dd></div>
        </dl>
      </section>
      <section class="croissance-carte">
        <h2><i class="ph ph-storefront"></i> Santé du catalogue</h2>
        <dl class="croissance-liste">
          <div><dt>Boutiques actives</dt><dd><?= $boutiquesActives ?></dd></div>
          <div><dt>Boutiques « prêtes » (5 produits avec photo ou plus)</dt><dd><?= $boutiquesPretes ?><small>objectif de lancement : 30 à 50</small></dd></div>
          <div><dt>Produits en vente sans photo</dt><dd class="<?= $sansPhoto ? 'baisse' : '' ?>"><?= $sansPhoto ?><small>un produit sans photo se vend très mal</small></dd></div>
        </dl>
      </section>
    </div>

    <h2 class="sous-titre">D'où viennent les clients (30 derniers jours)</h2>
    <?php if (!$canaux): ?>
      <p class="doux">Pas encore de données. Les liens partagés depuis Jënd (WhatsApp, statut, affiche, lien de paiement, parrainage) sont marqués automatiquement ; pour TikTok, Instagram et Facebook, mettez dans votre bio l'adresse de votre boutique suivie de <code>?src=tiktok</code> (ou instagram, facebook).</p>
    <?php else: ?>
      <div class="croissance-canaux">
        <?php foreach ($canaux as $cle => $c): ?>
          <div class="croissance-canal">
            <span class="croissance-canal-nom"><?= e(SOURCES_MARKETING[$cle] ?? $cle) ?></span>
            <span class="croissance-barre"><span data-largeur="<?= (int) round($c['commandes'] * 100 / $maxCanal) ?>"></span></span>
            <span class="croissance-canal-chiffres"><b><?= $c['commandes'] ?></b> commande(s) · <?= e(fcfa($c['volume'])) ?> · <?= $c['inscrits'] ?> inscrit(s)</span>
          </div>
        <?php endforeach; ?>
      </div>
      <p class="doux petit">« Direct / inconnu » : le client a tapé l'adresse ou ouvert un lien sans marque (souvent WhatsApp, qui n'indique pas d'où l'on vient).</p>
    <?php endif; ?>

    <h2 class="sous-titre">Semaine par semaine</h2>
    <div class="table-defile"><table class="table croissance-table">
      <thead><tr><th>Semaine du</th><th>Commandes payées</th><th>Volume</th><th>Livraisons</th><th>Boutiques qui ont vendu</th><th>Nouvelles boutiques</th><th>Nouveaux clients</th></tr></thead>
      <tbody>
      <?php foreach (array_reverse($semaines) as $s): ?>
        <tr><td><?= e(date('d/m', strtotime($s['debut']))) ?></td><td><b><?= $s['commandes'] ?></b></td>
          <td><span class="croissance-mini"><span data-largeur="<?= (int) round($s['volume'] * 100 / $maxVolume) ?>"></span></span> <?= e(fcfa($s['volume'])) ?></td>
          <td><?= $s['livrees'] ?></td><td><?= $s['actifs'] ?></td><td><?= $s['vendeurs'] ?></td><td><?= $s['clients'] ?></td></tr>
      <?php endforeach; ?>
      </tbody>
    </table></div>
  </div>
</main>
<?php require __DIR__ . '/../includes/footer.php'; ?>
