<?php
/** Active / désactive le mode « économie de données » (cookie d'un an), puis revient à la page d'origine. */
if (!post_verifie('')) {
    rediriger('');
}
$actif = !mode_leger();
setcookie('jend_leger', $actif ? '1' : '0', ['expires' => time() + 365 * 86400, 'path' => '/', 'secure' => !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off', 'httponly' => true, 'samesite' => 'Lax']);
flash($actif ? 'Économie de données activée : pages plus légères, sans animations.' : 'Économie de données désactivée.');
$retour = (string) ($_POST['retour'] ?? '');
$base = rtrim(base_path(), '/') . '/';
// retour uniquement vers une page de ce site (jamais une adresse externe)
if (!preg_match('#^/[^/\\\\]#', $retour) || strpos($retour, $base) !== 0) {
    $retour = $base;
}
header('Location: ' . $retour, true, 303);
exit;
