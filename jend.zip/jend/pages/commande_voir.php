<?php
/** Confirmation / détail d'une commande. $parametre = référence. */
$u = exiger_connexion();
$c = requete('SELECT * FROM commandes WHERE reference = ?', [strtoupper($parametre)])->fetch();

// Un client ne voit que SES commandes (l'admin peut tout voir)
if (!$c || ((int) $c['client_id'] !== (int) $u['id'] && $u['role'] !== 'admin')) {
    http_response_code(404);
    require __DIR__ . '/404.php';
    return;
}

// Le client confirme lui-même qu'il a reçu son colis (livraison assurée par le vendeur)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && (int) $c['client_id'] === (int) $u['id'] && post_verifie('commande/' . $c['reference'])) {
    try {
        livraison_confirmer_par_client((int) ($_POST['id'] ?? 0), (int) $u['id']);
        flash('Merci ! Réception confirmée : le vendeur peut être payé. Un souci avec le colis ? Vous pouvez encore le signaler.');
    } catch (RuntimeException $e) {
        flash($e->getMessage(), 'erreur');
    }
    rediriger('commande/' . $c['reference']);
}

$sousCommandes = requete(
    'SELECT cb.id, cb.statut, cb.numero_suivi, cb.code_livraison, cb.livre_par, cb.livreur_id, cb.affecte_le, cb.recupere_le, cb.en_route_le, cb.livre_le, b.nom AS boutique, b.contact_whatsapp, b.mode_simple, ul.nom AS livreur_nom,
            (SELECT l.reference FROM litiges l WHERE l.commande_boutique_id = cb.id) AS litige_ref,
            (SELECT l.statut FROM litiges l WHERE l.commande_boutique_id = cb.id) AS litige_statut
       FROM commande_boutiques cb JOIN boutiques b ON b.id = cb.boutique_id LEFT JOIN users ul ON ul.id = cb.livreur_id WHERE cb.commande_id = ? ORDER BY b.nom, cb.id',
    [$c['id']]
)->fetchAll();
$annulable = $c['client_id'] == $u['id'] && commande_annulable($c, $sousCommandes);

$lignes = requete(
    'SELECT cl.produit_id, cl.nom, cl.prix_unitaire, cl.quantite, cl.variante_libelle, b.nom AS boutique, cb.statut AS statut_boutique, p.slug
       FROM commande_lignes cl
       JOIN commande_boutiques cb ON cb.id = cl.commande_boutique_id
       JOIN boutiques b ON b.id = cb.boutique_id
       LEFT JOIN produits p ON p.id = cl.produit_id
      WHERE cb.commande_id = ? ORDER BY b.nom, cl.id',
    [$c['id']]
)->fetchAll();

$enLigne = $c['methode_paiement'] !== 'livraison';
$enRoute = (bool) array_filter($sousCommandes, fn ($s) => $s['en_route_le'] !== null && $s['statut'] === 'expediee');
$estProprio = (int) $c['client_id'] === (int) $u['id'];
// Juste après « Confirmer et payer » : le formulaire de paiement s'envoie tout seul (une seule fois ; sans JavaScript, le bouton reste)
$payerAuto = $estProprio && ($_SESSION['payer_auto'] ?? '') === $c['reference'] && commande_payable($c);
unset($_SESSION['payer_auto']);
if ($enRoute) {
    $scripts_extra = ['js/suivi.js'];            // la page se met à jour toute seule pendant que le livreur est en route
}
$titre = 'Commande ' . $c['reference'] . ' — Jënd';
require __DIR__ . '/../includes/header.php';
?>
<main class="page">
  <div class="wrap wrap-moyen">
    <div class="confirmation">
      <i class="ph-fill ph-check-circle"></i>
      <?php if ($c['statut'] === 'annulee'): ?>
        <h1 class="titre-page">Commande annulée</h1>
      <?php else: ?>
        <h1 class="titre-page">Merci pour votre commande !</h1>
      <?php endif; ?>
      <p>Référence : <b><?= e($c['reference']) ?></b></p>
    </div>

    <?php if ($c['statut'] === 'annulee'): ?>
      <p class="alerte alerte-info"><i class="ph ph-info"></i> Cette commande a été annulée. Aucun paiement n'est dû.</p>
    <?php elseif (commande_a_acompte($c) && commande_payable($c)): ?>
      <div class="alerte alerte-info"><i class="ph ph-info"></i> <span><?= $c['statut_paiement'] === 'echoue' ? 'Le dernier paiement a échoué.' : 'Commande enregistrée, <b>en attente de votre acompte</b>.' ?> Réglez <b><?= e(fcfa((int) $c['acompte'])) ?></b> par <?= e(MOYENS_PAIEMENT[$c['acompte_methode']][0]) ?> pour la confirmer. Il reste <b><?= e(fcfa((int) $c['total'] - (int) $c['acompte'])) ?></b> à payer en espèces à la livraison.</span></div>
      <form method="post" action="<?= e(url('paiement/' . $c['reference'])) ?>" class="centre-texte mb1"<?= $payerAuto ? ' data-envoi-auto' : '' ?>><?= csrf_champ() ?><button class="btn btn-primaire" type="submit"><i class="ph ph-credit-card"></i> Payer l'acompte (<?= e(fcfa((int) $c['acompte'])) ?>)</button></form>
    <?php elseif ($c['statut_paiement'] === 'acompte'): ?>
      <p class="alerte alerte-info"><i class="ph ph-check-circle"></i> Acompte de <b><?= e(fcfa((int) $c['acompte'])) ?></b> reçu via <?= e(MOYENS_PAIEMENT[$c['acompte_methode']][0]) ?>. <b>Reste à payer en espèces à la livraison : <?= e(fcfa((int) $c['total'] - (int) $c['acompte'])) ?></b>.</p>
    <?php elseif ($c['statut_paiement'] === 'paye'): ?>
      <p class="alerte alerte-info"><i class="ph ph-check-circle"></i> Paiement de <b><?= e(fcfa((int) $c['total'])) ?></b> reçu<?= commande_a_acompte($c) ? ' (acompte en ligne + espèces à la livraison)' : ' via ' . e(MOYENS_PAIEMENT[$c['methode_paiement']][0]) ?>. Merci !</p>
    <?php elseif ($enLigne && commande_payable($c)): ?>
      <div class="alerte alerte-info"><i class="ph ph-info"></i> <span><?= $c['statut_paiement'] === 'echoue' ? 'Le dernier paiement a échoué.' : 'Commande enregistrée, <b>en attente de paiement</b>.' ?> Réglez <b><?= e(fcfa((int) $c['total'])) ?></b> par <?= e(MOYENS_PAIEMENT[$c['methode_paiement']][0]) ?> pour la confirmer.</span></div>
      <form method="post" action="<?= e(url('paiement/' . $c['reference'])) ?>" class="centre-texte mb1"<?= $payerAuto ? ' data-envoi-auto' : '' ?>><?= csrf_champ() ?><button class="btn btn-primaire" type="submit"><i class="ph ph-credit-card"></i> Payer maintenant</button></form>
    <?php elseif (!paiement_en_ligne_actif() && in_array($c['statut_paiement'], ['en_attente', 'echoue'], true) && commande_methode_en_ligne($c) !== null): ?>
      <p class="alerte alerte-info"><i class="ph ph-info"></i> <span>Le paiement en ligne est <b>momentanément indisponible</b>. Vous pouvez annuler cette commande et la repasser en choisissant le <b>paiement à la livraison</b>, ou nous contacter.</span></p>
    <?php elseif (!$enLigne): ?>
      <p class="alerte alerte-info"><i class="ph ph-info"></i> Vous paierez <b><?= e(fcfa((int) $c['total'])) ?></b> en espèces à la livraison.</p>
    <?php endif; ?>

    <div class="recap recap-pleine">
      <h2>Détail</h2>
      <?php foreach ($lignes as $l): ?>
        <div class="recap-ligne"><span><?= (int) $l['quantite'] ?> × <?= e($l['nom']) ?><?= $l['variante_libelle'] ? ' <span class="variante-choisie">' . e($l['variante_libelle']) . '</span>' : '' ?> <small class="doux">· <?= e($l['boutique']) ?></small>
          <?php if ($l['statut_boutique'] === 'livree' && $l['slug']): ?><a class="lien petit" href="<?= e(url('produit/' . $l['slug'] . '#avis')) ?>">Donner mon avis</a><?php endif; ?></span>
        <b><?= e(fcfa((int) $l['prix_unitaire'] * (int) $l['quantite'])) ?></b></div>
      <?php endforeach; ?>
      <hr>
      <div class="recap-ligne"><span>Sous-total</span><b><?= e(fcfa((int) $c['sous_total'])) ?></b></div>
      <div class="recap-ligne"><span>Livraison</span><b><?= e(fcfa((int) $c['frais_livraison'])) ?></b></div>
      <?php if ((int) $c['frais_service'] > 0): ?><div class="recap-ligne"><span>Paiement sécurisé</span><b><?= e(fcfa((int) $c['frais_service'])) ?></b></div><?php endif; ?>
      <div class="recap-ligne recap-total"><span>Total</span><b><?= e(fcfa((int) $c['total'])) ?></b></div>
    </div>

    <div class="recap recap-pleine"<?= $enRoute ? ' data-rafraichir="45"' : '' ?>>
      <h2>Suivi de livraison</h2>
      <?php $gpsModifiable = $estProprio && position_modifiable((int) $c['id']); ?>
      <?php if ($c['livraison_lat'] !== null): ?>
        <p class="position-ok"><i class="ph-fill ph-map-pin"></i> <span><b>Position GPS enregistrée</b> : le livreur a l'itinéraire exact. <?= bouton_itineraire($c, 'Voir sur la carte') ?></span></p>
      <?php elseif ($gpsModifiable && (int) $c['cadeau'] === 1 && commande_engagee($c)):
          $lienPos = position_lien_proche($c);
          $msgPos = 'Bonjour ' . explode(' ', trim((string) $c['livraison_nom']))[0] . ', pour que le livreur te trouve facilement, ouvre ce lien et appuie sur « Envoyer ma position » : ' . $lienPos; ?>
        <p class="position-manque"><i class="ph ph-map-pin"></i> <span>Pour que le livreur trouve facilement votre proche, demandez-lui sa position :
          <a class="btn btn-whatsapp" href="<?= e('https://wa.me/' . preg_replace('/\D/', '', (string) $c['livraison_telephone']) . '?text=' . rawurlencode($msgPos)) ?>" target="_blank" rel="noopener noreferrer"><i class="ph-fill ph-whatsapp-logo"></i> Demander sa position</a></span></p>
      <?php endif; ?>
      <?php if ((int) $c['cadeau'] === 1): ?>
        <div class="encart-cadeau encart-cadeau-commande">
          <p><i class="ph ph-gift"></i> <b>Cadeau pour <?= e($c['livraison_nom']) ?></b> · <?= e($c['livraison_telephone']) ?> — le colis est livré sans prix ni facture.</p>
          <?php if ($c['message_cadeau']): ?><p class="doux">Votre mot : « <?= e($c['message_cadeau']) ?> »</p><?php endif; ?>
        </div>
      <?php endif; ?>
      <?php foreach ($sousCommandes as $sc): $etapes = suivi_etapes($sc, $c); $l = litige_livraison((int) $sc['id']); $raison = $estProprio && $l ? litige_impossible($l) : 'x'; ?>
        <div class="recap-ligne"><span><b><?= e($sc['boutique']) ?></b><?php if ($sc['numero_suivi']): ?> <small class="doux">· suivi n° <?= e($sc['numero_suivi']) ?></small><?php endif; ?></span>
          <span class="badge badge-<?= e($sc['statut']) ?>"><?= e(STATUTS_SOUS_COMMANDE[$sc['statut']]) ?></span></div>
        <?php if ($estProprio && ($waVendeur = lien_prevenir_vendeur($c, $sc))): ?>
          <div class="prevenir-vendeur">
            <a class="btn btn-whatsapp" href="<?= e($waVendeur) ?>" target="_blank" rel="noopener noreferrer"><i class="ph-fill ph-whatsapp-logo"></i> Prévenir <?= e($sc['boutique']) ?> sur WhatsApp</a>
            <span class="doux petit">Le message est déjà écrit : appuyez simplement sur « Envoyer ». Votre commande sera préparée plus vite.</span>
          </div>
        <?php endif; ?>
        <?php if ($c['statut'] !== 'annulee'): ?>
        <ol class="suivi">
          <?php foreach ($etapes as [$libelle, $quand, $etat]): ?>
            <li class="suivi-<?= e($etat) ?>"><span class="suivi-point"></span><span><?= e($libelle) ?><?php if ($quand): ?> <small class="doux"><?= e(heure_courte($quand)) ?></small><?php endif; ?></span></li>
          <?php endforeach; ?>
        </ol>
        <?php endif; ?>
        <?php if ($estProprio && $c['statut'] !== 'annulee' && $sc['code_livraison'] && in_array($sc['statut'], ['a_preparer', 'expediee'], true)): ?>
          <p class="code-livraison"><i class="ph ph-key"></i> Code de réception : <b><?= e($sc['code_livraison']) ?></b> <span class="doux petit">— ne le donnez qu'après avoir reçu et vérifié votre colis : il permet de confirmer la livraison.</span></p>
          <?php if ((int) $c['cadeau'] === 1 && commande_engagee($c)):
              $texteProche = 'Bonjour ' . explode(' ', trim((string) $c['livraison_nom']))[0] . ', je t\'ai envoyé un cadeau par Jënd (boutique ' . $sc['boutique'] . ', commande ' . $c['reference'] . '). '
                  . 'Quand le livreur arrive, vérifie le colis, puis donne-lui ce code de réception : ' . $sc['code_livraison'] . '. Ne le donne à personne avant.'; ?>
            <p><a class="btn btn-whatsapp" href="<?= e('https://wa.me/' . preg_replace('/\D/', '', (string) $c['livraison_telephone']) . '?text=' . rawurlencode($texteProche)) ?>" target="_blank" rel="noopener noreferrer"><i class="ph-fill ph-whatsapp-logo"></i> Envoyer le code à <?= e(explode(' ', trim((string) $c['livraison_nom']))[0]) ?> sur WhatsApp</a></p>
          <?php endif; ?>
        <?php endif; ?>
        <?php if ($estProprio && $c['statut'] !== 'annulee' && $sc['statut'] === 'expediee' && $sc['livre_par'] === 'vendeur' && $sc['livreur_id'] === null): ?>
          <form method="post" data-confirm="Confirmez-vous avoir bien reçu ce colis ? Le vendeur sera payé."><?= csrf_champ() ?><input type="hidden" name="id" value="<?= (int) $sc['id'] ?>">
            <button class="btn btn-primaire" type="submit"><i class="ph ph-package"></i> <?= (int) $c['cadeau'] === 1 ? 'Mon proche a bien reçu le colis' : 'J\'ai bien reçu ma commande' ?></button>
            <span class="doux petit">Ou donnez le code ci-dessus au vendeur.</span></form>
        <?php endif; ?>
        <?php if ($estProprio && $sc['litige_ref']): ?>
          <p class="petit"><i class="ph ph-chat-circle-text"></i> Signalement <a class="lien" href="<?= e(url('litige/' . $sc['litige_ref'])) ?>"><?= e($sc['litige_ref']) ?></a> : <b><?= e(STATUTS_LITIGE[$sc['litige_statut']]) ?></b></p>
        <?php elseif ($estProprio && $raison === null): ?>
          <p class="petit"><a class="lien" href="<?= e(url('litige/nouveau/' . $sc['id'])) ?>"><i class="ph ph-warning-circle"></i> Un problème avec cette livraison ? Le signaler</a></p>
        <?php endif; ?>
      <?php endforeach; ?>
    </div>

    <div class="recap recap-pleine">
      <h2>Livraison</h2>
      <p><b><?= e($c['livraison_nom']) ?></b> · <?= e($c['livraison_telephone']) ?><br><?= e($c['livraison_adresse']) ?><br><span class="doux"><?= e($c['livraison_zone']) ?></span></p>
      <p class="doux">Statut : <span class="badge badge-<?= e($c['statut']) ?>"><?= e(STATUTS_COMMANDE[$c['statut']]) ?></span></p>
    </div>

    <?php if ($annulable): ?>
      <form method="post" action="<?= e(url('commande/annuler')) ?>" class="annulation" data-confirm="Annuler cette commande ?">
        <?= csrf_champ() ?><input type="hidden" name="reference" value="<?= e($c['reference']) ?>">
        <button class="lien lien-danger" type="submit"><i class="ph ph-x-circle"></i> Annuler cette commande</button>
      </form>
    <?php endif; ?>

    <div class="cta mt15">
      <a href="<?= e(url('compte')) ?>" class="btn btn-contour">Mes commandes</a>
      <a href="<?= e(url('produits')) ?>" class="btn btn-primaire">Continuer mes achats</a>
    </div>
  </div>
</main>
<?php require __DIR__ . '/../includes/footer.php'; ?>
