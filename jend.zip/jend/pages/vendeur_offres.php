<?php
/** Offres reçues par le vendeur : accepter, refuser ou contre-proposer. */
[$u, $b] = exiger_vendeur();
if (post_verifie('vendeur/offres')) {
    try {
        $action = (string) ($_POST['action'] ?? '');
        $contre = trim((string) ($_POST['contre'] ?? ''));
        if ($action === 'contre' && !ctype_digit($contre)) {
            throw new RuntimeException('Indiquez votre prix en FCFA (nombre entier).');
        }
        offre_repondre_vendeur((int) ($_POST['id'] ?? 0), (int) $b['id'], $action, (int) $contre);
        flash(['accepter' => 'Offre acceptée : le client a ' . OFFRE_VALIDITE_ACHAT_HEURES . ' heures pour acheter à ce prix.', 'refuser' => 'Offre refusée.', 'contre' => 'Contre-proposition envoyée au client.'][$action] ?? 'Offre mise à jour.');
    } catch (RuntimeException $e) {
        flash($e->getMessage(), 'erreur');
    }
    rediriger('vendeur/offres');
}
$offres = requete(
    "SELECT o.*, p.nom AS produit, p.slug, p.prix AS prix_actuel, p.stock, u.nom AS client
       FROM offres o JOIN produits p ON p.id = o.produit_id JOIN users u ON u.id = o.client_id
      WHERE o.boutique_id = ? ORDER BY (o.statut = 'en_attente' AND o.expire_le > NOW()) DESC, o.id DESC LIMIT 60",
    [$b['id']]
)->fetchAll();
$titre = 'Offres reçues — Jënd';
require __DIR__ . '/../includes/header.php';
?>
<main class="page">
  <div class="wrap">
    <nav class="fil" aria-label="Fil d'Ariane"><a href="<?= e(url()) ?>">Accueil</a> / <a href="<?= e(url('vendeur')) ?>">Boutique</a> / <span>Offres</span></nav>
    <h1 class="titre-page"><?= e($b['nom']) ?></h1>
    <?php vendeur_onglets('offres'); ?>
    <p class="doux">Vos clients peuvent vous proposer un prix (jamais moins de <?= OFFRE_MIN_POURCENT ?> % du prix affiché). Répondez sous <?= OFFRE_REPONSE_HEURES ?> heures : sans réponse, l'offre tombe. La commission de Jënd se calcule sur le prix réellement payé.
      <?php if ((int) $b['offres_actives'] !== 1): ?><br><b>Vous avez désactivé les offres</b> dans l'onglet « Boutique » : vous n'en recevez plus de nouvelles.<?php endif; ?></p>
    <?php if (!$offres): ?>
      <div class="tb-vide"><i class="ph ph-handshake"></i><p><b>Aucune offre reçue pour le moment.</b></p></div>
    <?php else: ?>
      <div class="offres">
        <?php foreach ($offres as $o): $expiree = offre_expiree($o); $aTraiter = $o['statut'] === 'en_attente' && !$expiree; $vivante = !$expiree && in_array($o['statut'], ['en_attente', 'contre', 'acceptee'], true); ?>
          <article class="offre offre-<?= e($vivante ? $o['statut'] : 'close') ?>">
            <header><b><?= e($o['produit']) ?></b><span class="badge badge-offre-<?= e($vivante ? $o['statut'] : 'close') ?>"><?= e($aTraiter ? 'À traiter' : offre_libelle($o)) ?></span></header>
            <p class="doux petit"><?= e(explode(' ', $o['client'])[0]) ?> · quantité <?= (int) $o['quantite'] ?> · <?= e(date('d/m H:i', strtotime($o['created_at']))) ?> · stock : <?= (int) $o['stock'] ?></p>
            <p>Prix affiché : <?= e(fcfa((int) $o['prix_actuel'])) ?> → offre du client : <b><?= e(fcfa((int) $o['prix_propose'])) ?></b>
              <span class="doux">(− <?= (int) round((1 - $o['prix_propose'] / max(1, (int) $o['prix_initial'])) * 100) ?> %)</span>
              <?php if ($o['contre_prix']): ?> · votre contre-proposition : <b><?= e(fcfa((int) $o['contre_prix'])) ?></b><?php endif; ?>
              <?php if ($o['prix_final']): ?> · prix convenu : <b><?= e(fcfa((int) $o['prix_final'])) ?></b><?php endif; ?></p>
            <?php if ($aTraiter): ?>
              <p class="doux petit">À traiter avant le <?= e(date('d/m à H:i', strtotime($o['expire_le']))) ?></p>
              <div class="ligne-action">
                <form method="post"><?= csrf_champ() ?><input type="hidden" name="id" value="<?= (int) $o['id'] ?>"><input type="hidden" name="action" value="accepter"><button class="btn btn-primaire" type="submit"><i class="ph ph-check"></i> Accepter <?= e(fcfa((int) $o['prix_propose'])) ?></button></form>
                <form method="post" class="ligne-action m0"><?= csrf_champ() ?><input type="hidden" name="id" value="<?= (int) $o['id'] ?>"><input type="hidden" name="action" value="contre">
                  <label class="sr" for="c<?= (int) $o['id'] ?>">Votre prix</label><input id="c<?= (int) $o['id'] ?>" type="text" name="contre" inputmode="numeric" class="largeur-120" placeholder="Votre prix" required> FCFA
                  <button class="btn btn-contour" type="submit">Contre-proposer</button></form>
                <form method="post"><?= csrf_champ() ?><input type="hidden" name="id" value="<?= (int) $o['id'] ?>"><input type="hidden" name="action" value="refuser"><button class="lien lien-danger" type="submit">Refuser</button></form>
              </div>
            <?php endif; ?>
          </article>
        <?php endforeach; ?>
      </div>
    <?php endif; ?>
  </div>
</main>
<?php require __DIR__ . '/../includes/footer.php'; ?>
