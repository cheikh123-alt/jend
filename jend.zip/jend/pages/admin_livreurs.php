<?php
exiger_admin();

if (post_verifie('admin/livreurs')) {
    $action = $_POST['action'] ?? '';
    $id = (int) ($_POST['id'] ?? 0);
    if ($action === 'creer') {
        $nom = trim((string) ($_POST['nom'] ?? ''));
        $email = trim((string) ($_POST['email'] ?? ''));
        $tel = telephone_valide((string) ($_POST['telephone'] ?? ''));
        $zone = (int) ($_POST['zone_id'] ?? 0) ?: null;
        if (mb_strlen($nom) < 2 || mb_strlen($nom) > 120) {
            flash('Nom invalide (2 à 120 caractères).', 'erreur');
        } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL) || mb_strlen($email) > 190) {
            flash('Adresse e-mail invalide.', 'erreur');
        } elseif ($tel === null) {
            flash('Numéro de téléphone invalide (ex : 77 123 45 67) : le livreur est joint par WhatsApp à ce numéro.', 'erreur');
        } elseif ($zone && !requete('SELECT 1 FROM zones_livraison WHERE id = ?', [$zone])->fetch()) {
            flash('Zone inconnue.', 'erreur');
        } elseif (requete('SELECT 1 FROM users WHERE email = ?', [$email])->fetch()) {
            flash('Cette adresse e-mail est déjà utilisée.', 'erreur');
        } else {
            $mdp = rtrim(strtr(base64_encode(random_bytes(9)), '+/', '-_'), '=');
            $pdo = pdo();
            $pdo->beginTransaction();
            requete("INSERT INTO users (nom, email, telephone, mot_de_passe, role, mdp_provisoire) VALUES (?, ?, ?, ?, 'livreur', 1)", [$nom, $email, $tel, password_hash($mdp, PASSWORD_DEFAULT)]);
            requete('INSERT INTO livreurs (user_id, zone_id) VALUES (?, ?)', [(int) $pdo->lastInsertId(), $zone]);
            $pdo->commit();
            journaliser('livreur_cree', $nom . ' (' . $email . ')');
            $_SESSION['mdp_livreur'] = ['nom' => $nom, 'email' => $email, 'mdp' => $mdp, 'neuf' => true];
            flash('Livreur « ' . $nom . ' » créé : son mot de passe provisoire est affiché ci-dessous.');
        }
    } elseif ($id && requete("SELECT 1 FROM users WHERE id = ? AND role = 'livreur'", [$id])->fetch()) {
        if ($action === 'zone') {
            $zone = (int) ($_POST['zone_id'] ?? 0) ?: null;
            if ($zone && !requete('SELECT 1 FROM zones_livraison WHERE id = ?', [$zone])->fetch()) {
                flash('Zone inconnue.', 'erreur');
            } else {
                requete('UPDATE livreurs SET zone_id = ? WHERE user_id = ?', [$zone, $id]);
                journaliser('livreur_zone', '#' . $id . ' → zone ' . ($zone ?: 'toutes'));
                flash('Zone du livreur mise à jour.');
            }
        } elseif ($action === 'reinitialiser') {
            $mdp = rtrim(strtr(base64_encode(random_bytes(9)), '+/', '-_'), '=');
            $ligne = requete('SELECT nom, email FROM users WHERE id = ?', [$id])->fetch();
            requete('UPDATE users SET mot_de_passe = ?, mdp_provisoire = 1, session_version = session_version + 1 WHERE id = ?', [password_hash($mdp, PASSWORD_DEFAULT), $id]);
            journaliser('livreur_mdp_reinitialise', '#' . $id);
            $_SESSION['mdp_livreur'] = ['nom' => $ligne['nom'], 'email' => $ligne['email'], 'mdp' => $mdp, 'neuf' => false];
            flash('Nouveau mot de passe provisoire pour « ' . $ligne['nom'] . ' » : il est affiché ci-dessous.');
        } elseif ($action === 'basculer') {
            requete('UPDATE users SET actif = 1 - actif, session_version = session_version + 1 WHERE id = ?', [$id]);   // session_version : coupe aussitôt ses sessions ouvertes
            requete('UPDATE livreurs SET disponible = 0 WHERE user_id = ?', [$id]);
            journaliser('livreur_bascule', '#' . $id);
            flash('Compte du livreur mis à jour (actif / désactivé).');
        }
    }
    rediriger('admin/livreurs');
}

$nouveauMdp = $_SESSION['mdp_livreur'] ?? null;
unset($_SESSION['mdp_livreur']);               // affiché une seule fois
$livreurs = requete(
    "SELECT u.id, u.nom, u.email, u.telephone, u.actif, l.zone_id, l.disponible,
            (SELECT COUNT(*) FROM commande_boutiques cb WHERE cb.livreur_id = u.id AND cb.statut IN ('a_preparer', 'expediee')) AS en_cours,
            (SELECT COUNT(*) FROM commande_boutiques cb WHERE cb.livreur_id = u.id AND cb.statut = 'livree') AS livrees
       FROM users u JOIN livreurs l ON l.user_id = u.id WHERE u.role = 'livreur' ORDER BY u.actif DESC, l.disponible DESC, u.nom"
)->fetchAll();
$zones = requete('SELECT id, nom, actif FROM zones_livraison ORDER BY actif DESC, region, nom')->fetchAll();
$titre = 'Livreurs — Administration';
require __DIR__ . '/../includes/header.php';
?>
<main class="page">
  <div class="wrap">
    <nav class="fil" aria-label="Fil d'Ariane"><a href="<?= e(url()) ?>">Accueil</a> / <a href="<?= e(url('admin')) ?>">Administration</a> / <span>Livreurs</span></nav>
    <h1 class="titre-page">Administration</h1>
    <?php admin_onglets('livreurs'); ?>
    <?php if ($nouveauMdp): ?>
      <section class="carte-mdp" aria-live="polite">
        <h2><i class="ph-fill ph-key"></i> Mot de passe provisoire de <?= e($nouveauMdp['nom']) ?></h2>
        <p class="mdp-ligne"><code class="mdp-provisoire"><?= e($nouveauMdp['mdp']) ?></code>
          <button class="btn btn-primaire" type="button" data-copier="<?= e($nouveauMdp['mdp']) ?>"><i class="ph ph-copy"></i> Copier</button></p>
        <p>Identifiant (e-mail) : <b><?= e($nouveauMdp['email']) ?></b> · Connexion : <b><?= e(app_url('livreur/connexion')) ?></b></p>
        <p class="doux petit"><b>Notez-le maintenant : il ne sera plus jamais affiché</b> (rechargement de la page = disparu). Le livreur devra le changer à sa première connexion. Si vous le perdez, utilisez « Nouveau mot de passe » dans sa fiche.</p>
      </section>
    <?php endif; ?>
    <?php if (!livreurs_jend_actifs()): ?><p class="alerte alerte-info"><i class="ph ph-info"></i> La livraison par les livreurs Jënd n'est pas encore activée : chaque vendeur livre lui-même. <a class="lien" href="<?= e(url('admin/parametres')) ?>">Activer dans les paramètres</a>.</p><?php endif; ?>
    <p class="encadre-info"><i class="ph ph-link"></i> Adresse de connexion à donner aux livreurs : <b><?= e(app_url('livreur/connexion')) ?></b> (à ouvrir sur leur téléphone, puis « Ajouter à l'écran d'accueil »).</p>
    <div class="deux-colonnes">
      <section>
        <h2 class="sous-titre">Livreurs (<?= count($livreurs) ?>)</h2>
        <?php if (!$livreurs): ?><div class="vide"><i class="ph ph-motorcycle"></i><p><b>Aucun livreur.</b></p><p class="doux">Créez le premier avec le formulaire.</p></div><?php endif; ?>
        <?php foreach ($livreurs as $l): ?>
          <div class="adresse-carte zone-ligne <?= $l['actif'] ? '' : 'zone-inactive' ?>">
            <div><b><?= e($l['nom']) ?></b> <span class="badge <?= !$l['actif'] ? 'badge-annulee' : ($l['disponible'] ? 'badge-livree' : 'badge-a_preparer') ?>"><?= !$l['actif'] ? 'Désactivé' : ($l['disponible'] ? 'Disponible' : 'Indisponible') ?></span><br>
              <span class="doux petit"><?= e($l['email']) ?> · <?= e($l['telephone']) ?> · <?= (int) $l['en_cours'] ?> en cours · <?= (int) $l['livrees'] ?> livrée(s)</span></div>
            <form method="post" class="zone-actions"><?= csrf_champ() ?><input type="hidden" name="id" value="<?= (int) $l['id'] ?>">
              <select name="zone_id" aria-label="Zone du livreur"><option value="">Toutes les zones</option>
                <?php foreach ($zones as $z): ?><option value="<?= (int) $z['id'] ?>" <?= (int) $l['zone_id'] === (int) $z['id'] ? 'selected' : '' ?>><?= e($z['nom']) ?></option><?php endforeach; ?></select>
              <button class="btn btn-contour" type="submit" name="action" value="zone">Changer la zone</button>
              <button class="btn btn-contour" type="submit" name="action" value="reinitialiser" data-confirm="Générer un nouveau mot de passe provisoire pour ce livreur ? Son ancien mot de passe cessera de fonctionner et ses sessions seront fermées.">Nouveau mot de passe</button>
              <button class="btn btn-contour" type="submit" name="action" value="basculer"><?= $l['actif'] ? 'Désactiver' : 'Réactiver' ?></button>
              <?php $waLien = 'https://wa.me/' . preg_replace('/\D/', '', (string) $l['telephone']) . '?text=' . rawurlencode('Bonjour ' . explode(' ', $l['nom'])[0] . ', votre compte Jënd Livreur est prêt. Connectez-vous ici : ' . app_url('livreur/connexion') . "\nIdentifiant : " . $l['email'] . "\n(Le mot de passe provisoire vous est donné séparément.)"); ?>
              <a class="btn btn-accent" href="<?= e($waLien) ?>" target="_blank" rel="noopener noreferrer"><i class="ph-fill ph-whatsapp-logo"></i> Envoyer le lien</a>
            </form>
          </div>
        <?php endforeach; ?>
      </section>
      <form method="post" class="formulaire formulaire-large" novalidate autocomplete="off">
        <?= csrf_champ() ?><input type="hidden" name="action" value="creer">
        <h2 class="sous-titre">Ajouter un livreur</h2>
        <label class="champ"><span>Nom complet</span><input type="text" name="nom" maxlength="120" required></label>
        <label class="champ"><span>E-mail (identifiant de connexion)</span><input type="email" name="email" maxlength="190" required></label>
        <label class="champ"><span>Téléphone / WhatsApp</span><input type="tel" name="telephone" placeholder="77 123 45 67" required></label>
        <label class="champ"><span>Zone habituelle</span><select name="zone_id"><option value="">Toutes les zones</option>
          <?php foreach ($zones as $z): if ($z['actif']): ?><option value="<?= (int) $z['id'] ?>"><?= e($z['nom']) ?></option><?php endif; endforeach; ?></select></label>
        <button class="btn btn-primaire" type="submit">Créer le compte livreur</button>
        <p class="doux petit">Un mot de passe provisoire est généré et affiché une seule fois : transmettez-le au livreur, qui pourra le changer dans « Mon profil ».</p>
      </form>
    </div>
  </div>
</main>
<?php require __DIR__ . '/../includes/footer.php'; ?>
