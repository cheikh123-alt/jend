<?php
/** Liste des signalements du client. */
$u = exiger_connexion();
$liste = requete(
    "SELECT l.*, c.reference AS commande_ref, b.nom AS boutique FROM litiges l
       JOIN commande_boutiques cb ON cb.id = l.commande_boutique_id JOIN commandes c ON c.id = cb.commande_id JOIN boutiques b ON b.id = cb.boutique_id
      WHERE l.client_id = ? ORDER BY l.id DESC",
    [$u['id']]
)->fetchAll();
$titre = 'Mes signalements — Jënd';
require __DIR__ . '/../includes/header.php';
?>
<main class="page">
  <div class="wrap">
    <h1 class="titre-page">Mon compte</h1>
    <?php compte_onglets('litiges'); ?>
    <h2 class="sous-titre">Mes signalements</h2>
    <?php if (!$liste): ?>
      <div class="vide"><i class="ph ph-chat-circle-text"></i><p><b>Aucun signalement.</b></p><p class="doux">Un problème avec une livraison ? Ouvrez la commande concernée et choisissez « Le signaler ».</p></div>
    <?php else: foreach ($liste as $l): ?>
      <a class="adresse-carte lien-carte" href="<?= e(url('litige/' . $l['reference'])) ?>">
        <div><b><?= e($l['reference']) ?></b> · <?= e(MOTIFS_LITIGE[$l['motif']]) ?><br><span class="doux petit"><?= e($l['boutique']) ?> · commande <?= e($l['commande_ref']) ?> · <?= e(date('d/m/Y', strtotime($l['created_at']))) ?></span></div>
        <span class="badge badge-litige-<?= e($l['statut']) ?>"><?= e(STATUTS_LITIGE[$l['statut']]) ?></span>
      </a>
    <?php endforeach; endif; ?>
  </div>
</main>
<?php require __DIR__ . '/../includes/footer.php'; ?>
