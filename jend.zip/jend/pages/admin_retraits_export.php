<?php
/** Export CSV des retraits à payer (administrateur seulement) : à ouvrir dans Excel ou à recopier dans Wave / Orange Money. */
exiger_admin();
$lignes = requete(
    "SELECT r.id, r.created_at, r.montant, r.methode, b.nom AS boutique, u.nom AS vendeur, b.telephone_paiement
       FROM retraits r JOIN boutiques b ON b.id = r.boutique_id JOIN users u ON u.id = b.user_id
      WHERE r.statut = 'demande' ORDER BY r.id"
)->fetchAll();
/** Neutralise les formules de tableur (=, +, -, @) : un nom de boutique ne doit jamais s'exécuter dans Excel. */
$cellule = static function ($v): string {
    $v = (string) $v;
    if (preg_match('/^\+\d{6,15}$/', $v)) {
        return $v;                                 // un numéro de téléphone international n'est pas une formule
    }
    return $v !== '' && strpos("=+-@\t\r", $v[0]) !== false ? "'" . $v : $v;
};
journaliser('retraits_exportes', count($lignes) . ' demande(s)');
$nom = 'retraits-a-payer-' . date('Y-m-d') . '.csv';
header('Content-Type: text/csv; charset=UTF-8');
header('Content-Disposition: attachment; filename="' . $nom . '"');
header('Cache-Control: no-store');
$sortie = fopen('php://output', 'w');
fwrite($sortie, "\xEF\xBB\xBF");                       // BOM : Excel lit correctement les accents
fputcsv($sortie, ['Numéro', 'Date de la demande', 'Boutique', 'Vendeur', 'Envoyer sur', 'Numéro', 'Montant (FCFA)'], ';');
$total = 0;
foreach ($lignes as $l) {
    $total += (int) $l['montant'];
    fputcsv($sortie, [(int) $l['id'], date('d/m/Y', strtotime($l['created_at'])), $cellule($l['boutique']), $cellule($l['vendeur']), str_replace('_', ' ', $l['methode']), $cellule($l['telephone_paiement']), (int) $l['montant']], ';');
}
fputcsv($sortie, ['', '', '', '', '', 'TOTAL', $total], ';');
fclose($sortie);
