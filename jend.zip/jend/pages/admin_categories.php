<?php
exiger_admin();
$erreurs = [];
if (post_verifie('admin/categories')) {
    $action = $_POST['action'] ?? '';
    if ($action === 'ajouter') {
        $nom = trim((string) ($_POST['nom'] ?? ''));
        $parent = (int) ($_POST['parent_id'] ?? 0) ?: null;
        $icone = trim((string) ($_POST['icone'] ?? ''));
        $option = (string) ($_POST['option_type'] ?? '');
        if ($option !== '' && !isset(OPTIONS_PRODUIT[$option])) {
            $option = '';
        }
        if (mb_strlen($nom) < 2 || mb_strlen($nom) > 100) {
            flash('Nom de catégorie invalide (2 à 100 caractères).', 'erreur');
        } elseif ($parent && !requete('SELECT 1 FROM categories WHERE id = ? AND parent_id IS NULL', [$parent])->fetch()) {
            flash('La catégorie parente doit être une catégorie principale.', 'erreur');
        } elseif ($icone !== '' && !in_array($icone, ICONES_CATEGORIES, true)) {
            flash('Choisissez une icône dans la liste proposée.', 'erreur');
        } else {
            $slug = slugify($nom);
            for ($i = 2; requete('SELECT 1 FROM categories WHERE slug = ?', [$slug])->fetch(); $i++) {
                $slug = slugify($nom) . '-' . $i;
            }
            $pos = (int) requete('SELECT COALESCE(MAX(position), 0) + 1 FROM categories WHERE parent_id <=> ?', [$parent])->fetchColumn();
            requete('INSERT INTO categories (parent_id, nom, slug, icone, position, option_type) VALUES (?, ?, ?, ?, ?, ?)', [$parent, $nom, $slug, $icone !== '' ? $icone : null, $pos, $option !== '' ? $option : null]);
            journaliser('categorie_ajoutee', $nom);
            flash('Catégorie « ' . $nom . ' » ajoutée.');
        }
    } elseif ($action === 'option') {                 // tailles / pointures proposées aux vendeurs dans cette catégorie
        $option = (string) ($_POST['option_type'] ?? '');
        $id = (int) ($_POST['id'] ?? 0);
        if ($option === '' || isset(OPTIONS_PRODUIT[$option])) {
            requete('UPDATE categories SET option_type = ? WHERE id = ?', [$option !== '' ? $option : null, $id]);
            journaliser('categorie_tailles', '#' . $id . ' ' . ($option ?: 'aucune'));
            flash($option !== '' ? 'Les vendeurs pourront indiquer les ' . mb_strtolower(OPTIONS_PRODUIT[$option][0]) . 's dans cette catégorie.' : 'Plus de choix de taille dans cette catégorie (les produits existants gardent leurs tailles).');
        }
    } elseif ($action === 'supprimer') {
        $id = (int) ($_POST['id'] ?? 0);
        $utilisee = (int) requete('SELECT (SELECT COUNT(*) FROM produits WHERE categorie_id = ?) + (SELECT COUNT(*) FROM categories WHERE parent_id = ?)', [$id, $id])->fetchColumn();
        if ($utilisee > 0) {
            flash('Impossible : cette catégorie contient des produits ou des sous-catégories.', 'erreur');
        } else {
            requete('DELETE FROM categories WHERE id = ?', [$id]);
            journaliser('categorie_supprimee', '#' . $id);
            flash('Catégorie supprimée.');
        }
    }
    rediriger('admin/categories');
}
$arbre = categories_arbre();
$optionsCat = array_column(requete('SELECT id, option_type FROM categories')->fetchAll(), 'option_type', 'id');
$choixTailles = ['' => 'Pas de taille', 'taille' => 'Tailles (XS à 4XL)', 'pointure' => 'Pointures (35 à 47)', 'taille_enfant' => 'Tailles enfant (0 mois à 14 ans)'];
$formTailles = function (int $id) use ($optionsCat, $choixTailles): string {
    $html = '<form method="post" class="en-ligne form-tailles">' . csrf_champ() . '<input type="hidden" name="action" value="option"><input type="hidden" name="id" value="' . $id . '">'
          . '<label class="sr" for="opt' . $id . '">Tailles proposées</label><select id="opt' . $id . '" name="option_type">';
    foreach ($choixTailles as $val => $lib) {
        $html .= '<option value="' . e($val) . '"' . ((string) ($optionsCat[$id] ?? '') === $val ? ' selected' : '') . '>' . e($lib) . '</option>';
    }
    return $html . '</select><button class="lien" type="submit">OK</button></form>';
};
$compte = [];
foreach (requete('SELECT categorie_id, COUNT(*) n FROM produits GROUP BY categorie_id')->fetchAll() as $r) {
    $compte[(int) $r['categorie_id']] = (int) $r['n'];
}
$titre = 'Catégories — Administration';
require __DIR__ . '/../includes/header.php';
?>
<main class="page">
  <div class="wrap">
    <nav class="fil" aria-label="Fil d'Ariane"><a href="<?= e(url()) ?>">Accueil</a> / <a href="<?= e(url('admin')) ?>">Administration</a> / <span>Catégories</span></nav>
    <h1 class="titre-page">Administration</h1>
    <?php admin_onglets('categories'); ?>
    <div class="deux-colonnes">
      <section>
        <h2 class="sous-titre">Catégories</h2>
        <?php foreach ($arbre as $c): ?>
          <div class="adresse-carte"><div><b><?= e($c['nom']) ?></b> <span class="doux">(<?= $compte[$c['id']] ?? 0 ?> produits)</span> <?= $formTailles((int) $c['id']) ?>
            <?php foreach ($c['enfants'] as $s): ?>
              <div class="petit sous-ligne">↳ <?= e($s['nom']) ?> <span class="doux">(<?= $compte[$s['id']] ?? 0 ?>)</span> <?= $formTailles((int) $s['id']) ?>
                <form method="post" class="en-ligne" data-confirm="Supprimer cette sous-catégorie ?"><?= csrf_champ() ?><input type="hidden" name="action" value="supprimer"><input type="hidden" name="id" value="<?= $s['id'] ?>"><button class="lien lien-danger" type="submit"><i class="ph ph-trash"></i></button></form></div>
            <?php endforeach; ?></div>
            <form method="post" data-confirm="Supprimer cette catégorie ?"><?= csrf_champ() ?><input type="hidden" name="action" value="supprimer"><input type="hidden" name="id" value="<?= $c['id'] ?>"><button class="lien lien-danger" type="submit"><i class="ph ph-trash"></i></button></form></div>
        <?php endforeach; ?>
      </section>
      <form method="post" class="formulaire formulaire-large" novalidate>
        <?= csrf_champ() ?><input type="hidden" name="action" value="ajouter">
        <h2 class="sous-titre">Ajouter une catégorie</h2>
        <label class="champ"><span>Nom</span><input type="text" name="nom" maxlength="100" required></label>
        <label class="champ"><span>Catégorie parente</span>
          <select name="parent_id"><option value="">— Aucune (catégorie principale) —</option>
            <?php foreach ($arbre as $c): ?><option value="<?= $c['id'] ?>"><?= e($c['nom']) ?></option><?php endforeach; ?></select></label>
        <label class="champ"><span>Le client choisit une taille ?</span>
          <select name="option_type"><?php foreach ($choixTailles as $val => $lib): ?><option value="<?= e($val) ?>"><?= e($lib) ?></option><?php endforeach; ?></select>
          <small class="doux">Ex. : « Chaussures » → Pointures. Les sous-catégories reprennent le choix de leur catégorie principale si elles n'en ont pas.</small></label>
        <fieldset class="champ choix-icones"><legend>Icône (optionnel)</legend>
          <label><input type="radio" name="icone" value="" checked> <span>Aucune</span></label>
          <?php foreach (ICONES_CATEGORIES as $ic): ?><label title="<?= e(substr($ic, 3)) ?>"><input type="radio" name="icone" value="<?= e($ic) ?>"> <i class="ph <?= e($ic) ?>" aria-hidden="true"></i><span class="sr"><?= e(substr($ic, 3)) ?></span></label><?php endforeach; ?>
        </fieldset>
        <button class="btn btn-primaire" type="submit">Ajouter</button>
      </form>
    </div>
  </div>
</main>
<?php require __DIR__ . '/../includes/footer.php'; ?>
