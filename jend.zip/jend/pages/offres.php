<?php
/** « Mes offres » : les prix que le client a proposés, et les réponses des vendeurs. */
$u = exiger_connexion();
if (post_verifie('offres')) {
    try {
        $action = (string) ($_POST['action'] ?? '');
        if ($action === 'acheter') {
            $o = requete("SELECT o.id, o.produit_id, o.quantite FROM offres o WHERE o.id = ? AND o.client_id = ? AND o.statut = 'acceptee' AND o.expire_le > NOW()", [(int) ($_POST['id'] ?? 0), $u['id']])->fetch();
            if (!$o) {
                throw new RuntimeException('Cette offre n\'est plus valable.');
            }
            $prod = requete('SELECT slug, option_type FROM produits WHERE id = ?', [$o['produit_id']])->fetch();
            if ($prod && variantes_produit((int) $o['produit_id'])) {      // produit avec tailles : le client choisit la sienne, le prix convenu s'applique au panier
                flash('Choisissez votre ' . mb_strtolower(option_libelle($prod['option_type'])) . ' : le prix convenu sera appliqué dans le panier.');
                rediriger('produit/' . $prod['slug']);
            }
            $_SESSION['panier'] = [(int) $o['produit_id'] => (int) $o['quantite']];       // le prix convenu est appliqué automatiquement
            rediriger('commande');
        }
        offre_repondre_client((int) ($_POST['id'] ?? 0), (int) $u['id'], $action);
        flash(['accepter' => 'Prix accepté : vous pouvez acheter à ce prix.', 'refuser' => 'Contre-proposition refusée.', 'annuler' => 'Offre annulée.'][$action] ?? 'Offre mise à jour.');
    } catch (RuntimeException $e) {
        flash($e->getMessage(), 'erreur');
    }
    rediriger('offres');
}
$offres = requete(
    "SELECT o.*, p.nom AS produit, p.slug, p.prix AS prix_actuel, b.nom AS boutique
       FROM offres o JOIN produits p ON p.id = o.produit_id JOIN boutiques b ON b.id = o.boutique_id
      WHERE o.client_id = ? ORDER BY o.id DESC LIMIT 50",
    [$u['id']]
)->fetchAll();
$titre = 'Mes offres — Jënd';
require __DIR__ . '/../includes/header.php';
?>
<main class="page">
  <div class="wrap">
    <nav class="fil" aria-label="Fil d'Ariane"><a href="<?= e(url()) ?>">Accueil</a> / <a href="<?= e(url('compte')) ?>">Mon compte</a> / <span>Mes offres</span></nav>
    <h1 class="titre-page">Mon compte</h1>
    <?php compte_onglets('offres'); ?>
    <p class="doux">Proposez votre prix depuis la fiche d'un produit. Le vendeur a <?= OFFRE_REPONSE_HEURES ?> heures pour répondre ; s'il accepte, vous avez <?= OFFRE_VALIDITE_ACHAT_HEURES ?> heures pour acheter à ce prix.</p>
    <?php if (!$offres): ?>
      <div class="tb-vide"><i class="ph ph-handshake"></i><p><b>Aucune offre pour le moment.</b></p><a class="btn btn-primaire" href="<?= e(url('produits')) ?>">Découvrir les produits</a></div>
    <?php else: ?>
      <div class="offres">
        <?php foreach ($offres as $o): $expiree = offre_expiree($o); $vivante = !$expiree && in_array($o['statut'], ['en_attente', 'contre', 'acceptee'], true); ?>
          <article class="offre offre-<?= e($vivante ? $o['statut'] : 'close') ?>">
            <header><a class="lien" href="<?= e(url('produit/' . $o['slug'])) ?>"><b><?= e($o['produit']) ?></b></a>
              <span class="badge badge-offre-<?= e($vivante ? $o['statut'] : 'close') ?>"><?= e(offre_libelle($o)) ?></span></header>
            <p class="doux petit">chez <?= e($o['boutique']) ?> · quantité <?= (int) $o['quantite'] ?> · prix affiché <?= e(fcfa((int) $o['prix_initial'])) ?></p>
            <p>Votre offre : <b><?= e(fcfa((int) $o['prix_propose'])) ?></b>
              <?php if ($o['contre_prix']): ?> · contre-proposition du vendeur : <b><?= e(fcfa((int) $o['contre_prix'])) ?></b><?php endif; ?>
              <?php if ($o['prix_final']): ?> · prix convenu : <b><?= e(fcfa((int) $o['prix_final'])) ?></b><?php endif; ?></p>
            <?php if ($vivante): ?>
              <p class="doux petit"><?= $o['statut'] === 'en_attente' ? 'Réponse attendue avant le ' : 'Valable jusqu\'au ' ?><?= e(date('d/m à H:i', strtotime($o['expire_le']))) ?></p>
              <div class="ligne-action">
                <?php if ($o['statut'] === 'acceptee'): ?>
                  <form method="post"><?= csrf_champ() ?><input type="hidden" name="id" value="<?= (int) $o['id'] ?>"><input type="hidden" name="action" value="acheter"><button class="btn btn-primaire" type="submit"><i class="ph ph-shopping-bag"></i> Acheter à <?= e(fcfa((int) $o['prix_final'])) ?></button></form>
                <?php elseif ($o['statut'] === 'contre'): ?>
                  <form method="post"><?= csrf_champ() ?><input type="hidden" name="id" value="<?= (int) $o['id'] ?>"><input type="hidden" name="action" value="accepter"><button class="btn btn-primaire" type="submit">Accepter <?= e(fcfa((int) $o['contre_prix'])) ?></button></form>
                  <form method="post"><?= csrf_champ() ?><input type="hidden" name="id" value="<?= (int) $o['id'] ?>"><input type="hidden" name="action" value="refuser"><button class="btn btn-contour" type="submit">Refuser</button></form>
                <?php endif; ?>
                <form method="post" data-confirm="Annuler cette offre ?"><?= csrf_champ() ?><input type="hidden" name="id" value="<?= (int) $o['id'] ?>"><input type="hidden" name="action" value="annuler"><button class="lien lien-danger" type="submit">Annuler l'offre</button></form>
              </div>
            <?php endif; ?>
          </article>
        <?php endforeach; ?>
      </div>
    <?php endif; ?>
  </div>
</main>
<?php require __DIR__ . '/../includes/footer.php'; ?>
