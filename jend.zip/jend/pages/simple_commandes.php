<?php
/**
 * Mode simple : mes commandes — photo du produit, quantité, client (bouton Appeler / WhatsApp),
 * puis un seul gros bouton à la fois : « J'ai envoyé le colis », puis « Le client a reçu » avec son code à 4 chiffres.
 * Mêmes règles que l'espace complet (sous_commande_avancer) : pas d'envoi avant paiement, code du client exigé.
 */
[$u, $b] = exiger_vendeur_simple();
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_valide($_POST['csrf'] ?? null)) {
        flash('La page a expiré : recommencez, s\'il vous plaît.', 'erreur');
    } else {
        try {
            sous_commande_avancer((int) ($_POST['id'] ?? 0), (int) $b['id'], null, (string) ($_POST['code_livraison'] ?? ''));
            flash('✅ C\'est noté !');
        } catch (RuntimeException $e) {
            flash($e->getMessage(), 'erreur');
        }
    }
    rediriger('simple/commandes');
}
$commandes = requete(
    "SELECT cb.id, cb.statut, cb.livre_par, cb.livreur_id, cb.sous_total, cb.net_vendeur, cb.frais_part, cb.acompte_part, cb.commission, (cb.code_livraison IS NOT NULL) AS a_code,
            c.reference, c.created_at, c.statut AS statut_commande, c.statut_paiement, c.methode_paiement, c.acompte,
            c.livraison_nom, c.livraison_telephone, c.livraison_zone, c.livraison_adresse, c.livraison_lat, c.livraison_lng, c.cadeau, c.message_cadeau
       FROM commande_boutiques cb JOIN commandes c ON c.id = cb.commande_id
      WHERE cb.boutique_id = ? AND cb.statut IN ('a_preparer', 'expediee') AND c.statut <> 'annulee'
      ORDER BY c.created_at ASC, cb.id ASC LIMIT 50",
    [$b['id']]
)->fetchAll();
$lignes = [];
if ($commandes) {
    $in = implode(',', array_fill(0, count($commandes), '?'));
    foreach (requete("SELECT l.commande_boutique_id, l.nom, l.quantite, l.variante_libelle,
                             (SELECT chemin FROM produit_images i WHERE i.produit_id = l.produit_id ORDER BY position, id LIMIT 1) AS photo
                        FROM commande_lignes l WHERE l.commande_boutique_id IN ($in)", array_column($commandes, 'id'))->fetchAll() as $l) {
        $lignes[$l['commande_boutique_id']][] = $l;
    }
}
$titre = 'Mes commandes — Jënd';
$scripts_extra = ['js/simple.js'];
require __DIR__ . '/../includes/header.php';
?>
<main class="page simple">
  <div class="wrap">
    <?php simple_entete('Mes commandes', 'commandes'); ?>
    <?= push_bloc(true) ?>
    <?php if (!$commandes): ?>
      <p class="simple-info"><i class="ph-fill ph-smiley"></i> <span>Pas de commande en ce moment.</span></p>
    <?php endif; ?>
    <?php foreach ($commandes as $c):
        $paye = commande_engagee($c);
        $moi = $c['livre_par'] === 'vendeur' && $c['livreur_id'] === null;
        $especes = $c['methode_paiement'] === 'livraison' && $c['livre_par'] === 'vendeur'; ?>
      <article class="simple-commande">
        <ul class="simple-commande-produits">
          <?php foreach ($lignes[$c['id']] ?? [] as $l): ?>
            <li><span class="simple-commande-photo"><?php if ($l['photo']): ?><img src="<?= e(url(image_miniature($l['photo']))) ?>" alt="" loading="lazy"><?php else: ?><i class="ph ph-image"></i><?php endif; ?></span>
              <span><b class="simple-quantite">× <?= (int) $l['quantite'] ?></b><?= $l['variante_libelle'] ? ' <b class="variante-choisie">' . e($l['variante_libelle']) . '</b>' : '' ?><br><span class="doux petit"><?= e($l['nom']) ?></span></span></li>
          <?php endforeach; ?>
        </ul>
        <p class="simple-commande-client"><i class="ph-fill ph-user"></i> <b><?= e($c['livraison_nom']) ?></b> · <?= e($c['livraison_zone']) ?></p>
        <div class="simple-contact">
          <a class="simple-petit-btn simple-petit-btn-vert" href="tel:<?= e(preg_replace('/[^\d+]/', '', (string) $c['livraison_telephone'])) ?>"><i class="ph-fill ph-phone"></i> Appeler</a>
          <?php if ($wa = simple_lien_whatsapp($c['livraison_telephone'])): ?><a class="simple-petit-btn simple-petit-btn-whatsapp" href="<?= e($wa) ?>" target="_blank" rel="noopener"><i class="ph-fill ph-whatsapp-logo"></i> WhatsApp</a><?php endif; ?>
          <?php if ($gps = bouton_itineraire($c, 'Aller chez le client')): ?><?= $gps ?><?php endif; ?>
        </div>
        <?php if ((int) $c['cadeau'] === 1): ?><p class="simple-info"><i class="ph-fill ph-gift"></i> <span><b>Cadeau</b> : pas de prix dans le colis.</span></p><?php endif; ?>
        <p class="simple-argent-ligne"><?php if ($especes): ?><i class="ph-fill ph-hand-coins"></i> Le client vous donne <b><?= e(fcfa((int) $c['sous_total'] + (int) $c['frais_part'] - (int) $c['acompte_part'])) ?></b>
          <?php else: ?><i class="ph-fill ph-coins"></i> Vous recevez <b><?= e(fcfa((int) $c['net_vendeur'] + ($c['livre_par'] === 'vendeur' ? (int) $c['frais_part'] : 0))) ?></b><?php endif; ?></p>

        <?php if (!$paye): ?>
          <p class="simple-attente"><i class="ph-fill ph-hourglass-medium"></i> <span><b>Attendez</b> : le client n'a pas encore payé. N'envoyez rien.</span></p>
        <?php elseif ($c['statut'] === 'a_preparer'): ?>
          <form method="post" data-confirm="Vous avez envoyé (ou remis au livreur) ce colis ?"><?= csrf_champ() ?><input type="hidden" name="id" value="<?= (int) $c['id'] ?>">
            <button class="simple-valider" type="submit"><i class="ph-fill ph-truck"></i> <?= $c['livre_par'] === 'jend' ? 'Colis prêt pour le livreur' : 'J\'ai envoyé le colis' ?></button></form>
        <?php elseif (!$moi): ?>
          <p class="simple-attente"><i class="ph-fill ph-motorcycle"></i> <span>Le livreur Jënd s'occupe de la livraison. Rien à faire.</span></p>
        <?php else: ?>
          <form method="post" class="simple-livree"><?= csrf_champ() ?><input type="hidden" name="id" value="<?= (int) $c['id'] ?>">
            <?php if ($c['a_code']): ?>
              <label><span><i class="ph-fill ph-key"></i> Code du client</span>
                <input type="text" name="code_livraison" inputmode="numeric" pattern="[0-9]{4}" maxlength="4" autocomplete="off" placeholder="• • • •" required></label>
            <?php endif; ?>
            <button class="simple-valider simple-valider-vert" type="submit"><i class="ph-fill ph-check-circle"></i> Le client a reçu</button>
          </form>
        <?php endif; ?>
      </article>
    <?php endforeach; ?>
    <p class="simple-bas"><a class="simple-lien" href="<?= e(url('aide')) ?>"><i class="ph ph-lifebuoy"></i> Un problème avec une commande ? Écrire à Jënd</a></p>
  </div>
</main>
<?php require __DIR__ . '/../includes/footer.php'; ?>
