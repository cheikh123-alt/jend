<?php
/**
 * Retour du client après la page de paiement.
 * IMPORTANT : le navigateur du client ne prouve rien. Une commande n'est marquée payée que par le webhook signé (simulation)
 * ou par une vérification serveur à serveur auprès de PayDunya (clé privée), jamais sur la foi de cette adresse.
 */
$u = exiger_connexion();
$c = requete('SELECT * FROM commandes WHERE reference = ? AND client_id = ?', [strtoupper($parametre), $u['id']])->fetch();
if (!$c) {
    http_response_code(404);
    require __DIR__ . '/404.php';
    return;
}
if (paydunya_actif()) {
    paydunya_verifier_commande($c);                      // appel direct à PayDunya ; sans effet si déjà réglé
    $c = requete('SELECT * FROM commandes WHERE id = ?', [$c['id']])->fetch();
}
$titre = 'Paiement — Jënd';
$etat = in_array($c['statut_paiement'], ['paye', 'acompte'], true) ? 'paye' : ($c['statut_paiement'] === 'echoue' ? 'echoue' : 'attente');
require __DIR__ . '/../includes/header.php';
?>
<main class="page">
  <div class="wrap wrap-etroit">
    <div class="confirmation">
      <?php if ($etat === 'paye'): ?>
        <i class="ph-fill ph-check-circle"></i>
        <h1 class="titre-page">Paiement reçu</h1>
        <p>Merci ! Votre commande <b><?= e($c['reference']) ?></b> est confirmée.</p>
      <?php elseif ($etat === 'echoue'): ?>
        <i class="ph-fill ph-x-circle" class="ico-primaire"></i>
        <h1 class="titre-page">Paiement refusé</h1>
        <p>Le paiement de la commande <b><?= e($c['reference']) ?></b> n'a pas abouti. Aucun montant n'a été débité.</p>
      <?php else: ?>
        <i class="ph-fill ph-hourglass-medium" class="ico-accent"></i>
        <h1 class="titre-page">Paiement en cours de vérification</h1>
        <p>Nous attendons la confirmation de votre opérateur. Cela peut prendre quelques instants : actualisez cette page, ou retrouvez votre commande dans « Mon compte ».</p>
      <?php endif; ?>
    </div>

    <div class="cta centre">
      <?php if (commande_payable($c)): ?>
        <form method="post" action="<?= e(url('paiement/' . $c['reference'])) ?>"><?= csrf_champ() ?><button class="btn btn-primaire" type="submit"><i class="ph ph-credit-card"></i> <?= $etat === 'echoue' ? 'Réessayer le paiement' : 'Reprendre le paiement' ?></button></form>
      <?php endif; ?>
      <a href="<?= e(url('commande/' . $c['reference'])) ?>" class="btn btn-contour">Voir ma commande</a>
    </div>
  </div>
</main>
<?php require __DIR__ . '/../includes/footer.php'; ?>
