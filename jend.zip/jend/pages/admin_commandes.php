<?php
exiger_admin();
$vue = in_array($_GET['vue'] ?? '', ['rembourser', 'attente'], true) ? $_GET['vue'] : 'toutes';
if (post_verifie('admin/commandes') && ($_POST['action'] ?? '') === 'verifier_paydunya') {
    // Paiements PayDunya jamais confirmés (client parti avant le retour, notification bloquée par l'hébergeur…) : on interroge PayDunya, serveur à serveur
    $cibles = (int) ($_POST['id'] ?? 0) > 0 ? [(int) $_POST['id']] : array_map('intval', requete("SELECT DISTINCT p.commande_id FROM paiements p WHERE p.fournisseur = 'paydunya' AND p.statut = 'initie' AND p.reference_externe IS NOT NULL AND p.created_at > (NOW() - INTERVAL 3 DAY) LIMIT 50")->fetchAll(PDO::FETCH_COLUMN));
    $regles = 0;
    foreach ($cibles as $cid) {
        $avant = requete('SELECT statut_paiement FROM commandes WHERE id = ?', [$cid])->fetchColumn();
        $com = requete('SELECT * FROM commandes WHERE id = ?', [$cid])->fetch();
        if ($com) {
            requete("DELETE FROM limites WHERE cle = ?", ['paydunya-verif:' . $cid]);       // une vérification demandée par l'admin n'est pas freinée
            paydunya_verifier_commande($com);
            $regles += (requete('SELECT statut_paiement FROM commandes WHERE id = ?', [$cid])->fetchColumn() !== $avant) ? 1 : 0;
        }
    }
    journaliser('paydunya_verification', count($cibles) . ' paiement(s) vérifié(s), ' . $regles . ' mis à jour');
    flash(count($cibles) . ' paiement(s) vérifié(s) auprès de PayDunya : ' . $regles . ' mis à jour.');
    rediriger('admin/commandes?vue=attente');
}
if (post_verifie('admin/commandes')) {
    $c = requete('SELECT id, reference, statut, statut_paiement FROM commandes WHERE id = ?', [(int) ($_POST['id'] ?? 0)])->fetch();
    // On ne rembourse que ce qui a été annulé après encaissement
    if ($c && ($_POST['action'] ?? '') === 'refus') {
        // Client absent ou refus à la livraison : le colis revient, l'acompte est conservé (il indemnise le vendeur / les livreurs)
        $cbId = (int) ($_POST['cb'] ?? 0);
        $pdo = pdo();
        $pdo->beginTransaction();
        $cb = requete("SELECT cb.id, cb.statut FROM commande_boutiques cb JOIN commandes c ON c.id = cb.commande_id WHERE cb.id = ? AND cb.commande_id = ? AND c.statut_paiement = 'acompte' AND cb.statut IN ('a_preparer', 'expediee') FOR UPDATE", [$cbId, $c['id']])->fetch();
        if (!$cb) {
            $pdo->rollBack();
            flash('Action impossible : cette livraison n\'a pas d\'acompte conservable ou est déjà terminée.', 'erreur');
        } else {
            stock_restituer('cl.commande_boutique_id = ?', [$cb['id']]);
            requete("UPDATE commande_boutiques SET statut = 'retournee', acompte_acquis = 1 WHERE id = ?", [$cb['id']]);
            if (!(int) requete("SELECT COUNT(*) FROM commande_boutiques WHERE commande_id = ? AND statut IN ('a_preparer', 'expediee')", [$c['id']])->fetchColumn()) {
                requete("UPDATE commandes SET statut = 'terminee' WHERE id = ?", [$c['id']]);
            }
            $pdo->commit();
            journaliser('acompte_conserve', $c['reference'] . ' (livraison #' . $cb['id'] . ')');
            $client = requete('SELECT u.email FROM users u JOIN commandes c ON c.client_id = u.id WHERE c.id = ?', [$c['id']])->fetchColumn();
            if ($client) {
                envoyer_email((string) $client, 'Livraison non aboutie (' . $c['reference'] . ')', "La livraison de votre commande {$c['reference']} n'a pas pu avoir lieu (absent, injoignable ou colis refusé). Votre acompte est conservé, comme indiqué lors de la commande.\nUne question ? Contactez-nous : " . app_url('contact'));
            }
            flash('Livraison marquée « client absent / refus » : acompte conservé, produits remis en stock.');
        }
    } elseif ($c && ($_POST['action'] ?? '') === 'rembourser' && $c['statut'] === 'annulee' && in_array($c['statut_paiement'], ['paye', 'acompte'], true)) {
        $pdo = pdo();
        $pdo->beginTransaction();
        requete("UPDATE commandes SET statut_paiement = 'rembourse' WHERE id = ?", [$c['id']]);
        requete("UPDATE paiements SET statut = 'rembourse' WHERE commande_id = ? AND statut = 'reussi'", [$c['id']]);
        $pdo->commit();
        journaliser('commande_remboursee', $c['reference']);
        flash('Commande ' . $c['reference'] . ' marquée comme remboursée.');
    } else {
        flash('Remboursement impossible pour cette commande.', 'erreur');
    }
    rediriger('admin/commandes' . ($vue === 'rembourser' ? '?vue=rembourser' : ''));
}
$where = $vue === 'rembourser' ? "WHERE c.statut = 'annulee' AND c.statut_paiement IN ('paye', 'acompte')" : '';
if ($vue === 'attente') {
    $where = "WHERE c.statut <> 'annulee' AND c.statut_paiement IN ('en_attente', 'echoue') AND EXISTS (SELECT 1 FROM paiements p WHERE p.commande_id = c.id AND p.fournisseur = 'paydunya' AND p.statut = 'initie')";
}
$commandes = requete(
    "SELECT c.id, c.reference, c.total, c.acompte, c.methode_paiement, c.statut, c.statut_paiement, c.created_at, u.nom AS client
       FROM commandes c JOIN users u ON u.id = c.client_id $where ORDER BY c.id DESC LIMIT 100"
)->fetchAll();
$refusables = [];
foreach (requete("SELECT cb.id, cb.commande_id, b.nom AS boutique FROM commande_boutiques cb JOIN boutiques b ON b.id = cb.boutique_id JOIN commandes c ON c.id = cb.commande_id WHERE c.statut_paiement = 'acompte' AND cb.statut IN ('a_preparer', 'expediee') AND c.statut <> 'annulee' ORDER BY cb.id")->fetchAll() as $r) {
    $refusables[(int) $r['commande_id']][] = $r;
}
$titre = 'Commandes — Administration';
require __DIR__ . '/../includes/header.php';
?>
<main class="page">
  <div class="wrap">
    <nav class="fil" aria-label="Fil d'Ariane"><a href="<?= e(url()) ?>">Accueil</a> / <a href="<?= e(url('admin')) ?>">Administration</a> / <span>Commandes</span></nav>
    <h1 class="titre-page">Administration</h1>
    <?php admin_onglets('commandes'); ?>
    <div class="filtres-vue">
      <a href="<?= e(url('admin/commandes')) ?>" class="<?= $vue === 'toutes' ? 'actif' : '' ?>">Toutes</a>
      <a href="<?= e(url('admin/commandes?vue=rembourser')) ?>" class="<?= $vue === 'rembourser' ? 'actif' : '' ?>">À rembourser</a>
      <?php if (paydunya_actif()): ?><a href="<?= e(url('admin/commandes?vue=attente')) ?>" class="<?= $vue === 'attente' ? 'actif' : '' ?>">Paiements PayDunya en attente</a><?php endif; ?>
    </div>
    <?php if ($vue === 'attente'): ?>
      <p class="doux">Commandes dont le paiement PayDunya a été lancé mais pas encore confirmé (client parti avant le retour, notification bloquée…). « Vérifier » interroge PayDunya directement : rien n'est cru sans leur confirmation.</p>
      <form method="post" class="mb1"><?= csrf_champ() ?><input type="hidden" name="action" value="verifier_paydunya"><input type="hidden" name="id" value="0"><button class="btn btn-primaire" type="submit"><i class="ph ph-arrows-clockwise"></i> Tout vérifier maintenant</button></form>
    <?php endif; ?>
    <?php if (!$commandes): ?><div class="vide"><i class="ph ph-receipt"></i><p><b>Aucune commande.</b></p></div><?php else: ?>
    <div class="table-defile"><table class="table">
      <thead><tr><th>Référence</th><th>Client</th><th>Date</th><th>Total</th><th>Paiement</th><th>Statut</th><th></th></tr></thead>
      <tbody>
      <?php foreach ($commandes as $c): ?>
        <tr>
          <td><a class="lien" href="<?= e(url('commande/' . $c['reference'])) ?>"><?= e($c['reference']) ?></a></td>
          <td><?= e($c['client']) ?></td><td><?= e(date('d/m/Y', strtotime($c['created_at']))) ?></td><td><b><?= e(fcfa((int) $c['total'])) ?></b></td>
          <td><?= e(MOYENS_PAIEMENT[$c['methode_paiement']][0]) ?> · <span class="doux"><?= e(STATUTS_PAIEMENT[$c['statut_paiement']]) ?></span></td>
          <td><span class="badge badge-<?= e($c['statut']) ?>"><?= e(STATUTS_COMMANDE[$c['statut']]) ?></span></td>
          <td><?php if ($vue === 'attente'): ?><form method="post"><?= csrf_champ() ?><input type="hidden" name="action" value="verifier_paydunya"><input type="hidden" name="id" value="<?= (int) $c['id'] ?>"><button class="btn btn-contour" type="submit">Vérifier</button></form><?php endif; ?>
          <?php if ($c['statut'] === 'annulee' && in_array($c['statut_paiement'], ['paye', 'acompte'], true)): ?>
            <form method="post" data-confirm="Confirmer que le client a été remboursé ?"><?= csrf_champ() ?><input type="hidden" name="id" value="<?= (int) $c['id'] ?>"><input type="hidden" name="action" value="rembourser"><button class="btn btn-contour" type="submit">Marquer remboursée<?= $c['statut_paiement'] === 'acompte' ? ' (' . e(fcfa((int) $c['acompte'])) . ')' : '' ?></button></form>
          <?php endif; ?>
          <?php foreach ($refusables[(int) $c['id']] ?? [] as $r): ?>
            <form method="post" data-confirm="Le client était absent ou a refusé le colis ? L'acompte sera conservé et les produits remis en stock."><?= csrf_champ() ?><input type="hidden" name="id" value="<?= (int) $c['id'] ?>"><input type="hidden" name="cb" value="<?= (int) $r['id'] ?>"><input type="hidden" name="action" value="refus"><button class="btn btn-contour" type="submit">Client absent / refus — <?= e($r['boutique']) ?></button></form>
          <?php endforeach; ?></td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table></div>
    <?php endif; ?>
  </div>
</main>
<?php require __DIR__ . '/../includes/footer.php'; ?>
