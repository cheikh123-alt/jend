<?php
// robots.txt dynamique : un site de test s'interdit à tous les moteurs de recherche ; en production on protège les zones privées.
header('Content-Type: text/plain; charset=UTF-8');
if (est_test()) {
    echo "User-agent: *\nDisallow: /\n";
    return;
}
echo "User-agent: *\n";
foreach (['admin', 'compte', 'panier', 'commande', 'vendeur', 'livreur', 'paiement', 'connexion', 'inscription', 'favoris', 'reinitialiser', 'mot-de-passe-oublie'] as $zone) {
    echo "Disallow: /$zone\n";
}
echo "Allow: /\n";
