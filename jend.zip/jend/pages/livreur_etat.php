<?php
// État léger des courses du livreur connecté (interrogé toutes les 30 s par l'appli pour signaler les nouvelles courses).
[$u, $l] = exiger_livreur();
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
echo json_encode(['ids' => courses_actives_ids((int) $u['id'])]);
