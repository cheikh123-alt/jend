<?php
exiger_admin();
if (!livreurs_jend_actifs()) {
    flash('Les livreurs Jënd ne sont pas activés (Administration → Paramètres).', 'erreur');
    rediriger('admin/parametres');
}

if (post_verifie('admin/caisse')) {
    $action = $_POST['action'] ?? '';
    $adminId = (int) utilisateur()['id'];
    if ($action === 'remise') {
        $lid = (int) ($_POST['livreur_id'] ?? 0);
        $mt = trim((string) ($_POST['montant'] ?? ''));
        $note = mb_substr(trim((string) ($_POST['note'] ?? '')), 0, 190);
        if (!requete("SELECT 1 FROM users WHERE id = ? AND role = 'livreur'", [$lid])->fetch()) {
            flash('Livreur introuvable.', 'erreur');
        } elseif (!ctype_digit($mt) || (int) $mt < 1 || (int) $mt > livreur_especes($lid)['a_remettre']) {
            flash('Montant invalide : entier, supérieur à 0 et au plus égal à ce que le livreur doit remettre.', 'erreur');
        } else {
            requete('INSERT INTO caisse_livreurs (livreur_id, montant, note, admin_id) VALUES (?, ?, ?, ?)', [$lid, (int) $mt, $note !== '' ? $note : null, $adminId]);
            journaliser('caisse_remise', 'livreur #' . $lid . ' : ' . (int) $mt . ' FCFA');
            flash('Remise de ' . fcfa((int) $mt) . ' enregistrée.');
        }
    } elseif ($action === 'annuler') {
        $id = (int) ($_POST['id'] ?? 0);
        $r = requete('SELECT livreur_id, montant FROM caisse_livreurs WHERE id = ?', [$id])->fetch();
        if ($r) {
            requete('DELETE FROM caisse_livreurs WHERE id = ?', [$id]);
            journaliser('caisse_remise_annulee', 'livreur #' . $r['livreur_id'] . ' : ' . $r['montant'] . ' FCFA');
            flash('Remise annulée.');
        }
    }
    rediriger('admin/caisse');
}

$especes = livreur_especes();
$livreurs = requete("SELECT id, nom, telephone FROM users WHERE role = 'livreur' ORDER BY nom")->fetchAll();
$historique = requete('SELECT c.*, u.nom FROM caisse_livreurs c JOIN users u ON u.id = c.livreur_id ORDER BY c.id DESC LIMIT 50')->fetchAll();
$totalARemettre = array_sum(array_column($especes, 'a_remettre'));
$titre = 'Caisse des livreurs — Administration';
require __DIR__ . '/../includes/header.php';
?>
<main class="page">
  <div class="wrap">
    <nav class="fil" aria-label="Fil d'Ariane"><a href="<?= e(url()) ?>">Accueil</a> / <a href="<?= e(url('admin')) ?>">Administration</a> / <span>Caisse</span></nav>
    <h1 class="titre-page">Administration</h1>
    <?php admin_onglets('caisse'); ?>
    <p class="doux">Les livreurs Jënd encaissent les espèces des clients. Ils te les remettent : enregistre ici chaque remise pour savoir qui te doit encore de l'argent. Total à récupérer : <b><?= e(fcfa($totalARemettre)) ?></b>.</p>

    <section class="carte-param">
      <h2><i class="ph ph-hand-coins"></i> Espèces par livreur</h2>
      <?php if (!$livreurs): ?><p class="doux">Aucun livreur.</p><?php else: ?>
      <div class="table-defile"><table class="table"><thead><tr><th>Livreur</th><th>Encaissé</th><th>Remis</th><th>À remettre</th><th>Enregistrer une remise</th></tr></thead><tbody>
      <?php foreach ($livreurs as $l): $s = $especes[(int) $l['id']] ?? ['encaisse' => 0, 'remis' => 0, 'a_remettre' => 0]; ?>
        <tr>
          <td><?= e($l['nom']) ?></td>
          <td><?= e(fcfa($s['encaisse'])) ?></td>
          <td><?= e(fcfa($s['remis'])) ?></td>
          <td><b><?= e(fcfa($s['a_remettre'])) ?></b></td>
          <td><?php if ($s['a_remettre'] > 0): ?>
            <form method="post" class="ligne-action"><?= csrf_champ() ?><input type="hidden" name="action" value="remise"><input type="hidden" name="livreur_id" value="<?= (int) $l['id'] ?>">
              <input type="text" name="montant" value="<?= (int) $s['a_remettre'] ?>" inputmode="numeric" class="largeur-120" aria-label="Montant remis">
              <input type="text" name="note" maxlength="190" placeholder="Note (facultatif)" aria-label="Note">
              <button class="btn btn-contour" type="submit">Enregistrer</button></form>
          <?php else: ?><span class="doux">—</span><?php endif; ?></td>
        </tr>
      <?php endforeach; ?>
      </tbody></table></div>
      <?php endif; ?>
    </section>

    <section class="carte-param">
      <h2><i class="ph ph-clock-counter-clockwise"></i> Dernières remises</h2>
      <?php if (!$historique): ?><p class="doux">Aucune remise enregistrée.</p><?php else: ?>
      <div class="table-defile"><table class="table"><thead><tr><th>Date</th><th>Livreur</th><th>Montant</th><th>Note</th><th></th></tr></thead><tbody>
      <?php foreach ($historique as $h): ?>
        <tr><td><?= e(date('d/m/Y H:i', strtotime($h['created_at']))) ?></td><td><?= e($h['nom']) ?></td><td><?= e(fcfa((int) $h['montant'])) ?></td><td><?= e((string) $h['note']) ?></td>
          <td><form method="post" data-confirm="Annuler cette remise ?"><?= csrf_champ() ?><input type="hidden" name="action" value="annuler"><input type="hidden" name="id" value="<?= (int) $h['id'] ?>"><button class="lien lien-danger" type="submit">Annuler</button></form></td></tr>
      <?php endforeach; ?>
      </tbody></table></div>
      <?php endif; ?>
    </section>
  </div>
</main>
<?php require __DIR__ . '/../includes/footer.php'; ?>
