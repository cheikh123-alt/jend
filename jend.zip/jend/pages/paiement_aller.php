<?php
/**
 * Page relais vers la page de paiement d'un prestataire dont l'adresse n'est pas prévue par la politique de sécurité,
 * ou vers une application (Wave, Max It / Orange Money). L'adresse vient de NOTRE serveur (session), jamais de l'URL.
 */
$u = exiger_connexion();
$c = requete('SELECT * FROM commandes WHERE reference = ? AND client_id = ?', [strtoupper((string) $parametre), $u['id']])->fetch();
$adresse = $c ? (string) ($_SESSION['paiement_relais'][$c['reference']] ?? '') : '';
if (!$c || $adresse === '') {
    rediriger($c ? 'commande/' . $c['reference'] : 'compte');
}
$titre = 'Paiement — Jënd';
$scripts_extra = ['js/paiement-aller.js'];
require __DIR__ . '/../includes/header.php';
?>
<main class="page">
  <div class="wrap wrap-etroit centre-texte">
    <h1 class="titre-page">Paiement de votre commande</h1>
    <p>Commande <b><?= e($c['reference']) ?></b> · <b><?= e(fcfa(commande_a_payer($c))) ?></b></p>
    <p class="doux">Vous allez être dirigé vers <b><?= e(MOYENS_PAIEMENT[commande_methode_en_ligne($c) ?? '']['0'] ?? 'votre application de paiement') ?></b> pour confirmer le paiement.</p>
    <p><a class="btn btn-primaire" id="paiement-aller" href="<?= e($adresse) ?>" rel="noopener noreferrer"><i class="ph ph-credit-card"></i> Ouvrir la page de paiement</a></p>
    <p class="doux petit">Rien ne s'ouvre ? Touchez le bouton. Une fois le paiement confirmé, revenez sur <a class="lien" href="<?= e(url('commande/' . $c['reference'])) ?>">votre commande</a> : elle passera à « payée » dès que le prestataire nous l'aura confirmé.</p>
  </div>
</main>
<?php require __DIR__ . '/../includes/footer.php'; ?>
