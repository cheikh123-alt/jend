<?php
/**
 * Commissions dues par les vendeurs (ventes payées en espèces à la livraison : Jënd n'a pas touché l'argent).
 * L'administrateur indique le numéro Wave / Orange Money où les vendeurs paient, les relance sur WhatsApp,
 * et enregistre chaque règlement reçu (il ne peut jamais dépasser ce que le vendeur doit).
 */
$admin = exiger_admin();
if (post_verifie('admin/commissions')) {
    $action = (string) ($_POST['action'] ?? '');
    if ($action === 'numero') {
        $saisi = trim((string) ($_POST['numero'] ?? ''));
        $tel = $saisi === '' ? '' : telephone_valide($saisi);
        if ($tel === null) {
            flash('Numéro invalide (ex : 77 123 45 67).', 'erreur');
        } else {
            parametre_definir('reglement_numero', (string) $tel);
            journaliser('reglement_numero', $tel !== '' ? 'numéro défini' : 'numéro retiré');
            flash($tel !== '' ? 'Numéro enregistré : il est affiché aux vendeurs qui doivent une commission.' : 'Numéro retiré.');
        }
    } elseif ($action === 'reglement') {
        try {
            $bid = (int) ($_POST['boutique_id'] ?? 0);
            $montant = (int) preg_replace('/\D/', '', (string) ($_POST['montant'] ?? ''));
            reglement_enregistrer($bid, $montant, (string) ($_POST['methode'] ?? ''), (string) ($_POST['reference'] ?? ''), (int) $admin['id']);
            $nom = (string) requete('SELECT nom FROM boutiques WHERE id = ?', [$bid])->fetchColumn();
            journaliser('commission_reglee', $nom . ' : ' . $montant . ' FCFA (' . (METHODES_REGLEMENT[$_POST['methode']] ?? '') . ')');
            flash('Règlement de ' . fcfa($montant) . ' enregistré pour « ' . $nom . ' ». Le vendeur le voit dans son espace et dans son relevé.');
        } catch (RuntimeException $e) {
            flash($e->getMessage(), 'erreur');
        }
    }
    rediriger('admin/commissions');
}
$liste = vendeurs_endettes();
$total = array_sum(array_column($liste, 'dette'));
$historique = requete('SELECT r.created_at, r.montant, r.methode, r.reference, b.nom AS boutique FROM reglements_commission r JOIN boutiques b ON b.id = r.boutique_id ORDER BY r.id DESC LIMIT 30')->fetchAll();
$numero = reglement_numero();
$plafond = (int) parametre('dette_commission_max', '20000');
$titre = 'Commissions dues — Administration';
require __DIR__ . '/../includes/header.php';
?>
<main class="page">
  <div class="wrap">
    <nav class="fil" aria-label="Fil d'Ariane"><a href="<?= e(url()) ?>">Accueil</a> / <a href="<?= e(url('admin')) ?>">Administration</a> / <span>Commissions dues</span></nav>
    <h1 class="titre-page">Administration</h1>
    <?php admin_onglets('commissions'); ?>
    <p class="doux">Quand un client paie <b>en espèces</b> au vendeur, Jënd ne touche pas l'argent : ta commission devient une <b>dette du vendeur</b>. Avec le paiement en ligne, elle est retenue sur ses gains suivants ; sinon, il te la règle par Wave ou Orange Money. Au-delà de <b><?= e(fcfa($plafond)) ?></b> dus, ses commandes en espèces sont suspendues jusqu'au règlement (<a class="lien" href="<?= e(url('admin/parametres')) ?>">plafond réglable</a>).</p>

    <section class="carte-param <?= $numero ? 'param-actif' : '' ?>">
      <h2><i class="ph ph-device-mobile"></i> Numéro où les vendeurs paient leur commission</h2>
      <p>Ton numéro Wave ou Orange Money <b>professionnel</b>. Il est montré aux vendeurs qui te doivent une commission, avec les instructions et un bouton « J'ai payé : prévenir Jënd ».</p>
      <form method="post" class="ligne-action"><?= csrf_champ() ?><input type="hidden" name="action" value="numero">
        <label class="sr" for="rn">Numéro</label><input id="rn" type="tel" name="numero" value="<?= e((string) $numero) ?>" placeholder="77 123 45 67" class="largeur-180">
        <button class="btn btn-contour" type="submit">Enregistrer</button></form>
      <?php if (!$numero): ?><p class="alerte"><i class="ph ph-warning-circle"></i> <span>Aucun numéro : les vendeurs voient seulement qu'ils te doivent une commission, sans savoir où la payer.</span></p><?php endif; ?>
    </section>

    <h2 class="sous-titre">Vendeurs qui doivent une commission <?= $liste ? '· total ' . e(fcfa($total)) : '' ?></h2>
    <?php if (!$liste): ?>
      <div class="vide"><i class="ph ph-check-circle"></i><p><b>Aucune commission en attente.</b></p></div>
    <?php endif; ?>
    <div class="relances">
      <?php foreach ($liste as $v):
          $tel = $v['contact_whatsapp'] ?: ($v['telephone'] ?: $v['telephone_paiement']);
          $wa = simple_lien_whatsapp($tel); ?>
        <article class="relance">
          <header><b><?= e($v['nom']) ?></b> <span class="doux">· <?= e($v['vendeur']) ?></span>
            <span class="badge <?= $plafond > 0 && $v['dette'] > $plafond ? 'badge-litige-ouvert' : 'badge-a_preparer' ?>"><?= e(fcfa((int) $v['dette'])) ?></span></header>
          <p class="petit doux"><?= $plafond > 0 && $v['dette'] > $plafond ? '<b>Commandes en espèces suspendues</b> (au-delà de ' . e(fcfa($plafond)) . ') · ' : '' ?><?= $v['dernier_reglement'] ? 'Dernier règlement le ' . e(date('d/m/Y', strtotime((string) $v['dernier_reglement']))) : 'Aucun règlement pour l\'instant' ?></p>
          <div class="relance-actions">
            <?php if ($wa): ?><a class="btn btn-whatsapp" href="<?= e($wa . '?text=' . rawurlencode(reglement_message_relance($v))) ?>" target="_blank" rel="noopener"><i class="ph-fill ph-whatsapp-logo"></i> Rappeler sur WhatsApp</a><?php endif; ?>
            <?php if ($tel): ?><a class="btn btn-contour" href="tel:<?= e(preg_replace('/[^\d+]/', '', (string) $tel)) ?>"><i class="ph ph-phone"></i> Appeler</a><?php endif; ?>
          </div>
          <form method="post" class="ligne-action reglement-form" data-confirm="Enregistrer ce règlement ? Vérifie d'abord que l'argent est bien arrivé sur ton compte."><?= csrf_champ() ?>
            <input type="hidden" name="action" value="reglement"><input type="hidden" name="boutique_id" value="<?= (int) $v['id'] ?>">
            <label class="sr" for="m<?= (int) $v['id'] ?>">Montant reçu</label><input id="m<?= (int) $v['id'] ?>" type="text" name="montant" inputmode="numeric" value="<?= (int) $v['dette'] ?>" class="largeur-90"> FCFA
            <label class="sr" for="p<?= (int) $v['id'] ?>">Reçu par</label><select id="p<?= (int) $v['id'] ?>" name="methode"><?php foreach (METHODES_REGLEMENT as $k => $l): ?><option value="<?= e($k) ?>"><?= e($l) ?></option><?php endforeach; ?></select>
            <label class="sr" for="r<?= (int) $v['id'] ?>">Référence</label><input id="r<?= (int) $v['id'] ?>" type="text" name="reference" maxlength="60" placeholder="Référence du transfert">
            <button class="btn btn-primaire" type="submit"><i class="ph ph-check"></i> Règlement reçu</button>
          </form>
        </article>
      <?php endforeach; ?>
    </div>

    <?php if ($historique): ?>
      <h2 class="sous-titre">Derniers règlements reçus</h2>
      <div class="table-defile"><table class="table">
        <thead><tr><th>Date</th><th>Boutique</th><th>Montant</th><th>Par</th><th>Référence</th></tr></thead>
        <tbody><?php foreach ($historique as $h): ?>
          <tr><td><?= e(date('d/m/Y H:i', strtotime((string) $h['created_at']))) ?></td><td><?= e($h['boutique']) ?></td><td><b><?= e(fcfa((int) $h['montant'])) ?></b></td><td><?= e(METHODES_REGLEMENT[$h['methode']] ?? $h['methode']) ?></td><td><?= e((string) ($h['reference'] ?? '—')) ?></td></tr>
        <?php endforeach; ?></tbody>
      </table></div>
    <?php endif; ?>
  </div>
</main>
<?php require __DIR__ . '/../includes/footer.php'; ?>
