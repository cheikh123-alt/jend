<?php
/** Le vendeur enregistre son numéro WhatsApp public (rappel de l'accueil) : ses clients peuvent alors le prévenir de leurs commandes. */
[$u, $b] = exiger_vendeur();
$retour = simple_actif($b) ? 'simple' : 'vendeur';
if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !csrf_valide($_POST['csrf'] ?? null)) {
    rediriger($retour);
}
$tel = telephone_valide(trim((string) ($_POST['contact_whatsapp'] ?? '')));
if ($tel === null) {
    flash('Numéro WhatsApp invalide (ex : 77 123 45 67).', 'erreur');
} else {
    requete('UPDATE boutiques SET contact_whatsapp = ? WHERE id = ?', [$tel, $b['id']]);
    flash('✅ Numéro WhatsApp enregistré : vos clients pourront vous prévenir de leurs commandes.');
}
rediriger($retour);
