<?php
/** Suivi d'un signalement. $parametre = référence (LIT-XXXXXXXX). Visible par son auteur et par l'administrateur. */
$u = exiger_connexion();
$lit = requete('SELECT * FROM litiges WHERE reference = ?', [strtoupper($parametre)])->fetch();
if (!$lit || ((int) $lit['client_id'] !== (int) $u['id'] && $u['role'] !== 'admin')) {
    http_response_code(404);
    require __DIR__ . '/404.php';
    return;
}
$auteur = (int) $lit['client_id'] === (int) $u['id'];
if ($auteur && post_verifie('litige/' . $lit['reference'])) {
    try {
        litige_message_client((int) $lit['id'], (int) $u['id'], (string) ($_POST['message'] ?? ''));
        flash('Votre message a été ajouté au dossier. L\'équipe Jënd en est informée.');
    } catch (RuntimeException $e) {
        flash($e->getMessage(), 'erreur');
    }
    rediriger('litige/' . $lit['reference']);
}

$l = litige_livraison((int) $lit['commande_boutique_id']);
$photos = requete('SELECT id FROM litige_photos WHERE litige_id = ? ORDER BY id', [$lit['id']])->fetchAll();
$evenements = litige_evenements((int) $lit['id']);
$clos = litige_clos($lit);
$vueEquipe = !$auteur;
$nomClient = (string) requete('SELECT nom FROM users WHERE id = ?', [$lit['client_id']])->fetchColumn();
$concerne = (int) $l['sous_total'];
$titre = 'Signalement ' . $lit['reference'] . ' — Jënd';
require __DIR__ . '/../includes/header.php';
?>
<main class="page">
  <div class="wrap">
    <nav class="fil" aria-label="Fil d'Ariane"><a href="<?= e(url($auteur ? 'litiges' : 'admin/litiges')) ?>"><?= $auteur ? 'Mes signalements' : 'Signalements' ?></a> / <span><?= e($lit['reference']) ?></span></nav>

    <header class="lit-entete">
      <div>
        <p class="lit-surtitre">Dossier de signalement</p>
        <h1 class="titre-page"><?= e($lit['reference']) ?></h1>
        <p class="doux">Ouvert le <?= e(date('d/m/Y à H:i', strtotime($lit['created_at']))) ?> · <?= e(MOTIFS_LITIGE[$lit['motif']]) ?></p>
      </div>
      <span class="badge badge-grand badge-litige-<?= e($lit['statut']) ?>"><?= e(STATUTS_LITIGE[$lit['statut']]) ?></span>
    </header>

    <?php $partie = 'avancement'; require __DIR__ . '/../includes/litige_suivi.php'; ?>

    <div class="lit-grille">
      <div class="lit-principal">
        <?php if ($auteur && !$clos): ?>
          <form method="post" class="formulaire formulaire-large lit-repondre" novalidate>
            <?= csrf_champ() ?>
            <label class="champ"><span>Ajouter une précision à votre dossier</span>
              <textarea name="message" rows="4" minlength="5" maxlength="2000" required placeholder="Ex. : le vendeur m'a appelé, voici ce qu'il propose…"></textarea></label>
            <button class="btn btn-primaire" type="submit"><i class="ph ph-paper-plane-tilt"></i> Envoyer à l'équipe</button>
          </form>
        <?php elseif ($u['role'] === 'admin'): ?>
          <p><a class="btn btn-primaire" href="<?= e(url('admin/litiges?id=' . $lit['id'])) ?>"><i class="ph ph-gavel"></i> Traiter ce signalement</a></p>
        <?php endif; ?>
        <?php $partie = 'chronologie'; require __DIR__ . '/../includes/litige_suivi.php'; ?>
      </div>

      <aside class="lit-cote">
        <div class="lit-carte lit-carte-suite">
          <h2><i class="ph ph-signpost"></i> Prochaine étape</h2>
          <p><?= e(litige_prochaine_etape($lit)) ?></p>
        </div>

        <div class="lit-carte">
          <h2><i class="ph ph-folder-open"></i> Le dossier</h2>
          <dl class="lit-infos">
            <dt>Commande</dt><dd><a class="lien" href="<?= e(url('commande/' . $l['commande_ref'])) ?>"><?= e($l['commande_ref']) ?></a></dd>
            <dt>Boutique</dt><dd><?= e($l['boutique']) ?></dd>
            <dt>Motif</dt><dd><?= e(MOTIFS_LITIGE[$lit['motif']]) ?></dd>
            <dt>Montant des produits</dt><dd><?= e(fcfa($concerne)) ?></dd>
            <?php if ($lit['statut'] === 'rembourse'): ?>
              <dt>Remboursement</dt><dd><b><?= e(fcfa((int) $lit['montant_rembourse'])) ?></b> · <?= $lit['rembourse_le'] ? 'envoyé le ' . e(date('d/m/Y', strtotime($lit['rembourse_le']))) : 'en cours d\'envoi' ?></dd>
            <?php endif; ?>
          </dl>
        </div>

        <div class="lit-carte">
          <h2><i class="ph ph-note"></i> Description initiale</h2>
          <p><?= nl2br(e($lit['description'])) ?></p>
          <?php if ($photos): ?><div class="photos-litige"><?php foreach ($photos as $ph): ?><a href="<?= e(url('litige/photo/' . $ph['id'])) ?>" target="_blank" rel="noopener"><img src="<?= e(url('litige/photo/' . $ph['id'])) ?>" alt="Photo jointe au signalement" loading="lazy"></a><?php endforeach; ?></div><?php endif; ?>
        </div>

        <p class="petit doux lit-garantie"><i class="ph ph-shield-check"></i> Tant que le dossier est ouvert, l'argent de cette livraison reste bloqué par Jënd : le vendeur ne peut pas le retirer.</p>
      </aside>
    </div>
  </div>
</main>
<?php require __DIR__ . '/../includes/footer.php'; ?>
