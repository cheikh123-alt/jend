<?php
/** Passer du mode simple au mode complet de l'espace vendeur (et inversement). */
[$u, $b] = exiger_vendeur();
if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !csrf_valide($_POST['csrf'] ?? null)) {
    rediriger(simple_actif($b) ? 'simple' : 'vendeur');
}
$simple = ($_POST['mode'] ?? '') === 'simple';
simple_mode_changer((int) $b['id'], $simple);
flash($simple ? 'Mode simple activé.' : 'Mode complet activé. Vous pouvez revenir au mode simple depuis votre tableau de bord.');
rediriger($simple ? 'simple' : 'vendeur');
