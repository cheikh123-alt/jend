<?php
/** « Spécial fêtes » : l'administrateur programme les fêtes (dates à saisir chaque année : calendrier lunaire). */
exiger_admin();

if (post_verifie('admin/fetes')) {
    $id = (int) ($_POST['id'] ?? 0) ?: null;
    try {
        if (($_POST['action'] ?? '') === 'supprimer' && $id) {
            requete('DELETE FROM fetes WHERE id = ?', [$id]);
            journaliser('fete_supprimer', '#' . $id);
            flash('Fête supprimée.');
        } else {
            $id = fete_enregistrer($id, (string) ($_POST['nom'] ?? ''), (string) ($_POST['date_fete'] ?? ''), (string) ($_POST['date_limite'] ?? ''),
                (string) ($_POST['vitrine_des'] ?? ''), (string) ($_POST['texte'] ?? ''), !empty($_POST['actif']));
            journaliser('fete_enregistrer', '#' . $id . ' ' . mb_substr((string) $_POST['nom'], 0, 60));
            flash('Fête enregistrée.');
        }
    } catch (RuntimeException $e) {
        flash($e->getMessage(), 'erreur');
    }
    rediriger('admin/fetes');
}

$edit = isset($_GET['id']) ? (requete('SELECT * FROM fetes WHERE id = ?', [(int) $_GET['id']])->fetch() ?: null) : null;
$fetes = requete(
    'SELECT f.*, (SELECT COUNT(*) FROM produit_fetes pf WHERE pf.fete_id = f.id) AS nb_produits,
            (SELECT COUNT(DISTINCT p.boutique_id) FROM produit_fetes pf JOIN produits p ON p.id = pf.produit_id WHERE pf.fete_id = f.id) AS nb_boutiques
       FROM fetes f ORDER BY f.date_fete < CURDATE(), f.date_fete'
)->fetchAll();
$titre = 'Fêtes — Administration';
require __DIR__ . '/../includes/header.php';
?>
<main class="page">
  <div class="wrap">
    <nav class="fil" aria-label="Fil d'Ariane"><a href="<?= e(url()) ?>">Accueil</a> / <a href="<?= e(url('admin')) ?>">Administration</a> / <span>Fêtes</span></nav>
    <h1 class="titre-page">Administration</h1>
    <?php admin_onglets('fetes'); ?>
    <p class="doux">Programme ici les grandes fêtes (Magal, Tabaski, Korité, Gamou…). <b>Les dates changent chaque année</b> (calendrier lunaire) : saisis la date officielle une fois annoncée. Les vendeurs y rattachent leurs produits, et une vitrine « Spécial » s'affiche sur l'accueil à partir de la date de début.</p>

    <div class="deux-colonnes">
      <section>
        <h2 class="sous-titre">Fêtes programmées</h2>
        <?php if (!$fetes): ?>
          <div class="vide"><i class="ph ph-confetti"></i><p><b>Aucune fête programmée.</b></p></div>
        <?php else: ?>
          <ul class="tb-liste">
            <?php foreach ($fetes as $f): $passee = $f['date_fete'] < date('Y-m-d'); ?>
              <li>
                <span><b><?= e($f['nom']) ?></b> · <?= e(date_longue_fr($f['date_fete'])) ?>
                  <?php if ($passee): ?><span class="badge">Passée</span><?php elseif (!$f['actif']): ?><span class="badge">Masquée</span><?php elseif ($f['vitrine_des'] <= date('Y-m-d')): ?><span class="badge badge-litige-rembourse">En vitrine</span><?php else: ?><span class="badge badge-litige-ouvert">Vitrine le <?= e(date('d/m', strtotime($f['vitrine_des']))) ?></span><?php endif; ?>
                  <br><small class="doux"><?= (int) $f['nb_produits'] ?> produit(s) de <?= (int) $f['nb_boutiques'] ?> boutique(s)<?= $f['date_limite'] ? ' · commandes avant le ' . e(date('d/m', strtotime($f['date_limite']))) : '' ?></small></span>
                <span class="zone-actions">
                  <a class="btn btn-contour" href="<?= e(url('admin/fetes?id=' . $f['id'])) ?>">Modifier</a>
                  <?php if ($f['actif'] && !$passee): ?><a class="btn btn-contour" href="<?= e(url('fete/' . $f['slug'])) ?>">Voir</a><?php endif; ?>
                </span>
              </li>
            <?php endforeach; ?>
          </ul>
        <?php endif; ?>
      </section>

      <form method="post" class="formulaire formulaire-large" novalidate>
        <?= csrf_champ() ?>
        <?php if ($edit): ?><input type="hidden" name="id" value="<?= (int) $edit['id'] ?>"><?php endif; ?>
        <h2 class="sous-titre"><?= $edit ? 'Modifier « ' . e($edit['nom']) . ' »' : 'Programmer une fête' ?></h2>
        <label class="champ"><span>Nom de la fête</span>
          <input name="nom" list="fetes-suggerees" maxlength="80" required value="<?= e($edit['nom'] ?? '') ?>">
          <datalist id="fetes-suggerees"><?php foreach (FETES_SUGGEREES as $s): ?><option value="<?= e($s) ?>"><?php endforeach; ?></datalist></label>
        <label class="champ"><span>Date de la fête (date officielle annoncée)</span><input type="date" name="date_fete" required value="<?= e($edit['date_fete'] ?? '') ?>"></label>
        <label class="champ"><span>Commander au plus tard le (facultatif : pour être livré avant la fête)</span><input type="date" name="date_limite" value="<?= e($edit['date_limite'] ?? '') ?>"></label>
        <label class="champ"><span>Afficher la vitrine à partir du (vide : 3 semaines avant)</span><input type="date" name="vitrine_des" value="<?= e($edit['vitrine_des'] ?? '') ?>"></label>
        <label class="champ"><span>Texte de présentation (facultatif)</span><textarea name="texte" rows="3" maxlength="300"><?= e($edit['texte'] ?? '') ?></textarea></label>
        <label class="case"><input type="checkbox" name="actif" value="1" <?= !$edit || $edit['actif'] ? 'checked' : '' ?>> <span>Visible (vitrine et choix des produits par les vendeurs)</span></label>
        <div class="zone-actions">
          <button class="btn btn-primaire" type="submit"><?= $edit ? 'Enregistrer' : 'Programmer la fête' ?></button>
          <?php if ($edit): ?>
            <a class="btn btn-contour" href="<?= e(url('admin/fetes')) ?>">Annuler</a>
            <button class="btn btn-contour" type="submit" name="action" value="supprimer" data-confirm="Supprimer cette fête ? Les produits ne sont pas supprimés, seulement leur rattachement.">Supprimer</button>
          <?php endif; ?>
        </div>
      </form>
    </div>
  </div>
</main>
<?php require __DIR__ . '/../includes/footer.php'; ?>
