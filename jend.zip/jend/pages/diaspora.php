<?php
/** « Envoyer à ma famille » : page de présentation pour les Sénégalais de l'extérieur (et tous ceux qui offrent à un proche). */
$titre = 'Envoyer un cadeau à ma famille au Sénégal — Jënd';
$description = 'Depuis l\'étranger, offrez à vos proches au Sénégal : ils reçoivent le colis, vous gardez la preuve de remise. Paiement protégé jusqu\'à la réception.';
$fete = fete_en_vitrine();
require __DIR__ . '/../includes/header.php';
?>
<main class="page">
  <section class="fete-affiche diaspora-affiche">
    <div class="wrap">
      <p class="fete-surtitre"><i class="ph ph-airplane-tilt"></i> Pour la famille au pays</p>
      <h1>Offrez directement le produit, pas seulement l'argent.</h1>
      <p class="fete-texte">De Paris, Milan, Madrid ou New York, choisissez un produit dans une boutique sénégalaise : il est livré à votre proche, et vous êtes prévenu dès qu'il l'a reçu.</p>
      <p class="cta"><a class="btn btn-primaire" href="<?= e(url('produits')) ?>">Choisir un cadeau <i class="ph ph-arrow-right"></i></a>
        <?php if ($fete): ?> <a class="btn btn-contour diaspora-contour" href="<?= e(url('fete/' . $fete['slug'])) ?>"><i class="ph ph-confetti"></i> Spécial <?= e($fete['nom']) ?></a><?php endif; ?></p>
    </div>
  </section>
  <div class="wrap wrap-moyen">
    <h2 class="sous-titre">Comment ça marche</h2>
    <ol class="diaspora-etapes">
      <li><i class="ph ph-shopping-cart"></i><div><b>Choisissez et commandez</b><p>Au moment de commander, ouvrez « C'est pour un proche ? », cochez la case et ajoutez un petit mot. Indiquez le nom, le téléphone et l'adresse de votre proche.</p></div></li>
      <li><i class="ph ph-lock-key"></i><div><b>Payez en ligne</b><p>L'argent est gardé par Jënd : le vendeur n'est payé qu'après la remise du colis.</p></div></li>
      <li><i class="ph ph-whatsapp-logo"></i><div><b>Envoyez le code à votre proche</b><p>Depuis votre commande, un bouton prépare le message WhatsApp avec le code de réception.</p></div></li>
      <li><i class="ph ph-gift"></i><div><b>Votre proche reçoit son cadeau</b><p>Sans prix ni facture dans le colis. Il vérifie, donne le code au livreur, et vous recevez un e-mail : « Votre cadeau a été remis ».</p></div></li>
    </ol>
    <div class="lit-carte">
      <h2><i class="ph ph-shield-check"></i> En cas de problème</h2>
      <p>Colis non reçu, abîmé ou différent de l'annonce : signalez-le depuis votre commande pendant <?= LITIGE_DELAI_SIGNALEMENT_JOURS ?> jours après la livraison. Notre équipe répond sous <?= LITIGE_DELAI_REPONSE_HEURES ?> h, et vous suivez votre dossier en ligne.</p>
    </div>
    <p class="petit doux">Moyens de paiement proposés : <?= e(implode(', ', array_map(fn ($m) => MOYENS_PAIEMENT[$m][0], METHODES_EN_LIGNE))) ?>. Pour un paiement par carte émise hors du Sénégal, l'acceptation dépend de notre prestataire de paiement et de votre banque.</p>
  </div>
</main>
<?php require __DIR__ . '/../includes/footer.php'; ?>
