<?php
$u = exiger_connexion();
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    rediriger('');
}

$id = (int) ($_POST['produit_id'] ?? 0);
$produit = requete('SELECT id, slug FROM produits WHERE id = ?', [$id])->fetch();
if (!$produit) {
    rediriger('');
}
$retour = 'produit/' . $produit['slug'];

if (!csrf_valide($_POST['csrf'] ?? null)) {
    flash('Session expirée, merci de réessayer.', 'erreur');
    rediriger($retour);
}

// Seuls les clients dont la commande de ce produit a été LIVRÉE peuvent donner un avis
if (!achat_livre($id, (int) $u['id'])) {
    flash('Vous pouvez donner votre avis une fois le produit livré.', 'erreur');
    rediriger($retour);
}

$note = (int) ($_POST['note'] ?? 0);
$commentaire = trim((string) ($_POST['commentaire'] ?? ''));
if ($note < 1 || $note > 5 || mb_strlen($commentaire) > 1000) {
    flash('Choisissez une note de 1 à 5 (commentaire : 1000 caractères maximum).', 'erreur');
    rediriger($retour);
}

$pdo = pdo();
$pdo->beginTransaction();
requete(
    'INSERT INTO avis (produit_id, user_id, note, commentaire) VALUES (?, ?, ?, ?)
     ON DUPLICATE KEY UPDATE note = VALUES(note), commentaire = VALUES(commentaire)',
    [$id, $u['id'], $note, $commentaire !== '' ? $commentaire : null]
);
requete(
    'UPDATE produits SET note_moyenne = (SELECT ROUND(AVG(note), 1) FROM avis WHERE produit_id = ?),
                         nb_avis = (SELECT COUNT(*) FROM avis WHERE produit_id = ?) WHERE id = ?',
    [$id, $id, $id]
);
$pdo->commit();

flash('Merci pour votre avis !');
rediriger($retour);
