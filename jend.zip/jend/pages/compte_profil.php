<?php
$u = exiger_connexion();
$espaceVendeur = $espaceVendeur ?? false;                      // true quand la page est ouverte depuis l'espace vendeur (pages/vendeur_profil.php)
$cheminProfil = $espaceVendeur ? 'vendeur/profil' : 'compte/profil';
$erreurs = [];
$erreursMdp = [];
$v = ['nom' => $u['nom'], 'telephone' => $u['telephone'] ?? ''];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_valide($_POST['csrf'] ?? null)) {
        flash('Session expirée, merci de réessayer.', 'erreur');
        rediriger($cheminProfil);
    }

    if (($_POST['action'] ?? '') === 'profil') {
        $v['nom'] = trim((string) ($_POST['nom'] ?? ''));
        $v['telephone'] = trim((string) ($_POST['telephone'] ?? ''));
        $tel = $v['telephone'] !== '' ? telephone_valide($v['telephone']) : null;
        if (mb_strlen($v['nom']) < 2 || mb_strlen($v['nom']) > 120) {
            $erreurs[] = 'Indiquez votre nom (2 caractères minimum).';
        }
        if ($v['telephone'] !== '' && $tel === null) {
            $erreurs[] = 'Numéro de téléphone invalide (ex : 77 123 45 67).';
        }
        if (!$erreurs) {
            requete('UPDATE users SET nom = ?, telephone = ? WHERE id = ?', [$v['nom'], $tel, $u['id']]);
            flash('Profil mis à jour.');
            rediriger($cheminProfil);
        }
    } elseif (($_POST['action'] ?? '') === 'mdp') {
        $actuel = (string) ($_POST['actuel'] ?? '');
        $nouveau = (string) ($_POST['nouveau'] ?? '');
        $hash = (string) requete('SELECT mot_de_passe FROM users WHERE id = ?', [$u['id']])->fetchColumn();
        $cleMdp = 'mdp-compte:' . $u['id'];
        if (limite_atteinte($cleMdp, 5, 900)) {
            $erreursMdp[] = 'Trop d\'essais. Réessayez dans 15 minutes.';
        } elseif (!password_verify($actuel, $hash)) {
            limite_enregistrer($cleMdp);
            $erreursMdp[] = 'Le mot de passe actuel est incorrect.';
        }
        if ($msg = mot_de_passe_faible($nouveau, (string) $u['email'], (string) $u['nom'])) {
            $erreursMdp[] = $msg;
        }
        if ($nouveau !== (string) ($_POST['nouveau2'] ?? '')) {
            $erreursMdp[] = 'Les deux nouveaux mots de passe ne correspondent pas.';
        }
        if (!$erreursMdp) {
            requete('UPDATE users SET mot_de_passe = ? WHERE id = ?', [password_hash($nouveau, PASSWORD_DEFAULT), $u['id']]);
            session_regenerate_id(true);
            invalider_sessions((int) $u['id']);          // les autres appareils/sessions sont déconnectés
            flash('Mot de passe modifié. Vos autres sessions ont été déconnectées.');
            rediriger($cheminProfil);
        }
    }
}

$titre = 'Mon profil — Jënd';
require __DIR__ . '/../includes/header.php';
?>
<main class="page">
  <div class="wrap">
    <?php if ($espaceVendeur): ?>
    <nav class="fil" aria-label="Fil d'Ariane"><a href="<?= e(url()) ?>">Accueil</a> / <a href="<?= e(url('vendeur')) ?>">Boutique</a> / <span>Mon profil</span></nav>
    <h1 class="titre-page"><?= e($b['nom'] ?? 'Ma boutique') ?></h1>
    <?php vendeur_onglets('profil'); ?>
    <p class="doux">Vos informations personnelles et votre mot de passe. Les informations de la boutique (nom, description, numéro de paiement) se modifient dans l'onglet « Boutique ».</p>
    <?php else: ?>
    <nav class="fil" aria-label="Fil d'Ariane"><a href="<?= e(url()) ?>">Accueil</a> / <a href="<?= e(url('compte')) ?>">Mon compte</a> / <span>Profil</span></nav>
    <h1 class="titre-page">Mon compte</h1>
    <?php compte_onglets('profil'); ?>
    <?php endif; ?>

    <div class="deux-colonnes">
      <form method="post" class="formulaire formulaire-large" novalidate>
        <?= csrf_champ() ?><input type="hidden" name="action" value="profil">
        <h2 class="sous-titre">Mes informations</h2>
        <?php foreach ($erreurs as $er): ?><p class="alerte" role="alert"><?= e($er) ?></p><?php endforeach; ?>
        <label class="champ"><span>E-mail</span><input type="email" value="<?= e($u['email']) ?>" disabled></label>
        <label class="champ"><span>Nom complet</span><input type="text" name="nom" value="<?= e($v['nom']) ?>" autocomplete="name" required></label>
        <label class="champ"><span>Téléphone</span><input type="tel" name="telephone" value="<?= e($v['telephone']) ?>" placeholder="77 123 45 67" autocomplete="tel"></label>
        <button class="btn btn-primaire" type="submit">Enregistrer</button>
      </form>

      <form method="post" class="formulaire formulaire-large" novalidate>
        <?= csrf_champ() ?><input type="hidden" name="action" value="mdp">
        <h2 class="sous-titre">Changer de mot de passe</h2>
        <?php foreach ($erreursMdp as $er): ?><p class="alerte" role="alert"><?= e($er) ?></p><?php endforeach; ?>
        <label class="champ"><span>Mot de passe actuel</span><input type="password" name="actuel" autocomplete="current-password" required></label>
        <label class="champ"><span>Nouveau mot de passe (8 caractères minimum)</span><input type="password" name="nouveau" autocomplete="new-password" required></label>
        <label class="champ"><span>Confirmer le nouveau mot de passe</span><input type="password" name="nouveau2" autocomplete="new-password" required></label>
        <button class="btn btn-primaire" type="submit">Modifier le mot de passe</button>
      </form>
    </div>
  </div>
</main>
<?php require __DIR__ . '/../includes/footer.php'; ?>
