<?php
/** Vitrine « Spécial fête ». $parametre = slug de la fête. */
$f = requete('SELECT * FROM fetes WHERE slug = ? AND actif = 1', [$parametre])->fetch();
if (!$f || $f['date_fete'] < date('Y-m-d')) {
    http_response_code(404);
    require __DIR__ . '/404.php';
    return;
}
$res = catalogue_chercher(['fete_id' => (int) $f['id'], 'tri' => 'recent'], (int) ($_GET['page'] ?? 1));
$pageCourante = $res['page'];
$lien = app_url('fete/' . $f['slug']);
$titre = 'Spécial ' . $f['nom'] . ' — Jënd';
$description = 'Préparez ' . $f['nom'] . ' avec les boutiques sénégalaises de Jënd : paiement protégé jusqu\'à la réception.';
require __DIR__ . '/../includes/header.php';
?>
<main class="page">
  <section class="fete-affiche">
    <div class="wrap">
      <p class="fete-surtitre"><i class="ph ph-confetti"></i> Spécial fête</p>
      <h1><?= e($f['nom']) ?></h1>
      <p class="fete-date"><?= e(date_longue_fr($f['date_fete'])) ?> · <b><?= e(fete_compte($f)) ?></b></p>
      <?php if ($f['texte']): ?><p class="fete-texte"><?= nl2br(e($f['texte'])) ?></p><?php endif; ?>
      <?php if (fete_commande_a_temps($f)): ?>
        <p class="fete-limite"><i class="ph ph-truck"></i> Pour être livré avant la fête, commandez au plus tard le <b><?= e(date_longue_fr($f['date_limite'])) ?></b>.</p>
      <?php elseif ($f['date_limite']): ?>
        <p class="fete-limite fete-limite-passee"><i class="ph ph-info"></i> La date conseillée pour une livraison avant la fête est passée : vérifiez le délai avec la boutique.</p>
      <?php endif; ?>
      <p><?= bouton_whatsapp('Spécial ' . $f['nom'] . ' sur Jënd : ' . lien_source($lien, 'whatsapp'), 'Partager la vitrine') ?></p>
    </div>
  </section>
  <div class="wrap">
    <p class="compte"><?= $res['total'] ?> produit<?= $res['total'] > 1 ? 's' : '' ?> sélectionné<?= $res['total'] > 1 ? 's' : '' ?> par nos boutiques</p>
    <?php if (!$res['produits']): ?>
      <div class="vide"><i class="ph ph-confetti"></i><p><b>Les boutiques préparent leur sélection.</b></p><p><a class="btn btn-primaire" href="<?= e(url('produits')) ?>">Voir tout l'étalage</a></p></div>
    <?php else: ?>
      <div class="produits produits-3">
        <?php foreach ($res['produits'] as $p) { include __DIR__ . '/../includes/carte.php'; } ?>
      </div>
      <?php if ($res['pages'] > 1): ?>
        <nav class="pagination" aria-label="Pagination">
          <?php for ($i = 1; $i <= $res['pages']; $i++): ?><a href="<?= e(url_avec(['page' => $i])) ?>" <?= $i === $pageCourante ? 'class="actif" aria-current="page"' : '' ?>><?= $i ?></a><?php endfor; ?>
        </nav>
      <?php endif; ?>
    <?php endif; ?>
  </div>
</main>
<?php require __DIR__ . '/../includes/footer.php'; ?>
