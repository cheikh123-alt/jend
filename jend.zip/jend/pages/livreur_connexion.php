<?php
$u = utilisateur();
if ($u && $u['role'] === 'livreur') {
    rediriger('livreur');
}
$erreur = null;
$email = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim((string) ($_POST['email'] ?? ''));
    if (!csrf_valide($_POST['csrf'] ?? null)) {
        $erreur = 'Session expirée, merci de réessayer.';
    } elseif ($u) {
        $erreur = 'Déconnectez-vous d\'abord du compte actuel.';
    } else {
        $erreur = tenter_connexion($email, (string) ($_POST['mot_de_passe'] ?? ''), url('livreur'), url('livreur'));
    }
}
livreur_entete('Connexion livreur — Jënd', '');
?>
<section class="accueil-livreur">
  <i class="ph-fill ph-motorcycle" aria-hidden="true"></i>
  <h1 class="app-titre">Espace livreur</h1>
  <p class="doux">Connectez-vous pour voir vos courses.</p>
</section>
<?php if ($u): ?>
  <p class="app-alerte">Vous êtes connecté avec un compte qui n'est pas un compte livreur. Déconnectez-vous pour utiliser cet espace.</p>
  <form method="post" action="<?= e(url('deconnexion')) ?>"><?= csrf_champ() ?><button class="bouton-principal" type="submit"><i class="ph-fill ph-sign-out"></i> Me déconnecter</button></form>
<?php else: ?>
<form method="post" class="carte-info formulaire-app" novalidate>
  <?= csrf_champ() ?>
  <?php if ($erreur): ?><p class="app-alerte" role="alert"><?= e($erreur) ?></p><?php endif; ?>
  <label class="champ-app"><span>E-mail</span><input type="email" name="email" value="<?= e($email) ?>" autocomplete="username" inputmode="email" required autofocus></label>
  <label class="champ-app"><span>Mot de passe</span><input type="password" name="mot_de_passe" autocomplete="current-password" required></label>
  <button class="bouton-principal" type="submit"><i class="ph-fill ph-sign-in"></i> Se connecter</button>
  <p class="doux petit-centre"><a class="lien-app" href="<?= e(url('mot-de-passe-oublie')) ?>">Mot de passe oublié ?</a></p>
</form>
<p class="doux petit-centre">Pas de compte ? Il est créé par l'administrateur de Jënd.</p>
<?php endif; ?>
<?php livreur_pied(false); ?>
