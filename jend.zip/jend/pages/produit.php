<?php
/** Fiche produit. $parametre = slug du produit. */
$p = requete(
    "SELECT p.*, " . SQL_PROMO_FETE . " AS promo_pct, b.nom AS boutique, b.slug AS boutique_slug, b.description AS boutique_desc, b.verifiee, b.offres_actives, b.sur_mesure, b.user_id AS vendeur_id,
            c.nom AS categorie, c.slug AS categorie_slug, COALESCE(c.icone, pc.icone) AS icone
       FROM produits p
       JOIN boutiques b ON b.id = p.boutique_id AND b.statut = 'active'
       JOIN categories c ON c.id = p.categorie_id
       LEFT JOIN categories pc ON pc.id = c.parent_id
      WHERE p.slug = ? AND p.statut = 'publie' AND (p.reserve_client_id IS NULL OR p.reserve_client_id = " . (int) ($_SESSION['user_id'] ?? 0) . ")",
    [$parametre]
)->fetch();

if (!$p) {
    http_response_code(404);
    require __DIR__ . '/404.php';
    return;
}

$images  = requete('SELECT chemin FROM produit_images WHERE produit_id = ? ORDER BY position', [$p['id']])->fetchAll(PDO::FETCH_COLUMN);
$avis    = requete(
    'SELECT a.note, a.commentaire, a.created_at, u.nom FROM avis a JOIN users u ON u.id = a.user_id
      WHERE a.produit_id = ? ORDER BY a.created_at DESC LIMIT 10',
    [$p['id']]
)->fetchAll();
$moi2 = utilisateur();
$peutNoter = $moi2 && achat_livre((int) $p['id'], (int) $moi2['id']);
$monAvis = $moi2 ? requete('SELECT note, commentaire FROM avis WHERE produit_id = ? AND user_id = ?', [$p['id'], $moi2['id']])->fetch() : null;
$zonesDesservies = array_filter(zones_actives(), fn ($z) => boutique_livre_vers((int) $p['boutique_id'], (string) $z['region']));
$modeLivraison = ((string) requete('SELECT livraison_par FROM boutiques WHERE id = ?', [$p['boutique_id']])->fetchColumn() === 'jend' && livreurs_jend_actifs()) ? 'jend' : 'vendeur';
$fraisZonesProduit = frais_panier([(int) $p['boutique_id'] => $modeLivraison], $zonesDesservies);
$fraisMin = $fraisZonesProduit ? min(array_column($fraisZonesProduit, 'frais')) : 0;

$similaires = array_values(array_filter(
    catalogue_chercher(['categorie_id' => $p['categorie_id'], 'tri' => 'populaire', 'sans_total' => true], 1)['produits'],
    fn($s) => (int) $s['id'] !== (int) $p['id']
));
$similaires = array_slice($similaires, 0, 4);

$moi = utilisateur();
$erreurOffre = null;
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'alerte') {           // « Prévenez-moi »
    if (!$moi) {
        rediriger('connexion?retour=' . urlencode(url('produit/' . $p['slug'])));
    }
    if (post_verifie('produit/' . $p['slug'])) {
        try {
            $actif = alerte_basculer((int) $moi['id'], (int) $p['id'], prix_promo((int) $p['prix'], (int) $p['promo_pct']), (int) $p['stock'] < 1);
            flash($actif ? 'C\'est noté : nous vous écrirons si le prix baisse' . ((int) $p['stock'] < 1 ? ' ou dès son retour en stock' : '') . '.' : 'Alerte retirée.');
        } catch (RuntimeException $e) {
            flash($e->getMessage(), 'erreur');
        }
        rediriger('produit/' . $p['slug']);
    }
}
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'offre') {            // « Proposer un prix »
    if (!$moi) {
        rediriger('connexion?retour=' . urlencode(url('produit/' . $p['slug'])));
    }
    exiger_email_confirme($moi);
    if (!csrf_valide($_POST['csrf'] ?? null)) {
        $erreurOffre = 'Session expirée, merci de réessayer.';
    } elseif (!ctype_digit(trim((string) ($_POST['prix'] ?? '')))) {
        $erreurOffre = 'Indiquez votre prix en FCFA (nombre entier).';
    } else {
        try {
            offre_creer((int) $moi['id'], (int) $p['id'], (int) trim((string) $_POST['prix']), (int) ($_POST['quantite'] ?? 1));
            flash('Offre envoyée au vendeur. Il a ' . OFFRE_REPONSE_HEURES . ' heures pour répondre : suivez-la dans « Mes offres ».');
            rediriger('offres');
        } catch (RuntimeException $e) {
            $erreurOffre = $e->getMessage();
        }
    }
}
$offreEnCours = $moi ? requete("SELECT statut, prix_propose, prix_final FROM offres WHERE client_id = ? AND produit_id = ? AND statut IN ('en_attente', 'contre', 'acceptee') AND expire_le > NOW() ORDER BY id DESC LIMIT 1", [$moi['id'], $p['id']])->fetch() : null;
$offrePossible = ((int) $p['offres_actives'] === 1 && (int) $p['stock'] > 0 && (!$moi || (int) $moi['id'] !== (int) $p['vendeur_id'])) && empty($p['promo_pct']);      // pendant une promotion de fête, pas de négociation en plus
$noteBoutique = boutique_note((int) $p['boutique_id']);
$confiance = boutique_confiance((int) $p['boutique_id']);
$regionsBoutique = boutique_regions((int) $p['boutique_id']);
$lienProduit = app_url('produit/' . $p['slug']);

$p = produit_avec_promo($p);                         // promotion de fête en cours (prix affiché = prix payé)
$remise  = ($p['prix_barre'] && $p['prix_barre'] > $p['prix']) ? (int) round((1 - $p['prix'] / $p['prix_barre']) * 100) : 0;
$enStock = (int) $p['stock'] > 0;
$maxQte  = max(1, min(10, (int) $p['stock']));
$variantes = variantes_produit((int) $p['id']);             // tailles / pointures (le client doit en choisir une)
$motTaille = option_libelle($p['option_type']);

$titre = $p['nom'] . ' — Jënd';
$description = mb_substr(strip_tags((string) $p['description']) ?: $p['nom'], 0, 155);

$aideFlottante = true;
require __DIR__ . '/../includes/header.php';
?>
<main class="page">
  <div class="wrap">
    <nav class="fil" aria-label="Fil d'Ariane">
      <a href="<?= e(url()) ?>">Accueil</a> /
      <a href="<?= e(url('categorie/' . $p['categorie_slug'])) ?>"><?= e($p['categorie']) ?></a> /
      <span><?= e($p['nom']) ?></span>
    </nav>

    <div class="fiche">
      <div class="galerie">
        <div class="galerie-grande <?= classe_fond((int) $p['id']) ?>">
          <?php if ($images): ?>
            <img src="<?= e(url($images[0])) ?>" alt="<?= e($p['nom']) ?>">
          <?php else: ?>
            <i class="ph-fill <?= e($p['icone'] ?: 'ph-package') ?>" aria-hidden="true"></i>
          <?php endif; ?>
          <?php if ($remise): ?><span class="promo">-<?= $remise ?>%</span><?php endif; ?>
        </div>
        <?php if (count($images) > 1): ?>
          <div class="miniatures">
            <?php foreach ($images as $img): ?><img src="<?= e(url($img)) ?>" alt="" loading="lazy"><?php endforeach; ?>
          </div>
        <?php endif; ?>
      </div>

      <div class="fiche-infos">
        <span class="vendeur"><i class="ph-fill ph-seal-check"></i> Vendu par <a href="<?= e(url('boutique/' . $p['boutique_slug'])) ?>"><b><?= e($p['boutique']) ?></b></a>
          <?php if ($p['verifiee']): ?><span class="badge-verifie"><i class="ph-fill ph-seal-check"></i> Boutique vérifiée</span><?php endif; ?>
          <?php if ($noteBoutique['nb'] > 0): ?><small class="doux">· boutique notée <?= e(note_texte($noteBoutique['note'])) ?>/5 (<?= $noteBoutique['nb'] ?> avis)</small><?php endif; ?></span>
        <?php $compact = true; require __DIR__ . '/../includes/confiance.php'; ?>
        <?php if ($feteProduit = fete_du_produit((int) $p['id'])): ?>
          <a class="badge-fete" href="<?= e(url('fete/' . $feteProduit['slug'])) ?>"><i class="ph ph-confetti"></i> <?= (int) $feteProduit['remise_pct'] > 0 ? 'Promo ' . e($feteProduit['nom']) . ' −' . (int) $feteProduit['remise_pct'] . ' % jusqu\'au ' . e(date('d/m', strtotime($feteProduit['date_fete']))) : 'Spécial ' . e($feteProduit['nom']) ?><?= fete_commande_a_temps($feteProduit) ? ' · commandez avant le ' . e(date('d/m', strtotime($feteProduit['date_limite']))) . ' pour être livré à temps' : '' ?></a>
        <?php endif; ?>
        <h1><?= e($p['nom']) ?></h1>
        <?php if ($p['nb_avis'] > 0): ?>
          <span class="etoiles"><i class="ph-fill ph-star"></i> <?= e((string) $p['note_moyenne']) ?><small>(<?= (int) $p['nb_avis'] ?> avis)</small></span>
        <?php endif; ?>

        <div class="fiche-prix">
          <span class="prix"><?= e(fcfa((int) $p['prix'])) ?></span>
          <?php if ($remise): ?><s><?= e(fcfa((int) $p['prix_barre'])) ?></s><?php endif; ?>
        </div>

        <?php if (!empty($p['voix_chemin'])): ?>
          <div class="voix-produit"><span><i class="ph-fill ph-microphone"></i> Le vendeur vous parle de son produit</span>
            <audio controls preload="none"><source src="<?= e(url($p['voix_chemin'])) ?>" type="<?= e(voix_type($p['voix_chemin'])) ?>">Votre navigateur ne lit pas cet enregistrement.</audio></div>
        <?php endif; ?>

        <?php if ($enStock): ?>
          <p class="stock <?= $p['stock'] <= 5 ? 'stock-bas' : '' ?>">
            <i class="ph-fill ph-check-circle"></i>
            <?= $p['stock'] <= 5 ? 'Plus que ' . (int) $p['stock'] . ' en stock' : 'En stock' ?>
          </p>
          <form method="post" action="<?= e(url('panier/ajouter')) ?>" class="achat" id="form-achat">
            <?= csrf_champ() ?>
            <input type="hidden" name="produit_id" value="<?= (int) $p['id'] ?>">
            <input type="hidden" name="retour" value="<?= e($_SERVER['REQUEST_URI'] ?? '') ?>">
            <?php if ($variantes): ?>
              <fieldset class="choix-taille">
                <legend><?= e($motTaille) ?> <small class="doux">— choisissez avant d'ajouter au panier</small></legend>
                <?php foreach ($variantes as $vr): $epuisee = (int) $vr['stock'] < 1; ?>
                  <label class="<?= $epuisee ? 'epuisee' : '' ?>"><input type="radio" name="variante_id" value="<?= (int) $vr['id'] ?>" required <?= $epuisee ? 'disabled' : '' ?>>
                    <span><?= e($vr['libelle']) ?></span><?php if ($epuisee): ?><small>épuisée</small><?php elseif ((int) $vr['stock'] <= 3): ?><small>plus que <?= (int) $vr['stock'] ?></small><?php endif; ?></label>
                <?php endforeach; ?>
              </fieldset>
            <?php endif; ?>
            <label class="qte">
              <span class="sr">Quantité</span>
              <input type="number" name="quantite" value="1" min="1" max="<?= $maxQte ?>">
            </label>
            <button class="btn btn-primaire" type="submit" name="acheter" value="1"><i class="ph ph-lightning"></i> Acheter maintenant</button>
            <button class="btn btn-contour" type="submit"><i class="ph ph-shopping-bag"></i> Ajouter au panier</button>
          </form>
          <ul class="rassurance-achat">
            <li><i class="ph-fill ph-shield-check"></i> <span><b>Argent protégé</b> : le vendeur n'est payé qu'après votre réception</span></li>
            <li><i class="ph-fill ph-key"></i> <span><b>Code de réception</b> : vous le donnez seulement quand le colis est dans vos mains</span></li>
            <li><i class="ph-fill ph-lifebuoy"></i> <span><b>Un problème ?</b> Signalement pendant <?= LITIGE_DELAI_SIGNALEMENT_JOURS ?> jours, réponse sous <?= LITIGE_DELAI_REPONSE_HEURES ?> h</span></li>
          </ul>
          <div class="barre-achat" aria-hidden="true">
            <span><b><?= e(fcfa((int) $p['prix'])) ?></b><?php if ($remise): ?> <s><?= e(fcfa((int) $p['prix_barre'])) ?></s><?php endif; ?></span>
            <button class="btn btn-contour" type="submit" form="form-achat" tabindex="-1"><i class="ph ph-shopping-bag"></i><span class="sr">Ajouter au panier</span></button>
            <button class="btn btn-primaire" type="submit" form="form-achat" name="acheter" value="1" tabindex="-1">Acheter</button>
          </div>
          <?php if ($offreEnCours): ?>
            <p class="alerte alerte-info"><i class="ph ph-handshake"></i> <span><?= $offreEnCours['statut'] === 'acceptee'
                ? 'Le vendeur a accepté votre prix de <b>' . e(fcfa((int) $offreEnCours['prix_final'])) . '</b>.'
                : 'Vous avez proposé <b>' . e(fcfa((int) $offreEnCours['prix_propose'])) . '</b> pour ce produit.' ?> <a class="lien" href="<?= e(url('offres')) ?>">Voir mes offres</a></span></p>
          <?php elseif ($offrePossible): ?>
            <details class="offre-boite" <?= $erreurOffre ? 'open' : '' ?>>
              <summary><i class="ph ph-handshake"></i> Proposer mon prix au vendeur</summary>
              <form method="post" class="offre-form">
                <?= csrf_champ() ?><input type="hidden" name="action" value="offre">
                <?php if ($erreurOffre): ?><p class="alerte" role="alert"><?= e($erreurOffre) ?></p><?php endif; ?>
                <p class="doux petit">Le vendeur peut accepter, refuser ou vous proposer un autre prix. Minimum : <?= e(fcfa(offre_prix_minimum((int) $p['prix']))) ?>.</p>
                <label class="champ"><span>Mon prix par article (FCFA)</span><input type="text" name="prix" inputmode="numeric" placeholder="<?= (int) round((int) $p['prix'] * 0.85) ?>" required></label>
                <label class="champ"><span>Quantité</span><input type="number" name="quantite" value="1" min="1" max="<?= $maxQte ?>"></label>
                <button class="btn btn-contour" type="submit"><?= $moi ? 'Envoyer mon offre' : 'Me connecter et envoyer mon offre' ?></button>
              </form>
            </details>
          <?php endif; ?>
        <?php else: ?>
          <p class="stock stock-vide"><i class="ph-fill ph-x-circle"></i> Épuisé pour le moment</p>
        <?php endif; ?>

        <?php if ((int) $p['sur_mesure'] === 1 && empty($p['reserve_client_id']) && (!$moi || (int) $moi['id'] !== (int) $p['vendeur_id'])): ?>
          <a class="encart-mesure" href="<?= e(url('sur-mesure/' . $p['boutique_slug'])) ?>">
            <i class="ph-fill ph-scissors" aria-hidden="true"></i>
            <span><b>Vous le voulez à votre taille ou à votre goût ?</b><small><?= e($p['boutique']) ?> fait aussi du sur-mesure : décrivez ce que vous voulez et recevez un prix et un délai.</small></span>
            <span class="encart-mesure-action">Demander un devis <i class="ph ph-arrow-right"></i></span>
          </a>
        <?php endif; ?>
        <?php if (!empty($p['video_url']) && video_url_valide((string) $p['video_url'])): ?>
          <p class="partage"><a class="btn btn-video" href="<?= e($p['video_url']) ?>" target="_blank" rel="noopener noreferrer nofollow"><i class="ph-fill ph-play-circle"></i> Voir la vidéo du produit</a></p>
        <?php endif; ?>
        <p class="partage"><?= bouton_whatsapp($p['nom'] . ' à ' . fcfa((int) $p['prix']) . ' sur Jënd : ' . lien_source($lienProduit, 'whatsapp'), 'Partager sur WhatsApp') ?></p>
        <?php if (!$moi || (int) $moi['id'] !== (int) $p['vendeur_id']): $suivi = $moi && alerte_active((int) $moi['id'], (int) $p['id']); ?>
          <form method="post" class="alerte-produit"><?= csrf_champ() ?><input type="hidden" name="action" value="alerte">
            <button class="btn btn-contour<?= $suivi ? ' actif' : '' ?>" type="submit"><i class="ph<?= $suivi ? '-fill' : '' ?> ph-bell-ringing"></i>
              <?= $suivi ? 'Alerte activée — retirer' : ($enStock ? 'Prévenez-moi si le prix baisse' : 'Prévenez-moi de son retour') ?></button>
          </form>
        <?php endif; ?>
        <ul class="garanties">
          <li><i class="ph ph-map-pin"></i> Cette boutique livre <?= $regionsBoutique ? 'à : <b>' . e(implode(', ', $regionsBoutique)) . '</b>' : 'dans <b>tout le Sénégal</b>' ?></li>
          <li><i class="ph ph-truck"></i> Livraison à partir de <?= e(fcfa((int) $fraisMin)) ?> (<?= e(villes_livrees()) ?> · délai de <?= (int) delais_livraison()[0] ?><?= delais_livraison()[0] === delais_livraison()[1] ? '' : ' à ' . (int) delais_livraison()[1] ?> jour(s) selon la zone)</li>
          <li><i class="ph ph-hand-coins"></i> <?= paiement_en_ligne_actif() ? 'Paiement Wave, Orange Money, carte' . (paiement_livraison_actif() ? ' ou à la livraison' : '') : 'Paiement en espèces à la livraison' ?></li>
          <li><i class="ph ph-arrow-u-up-left"></i> Un problème ? Signalement possible pendant <?= LITIGE_DELAI_SIGNALEMENT_JOURS ?> jours</li>
        </ul>
      </div>
    </div>

    <?php if ($p['description']): ?>
      <section class="bloc-fiche">
        <h2>Description</h2>
        <p><?= nl2br(e($p['description'])) ?></p>
      </section>
    <?php endif; ?>

    <section class="bloc-fiche" id="avis">
      <h2>Avis des clients</h2>
      <?php if ($peutNoter): ?>
        <form method="post" action="<?= e(url('avis/ajouter')) ?>" class="formulaire formulaire-large form-avis">
          <?= csrf_champ() ?><input type="hidden" name="produit_id" value="<?= (int) $p['id'] ?>">
          <b><?= $monAvis ? 'Modifier mon avis' : 'Donner mon avis' ?></b>
          <div class="note-choix" role="radiogroup" aria-label="Note">
            <?php for ($n = 5; $n >= 1; $n--): ?>
              <input type="radio" name="note" id="n<?= $n ?>" value="<?= $n ?>" <?= ($monAvis['note'] ?? 0) == $n ? 'checked' : '' ?> required><label for="n<?= $n ?>" title="<?= $n ?> sur 5"><i class="ph-fill ph-star"></i></label>
            <?php endfor; ?>
          </div>
          <label class="champ"><span class="sr">Commentaire</span><textarea name="commentaire" rows="3" maxlength="1000" placeholder="Votre commentaire (optionnel)"><?= e($monAvis['commentaire'] ?? '') ?></textarea></label>
          <button class="btn btn-primaire" type="submit">Publier mon avis</button>
        </form>
      <?php endif; ?>
      <?php if (!$avis): ?>
        <p class="doux">Pas encore d'avis pour ce produit.</p>
      <?php else: foreach ($avis as $a): ?>
        <div class="avis-item">
          <b><?= e(explode(' ', trim($a['nom']))[0]) ?></b>
          <span class="etoiles"><?= str_repeat('<i class="ph-fill ph-star"></i>', (int) $a['note']) ?></span>
          <?php if ($a['commentaire']): ?><p><?= e($a['commentaire']) ?></p><?php endif; ?>
        </div>
      <?php endforeach; endif; ?>
    </section>

    <?php if ($similaires): ?>
      <section class="bloc-fiche">
        <h2>Vous aimerez aussi</h2>
        <div class="produits">
          <?php foreach ($similaires as $p2) { $p_sauve = $p; $p = $p2; include __DIR__ . '/../includes/carte.php'; $p = $p_sauve; } ?>
        </div>
      </section>
    <?php endif; ?>
  </div>
</main>
<?php require __DIR__ . '/../includes/footer.php'; ?>
