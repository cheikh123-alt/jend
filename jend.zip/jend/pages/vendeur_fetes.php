<?php
/** « Spécial fêtes » côté vendeur : il choisit les produits à mettre dans la vitrine de chaque fête à venir. */
[$u, $b] = exiger_vendeur();
$fetes = fetes_a_venir();

if (post_verifie('vendeur/fetes')) {
    try {
        $n = fete_produits_vendeur((int) ($_POST['fete_id'] ?? 0), (int) $b['id'], (array) ($_POST['produits'] ?? []), array_map('intval', (array) ($_POST['remise'] ?? [])));
        flash($n . ' produit(s) dans la vitrine de la fête.');
    } catch (RuntimeException $e) {
        flash($e->getMessage(), 'erreur');
    }
    rediriger('vendeur/fetes');
}

$produits = requete(
    "SELECT p.id, p.nom, p.prix, p.stock, (SELECT chemin FROM produit_images i WHERE i.produit_id = p.id ORDER BY i.position LIMIT 1) AS image
       FROM produits p WHERE p.boutique_id = ? AND p.statut = 'publie' AND p.reserve_client_id IS NULL ORDER BY p.nom",
    [$b['id']]
)->fetchAll();
$choisis = [];
foreach (requete('SELECT pf.fete_id, pf.produit_id, pf.remise_pct FROM produit_fetes pf JOIN produits p ON p.id = pf.produit_id WHERE p.boutique_id = ?', [$b['id']])->fetchAll() as $r) {
    $choisis[(int) $r['fete_id']][(int) $r['produit_id']] = (int) $r['remise_pct'];
}
$titre = 'Spécial fêtes — Espace vendeur';
require __DIR__ . '/../includes/header.php';
?>
<main class="page">
  <div class="wrap">
    <nav class="fil" aria-label="Fil d'Ariane"><a href="<?= e(url('vendeur')) ?>">Espace vendeur</a> / <span>Spécial fêtes</span></nav>
    <h1 class="titre-page">Espace vendeur</h1>
    <?php vendeur_onglets('fetes'); ?>
    <p class="doux">Avant chaque grande fête, Jënd ouvre une vitrine spéciale sur l'accueil. Cochez les produits qui conviennent (tenues, tissus, encens, cadeaux…) : ils y apparaîtront avec un badge.</p>
    <p class="alerte alerte-info"><i class="ph ph-percent"></i> <span><b>Promotion facultative :</b> choisissez un pourcentage pour un produit coché. Le prix baisse <b>automatiquement</b> à l'ouverture de la vitrine et <b>revient tout seul</b> le lendemain de la fête. La promotion est à votre charge : la commission de Jënd est calculée sur le prix réellement payé. Pendant la promotion, les clients ne peuvent pas faire d'offre sur ce produit.</span></p>

    <?php if (!$fetes): ?>
      <div class="vide"><i class="ph ph-confetti"></i><p><b>Aucune fête programmée pour le moment.</b></p><p class="doux">Vous serez prévenu ici dès que l'équipe ouvrira la prochaine vitrine.</p></div>
    <?php elseif (!$produits): ?>
      <div class="vide"><i class="ph ph-package"></i><p><b>Publiez d'abord des produits.</b></p><p><a class="btn btn-primaire" href="<?= e(url('vendeur/produits')) ?>">Mes produits</a></p></div>
    <?php else: foreach ($fetes as $f): ?>
      <form method="post" class="fete-vendeur">
        <?= csrf_champ() ?><input type="hidden" name="fete_id" value="<?= (int) $f['id'] ?>">
        <header>
          <div><h2 class="sous-titre"><i class="ph ph-confetti"></i> <?= e($f['nom']) ?></h2>
            <p class="doux"><?= e(date_longue_fr($f['date_fete'])) ?> · <?= e(fete_compte($f)) ?>
              <?= $f['date_limite'] ? ' · clients invités à commander avant le <b>' . e(date_longue_fr($f['date_limite'])) . '</b>' : '' ?>
              · vitrine ouverte <?= $f['vitrine_des'] <= date('Y-m-d') ? '<b>maintenant</b>' : 'le ' . e(date_longue_fr($f['vitrine_des'])) ?></p></div>
          <button class="btn btn-primaire" type="submit">Enregistrer ma sélection</button>
        </header>
        <?php if ($f['date_limite']): ?><p class="alerte alerte-info"><i class="ph ph-truck"></i> <span>Ne cochez que les produits que vous pouvez <b>livrer avant la fête</b> pour une commande passée le <?= e(date('d/m', strtotime($f['date_limite']))) ?> : c'est ce qui est annoncé aux clients.</span></p><?php endif; ?>
        <ul class="fete-produits">
          <?php foreach ($produits as $p): ?>
            <?php $actuelle = $choisis[(int) $f['id']][(int) $p['id']] ?? null; ?>
            <li><label>
              <input type="checkbox" name="produits[]" value="<?= (int) $p['id'] ?>" <?= $actuelle !== null ? 'checked' : '' ?>>
              <?php if ($p['image']): ?><img src="<?= e(url(image_miniature($p['image']))) ?>" alt="" loading="lazy"><?php else: ?><span class="fete-sans-photo"><i class="ph ph-image"></i></span><?php endif; ?>
              <span><b><?= e($p['nom']) ?></b><small><?= e(fcfa((int) $p['prix'])) ?><?= (int) $p['stock'] < 1 ? ' · épuisé' : '' ?></small></span>
            </label>
            <select name="remise[<?= (int) $p['id'] ?>]" class="fete-remise" aria-label="Promotion pour <?= e($p['nom']) ?>">
              <?php foreach (FETE_REMISES as $pct): ?><option value="<?= $pct ?>" <?= (int) $actuelle === $pct ? 'selected' : '' ?>><?= $pct ? 'Promo −' . $pct . ' % → ' . e(fcfa(prix_promo((int) $p['prix'], $pct))) : 'Sans promotion' ?></option><?php endforeach; ?>
            </select></li>
          <?php endforeach; ?>
        </ul>
      </form>
    <?php endforeach; endif; ?>
  </div>
</main>
<?php require __DIR__ . '/../includes/footer.php'; ?>
