<?php
/** « La dépense du mois » : liste des paniers mensuels du client. */
$u = exiger_connexion();
$depenses = requete('SELECT d.*, z.nom AS zone, (SELECT COUNT(*) FROM depense_lignes dl WHERE dl.depense_id = d.id) AS nb FROM depenses d JOIN zones_livraison z ON z.id = d.zone_id WHERE d.client_id = ? ORDER BY d.actif DESC, d.prochain_rappel', [$u['id']])->fetchAll();
$titre = 'La dépense du mois — Jënd';
require __DIR__ . '/../includes/header.php';
?>
<main class="page">
  <div class="wrap wrap-moyen">
    <nav class="fil" aria-label="Fil d'Ariane"><a href="<?= e(url('compte')) ?>">Mon compte</a> / <span>La dépense du mois</span></nav>
    <h1 class="titre-page">Mon compte</h1>
    <?php compte_onglets('depense'); ?>
    <h2 class="sous-titre">La dépense du mois</h2>
    <p class="doux">Enregistrez une fois les produits de chaque mois (riz, huile, sucre, lait, savon…), pour vous ou pour votre famille. Chaque mois, nous vous envoyons un rappel : vous vérifiez, puis vous commandez et payez en un clic. <b>Rien n'est prélevé automatiquement.</b></p>

    <?php if (!$depenses): ?>
      <div class="vide"><i class="ph ph-basket"></i><p><b>Aucune dépense enregistrée.</b></p>
        <p class="doux">Remplissez votre panier avec les produits du mois, puis cliquez sur « Enregistrer comme dépense du mois ».</p>
        <p><a class="btn btn-primaire" href="<?= e(url('categorie/alimentation')) ?>">Faire ma liste</a></p></div>
    <?php else: ?>
      <ul class="depenses">
        <?php foreach ($depenses as $d): $total = depense_total(depense_lignes((int) $d['id'])); ?>
          <li class="depense-carte<?= $d['actif'] ? '' : ' en-pause' ?>">
            <div>
              <h2><i class="ph ph-basket"></i> <?= e($d['nom']) ?> <?= $d['actif'] ? '' : '<span class="badge">En pause</span>' ?></h2>
              <p class="doux">Pour <b><?= e($d['livraison_nom']) ?></b> · <?= e($d['zone']) ?> · <?= (int) $d['nb'] ?> produit(s) · environ <b><?= e(fcfa($total)) ?></b> hors livraison</p>
              <p class="petit"><?= $d['actif'] ? 'Prochain rappel le <b>' . e(date_longue_fr($d['prochain_rappel'])) . '</b>' : 'Aucun rappel tant que la dépense est en pause' ?></p>
            </div>
            <a class="btn btn-primaire" href="<?= e(url('depense/' . $d['id'])) ?>">Voir et commander</a>
          </li>
        <?php endforeach; ?>
      </ul>
      <?php if (count($depenses) < DEPENSES_MAX): ?><p class="petit doux">Pour créer une autre dépense : remplissez votre panier, puis « Enregistrer comme dépense du mois ».</p><?php endif; ?>
    <?php endif; ?>
  </div>
</main>
<?php require __DIR__ . '/../includes/footer.php'; ?>
