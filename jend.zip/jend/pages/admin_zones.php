<?php
exiger_admin();

/** Valide les champs d'une zone ; renvoie [nom, ville, frais, délai] ou un message d'erreur (string). */
function zone_champs_valides(): array|string
{
    $nom = trim((string) ($_POST['nom'] ?? ''));
    $ville = trim((string) ($_POST['region'] ?? ''));
    $frais = trim((string) ($_POST['frais'] ?? ''));
    $delai = trim((string) ($_POST['delai_jours'] ?? ''));
    if (mb_strlen($nom) < 2 || mb_strlen($nom) > 100 || mb_strlen($ville) < 2 || mb_strlen($ville) > 60) {
        return 'Nom de zone (2 à 100 caractères) ou ville (2 à 60) invalide.';
    }
    if (!ctype_digit($frais) || (int) $frais > 100000) {
        return 'Frais de livraison invalides (nombre entier en FCFA, 0 à 100 000).';
    }
    if (!ctype_digit($delai) || (int) $delai < 1 || (int) $delai > 30) {
        return 'Délai invalide (1 à 30 jours).';
    }
    return [$nom, $ville, (int) $frais, (int) $delai];
}

if (post_verifie('admin/zones')) {
    $action = $_POST['action'] ?? '';
    $id = (int) ($_POST['id'] ?? 0);
    $zone = $id ? requete('SELECT * FROM zones_livraison WHERE id = ?', [$id])->fetch() : null;
    if ($action === 'ajouter' || $action === 'modifier') {
        $c = zone_champs_valides();
        if (is_string($c)) {
            flash($c, 'erreur');
        } elseif ($action === 'modifier' && !$zone) {
            flash('Zone introuvable.', 'erreur');
        } elseif (requete('SELECT 1 FROM zones_livraison WHERE nom = ? AND id <> ?', [$c[0], $id])->fetch()) {
            flash('Une zone porte déjà ce nom.', 'erreur');
        } elseif ($action === 'ajouter') {
            requete('INSERT INTO zones_livraison (nom, region, frais, delai_jours) VALUES (?, ?, ?, ?)', $c);
            journaliser('zone_ajoutee', $c[0] . ' (' . $c[1] . ') : ' . $c[2] . ' FCFA, ' . $c[3] . ' j');
            flash('Zone « ' . $c[0] . ' » ajoutée : elle est proposée aux clients dès maintenant.');
        } else {
            requete('UPDATE zones_livraison SET nom = ?, region = ?, frais = ?, delai_jours = ? WHERE id = ?', [...$c, $id]);
            journaliser('zone_modifiee', $c[0] . ' (#' . $id . ') : ' . $c[2] . ' FCFA, ' . $c[3] . ' j');
            flash('Zone mise à jour (elle s\'applique aux prochaines commandes).');
        }
    } elseif ($action === 'basculer' && $zone) {
        $actives = (int) requete('SELECT COUNT(*) FROM zones_livraison WHERE actif = 1')->fetchColumn();
        if ($zone['actif'] && $actives <= 1) {
            flash('Impossible : il faut au moins une zone active, sinon plus personne ne peut commander.', 'erreur');
        } else {
            requete('UPDATE zones_livraison SET actif = 1 - actif WHERE id = ?', [$id]);
            journaliser($zone['actif'] ? 'zone_desactivee' : 'zone_activee', $zone['nom'] . ' (#' . $id . ')');
            flash('Zone « ' . $zone['nom'] . ' » ' . ($zone['actif'] ? 'désactivée : elle n\'est plus proposée.' : 'activée.'));
        }
    } elseif ($action === 'supprimer' && $zone) {
        if ((int) requete('SELECT COUNT(*) FROM adresses WHERE zone_id = ?', [$id])->fetchColumn() > 0) {
            flash('Impossible de supprimer : des clients ont enregistré une adresse dans cette zone. Désactivez-la plutôt.', 'erreur');
        } elseif ($zone['actif'] && (int) requete('SELECT COUNT(*) FROM zones_livraison WHERE actif = 1')->fetchColumn() <= 1) {
            flash('Impossible : il faut au moins une zone active.', 'erreur');
        } else {
            requete('DELETE FROM zones_livraison WHERE id = ?', [$id]);
            journaliser('zone_supprimee', $zone['nom'] . ' (#' . $id . ')');
            flash('Zone supprimée.');
        }
    }
    rediriger('admin/zones');
}

$zones = requete('SELECT z.*, (SELECT COUNT(*) FROM adresses a WHERE a.zone_id = z.id) AS nb_adresses FROM zones_livraison z ORDER BY z.actif DESC, z.region, z.frais, z.nom')->fetchAll();
$titre = 'Zones de livraison — Administration';
require __DIR__ . '/../includes/header.php';
?>
<main class="page">
  <div class="wrap">
    <nav class="fil" aria-label="Fil d'Ariane"><a href="<?= e(url()) ?>">Accueil</a> / <a href="<?= e(url('admin')) ?>">Administration</a> / <span>Zones de livraison</span></nav>
    <h1 class="titre-page">Administration</h1>
    <?php admin_onglets('zones'); ?>
    <p class="doux">Les clients ne peuvent commander que vers une zone <b>active</b>. Les frais indiqués ici sont les <b>frais de référence</b> : chaque vendeur peut fixer les siens dans son espace (onglet « Boutique »), et ce sont ceux de référence qui s'appliquent pour les livraisons des livreurs Jënd. Une modification de frais s'applique aux prochaines commandes seulement.</p>
    <div class="deux-colonnes">
      <section>
        <h2 class="sous-titre">Zones (<?= count($zones) ?>)</h2>
        <?php foreach ($zones as $z): ?>
          <div class="adresse-carte zone-ligne <?= $z['actif'] ? '' : 'zone-inactive' ?>">
          <form method="post" class="zone-ligne" novalidate>
            <?= csrf_champ() ?><input type="hidden" name="id" value="<?= (int) $z['id'] ?>">
            <div class="zone-champs">
              <label class="champ"><span>Quartier / zone</span><input type="text" name="nom" value="<?= e($z['nom']) ?>" maxlength="100" required></label>
              <label class="champ"><span>Ville</span><input type="text" name="region" value="<?= e($z['region']) ?>" maxlength="60" required></label>
              <label class="champ"><span>Frais de référence (FCFA)</span><input type="number" name="frais" value="<?= (int) $z['frais'] ?>" min="0" max="100000" step="50" required></label>
              <label class="champ"><span>Délai (jours)</span><input type="number" name="delai_jours" value="<?= (int) $z['delai_jours'] ?>" min="1" max="30" required></label>
            </div>
            <p class="petit doux"><?= $z['actif'] ? 'Active' : '<b>Désactivée</b> (non proposée aux clients)' ?> · <?= (int) $z['nb_adresses'] ?> adresse(s) enregistrée(s)</p>
            <div class="zone-actions">
              <button class="btn btn-contour" type="submit" name="action" value="modifier">Enregistrer</button>
              <button class="btn btn-contour" type="submit" name="action" value="basculer"><?= $z['actif'] ? 'Désactiver' : 'Activer' ?></button>
            </div>
          </form>
          <?php if ((int) $z['nb_adresses'] === 0): ?>
            <form method="post" data-confirm="Supprimer cette zone définitivement ?"><?= csrf_champ() ?><input type="hidden" name="action" value="supprimer"><input type="hidden" name="id" value="<?= (int) $z['id'] ?>"><button class="lien lien-danger" type="submit"><i class="ph ph-trash"></i> Supprimer</button></form>
          <?php endif; ?>
          </div>
        <?php endforeach; ?>
      </section>
      <form method="post" class="formulaire formulaire-large" novalidate>
        <?= csrf_champ() ?><input type="hidden" name="action" value="ajouter">
        <h2 class="sous-titre">Ajouter une zone</h2>
        <label class="champ"><span>Quartier / zone</span><input type="text" name="nom" maxlength="100" placeholder="ex : Darou Marnane, ou Kaolack" required></label>
        <label class="champ"><span>Ville</span><input type="text" name="region" maxlength="60" placeholder="ex : Touba, Dakar, Kaolack…" required></label>
        <label class="champ"><span>Frais de livraison (FCFA)</span><input type="number" name="frais" min="0" max="100000" step="50" value="1000" required></label>
        <label class="champ"><span>Délai indicatif (jours)</span><input type="number" name="delai_jours" min="1" max="30" value="1" required></label>
        <button class="btn btn-primaire" type="submit">Ajouter la zone</button>
      </form>
    </div>
  </div>
</main>
<?php require __DIR__ . '/../includes/footer.php'; ?>
