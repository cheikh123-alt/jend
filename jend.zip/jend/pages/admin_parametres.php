<?php
exiger_admin();

if (post_verifie('admin/parametres')) {
    $action = $_POST['action'] ?? '';
    if ($action === 'frais_service') {
        $pct = str_replace(',', '.', trim((string) ($_POST['pct'] ?? '')));
        $min = trim((string) ($_POST['minimum'] ?? ''));
        if (!is_numeric($pct) || (float) $pct < 0 || (float) $pct > 10 || !ctype_digit($min) || (int) $min > 5000) {
            flash('Valeurs invalides : pourcentage entre 0 et 10, minimum entre 0 et 5 000 FCFA.', 'erreur');
        } else {
            $fin = trim((string) ($_POST['fin'] ?? ''));
            if ($fin !== '' && (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $fin) || strtotime($fin) === false)) {
                flash('Date de fin invalide.', 'erreur');
                rediriger('admin/parametres');
            }
            parametre_definir('frais_service_pct', (string) round((float) $pct, 2));
            parametre_definir('frais_service_min', (string) (int) $min);
            parametre_definir('frais_service_fin', $fin);
            journaliser('frais_service_modifies', round((float) $pct, 2) . ' %, minimum ' . (int) $min . ' FCFA' . ($fin !== '' ? ', jusqu\'au ' . $fin : ', sans date de fin'));
            flash((float) $pct > 0 ? 'Frais de paiement sécurisé : ' . str_replace('.', ',', (string) round((float) $pct, 2)) . ' % (minimum ' . fcfa((int) $min) . '), affichés au client avant de payer.' : 'Frais de paiement sécurisé désactivés : Jënd paie seul les frais du prestataire.');
        }
    } elseif ($action === 'unitech_webhook') {
        try {
            unitech_configurer_webhook();
            journaliser('unitech_webhook', app_url('paiement/webhook'));
            flash('Adresse de notification enregistrée chez UnitechPay : ' . app_url('paiement/webhook'));
        } catch (RuntimeException $e) {
            flash('UnitechPay : ' . $e->getMessage(), 'erreur');
        }
    } elseif ($action === 'prestataire') {
        $p = (string) ($_POST['principal'] ?? '');
        if (!in_array($p, prestataires_actifs(), true)) {
            flash('Prestataire non disponible.', 'erreur');
        } else {
            parametre_definir('prestataire_principal', $p);
            journaliser('prestataire_principal', PRESTATAIRES[$p]);
            flash(PRESTATAIRES[$p] . ' est maintenant le prestataire principal' . (count(prestataires_actifs()) > 1 ? ' (les autres restent en secours automatique et leurs paiements en cours sont toujours confirmés).' : '.'));
        }
    } elseif ($action === 'retrait_2fa') {
        $actif = !empty($_POST['actif']);
        parametre_definir('retrait_2fa', $actif ? '1' : '0');
        journaliser($actif ? 'retrait_2fa_active' : 'retrait_2fa_desactive');
        flash($actif ? 'Les vendeurs devront activer la double authentification pour retirer leurs gains.' : 'Double authentification non exigée pour les retraits.');
    } elseif ($action === 'email_test') {
        $dest = (string) utilisateur()['email'];
        $ok = envoyer_email($dest, 'Test d\'envoi — Jënd', "Bonjour,\n\nSi vous lisez ce message, l'envoi d'e-mails de Jënd fonctionne.\n\nEnvoyé le " . date('d/m/Y à H:i') . '.');
        journaliser('email_test', $ok ? 'envoyé' : 'échec');
        flash($ok ? 'E-mail de test envoyé à ' . $dest . ' : vérifiez votre boîte (et les indésirables). S\'il n\'arrive pas, le service d\'envoi refuse les messages.' : 'Échec de l\'envoi : vérifiez MAIL_DRIVER et les réglages SMTP du fichier .env (détail dans le journal d\'erreurs du serveur).', $ok ? 'ok' : 'erreur');
    } elseif ($action === 'paiement_en_ligne') {
        $actif = !empty($_POST['actif']);
        if (!$actif && !paiement_livraison_actif()) {
            flash('Activez d\'abord le paiement à la livraison : sans lui, plus aucun client ne pourrait commander.', 'erreur');
        } else {
            parametre_definir('paiement_en_ligne', $actif ? '1' : '0');
            journaliser($actif ? 'paiement_en_ligne_active' : 'paiement_en_ligne_desactive');
            flash($actif ? 'Paiement en ligne réactivé : Wave, Orange Money et carte sont de nouveau proposés.' : 'Paiement en ligne coupé : les clients paient en espèces à la livraison, sans acompte. Rallumez-le dès qu\'un prestataire a validé votre compte.');
        }
    } elseif ($action === 'paiement_livraison') {
        $actif = !empty($_POST['actif']);
        if (!$actif && !paiement_en_ligne_actif()) {
            flash('Le paiement en ligne est coupé : réactivez-le avant de retirer le paiement à la livraison, sinon plus aucun client ne pourrait commander.', 'erreur');
            rediriger('admin/parametres');
        }
        parametre_definir('paiement_livraison', $actif ? '1' : '0');
        journaliser($actif ? 'paiement_livraison_active' : 'paiement_livraison_desactive');
        flash($actif ? 'Paiement à la livraison activé pour les prochaines commandes (avec acompte si l\'acompte est activé).' : 'Paiement à la livraison désactivé : les clients paient en ligne. Les commandes déjà passées ne changent pas.');
    } elseif ($action === 'livreurs') {
        $actif = !empty($_POST['actif']);
        parametre_definir('livreurs_jend', $actif ? '1' : '0');
        journaliser($actif ? 'livreurs_jend_actives' : 'livreurs_jend_desactives');
        flash($actif ? 'Livraison par les livreurs Jënd activée : elle s\'applique aux boutiques que vous lui confiez (page Boutiques), pour les prochaines commandes.' : 'Livraison par les livreurs Jënd désactivée : chaque vendeur livre lui-même ses prochaines commandes. Les livraisons déjà en cours se terminent normalement.');
    } elseif ($action === 'acompte') {
        $actif = !empty($_POST['actif']);
        $pct = str_replace(',', '.', trim((string) ($_POST['pourcent'] ?? '')));
        $min = trim((string) ($_POST['minimum'] ?? ''));
        if ($actif && (!is_numeric($pct) || $pct <= 0 || $pct > 100)) {
            flash('Pourcentage d\'acompte invalide (entre 1 et 100).', 'erreur');
        } elseif ($actif && (!ctype_digit($min) || (int) $min > 1000000)) {
            flash('Minimum invalide (nombre entier de FCFA, 0 à 1 000 000).', 'erreur');
        } else {
            parametre_definir('acompte_actif', $actif ? '1' : '0');
            if ($actif) {
                parametre_definir('acompte_pourcent', (string) round((float) $pct, 1));
                parametre_definir('acompte_minimum', $min);
            }
            journaliser('acompte_modifie', $actif ? round((float) $pct, 1) . ' %, minimum ' . $min . ' FCFA' : 'désactivé');
            flash($actif ? 'Acompte enregistré : il s\'applique aux prochaines commandes payées à la livraison.' : 'Acompte désactivé : les commandes payées à la livraison n\'en demandent plus.');
        }
    } elseif ($action === 'verification_email') {
        $actif = !empty($_POST['actif']);
        parametre_definir('verification_email', $actif ? '1' : '0');
        journaliser($actif ? 'verification_email_activee' : 'verification_email_desactivee');
        flash($actif ? 'Les nouveaux inscrits devront confirmer leur adresse e-mail avant d\'ouvrir une boutique.' : 'Confirmation de l\'e-mail désactivée : les nouveaux inscrits peuvent ouvrir une boutique tout de suite.');
    } elseif ($action === 'parrainage') {
        $j = trim((string) ($_POST['jours'] ?? ''));
        if (!ctype_digit($j) || (int) $j > 365) {
            flash('Nombre de jours invalide (0 à 365 ; 0 = parrainage désactivé).', 'erreur');
        } else {
            parametre_definir('parrainage_jours', (string) (int) $j);
            journaliser('parrainage_modifie', (int) $j . ' jours');
            flash((int) $j === 0 ? 'Parrainage désactivé.' : 'Parrainage : ' . (int) $j . ' jours sans commission pour le parrain et le filleul, à la validation de la boutique parrainée.');
        }
    } elseif ($action === 'dette') {
        $max = trim((string) ($_POST['maximum'] ?? ''));
        if (!ctype_digit($max) || (int) $max > 10000000) {
            flash('Montant invalide (nombre entier de FCFA ; 0 = ne jamais bloquer).', 'erreur');
        } else {
            parametre_definir('dette_commission_max', (string) (int) $max);
            journaliser('dette_max_modifiee', (int) $max . ' FCFA');
            flash((int) $max === 0 ? 'Blocage désactivé : les commandes en espèces ne sont jamais bloquées.' : 'Un vendeur qui doit plus de ' . fcfa((int) $max) . ' à Jënd ne reçoit plus de commandes en espèces tant qu\'il n\'a pas régularisé.');
        }
    } elseif ($action === 'retraits') {
        $j = trim((string) ($_POST['jours'] ?? ''));
        if (!ctype_digit($j) || (int) $j > 30) {
            flash('Délai invalide (nombre de jours entier, de 0 à 30).', 'erreur');
        } else {
            parametre_definir('delai_retrait_jours', (string) (int) $j);
            journaliser('delai_retrait_modifie', (int) $j . ' jour(s)');
            flash('Délai avant retrait : ' . (int) $j . ' jour(s) après la livraison. Il s\'applique à tous les gains non encore retirés.');
        }
    } elseif ($action === 'infos_paiement') {
        $jour = (string) ($_POST['jour'] ?? '');
        $taux = trim((string) ($_POST['taux'] ?? ''));
        if (!in_array($jour, ['', 'lundi', 'mardi', 'mercredi', 'jeudi', 'vendredi'], true)) {
            flash('Jour de reversement invalide.', 'erreur');
        } elseif (mb_strlen($taux) > 80 || preg_match('/[<>"\x00-\x1F]/u', $taux)) {
            flash('Taux indicatif invalide (80 caractères maximum, sans balises ni guillemets).', 'erreur');
        } else {
            parametre_definir('jour_reversement', $jour);
            parametre_definir('paydunya_taux_indicatif', $taux);
            journaliser('infos_paiement_modifiees', ($jour ?: 'sans jour fixe') . ' · taux : ' . ($taux ?: 'non indiqué'));
            flash('Informations de paiement enregistrées : elles s\'affichent sur la page « Paiements et reversements ».');
        }
    } elseif ($action === 'commission') {
        $pct = str_replace(',', '.', trim((string) ($_POST['commission'] ?? '')));
        if (is_numeric($pct) && $pct >= 0 && $pct <= 50) {
            parametre_definir('commission_defaut', (string) round((float) $pct, 2));
            parametre_definir('commission_offre_lancement', !empty($_POST['lancement']) ? '1' : '0');
            journaliser('commission_defaut_modifiee', round((float) $pct, 2) . ' %');
            flash('Commission des nouvelles boutiques : ' . commission_texte() . ' %. Les boutiques existantes gardent leur taux (modifiable page Boutiques).');
        } else {
            flash('Commission invalide (entre 0 et 50 %).', 'erreur');
        }
    }
    if ($action === 'annonce') {
        $pct = str_replace(',', '.', trim((string) ($_POST['pct'] ?? '')));
        $le = trim((string) ($_POST['le'] ?? ''));
        $minimum = date('Y-m-d', strtotime('+' . COMMISSION_PREAVIS_JOURS . ' days'));
        if (!is_numeric($pct) || $pct < 0 || $pct > 50) {
            flash('Taux annoncé invalide (entre 0 et 50 %).', 'erreur');
        } elseif (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $le) || strtotime($le) === false) {
            flash('Date d\'entrée en vigueur invalide.', 'erreur');
        } elseif ($le < $minimum) {
            flash('Les vendeurs doivent être prévenus au moins ' . COMMISSION_PREAVIS_JOURS . ' jours à l\'avance : choisissez le ' . date('d/m/Y', strtotime($minimum)) . ' ou une date plus tardive.', 'erreur');
        } else {
            parametre_definir('commission_annonce_pct', (string) round((float) $pct, 2));
            parametre_definir('commission_annonce_le', $le);
            $n = 0;
            foreach (requete("SELECT DISTINCT u.email, u.nom FROM boutiques b JOIN users u ON u.id = b.user_id WHERE b.statut IN ('active', 'en_attente')")->fetchAll() as $v) {
                $prenom = explode(' ', trim((string) $v['nom']))[0];
                if (envoyer_email((string) $v['email'], 'Évolution de la commission Jënd à partir du ' . date('d/m/Y', strtotime($le)),
                    "Bonjour $prenom,\n\nÀ partir du " . date('d/m/Y', strtotime($le)) . ", la commission de Jënd sera de " . commission_texte((float) $pct) . " % sur le prix des produits des commandes passées à partir de cette date (livrées et payées). Les commandes passées avant cette date ne sont pas concernées.\n\nSi ce taux ne vous convient pas, vous pouvez fermer votre boutique avant cette date : vos gains vous seront versés normalement.\n\nDétails : " . app_url('frais-commissions'))) {
                    $n++;
                }
            }
            journaliser('commission_annoncee', round((float) $pct, 2) . ' % à partir du ' . $le . ' (' . $n . ' vendeur(s) prévenu(s))');
            flash('Annonce enregistrée et envoyée à ' . $n . ' vendeur(s). Elle est affichée sur la page « Frais et commissions » et dans leur espace. Le nouveau taux ne s\'appliquera pas avant le ' . date('d/m/Y', strtotime($le)) . '.');
        }
    } elseif ($action === 'annonce_annuler') {
        requete("DELETE FROM parametres WHERE cle IN ('commission_annonce_pct', 'commission_annonce_le')");
        parametres_charges(true);
        journaliser('commission_annonce_annulee');
        flash('Annonce annulée. Pensez à prévenir les vendeurs qu\'aucun changement n\'aura lieu.');
    } elseif ($action === 'appliquer') {
        $ann = commission_annonce();
        if (!$ann) {
            flash('Aucune annonce à appliquer.', 'erreur');
        } elseif ($ann['le'] > date('Y-m-d')) {
            flash('Le nouveau taux ne peut être appliqué qu\'à partir du ' . date('d/m/Y', strtotime($ann['le'])) . ' (préavis promis aux vendeurs).', 'erreur');
        } else {
            commission_annonce_appliquer();
            flash('Nouvelle commission de ' . commission_texte($ann['pct']) . ' % appliquée à toutes les boutiques, pour les commandes à partir de maintenant.');
        }
    }
    rediriger('admin/parametres');
}

$nbLivreurs = (int) requete("SELECT COUNT(*) FROM users WHERE role = 'livreur' AND actif = 1")->fetchColumn();
$nbBoutiquesJend = (int) requete("SELECT COUNT(*) FROM boutiques WHERE livraison_par = 'jend'")->fetchColumn();
$livreursActifs = livreurs_jend_actifs();
$acompteActif = parametre_actif('acompte_actif', true);
$codActif = paiement_livraison_actif();
$acomptePct = (string) (parametre('acompte_pourcent', env('ACOMPTE_POURCENT', '20')));
$acompteMin = (string) (parametre('acompte_minimum', env('ACOMPTE_MINIMUM', '1000')));
$titre = 'Paramètres — Administration';
require __DIR__ . '/../includes/header.php';
?>
<main class="page">
  <div class="wrap">
    <nav class="fil" aria-label="Fil d'Ariane"><a href="<?= e(url()) ?>">Accueil</a> / <a href="<?= e(url('admin')) ?>">Administration</a> / <span>Paramètres</span></nav>
    <h1 class="titre-page">Administration</h1>
    <?php admin_onglets('parametres'); ?>
    <p class="doux">Ces réglages se changent à tout moment. Ils s'appliquent aux <b>prochaines commandes</b> : les commandes déjà passées ne changent pas.</p>

    <section class="carte-param <?= $livreursActifs ? 'param-actif' : '' ?>">
      <h2><i class="ph ph-motorcycle"></i> Livraison par les livreurs Jënd
        <span class="badge <?= $livreursActifs ? 'badge-livree' : 'badge-a_preparer' ?>"><?= $livreursActifs ? 'Activée' : 'Désactivée' ?></span></h2>
      <p>Au démarrage, <b>chaque vendeur livre lui-même</b> et touche le frais de livraison. Quand le site grandit, activez ici les livreurs Jënd : vous créez leurs comptes, affectez les courses (avec WhatsApp), et confiez à des boutiques précises la livraison par vos livreurs.</p>
      <p class="doux petit">Livreurs actifs : <b><?= $nbLivreurs ?></b> · boutiques déjà confiées aux livreurs Jënd (appliqué dès l'activation) : <b><?= $nbBoutiquesJend ?></b></p>
      <?php if ($livreursActifs): ?>
        <p class="petit"><a class="lien" href="<?= e(url('admin/livreurs')) ?>">Gérer les livreurs</a> · <a class="lien" href="<?= e(url('admin/courses')) ?>">Affecter les courses</a> · <a class="lien" href="<?= e(url('admin/boutiques')) ?>">Choisir les boutiques livrées par Jënd</a></p>
      <?php endif; ?>
      <form method="post" data-confirm="<?= $livreursActifs ? 'Désactiver la livraison par les livreurs Jënd ? Chaque vendeur livrera lui-même ses prochaines commandes.' : 'Activer la livraison par les livreurs Jënd ?' ?>"><?= csrf_champ() ?>
        <input type="hidden" name="action" value="livreurs"><input type="hidden" name="actif" value="<?= $livreursActifs ? '0' : '1' ?>">
        <button class="btn <?= $livreursActifs ? 'btn-contour' : 'btn-primaire' ?>" type="submit"><?= $livreursActifs ? 'Désactiver' : 'Activer les livreurs Jënd' ?></button></form>
    </section>

    <?php $enLigneActif = paiement_en_ligne_actif(); ?>
    <section class="carte-param <?= $enLigneActif ? '' : 'param-actif' ?>">
      <h2><i class="ph ph-credit-card"></i> Paiement en ligne (Wave, Orange Money, carte)
        <span class="badge <?= $enLigneActif ? 'badge-livree' : 'badge-a_preparer' ?>"><?= $enLigneActif ? 'Proposé' : 'Coupé' ?></span></h2>
      <p>Tant qu'aucun prestataire (PayDunya, PayTech) n'a <b>validé votre compte</b>, coupez le paiement en ligne : le site fonctionne alors en <b>paiement à la livraison uniquement</b>, sans acompte. Le client paie en espèces au vendeur à la réception. Rallumez-le le jour où un prestataire active votre compte.</p>
      <form method="post" data-confirm="<?= $enLigneActif ? 'Couper le paiement en ligne ? Les clients paieront uniquement à la livraison.' : 'Réactiver le paiement en ligne ?' ?>"><?= csrf_champ() ?><input type="hidden" name="action" value="paiement_en_ligne">
        <label class="case"><input type="checkbox" name="actif" value="1" <?= $enLigneActif ? 'checked' : '' ?>> <span>Proposer le paiement en ligne</span></label>
        <button class="btn btn-primaire" type="submit">Enregistrer</button>
      </form>
    </section>

    <section class="carte-param <?= $codActif ? 'param-actif' : '' ?>">
      <h2><i class="ph ph-hand-coins"></i> Paiement à la livraison (espèces)
        <span class="badge <?= $codActif ? 'badge-livree' : 'badge-a_preparer' ?>"><?= $codActif ? 'Activé' : 'Désactivé' ?></span></h2>
      <p>Désactivé, <b>tout l'argent passe d'abord par Jënd</b> (Wave, Orange Money, carte) : aucun risque d'espèces non reversées, pas d'acompte, pas de caisse livreur ni de dette de commission. Activé, le client peut payer en espèces à la réception, avec un acompte en ligne.</p>
      <form method="post" data-confirm="<?= $codActif ? 'Désactiver le paiement à la livraison ? Les clients devront payer en ligne.' : 'Activer le paiement à la livraison ?' ?>"><?= csrf_champ() ?><input type="hidden" name="action" value="paiement_livraison">
        <label class="case"><input type="checkbox" name="actif" value="1" <?= $codActif ? 'checked' : '' ?>> <span>Proposer le paiement à la livraison</span></label>
        <button class="btn btn-primaire" type="submit">Enregistrer</button>
      </form>
    </section>

    <section class="carte-param <?= $acompteActif ? 'param-actif' : '' ?>">
      <h2><i class="ph ph-hand-coins"></i> Acompte pour les paiements à la livraison
        <span class="badge <?= $acompteActif ? 'badge-livree' : 'badge-a_preparer' ?>"><?= $acompteActif ? 'Activé' : 'Désactivé' ?></span></h2>
      <p>Le client règle d'abord une partie en ligne pour confirmer sa commande ; le reste est payé en espèces à la livraison. Il limite les refus et les commandes fantaisistes.</p>
      <form method="post" class="formulaire formulaire-large" novalidate><?= csrf_champ() ?><input type="hidden" name="action" value="acompte">
        <label class="case"><input type="checkbox" name="actif" value="1" <?= $acompteActif ? 'checked' : '' ?>> <span>Demander un acompte</span></label>
        <label class="champ"><span>Pourcentage du total</span><input type="text" name="pourcent" value="<?= e($acomptePct) ?>" inputmode="decimal" class="largeur-90"> %</label>
        <label class="champ"><span>Minimum (FCFA)</span><input type="text" name="minimum" value="<?= e($acompteMin) ?>" inputmode="numeric" class="largeur-90"></label>
        <button class="btn btn-primaire" type="submit">Enregistrer</button>
      </form>
    </section>

    <?php $actifs = prestataires_actifs(); $principal = prestataire_principal(); ?>
    <section class="carte-param <?= $actifs ? 'param-actif' : '' ?>">
      <h2><i class="ph ph-credit-card"></i> Prestataires de paiement</h2>
      <?php if (!$actifs): ?>
        <p>Paiement <b>simulé</b> (développement / site de test) : aucun argent réel. Pour encaisser, mettez dans config.env <code>PAIEMENT_FOURNISSEUR=paydunya</code>, <code>paytech</code>, ou les deux : <code>paydunya,paytech</code>, avec leurs clés.</p>
      <?php else: ?>
        <p>Le <b>principal</b> crée les nouveaux paiements. Les autres restent branchés : <b>secours automatique</b> si le principal ne répond pas, et leurs paiements en cours sont toujours confirmés. Le client ne voit aucune différence (Wave, Orange Money, carte…).</p>
        <form method="post"><?= csrf_champ() ?><input type="hidden" name="action" value="prestataire">
          <?php foreach ($actifs as $p):
              $ok = prestataire_configure($p);
              $test = prestataire_mode_test($p); ?>
            <label class="case"><input type="radio" name="principal" value="<?= e($p) ?>" <?= $p === $principal ? 'checked' : '' ?> <?= $ok ? '' : 'disabled' ?>>
              <span><b><?= e(PRESTATAIRES[$p]) ?></b> — <?= $ok ? '<i class="ph ph-check-circle"></i> clés présentes · ' . ($test ? 'mode <b>TEST</b>' : 'mode <b>RÉEL</b>') : '<i class="ph ph-warning-circle"></i> clés manquantes dans config.env' ?><?= $p === $principal ? ' · <b>principal</b>' : ' · secours' ?></span></label>
          <?php endforeach; ?>
          <button class="btn btn-contour" type="submit">Enregistrer</button>
        </form>
        <?php if ($derniere = paiement_derniere_erreur()): ?>
          <p class="alerte" role="alert"><i class="ph ph-warning-circle"></i> <span><b>Dernier paiement impossible</b> (le client a vu « paiement momentanément indisponible ») : <?= e($derniere) ?></span></p>
        <?php endif; ?>
        <?php if (in_array('unitech', $actifs, true) && unitech_configure()): ?>
          <form method="post" class="ligne-action"><?= csrf_champ() ?><input type="hidden" name="action" value="unitech_webhook">
            <span class="doux petit">UnitechPay prévient le site à une adresse unique, à enregistrer chez eux une fois : <code><?= e(app_url('paiement/webhook')) ?></code></span>
            <button class="btn btn-contour" type="submit"><i class="ph ph-plugs-connected"></i> Enregistrer cette adresse chez UnitechPay</button></form>
        <?php endif; ?>
        <?php if (count($actifs) < 2): ?><p class="doux petit">Pour garder les deux : <code>PAIEMENT_FOURNISSEUR=paydunya,paytech</code> dans config.env, avec les clés de chacun.</p><?php endif; ?>
      <?php endif; ?>
    </section>

    <?php $fsPct = (string) parametre('frais_service_pct', '0'); $fsMin = (string) parametre('frais_service_min', '0'); ?>
    <section class="carte-param <?= frais_service(100000) > 0 ? 'param-actif' : '' ?>">
      <h2><i class="ph ph-shield-check"></i> Frais de paiement sécurisé (payés par le client)</h2>
      <p>Le prestataire de paiement prélève des frais sur chaque paiement en ligne. Avec une commission basse, <b>ces frais peuvent dépasser ce que tu gagnes</b> (voir Trésorerie). Ici, tu peux les faire payer au client : une ligne « Paiement sécurisé » s'ajoute au total, <b>affichée avant qu'il paie</b>. Elle te revient (jamais au vendeur) et elle est remboursée si la commande est annulée. Mets le pourcentage proche de celui de ton prestataire.</p>
      <form method="post" class="ligne-action"><?= csrf_champ() ?><input type="hidden" name="action" value="frais_service">
        <label class="sr" for="fsp">Pourcentage</label><input id="fsp" type="text" name="pct" value="<?= e(str_replace('.', ',', $fsPct)) ?>" inputmode="decimal" class="largeur-90"> %
        · minimum <label class="sr" for="fsm">Minimum</label><input id="fsm" type="text" name="minimum" value="<?= e($fsMin) ?>" inputmode="numeric" class="largeur-90"> FCFA (0 % = désactivé)
        · jusqu'au <label class="sr" for="fsf">Date de fin</label><input id="fsf" type="date" name="fin" value="<?= e((string) parametre('frais_service_fin', '')) ?>"> <span class="doux petit">(vide = sans fin)</span>
        <button class="btn btn-contour" type="submit">Enregistrer</button></form>
      <?php $fsFin = (string) parametre('frais_service_fin', ''); if ($fsFin !== '' && (float) str_replace(',', '.', $fsPct) > 0): ?>
        <p class="doux petit"><?= date('Y-m-d') > $fsFin ? '<b>Terminé</b> depuis le ' . e(date('d/m/Y', strtotime($fsFin))) . ' : les clients ne paient plus ce frais.' : 'Les clients paient ce frais <b>jusqu\'au ' . e(date('d/m/Y', strtotime($fsFin))) . ' inclus</b>, puis il s\'arrête tout seul.' ?></p>
      <?php endif; ?>
    </section>

    <section class="carte-param <?= parametre_actif('retrait_2fa', false) ? 'param-actif' : '' ?>">
      <h2><i class="ph ph-lock-key"></i> Sécurité des retraits des vendeurs</h2>
      <p>Toujours actif : un e-mail de contrôle au vendeur à chaque demande de retrait et à chaque changement de numéro de paiement ; <b>retraits suspendus <?= RETRAIT_DELAI_CHANGEMENT_HEURES ?> h</b> après un changement de numéro ; avertissement « Numéro changé » sur la page Retraits. En plus, tu peux exiger la double authentification pour retirer (recommandé quand le volume grandit).</p>
      <form method="post"><?= csrf_champ() ?><input type="hidden" name="action" value="retrait_2fa">
        <label class="case"><input type="checkbox" name="actif" value="1" <?= parametre_actif('retrait_2fa', false) ? 'checked' : '' ?>> <span>Exiger la double authentification des vendeurs pour retirer leurs gains</span></label>
        <button class="btn btn-primaire" type="submit">Enregistrer</button></form>
    </section>

    <?php $driver = (string) (env('MAIL_DRIVER') ?: (env('APP_ENV', 'prod') === 'dev' ? 'log' : 'mail')); $smtpOk = env('SMTP_HOST', '') !== '' && env('SMTP_USER', '') !== '' && env('SMTP_PASS', '') !== ''; ?>
    <section class="carte-param <?= $driver === 'smtp' && $smtpOk ? 'param-actif' : '' ?>">
      <h2><i class="ph ph-envelope-simple"></i> Envoi des e-mails
        <span class="badge <?= $driver === 'smtp' && $smtpOk ? 'badge-livree' : 'badge-a_preparer' ?>"><?= e($driver === 'smtp' ? ($smtpOk ? 'SMTP configuré' : 'SMTP incomplet') : ($driver === 'log' ? 'Aucun envoi (journal)' : 'Fonction mail() du serveur')) ?></span></h2>
      <p>Confirmation d'inscription, mot de passe oublié, réponses d'aide, alertes : tout passe par e-mail. <b>Le plus fiable est un service SMTP</b> (Brevo, Mailjet…) réglé dans le fichier <code>.env</code> (<code>MAIL_DRIVER=smtp</code>, <code>SMTP_HOST</code>, <code>SMTP_PORT</code>, <code>SMTP_USER</code>, <code>SMTP_PASS</code>, <code>MAIL_FROM</code>). Envoie-toi un test après chaque changement.</p>
      <form method="post"><?= csrf_champ() ?><input type="hidden" name="action" value="email_test"><button class="btn btn-contour" type="submit"><i class="ph ph-paper-plane-tilt"></i> M'envoyer un e-mail de test</button></form>
    </section>

    <section class="carte-param <?= verification_email_active() ? 'param-actif' : '' ?>">
      <h2><i class="ph ph-envelope-simple"></i> Confirmation de l'e-mail à l'inscription
        <span class="badge <?= verification_email_active() ? 'badge-livree' : 'badge-a_preparer' ?>"><?= verification_email_active() ? 'Activée' : 'Désactivée' ?></span></h2>
      <p>Activée, un nouvel inscrit reçoit un lien par e-mail et doit l'ouvrir avant d'ouvrir une boutique, de négocier un prix ou de demander du sur-mesure (il peut commander sans attendre) : personne ne peut créer un compte avec l'adresse d'un autre. <b>Désactive-la seulement si ton hébergeur n'envoie pas d'e-mails</b>, sinon les vendeurs resteraient bloqués.</p>
      <?php if (env('APP_ENV') === 'dev'): ?><p class="petit"><a class="lien" href="<?= e(url('dev/emails')) ?>"><i class="ph ph-tray"></i> Voir les e-mails envoyés par le site local (boîte de réception de test)</a></p><?php endif; ?>
      <?php if (verification_email_active() && in_array((string) env('MAIL_DRIVER'), ['log', ''], true) && env('APP_ENV') !== 'dev'): ?>
        <p class="alerte" role="alert"><i class="ph ph-warning"></i> <span><b>Les e-mails ne sont pas envoyés sur ce site</b> (MAIL_DRIVER=<?= e((string) env('MAIL_DRIVER') ?: 'non défini') ?>) : personne ne reçoit le lien de confirmation, donc <b>personne ne peut ouvrir de boutique</b>. Configure le SMTP dans le fichier de configuration, ou désactive la confirmation ci-dessous en attendant.</span></p>
      <?php endif; ?>
      <form method="post"><?= csrf_champ() ?><input type="hidden" name="action" value="verification_email">
        <label class="case"><input type="checkbox" name="actif" value="1" <?= verification_email_active() ? 'checked' : '' ?>> <span>Exiger la confirmation de l'adresse e-mail</span></label>
        <button class="btn btn-primaire" type="submit">Enregistrer</button></form>
    </section>

    <section class="carte-param <?= parrainage_jours() > 0 ? 'param-actif' : '' ?>">
      <h2><i class="ph ph-gift"></i> Parrainage entre vendeurs</h2>
      <p>Chaque vendeur a un lien d'invitation. Quand tu <b>valides</b> une boutique parrainée, le parrain et le nouveau vendeur gagnent chacun une période <b>sans commission</b> (elle s'ajoute à celle qu'ils ont déjà). Tu restes le garde-fou : pas de validation, pas de récompense.</p>
      <form method="post" class="ligne-action"><?= csrf_champ() ?><input type="hidden" name="action" value="parrainage">
        <label class="sr" for="pj">Jours sans commission</label><input id="pj" type="text" name="jours" value="<?= parrainage_jours() ?>" inputmode="numeric" class="largeur-90"> jours sans commission (0 = désactivé)
        <button class="btn btn-contour" type="submit">Enregistrer</button></form>
    </section>

    <section class="carte-param">
      <h2><i class="ph ph-warning-circle"></i> Dettes de commission des vendeurs</h2>
      <p>Quand un vendeur encaisse des espèces, il te doit ta commission. Elle est retenue automatiquement sur ses gains ; s'il n'en a pas assez, sa dette est <b>reportée sur ses prochains gains</b> et affichée dans « Mes gains ». Au-delà du plafond ci-dessous, ses nouvelles commandes <b>en espèces</b> sont bloquées (les paiements en ligne restent possibles). Sans commission (0 %), il n'y a jamais de dette.</p>
      <form method="post" class="ligne-action"><?= csrf_champ() ?><input type="hidden" name="action" value="dette">
        <label class="sr" for="dmax">Plafond en FCFA</label><input id="dmax" type="text" name="maximum" value="<?= (int) parametre('dette_commission_max', '20000') ?>" inputmode="numeric" class="largeur-120"> FCFA (0 = ne jamais bloquer)
        <button class="btn btn-contour" type="submit">Enregistrer</button></form>
    </section>

    <section class="carte-param">
      <h2><i class="ph ph-bank"></i> Retraits des vendeurs</h2>
      <p>Un gain devient retirable quelques jours <b>après la livraison confirmée</b>. Ce délai laisse au client le temps de signaler un problème (7 jours) sans que l'argent soit déjà parti chez le vendeur. Reverse tes vendeurs à jour fixe (par exemple le lundi) depuis « Retraits ».</p>
      <form method="post" class="ligne-action"><?= csrf_champ() ?><input type="hidden" name="action" value="retraits">
        <label class="sr" for="jours">Délai en jours</label><input id="jours" type="text" name="jours" value="<?= (int) delai_retrait_jours() ?>" inputmode="numeric" class="largeur-90"> jour(s) après la livraison (0 à 30)
        <button class="btn btn-contour" type="submit">Enregistrer</button></form>
    </section>

    <section class="carte-param">
      <h2><i class="ph ph-info"></i> Informations de paiement montrées aux vendeurs</h2>
      <p>Affichées sur la page publique <a class="lien" href="<?= e(url('paiements-vendeurs')) ?>">Paiements et reversements</a>. Rien n'est inventé : si tu ne remplis pas ces champs, la page renvoie vers la grille officielle de PayDunya.</p>
      <form method="post" class="formulaire formulaire-large" novalidate><?= csrf_champ() ?><input type="hidden" name="action" value="infos_paiement">
        <label class="champ"><span>Jour des versements automatiques aux vendeurs (ce jour-là, le solde de chaque vendeur est préparé « à payer » dans Retraits)</span>
          <select name="jour"><?php $jr = (string) parametre('jour_reversement', ''); foreach (['' => 'Pas de jour fixe (« dans les meilleurs délais »)', 'lundi' => 'Chaque lundi', 'mardi' => 'Chaque mardi', 'mercredi' => 'Chaque mercredi', 'jeudi' => 'Chaque jeudi', 'vendredi' => 'Chaque vendredi'] as $cle => $lib): ?><option value="<?= e($cle) ?>" <?= $jr === $cle ? 'selected' : '' ?>><?= e($lib) ?></option><?php endforeach; ?></select></label>
        <label class="champ"><span>Taux de frais PayDunya, à titre indicatif (facultatif, recopié depuis leur grille officielle)</span>
          <input type="text" name="taux" maxlength="80" value="<?= e((string) parametre('paydunya_taux_indicatif', '')) ?>" placeholder="ex : 3 % par paiement mobile money (à vérifier)"></label>
        <button class="btn btn-primaire" type="submit">Enregistrer</button>
        <p class="doux petit">Ne recopie que ce que PayDunya affiche officiellement ; les vendeurs s'appuieront sur ce chiffre.</p>
      </form>
    </section>

    <section class="carte-param">
      <h2><i class="ph ph-percent"></i> Commission des nouvelles boutiques</h2>
      <p>Actuellement <b><?= e(commission_texte()) ?> %</b><?= commission_defaut() == 0.0 ? ' (offre de lancement : les vendeurs gardent 100 % de leurs ventes)' : '' ?>. Quand le site grandit, vous pouvez la relever : les vendeurs doivent être prévenus <b>30 jours à l'avance</b> (voir les conditions des vendeurs). Les boutiques existantes gardent leur taux, modifiable une par une dans <a class="lien" href="<?= e(url('admin/boutiques')) ?>">Boutiques</a>.</p>
      <form method="post" class="ligne-action"><?= csrf_champ() ?><input type="hidden" name="action" value="commission">
        <label class="sr" for="com">Commission en %</label><input id="com" type="text" name="commission" value="<?= e(commission_texte()) ?>" inputmode="decimal" class="largeur-90"> %
        <label class="case"><input type="checkbox" name="lancement" value="1" <?= parametre_actif('commission_offre_lancement', true) ? 'checked' : '' ?>> <span>Présenter ce taux comme une <b>offre de lancement</b> sur le site</span></label>
        <button class="btn btn-contour" type="submit">Enregistrer</button></form>
      <p class="doux petit">« Enregistrer » ne change que les <b>nouvelles</b> boutiques. Pour une hausse annoncée à tous les vendeurs, utilisez l'annonce ci-dessous.</p>

      <h3 class="sous-titre">Annoncer un changement de commission aux vendeurs</h3>
      <?php $annonce = commission_annonce(); $minAnn = date('Y-m-d', strtotime('+' . COMMISSION_PREAVIS_JOURS . ' days')); ?>
      <?php if ($annonce): ?>
        <p class="alerte alerte-info"><i class="ph ph-megaphone"></i> <span>Annonce en cours : <b><?= e(commission_texte($annonce['pct'])) ?> %</b> à partir du <b><?= e(date('d/m/Y', strtotime($annonce['le']))) ?></b>. Les vendeurs ont été prévenus par e-mail ; l'annonce est visible sur « Frais et commissions », sur la page « Vendre » et dans leur espace. <b>Le taux s'appliquera automatiquement à cette date.</b></span></p>
        <div class="ligne-action">
          <form method="post" data-confirm="Appliquer ce taux à TOUTES les boutiques maintenant ?"><?= csrf_champ() ?><input type="hidden" name="action" value="appliquer">
            <button class="btn btn-primaire" type="submit" <?= $annonce['le'] > date('Y-m-d') ? 'disabled' : '' ?>>Appliquer à toutes les boutiques<?= $annonce['le'] > date('Y-m-d') ? ' (à partir du ' . e(date('d/m/Y', strtotime($annonce['le']))) . ')' : '' ?></button></form>
          <form method="post" data-confirm="Annuler cette annonce ?"><?= csrf_champ() ?><input type="hidden" name="action" value="annonce_annuler"><button class="btn btn-contour" type="submit">Annuler l'annonce</button></form>
        </div>
      <?php else: ?>
        <form method="post" class="formulaire formulaire-large" novalidate><?= csrf_champ() ?><input type="hidden" name="action" value="annonce">
          <label class="champ"><span>Nouveau taux (%)</span><input type="text" name="pct" inputmode="decimal" class="largeur-90" required></label>
          <label class="champ"><span>Entre en vigueur le (au moins <?= COMMISSION_PREAVIS_JOURS ?> jours après aujourd'hui)</span><input type="date" name="le" min="<?= e($minAnn) ?>" required></label>
          <button class="btn btn-primaire" type="submit">Envoyer l'annonce à tous les vendeurs</button>
          <p class="doux petit">Un e-mail part immédiatement à chaque vendeur. <b>Le nouveau taux s'applique tout seul à la date choisie</b> (dans l'heure), à toutes les boutiques, et seulement pour les commandes qui suivent. Exemple d'offre de lancement : commission à 1 % maintenant, puis annonce « 5 % à partir du 1er mars ».</p>
        </form>
      <?php endif; ?>
    </section>
  </div>
</main>
<?php require __DIR__ . '/../includes/footer.php'; ?>
