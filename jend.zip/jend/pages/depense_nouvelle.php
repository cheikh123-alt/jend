<?php
/** Enregistre le panier actuel comme « dépense du mois ». */
$u = exiger_connexion();
$panier = panier_charger();
if (!$panier['lignes']) {
    flash('Votre panier est vide : ajoutez d\'abord les produits de la dépense.', 'erreur');
    rediriger('panier');
}
$zones = zones_actives();
$derniere = requete('SELECT zone_id, adresse, telephone FROM adresses WHERE user_id = ? ORDER BY id DESC LIMIT 1', [$u['id']])->fetch() ?: [];
$v = ['nom' => 'Dépense du mois', 'jour' => (string) min(28, (int) date('j')), 'livraison_nom' => $u['nom'], 'livraison_telephone' => $derniere['telephone'] ?? '',
      'zone_id' => (string) ($derniere['zone_id'] ?? ''), 'adresse' => $derniere['adresse'] ?? '', 'cadeau' => ''];
$erreur = null;
if (post_verifie('depense/nouvelle')) {
    foreach ($v as $k => $_) {
        $v[$k] = trim((string) ($_POST[$k] ?? ''));
    }
    try {
        $id = depense_creer((int) $u['id'], $v);
        flash('Dépense enregistrée : nous vous rappellerons chaque mois. Vous pouvez la commander dès maintenant.');
        rediriger('depense/' . $id);
    } catch (RuntimeException $e) {
        $erreur = $e->getMessage();
    }
}
$titre = 'Nouvelle dépense du mois — Jënd';
require __DIR__ . '/../includes/header.php';
?>
<main class="page">
  <div class="wrap wrap-moyen">
    <nav class="fil" aria-label="Fil d'Ariane"><a href="<?= e(url('panier')) ?>">Panier</a> / <span>Dépense du mois</span></nav>
    <h1 class="titre-page">Enregistrer comme dépense du mois</h1>
    <p class="doux">Les <?= count($panier['lignes']) ?> produits de votre panier (environ <b><?= e(fcfa($panier['sous_total'])) ?></b>) seront enregistrés. Chaque mois, au jour choisi, vous recevrez un rappel pour la commander en un clic. Les prix seront ceux du jour.</p>
    <form method="post" class="formulaire formulaire-large" novalidate>
      <?= csrf_champ() ?>
      <?php if ($erreur): ?><p class="alerte" role="alert"><?= e($erreur) ?></p><?php endif; ?>
      <label class="champ"><span>Nom de la dépense</span><input name="nom" maxlength="80" required value="<?= e($v['nom']) ?>" placeholder="Ex. : Dépense de Maman"></label>
      <label class="champ"><span>Me le rappeler chaque mois le</span>
        <select name="jour"><?php for ($j = 1; $j <= 28; $j++): ?><option value="<?= $j ?>" <?= (int) $v['jour'] === $j ? 'selected' : '' ?>><?= $j === 1 ? '1er' : $j ?> du mois</option><?php endfor; ?></select></label>
      <h2 class="sous-titre">Qui reçoit la dépense ?</h2>
      <label class="case"><input type="checkbox" name="cadeau" value="1" <?= $v['cadeau'] ? 'checked' : '' ?>> <span>C'est pour un proche (famille au Sénégal) : livré sans prix ni facture</span></label>
      <label class="champ"><span>Nom du destinataire</span><input name="livraison_nom" maxlength="120" required value="<?= e($v['livraison_nom']) ?>"></label>
      <label class="champ"><span>Téléphone du destinataire</span><input type="tel" name="livraison_telephone" required value="<?= e($v['livraison_telephone']) ?>" placeholder="77 123 45 67"></label>
      <label class="champ"><span>Zone de livraison</span>
        <select name="zone_id" required><option value="">— Choisir —</option><?php foreach ($zones as $z): ?><option value="<?= (int) $z['id'] ?>" <?= (string) $z['id'] === $v['zone_id'] ? 'selected' : '' ?>><?= e($z['nom']) ?></option><?php endforeach; ?></select></label>
      <label class="champ"><span>Adresse précise</span><textarea name="adresse" rows="2" maxlength="255" required><?= e($v['adresse']) ?></textarea></label>
      <button class="btn btn-primaire" type="submit"><i class="ph ph-basket"></i> Enregistrer la dépense</button>
    </form>
  </div>
</main>
<?php require __DIR__ . '/../includes/footer.php'; ?>
