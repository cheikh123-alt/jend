<?php
/**
 * « Images pour mon statut » : le vendeur crée, pour chaque produit, une image verticale (format statut WhatsApp / TikTok)
 * avec la photo, le prix, sa boutique et le lien Jënd. L'image est dessinée dans son navigateur (assets/js/statut.js) : rien n'est envoyé.
 */
[$u, $b] = exiger_vendeur();
$produits = requete(
    "SELECT p.id, p.nom, p.slug, p.prix, p.prix_barre, " . SQL_PROMO_FETE . " AS promo_pct,
            (SELECT chemin FROM produit_images i WHERE i.produit_id = p.id ORDER BY i.position LIMIT 1) AS image
       FROM produits p WHERE p.boutique_id = ? AND p.statut = 'publie' AND p.reserve_client_id IS NULL AND p.stock > 0
      ORDER BY p.created_at DESC LIMIT 60",
    [$b['id']]
)->fetchAll();
$titre = 'Images pour mon statut — Jënd';
$scripts_extra = ['js/statut.js'];
require __DIR__ . '/../includes/header.php';
?>
<main class="page">
  <div class="wrap">
    <nav class="fil" aria-label="Fil d'Ariane"><a href="<?= e(url('vendeur')) ?>">Espace vendeur</a> / <span>Images pour mon statut</span></nav>
    <h1 class="titre-page">Espace vendeur</h1>
    <?php vendeur_onglets('statut'); ?>
    <h2 class="sous-titre">Images pour mon statut</h2>
    <p class="doux">Choisissez un produit : Jënd prépare une belle image au format statut WhatsApp (et TikTok, Instagram) avec la photo, le prix, le nom de votre boutique et le lien pour commander. Publiez-la, vos contacts commandent en toute sécurité.</p>

    <?php if ($b['statut'] !== 'active'): ?>
      <p class="alerte alerte-info">Votre boutique doit être validée avant de partager vos produits.</p>
    <?php elseif (!$produits): ?>
      <div class="vide"><i class="ph ph-image"></i><p><b>Aucun produit publié en stock.</b></p><p><a class="btn btn-primaire" href="<?= e(url('vendeur/produits')) ?>">Ajouter un produit</a></p></div>
    <?php else: ?>
      <div class="statut-atelier">
        <ul class="statut-produits">
          <?php foreach ($produits as $p): $p = produit_avec_promo($p); $lien = lien_source(app_url('produit/' . $p['slug']), 'statut'); ?>
            <li>
              <button type="button" class="statut-choix"
                data-nom="<?= e($p['nom']) ?>" data-prix="<?= e(fcfa((int) $p['prix'])) ?>"
                data-prix-barre="<?= $p['prix_barre'] && (int) $p['prix_barre'] > (int) $p['prix'] ? e(fcfa((int) $p['prix_barre'])) : '' ?>"
                data-image="<?= $p['image'] ? e(url($p['image'])) : '' ?>" data-boutique="<?= e($b['nom']) ?>"
                data-lien="<?= e($lien) ?>" data-fichier="jend-<?= e($p['slug']) ?>.png">
                <?php if ($p['image']): ?><img src="<?= e(url(image_miniature($p['image']))) ?>" alt="" loading="lazy"><?php else: ?><span class="statut-sans-photo"><i class="ph ph-image"></i></span><?php endif; ?>
                <span><b><?= e($p['nom']) ?></b><small><?= e(fcfa((int) $p['prix'])) ?></small></span>
              </button>
            </li>
          <?php endforeach; ?>
        </ul>
        <section class="statut-apercu" aria-live="polite">
          <p class="statut-vide" id="statut-vide"><i class="ph ph-hand-pointing"></i> Choisissez un produit pour créer son image.</p>
          <img id="statut-image" alt="Aperçu de l'image pour le statut" hidden>
          <div class="statut-actions" id="statut-actions" hidden>
            <button type="button" class="btn btn-primaire" id="statut-partager" hidden><i class="ph ph-share-network"></i> Partager (WhatsApp…)</button>
            <a class="btn btn-contour" id="statut-telecharger" download><i class="ph ph-download-simple"></i> Télécharger l'image</a>
            <button type="button" class="btn btn-contour" id="statut-copier"><i class="ph ph-link"></i> Copier le lien du produit</button>
          </div>
          <p class="petit doux" id="statut-aide" hidden>Sur téléphone : « Partager » puis WhatsApp → « Mon statut ». Ajoutez le lien copié en légende pour que vos contacts puissent commander.</p>
        </section>
      </div>
    <?php endif; ?>
  </div>
</main>
<?php require __DIR__ . '/../includes/footer.php'; ?>
