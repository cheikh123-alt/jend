<?php
exiger_admin();

if (post_verifie('admin/courses')) {
    $id = (int) ($_POST['id'] ?? 0);
    try {
        course_affecter($id, (int) ($_POST['livreur_id'] ?? 0));
        $c = requete('SELECT reference FROM commande_boutiques cb JOIN commandes c ON c.id = cb.commande_id WHERE cb.id = ?', [$id])->fetch();
        journaliser('course_affectee', ($c['reference'] ?? '#' . $id) . ' (livraison #' . $id . ') → livreur #' . (int) $_POST['livreur_id']);
        flash('Course affectée. Utilisez le bouton WhatsApp pour prévenir le livreur.');
    } catch (RuntimeException $e) {
        flash($e->getMessage(), 'erreur');
    }
    rediriger('admin/courses');
}

$courses = requete(SQL_COURSE . " WHERE cb.livre_par = 'jend' AND cb.statut IN ('a_preparer', 'expediee') AND c.statut <> 'annulee' AND " . SQL_ENGAGEE . "
                                   ORDER BY (cb.livreur_id IS NULL) DESC, c.created_at")->fetchAll();
$livreurs = requete(
    "SELECT u.id, u.nom, l.disponible, z.nom AS zone,
            (SELECT COUNT(*) FROM commande_boutiques cb WHERE cb.livreur_id = u.id AND cb.statut IN ('a_preparer', 'expediee')) AS en_cours
       FROM users u JOIN livreurs l ON l.user_id = u.id LEFT JOIN zones_livraison z ON z.id = l.zone_id
      WHERE u.role = 'livreur' AND u.actif = 1 ORDER BY l.disponible DESC, u.nom"
)->fetchAll();
$titre = 'Courses — Administration';
require __DIR__ . '/../includes/header.php';
?>
<main class="page">
  <div class="wrap">
    <nav class="fil" aria-label="Fil d'Ariane"><a href="<?= e(url()) ?>">Accueil</a> / <a href="<?= e(url('admin')) ?>">Administration</a> / <span>Courses</span></nav>
    <h1 class="titre-page">Administration</h1>
    <?php admin_onglets('courses'); ?>
    <?php if (!livreurs_jend_actifs()): ?><p class="alerte alerte-info"><i class="ph ph-info"></i> La livraison par les livreurs Jënd n'est pas encore activée : chaque vendeur livre lui-même. <a class="lien" href="<?= e(url('admin/parametres')) ?>">Activer dans les paramètres</a>.</p><?php endif; ?>
    <p class="doux">Livraisons payées (ou à payer à la livraison) qui n'ont pas encore été livrées. Choisissez un livreur, puis prévenez-le par WhatsApp.</p>
    <?php if (!$livreurs): ?><p class="alerte">Aucun livreur actif. <a class="lien" href="<?= e(url('admin/livreurs')) ?>">Créez-en un</a>.</p><?php endif; ?>
    <?php if (!$courses): ?><div class="vide"><i class="ph ph-motorcycle"></i><p><b>Aucune livraison en attente.</b></p></div><?php else: ?>
    <div class="table-defile"><table class="table">
      <thead><tr><th>Commande</th><th>Vendeur → destination</th><th>À encaisser</th><th>Étape</th><th>Livreur</th></tr></thead>
      <tbody>
      <?php foreach ($courses as $c): $etape = course_etape($c); $verrou = course_non_affectable($c); $wa = $c['livreur_id'] ? course_lien_whatsapp($c) : null; ?>
        <tr>
          <td><b><?= e($c['reference']) ?></b><br><span class="doux petit"><?= e(date('d/m H:i', strtotime($c['created_at']))) ?></span></td>
          <td><?= e($c['boutique']) ?> → <b><?= e($c['livraison_zone']) ?></b><br><span class="doux petit"><?= e($c['livraison_adresse']) ?></span></td>
          <td><?= course_a_encaisser($c) > 0 ? '<b>' . e(fcfa(course_a_encaisser($c))) . '</b>' : '<span class="doux">payé</span>' ?></td>
          <td><span class="badge badge-etape-<?= e($etape) ?>"><?= $c['livreur_id'] ? e(ETAPES_COURSE[$etape]) : 'Sans livreur' ?></span></td>
          <td>
            <?php if ($c['livreur_id']): ?><b><?= e($c['livreur_nom']) ?></b><br><?php endif; ?>
            <?php if ($verrou === null || !$c['livreur_id']): ?>
              <form method="post" class="zone-actions"><?= csrf_champ() ?><input type="hidden" name="id" value="<?= (int) $c['id'] ?>">
                <select name="livreur_id" aria-label="Livreur" required><option value="">— Choisir —</option>
                  <?php foreach ($livreurs as $l): ?><option value="<?= (int) $l['id'] ?>" <?= (int) $c['livreur_id'] === (int) $l['id'] ? 'selected' : '' ?>><?= $l['disponible'] ? '● ' : '○ ' ?><?= e($l['nom']) ?><?= $l['zone'] ? ' (' . e($l['zone']) . ')' : '' ?> — <?= (int) $l['en_cours'] ?> en cours</option><?php endforeach; ?></select>
                <button class="btn btn-contour" type="submit"><?= $c['livreur_id'] ? 'Changer' : 'Affecter' ?></button>
              </form>
            <?php endif; ?>
            <?php if ($wa): ?><a class="btn btn-accent" href="<?= e($wa) ?>" target="_blank" rel="noopener noreferrer"><i class="ph-fill ph-whatsapp-logo"></i> Prévenir sur WhatsApp</a><?php endif; ?>
          </td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table></div>
    <p class="doux petit">● disponible · ○ indisponible. Le message WhatsApp contient la boutique, l'adresse, le montant à encaisser et le lien de la course ; le téléphone du client reste visible seulement dans l'espace du livreur.</p>
    <?php endif; ?>
  </div>
</main>
<?php require __DIR__ . '/../includes/footer.php'; ?>
