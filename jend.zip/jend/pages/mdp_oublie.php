<?php
$titre = 'Mot de passe oublié — Jënd';
$envoye = false;
$erreur = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_valide($_POST['csrf'] ?? null)) {
        $erreur = 'Session expirée, merci de réessayer.';
    } elseif (limite_atteinte('mdp:ip:' . ip_client(), 5, 3600) || limite_atteinte('mdp:email:' . cle_email((string) ($_POST['email'] ?? '')), 3, 3600)) {
        $erreur = 'Trop de demandes. Réessayez plus tard.';
    } else {
        $email = trim((string) ($_POST['email'] ?? ''));
        limite_enregistrer('mdp:ip:' . ip_client());
        limite_enregistrer('mdp:email:' . cle_email($email));
        $u = requete('SELECT id, nom FROM users WHERE email = ? AND actif = 1', [$email])->fetch();
        if ($u) {
            $jeton = bin2hex(random_bytes(32));
            requete('DELETE FROM reinitialisations_mdp WHERE user_id = ?', [$u['id']]);
            requete('INSERT INTO reinitialisations_mdp (user_id, token_hash, expire_le) VALUES (?, ?, DATE_ADD(NOW(), INTERVAL 1 HOUR))', [$u['id'], hash('sha256', $jeton)]);
            envoyer_email($email, 'Réinitialisation de votre mot de passe Jënd',
                "Bonjour " . explode(' ', $u['nom'])[0] . ",\n\nPour choisir un nouveau mot de passe, ouvrez ce lien (valable 1 heure) :\n" .
                app_url('reinitialiser/' . $jeton) . "\n\nSi vous n'êtes pas à l'origine de cette demande, ignorez ce message.");
        }
        $envoye = true;   // même réponse que l'e-mail existe ou non : on ne révèle pas qui a un compte
    }
}
require __DIR__ . '/../includes/header.php';
?>
<main class="page">
  <div class="wrap wrap-etroit">
    <h1 class="titre-page">Mot de passe oublié</h1>
    <?php if ($envoye): ?>
      <p class="alerte alerte-info"><i class="ph ph-envelope-simple"></i> Si un compte existe avec cette adresse, un lien de réinitialisation vient d'être envoyé. Il est valable 1 heure.</p>
    <?php else: ?>
      <form method="post" class="formulaire" novalidate>
        <?= csrf_champ() ?>
        <?php if ($erreur): ?><p class="alerte" role="alert"><?= e($erreur) ?></p><?php endif; ?>
        <p class="doux">Entrez l'e-mail de votre compte, nous vous enverrons un lien pour choisir un nouveau mot de passe.</p>
        <label class="champ"><span>E-mail</span><input type="email" name="email" autocomplete="email" required autofocus></label>
        <button class="btn btn-primaire" type="submit">Envoyer le lien</button>
      </form>
    <?php endif; ?>
    <p class="doux mt1"><a class="lien" href="<?= e(url('connexion')) ?>">Retour à la connexion</a></p>
  </div>
</main>
<?php require __DIR__ . '/../includes/footer.php'; ?>
