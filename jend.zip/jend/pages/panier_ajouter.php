<?php
// Ajoute un produit au panier (session). Le vrai panier — page, quantités, commande — arrive à l'étape 6.
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    rediriger('');
}

$retour = retour_sur($_POST['retour'] ?? '');

if (!csrf_valide($_POST['csrf'] ?? null)) {
    flash('Session expirée, merci de réessayer.', 'erreur');
    header('Location: ' . $retour);
    exit;
}

$id       = (int) ($_POST['produit_id'] ?? 0);
$quantite = max(1, min(10, (int) ($_POST['quantite'] ?? 1)));

$produit = requete(
    "SELECT p.id, p.nom, p.slug, p.stock, p.option_type
       FROM produits p JOIN boutiques b ON b.id = p.boutique_id AND b.statut = 'active'
      WHERE p.id = ? AND p.statut = 'publie' AND p.stock > 0 AND (p.reserve_client_id IS NULL OR p.reserve_client_id = " . (int) ($_SESSION['user_id'] ?? 0) . ")",
    [$id]
)->fetch();

if (!$produit) {
    flash("Ce produit n'est plus disponible.", 'erreur');
} else {
    // Taille / pointure : obligatoire si le vendeur en a indiqué ; le stock est celui de la taille choisie
    $variantes = variantes_produit($id);
    $variante = null;
    if ($variantes) {
        foreach ($variantes as $vr) {
            if ((int) $vr['id'] === (int) ($_POST['variante_id'] ?? 0)) {
                $variante = $vr;
            }
        }
        if (!$variante || (int) $variante['stock'] < 1) {
            flash($variante ? 'Cette ' . mb_strtolower(option_libelle($produit['option_type'])) . ' est épuisée : choisissez-en une autre.' : 'Choisissez d\'abord votre ' . mb_strtolower(option_libelle($produit['option_type'])) . '.', 'erreur');
            rediriger('produit/' . $produit['slug']);
        }
    }
    $cle     = panier_cle($id, $variante ? (int) $variante['id'] : null);
    $deja    = (int) ($_SESSION['panier'][$cle] ?? 0);
    $nouveau = min($deja + $quantite, (int) ($variante['stock'] ?? $produit['stock']), 10);
    $_SESSION['panier'][$cle] = $nouveau;
    $produit['nom'] .= $variante ? ' (' . option_libelle($produit['option_type']) . ' ' . $variante['libelle'] . ')' : '';
    if (!empty($_POST['acheter'])) {                       // « Acheter maintenant » : directement à la commande
        rediriger('commande');
    }
    flash('« ' . $produit['nom'] . ' » ajouté au panier.', 'ok', ['url' => url('panier'), 'texte' => 'Voir le panier et commander']);
}

header('Location: ' . $retour);
exit;
