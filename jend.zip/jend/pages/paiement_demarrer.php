<?php
/** paiement/{reference} : lance (ou relance) le paiement en ligne d'une commande. */
$u = exiger_connexion();
$c = requete('SELECT * FROM commandes WHERE reference = ? AND client_id = ?', [strtoupper($parametre), $u['id']])->fetch();
if (!$c) {
    http_response_code(404);
    require __DIR__ . '/404.php';
    return;
}
if (!commande_payable($c)) {
    flash('Cette commande n\'a pas de paiement en attente.', 'erreur');
    rediriger('commande/' . $c['reference']);
}
// Le démarrage passe par un formulaire POST (jeton CSRF) pour qu'un lien piégé ne puisse pas relancer un paiement
if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !csrf_valide($_POST['csrf'] ?? null)) {
    flash('Utilisez le bouton « Payer » de votre commande.', 'erreur');
    rediriger('commande/' . $c['reference']);
}
try {
    $adresse = paiement_initier($c);
} catch (Throwable $e) {
    error_log('Jënd — initiation paiement : ' . $e->getMessage());
    flash('Le paiement est momentanément indisponible. Réessayez dans un instant.', 'erreur');
    rediriger('commande/' . $c['reference']);
}
// Pages de paiement autorisées en redirection directe (form-action de la politique de sécurité) ; sinon page relais du site
$hote = strtolower((string) parse_url($adresse, PHP_URL_HOST));
$direct = str_starts_with($adresse, url('')) || preg_match('/(^|\.)(paydunya\.com|paytech\.sn)$/', $hote) === 1 || str_starts_with($adresse, 'http://127.0.0.1');
if (!$direct) {
    $_SESSION['paiement_relais'][$c['reference']] = $adresse;
    rediriger('paiement/aller/' . $c['reference']);
}
header('Location: ' . $adresse);
exit;
