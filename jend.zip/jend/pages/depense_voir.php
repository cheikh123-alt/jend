<?php
/** Une « dépense du mois » : contenu au prix du jour, modification, pause, suppression, commande en un clic. $parametre = id. */
$u = exiger_connexion();
$d = depense_du_client((int) $parametre, (int) $u['id']);
if (!$d) {
    http_response_code(404);
    require __DIR__ . '/404.php';
    return;
}
$retour = 'depense/' . $d['id'];
if (post_verifie($retour)) {
    $action = (string) ($_POST['action'] ?? '');
    if ($action === 'commander') {
        [$n, $manquants] = depense_vers_panier($d);
        if ($n === 0) {
            flash('Aucun produit de cette dépense n\'est disponible pour le moment.', 'erreur');
            rediriger($retour);
        }
        flash($manquants ? 'Attention, indisponible(s) : ' . implode(', ', $manquants) . '. Le reste est dans votre panier.' : 'Votre dépense est dans le panier : vérifiez l\'adresse puis payez.', $manquants ? 'erreur' : 'ok');
        rediriger('commande');
    } elseif ($action === 'quantites') {
        foreach ((array) ($_POST['q'] ?? []) as $cle => $q) {
            [$pid, $vid] = panier_cle_lire($cle);
            $q = (int) $q;
            if ($q <= 0) {
                requete('DELETE FROM depense_lignes WHERE depense_id = ? AND produit_id = ? AND variante_id = ?', [$d['id'], $pid, (int) $vid]);
            } else {
                requete('UPDATE depense_lignes SET quantite = ? WHERE depense_id = ? AND produit_id = ? AND variante_id = ?', [min(10, $q), $d['id'], $pid, (int) $vid]);
            }
        }
        flash('Quantités mises à jour.');
    } elseif ($action === 'pause') {
        requete('UPDATE depenses SET actif = 1 - actif, prochain_rappel = IF(actif = 0, ?, prochain_rappel) WHERE id = ?', [depense_prochaine_date((int) $d['jour']), $d['id']]);
        flash($d['actif'] ? 'Dépense mise en pause : plus de rappel.' : 'Dépense réactivée.');
    } elseif ($action === 'jour') {
        $j = (int) ($_POST['jour'] ?? 0);
        if ($j >= 1 && $j <= 28) {
            requete('UPDATE depenses SET jour = ?, prochain_rappel = ? WHERE id = ?', [$j, depense_prochaine_date($j), $d['id']]);
            flash('Jour du rappel modifié.');
        }
    } elseif ($action === 'supprimer') {
        requete('DELETE FROM depenses WHERE id = ?', [$d['id']]);
        flash('Dépense supprimée.');
        rediriger('depense');
    }
    rediriger($retour);
}
$lignes = depense_lignes((int) $d['id']);
$titre = $d['nom'] . ' — Jënd';
require __DIR__ . '/../includes/header.php';
?>
<main class="page">
  <div class="wrap wrap-moyen">
    <nav class="fil" aria-label="Fil d'Ariane"><a href="<?= e(url('depense')) ?>">La dépense du mois</a> / <span><?= e($d['nom']) ?></span></nav>
    <h1 class="titre-page"><?= e($d['nom']) ?></h1>
    <p class="doux">Pour <b><?= e($d['livraison_nom']) ?></b> (<?= e($d['livraison_telephone']) ?>) · <?= e($d['zone']) ?>, <?= e($d['adresse']) ?><?= $d['cadeau'] ? ' · <i class="ph ph-gift"></i> cadeau, sans prix ni facture' : '' ?></p>

    <div class="depense-action">
      <div><b>Environ <?= e(fcfa(depense_total($lignes))) ?></b> <span class="doux">au prix du jour, hors livraison</span><br>
        <small class="doux"><?= $d['actif'] ? 'Prochain rappel le ' . e(date_longue_fr($d['prochain_rappel'])) : 'En pause : aucun rappel' ?></small></div>
      <form method="post"><?= csrf_champ() ?><input type="hidden" name="action" value="commander"><button class="btn btn-primaire" type="submit"><i class="ph ph-shopping-cart"></i> Commander maintenant</button></form>
    </div>

    <form method="post" class="depense-lignes">
      <?= csrf_champ() ?><input type="hidden" name="action" value="quantites">
      <?php foreach ($lignes as $l): ?>
        <div class="depense-ligne<?= $l['ok'] ? '' : ' indispo' ?>">
          <?php if ($l['image']): ?><img src="<?= e(url(image_miniature($l['image']))) ?>" alt="" loading="lazy"><?php else: ?><span class="fete-sans-photo"><i class="ph ph-package"></i></span><?php endif; ?>
          <span><a href="<?= e(url('produit/' . $l['slug'])) ?>"><b><?= e($l['nom']) ?></b></a><?= $l['variante_libelle'] ? ' <span class="variante-choisie">' . e($l['variante_libelle']) . '</span>' : '' ?><small><?= e(fcfa($l['prix_jour'])) ?> l'unité<?= $l['promo_pct'] ? ' · promo fête −' . (int) $l['promo_pct'] . ' %' : '' ?><?= $l['ok'] ? '' : ' · <b>indisponible</b>' ?></small></span>
          <label><span class="sr">Quantité</span><input type="number" name="q[<?= e($l['cle']) ?>]" value="<?= (int) $l['quantite'] ?>" min="0" max="10"></label>
        </div>
      <?php endforeach; ?>
      <p class="petit doux">Mettez 0 pour retirer un produit. Pour en ajouter, mettez-le dans votre panier et créez une nouvelle dépense, ou commandez-le en plus.</p>
      <button class="btn btn-contour" type="submit">Enregistrer les quantités</button>
    </form>

    <div class="depense-reglages">
      <form method="post" class="ligne-form"><?= csrf_champ() ?><input type="hidden" name="action" value="jour">
        <label>Rappel le <select name="jour"><?php for ($j = 1; $j <= 28; $j++): ?><option value="<?= $j ?>" <?= (int) $d['jour'] === $j ? 'selected' : '' ?>><?= $j === 1 ? '1er' : $j ?></option><?php endfor; ?></select> du mois</label>
        <button class="btn btn-contour" type="submit">Changer</button></form>
      <form method="post"><?= csrf_champ() ?><input type="hidden" name="action" value="pause"><button class="btn btn-contour" type="submit"><i class="ph <?= $d['actif'] ? 'ph-pause' : 'ph-play' ?>"></i> <?= $d['actif'] ? 'Mettre en pause' : 'Réactiver' ?></button></form>
      <form method="post" data-confirm="Supprimer cette dépense ?"><?= csrf_champ() ?><input type="hidden" name="action" value="supprimer"><button class="btn btn-contour" type="submit"><i class="ph ph-trash"></i> Supprimer</button></form>
    </div>
  </div>
</main>
<?php require __DIR__ . '/../includes/footer.php'; ?>
