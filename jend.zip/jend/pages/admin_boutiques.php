<?php
exiger_admin();
if (post_verifie('admin/boutiques')) {
    $id = (int) ($_POST['id'] ?? 0);
    $b = requete('SELECT b.id, b.nom, b.statut, u.email FROM boutiques b JOIN users u ON u.id = b.user_id WHERE b.id = ?', [$id])->fetch();
    if ($b) {
        $action = $_POST['action'] ?? '';
        if ($action === 'activer') {
            requete("UPDATE boutiques SET statut = 'active' WHERE id = ?", [$id]);
            envoyer_email($b['email'], 'Votre boutique Jënd est validée', "Bonne nouvelle : votre boutique « {$b['nom']} » est validée. Vos produits publiés sont maintenant visibles.\n" . app_url('vendeur'));
            journaliser('boutique_activee', $b['nom'] . ' (#' . $id . ')');
            $recompense = parrainage_recompenser($id);
            if ($recompense) {
                journaliser('parrainage_recompense', $b['nom'] . ' (#' . $id . ') : ' . parrainage_jours() . ' j sans commission pour le parrain et le filleul');
            }
            flash('Boutique « ' . $b['nom'] . ' » activée.' . ($recompense ? ' Parrainage : ' . parrainage_jours() . ' jours sans commission offerts au parrain et à cette boutique.' : ''));
        } elseif ($action === 'suspendre') {
            requete("UPDATE boutiques SET statut = 'suspendue' WHERE id = ?", [$id]);
            journaliser('boutique_suspendue', $b['nom'] . ' (#' . $id . ')');
            flash('Boutique « ' . $b['nom'] . ' » suspendue : ses produits ne sont plus visibles.');
        } elseif ($action === 'verifier') {
            $nouveau = (int) requete('SELECT verifiee FROM boutiques WHERE id = ?', [$id])->fetchColumn() === 1 ? 0 : 1;
            requete('UPDATE boutiques SET verifiee = ? WHERE id = ?', [$nouveau, $id]);
            journaliser($nouveau ? 'boutique_verifiee' : 'boutique_verification_retiree', $b['nom'] . ' (#' . $id . ')');
            flash($nouveau ? 'Boutique « ' . $b['nom'] . ' » marquée « vérifiée » : le badge s\'affiche sur ses produits et sa page.' : 'Badge « vérifiée » retiré à « ' . $b['nom'] . ' ».');
        } elseif ($action === 'livraison') {
            $mode = ($_POST['mode'] ?? '') === 'jend' ? 'jend' : 'vendeur';
            requete('UPDATE boutiques SET livraison_par = ? WHERE id = ?', [$mode, $id]);
            journaliser('livraison_modifiee', $b['nom'] . ' (#' . $id . ') : ' . $mode);
            flash('Livraison de « ' . $b['nom'] . ' » : ' . ($mode === 'jend' ? 'assurée par les livreurs Jënd (le frais de livraison reste à Jënd)' : 'assurée par le vendeur (il touche le frais de livraison)') . '. S\'applique aux prochaines commandes.');
        } elseif ($action === 'commission') {
            $pct = str_replace(',', '.', trim((string) ($_POST['commission'] ?? '')));
            if (is_numeric($pct) && $pct >= 0 && $pct <= 50) {
                requete('UPDATE boutiques SET commission_pct = ? WHERE id = ?', [round((float) $pct, 2), $id]);
                journaliser('commission_modifiee', $b['nom'] . ' (#' . $id . ') : ' . round((float) $pct, 2) . ' %');
                flash('Commission mise à jour (elle s\'applique aux prochaines commandes).');
            } else {
                flash('Commission invalide (entre 0 et 50 %).', 'erreur');
            }
        }
    }
    rediriger('admin/boutiques');
}
$boutiques = requete(
    "SELECT b.id, b.nom, b.statut, b.commission_pct, b.livraison_par, b.verifiee, b.slug, b.created_at, u.nom AS proprio, u.email, b.telephone_paiement,
            (SELECT COUNT(*) FROM produits p WHERE p.boutique_id = b.id AND p.statut = 'publie') AS nb_produits
       FROM boutiques b JOIN users u ON u.id = b.user_id
      ORDER BY FIELD(b.statut, 'en_attente', 'active', 'suspendue'), b.created_at DESC"
)->fetchAll();
$lib = ['en_attente' => 'À valider', 'active' => 'Active', 'suspendue' => 'Suspendue'];
$titre = 'Boutiques — Administration';
require __DIR__ . '/../includes/header.php';
?>
<main class="page">
  <div class="wrap">
    <nav class="fil" aria-label="Fil d'Ariane"><a href="<?= e(url()) ?>">Accueil</a> / <a href="<?= e(url('admin')) ?>">Administration</a> / <span>Boutiques</span></nav>
    <h1 class="titre-page">Administration</h1>
    <?php admin_onglets('boutiques'); ?>
    <?php if (!$boutiques): ?><div class="vide"><i class="ph ph-storefront"></i><p><b>Aucune boutique.</b></p></div><?php endif; ?>
    <?php foreach ($boutiques as $b): ?>
      <article class="commande-vendeur">
        <header>
          <div><b><?= e($b['nom']) ?></b> <span class="doux">· <?= e($b['proprio']) ?> · <?= e($b['email']) ?> · <?= e((string) $b['telephone_paiement']) ?></span></div>
          <span class="badge badge-<?= $b['statut'] === 'active' ? 'confirmee' : ($b['statut'] === 'suspendue' ? 'annulee' : 'en_attente') ?>"><?= e($lib[$b['statut']]) ?></span>
        </header>
        <p class="petit doux"><?= (int) $b['nb_produits'] ?> produit(s) en vente · créée le <?= e(date('d/m/Y', strtotime($b['created_at']))) ?></p>
        <div class="ligne-action">
          <?php if ($b['statut'] !== 'active'): ?>
            <form method="post"><?= csrf_champ() ?><input type="hidden" name="id" value="<?= (int) $b['id'] ?>"><input type="hidden" name="action" value="activer"><button class="btn btn-primaire" type="submit"><i class="ph ph-check"></i> <?= $b['statut'] === 'suspendue' ? 'Réactiver' : 'Valider' ?></button></form>
          <?php endif; ?>
          <?php if ($b['statut'] === 'active'): ?>
            <form method="post" data-confirm="Suspendre cette boutique ? Ses produits disparaîtront du site."><?= csrf_champ() ?><input type="hidden" name="id" value="<?= (int) $b['id'] ?>"><input type="hidden" name="action" value="suspendre"><button class="btn btn-contour" type="submit">Suspendre</button></form>
          <?php endif; ?>
          <form method="post"><?= csrf_champ() ?><input type="hidden" name="id" value="<?= (int) $b['id'] ?>"><input type="hidden" name="action" value="verifier">
            <button class="btn btn-contour" type="submit"><i class="ph ph-seal-check"></i> <?= $b['verifiee'] ? 'Retirer le badge vérifiée' : 'Marquer « vérifiée »' ?></button></form>
          <form method="post" class="ligne-action m0"><?= csrf_champ() ?><input type="hidden" name="id" value="<?= (int) $b['id'] ?>"><input type="hidden" name="action" value="commission">
            <label class="sr" for="c<?= (int) $b['id'] ?>">Commission</label><input id="c<?= (int) $b['id'] ?>" type="text" name="commission" value="<?= e((string) $b['commission_pct']) ?>" class="largeur-90" inputmode="decimal"> %
            <button class="lien" type="submit">Appliquer</button></form>
          <form method="post" class="ligne-action m0"><?= csrf_champ() ?><input type="hidden" name="id" value="<?= (int) $b['id'] ?>"><input type="hidden" name="action" value="livraison">
            <label class="sr" for="l<?= (int) $b['id'] ?>">Qui livre</label>
            <select id="l<?= (int) $b['id'] ?>" name="mode"><option value="vendeur" <?= $b['livraison_par'] === 'vendeur' ? 'selected' : '' ?>>Le vendeur livre (il touche la livraison)</option><option value="jend" <?= $b['livraison_par'] === 'jend' ? 'selected' : '' ?>>Livreurs Jënd<?= livreurs_jend_actifs() ? '' : ' (quand activés)' ?></option></select>
            <button class="lien" type="submit">Appliquer</button></form>
        </div>
      </article>
    <?php endforeach; ?>
  </div>
</main>
<?php require __DIR__ . '/../includes/footer.php'; ?>
