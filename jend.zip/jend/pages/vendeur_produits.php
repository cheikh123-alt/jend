<?php
[$u, $b] = exiger_vendeur();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_valide($_POST['csrf'] ?? null)) {
        flash('Session expirée, merci de réessayer.', 'erreur');
        rediriger('vendeur/produits');
    }
    $id = (int) ($_POST['id'] ?? 0);
    // La condition boutique_id garantit qu'on ne touche qu'à SES produits
    $p = requete('SELECT id, nom, statut FROM produits WHERE id = ? AND boutique_id = ? AND reserve_client_id IS NULL', [$id, $b['id']])->fetch();
    if ($p) {
        $action = $_POST['action'] ?? '';
        if ($action === 'supprimer') {
            $images = requete('SELECT chemin FROM produit_images WHERE produit_id = ?', [$id])->fetchAll(PDO::FETCH_COLUMN);
            requete('DELETE FROM produits WHERE id = ?', [$id]);
            foreach ($images as $img) {
                image_supprimer($img);
            }
            flash('Produit supprimé.');
        } elseif ($action === 'basculer') {
            $nouveau = $p['statut'] === 'publie' ? 'archive' : 'publie';
            requete('UPDATE produits SET statut = ? WHERE id = ?', [$nouveau, $id]);
            flash($nouveau === 'publie' ? 'Produit publié.' : 'Produit retiré de la vente.');
        }
    }
    rediriger('vendeur/produits');
}

$produits = requete(
    "SELECT p.id, p.nom, p.slug, p.prix, p.stock, p.statut, c.nom AS categorie,
            (SELECT chemin FROM produit_images i WHERE i.produit_id = p.id ORDER BY i.position LIMIT 1) AS image
       FROM produits p JOIN categories c ON c.id = p.categorie_id
      WHERE p.boutique_id = ? AND p.reserve_client_id IS NULL ORDER BY p.id DESC",
    [$b['id']]
)->fetchAll();
$libStatut = ['brouillon' => 'Brouillon', 'publie' => 'En vente', 'archive' => 'Retiré'];
$titre = 'Mes produits — Jënd';
require __DIR__ . '/../includes/header.php';
?>
<main class="page">
  <div class="wrap">
    <nav class="fil" aria-label="Fil d'Ariane"><a href="<?= e(url()) ?>">Accueil</a> / <a href="<?= e(url('vendeur')) ?>">Boutique</a> / <span>Produits</span></nav>
    <div class="compte-tete">
      <h1 class="titre-page"><?= e($b['nom']) ?></h1>
      <a class="btn btn-primaire" href="<?= e(url('vendeur/produits/nouveau')) ?>"><i class="ph ph-plus"></i> Nouveau produit</a>
    </div>
    <?php vendeur_onglets('produits'); ?>
    <p class="alerte alerte-info"><i class="ph ph-shield-check"></i> <span><b>Vous vendez sur TikTok, WhatsApp ou Instagram ?</b> Envoyez à votre client le <b>lien de paiement</b> du produit : il paie sur Jënd en toute sécurité, et vous êtes sûr d'être payé dès qu'il confirme la réception.</span></p>

    <?php if (!$produits): ?>
      <div class="vide"><i class="ph ph-package"></i><p><b>Aucun produit.</b><br>Ajoutez votre premier produit pour commencer à vendre.</p></div>
    <?php else: ?>
      <div class="table-defile">
        <table class="table">
          <thead><tr><th></th><th>Produit</th><th>Prix</th><th>Stock</th><th>Statut</th><th></th></tr></thead>
          <tbody>
          <?php foreach ($produits as $p): ?>
            <tr>
              <td><span class="mini <?= classe_fond((int) $p['id']) ?>"><?= $p['image'] ? '<img src="' . e(url(image_miniature($p['image']))) . '" alt="">' : '<i class="ph-fill ph-package"></i>' ?></span></td>
              <td><b><?= e($p['nom']) ?></b><br><span class="doux petit"><?= e($p['categorie']) ?></span></td>
              <td><?= e(fcfa((int) $p['prix'])) ?></td>
              <td><?= (int) $p['stock'] ?></td>
              <td><span class="badge badge-<?= $p['statut'] === 'publie' ? 'confirmee' : ($p['statut'] === 'archive' ? 'annulee' : 'en_attente') ?>"><?= e($libStatut[$p['statut']]) ?></span></td>
              <td class="actions-ligne">
                <a class="lien" href="<?= e(url('vendeur/produits/' . $p['id'] . '/modifier')) ?>">Modifier</a>
                <?php if ($p['statut'] === 'publie' && $b['statut'] === 'active'): $lienPaiement = lien_source(app_url('payer/' . $p['slug']), 'lien'); ?>
                  <button class="lien" type="button" data-copier="<?= e($lienPaiement) ?>"><i class="ph ph-link"></i> Lien de paiement</button>
                  <a class="lien" href="<?= e(lien_whatsapp_partage('Payez « ' . $p['nom'] . ' » en toute sécurité sur Jënd (' . fcfa((int) $p['prix']) . ') : ' . $lienPaiement)) ?>" target="_blank" rel="noopener noreferrer"><i class="ph-fill ph-whatsapp-logo"></i> Envoyer</a>
                <?php endif; ?>
                <form method="post"><?= csrf_champ() ?><input type="hidden" name="id" value="<?= (int) $p['id'] ?>"><input type="hidden" name="action" value="basculer"><button class="lien lien-danger" type="submit"><?= $p['statut'] === 'publie' ? 'Retirer' : 'Publier' ?></button></form>
                <form method="post" data-confirm="Supprimer définitivement ce produit ?"><?= csrf_champ() ?><input type="hidden" name="id" value="<?= (int) $p['id'] ?>"><input type="hidden" name="action" value="supprimer"><button class="lien lien-danger" type="submit"><i class="ph ph-trash"></i></button></form>
              </td>
            </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    <?php endif; ?>
  </div>
</main>
<?php require __DIR__ . '/../includes/footer.php'; ?>
