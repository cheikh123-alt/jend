<?php
/**
 * « Boîte de réception de test » : affiche les e-mails que le site a « envoyés » en mode développement
 * (MAIL_DRIVER=log : ils sont écrits dans storage/emails.log au lieu de partir).
 * N'existe QUE si APP_ENV=dev (site local) : partout ailleurs, la page est introuvable.
 */
if (env('APP_ENV') !== 'dev') {
    http_response_code(404);
    require __DIR__ . '/404.php';
    return;
}
$fichier = dirname(__DIR__) . '/storage/emails.log';
if (post_verifie('dev/emails') && ($_POST['action'] ?? '') === 'vider') {
    @file_put_contents($fichier, '');
    flash('Boîte de test vidée.');
    rediriger('dev/emails');
}
$emails = [];
$texte = is_file($fichier) ? (string) file_get_contents($fichier) : '';
foreach (preg_split('/^-{60}\R/m', $texte) as $bloc) {
    if (preg_match('/^\[([^\]]+)\] À : ([^\r\n]*)\RSujet : ([^\r\n]*)\R(.*)$/s', trim($bloc, "\r\n"), $m)) {
        $emails[] = ['date' => $m[1], 'a' => $m[2], 'sujet' => $m[3], 'corps' => trim($m[4])];
    }
}
$emails = array_reverse($emails);                       // le plus récent en premier
$filtre = trim((string) ($_GET['q'] ?? ''));
if ($filtre !== '') {
    $emails = array_values(array_filter($emails, fn ($e) => mb_stripos($e['a'] . ' ' . $e['sujet'] . ' ' . $e['corps'], $filtre) !== false));
}
/** Texte d'e-mail échappé, avec les adresses du site rendues cliquables. */
$liens = fn (string $t): string => preg_replace('#(https?://[^\s<]+)#', '<a class="lien" href="$1">$1</a>', nl2br(e($t)));
$titre = 'Boîte de réception de test — Jënd';
$robots = 'noindex';
require __DIR__ . '/../includes/header.php';
?>
<main class="page">
  <div class="wrap wrap-moyen">
    <h1 class="titre-page">Boîte de réception de test</h1>
    <p class="alerte alerte-info"><i class="ph ph-flask"></i> <span>Site local (mode développement) : les e-mails ne partent pas, ils arrivent ici. Les liens (confirmation, mot de passe oublié, suivi…) sont cliquables. Cette page n'existe pas sur le site en ligne.</span></p>
    <div class="dev-emails-outils">
      <form method="get" class="ligne-form"><label class="sr" for="q">Rechercher</label><input id="q" name="q" value="<?= e($filtre) ?>" placeholder="Destinataire, sujet…"><button class="btn btn-contour" type="submit">Filtrer</button></form>
      <form method="post" data-confirm="Vider la boîte de test ?"><?= csrf_champ() ?><input type="hidden" name="action" value="vider"><button class="btn btn-contour" type="submit"><i class="ph ph-trash"></i> Vider</button></form>
    </div>
    <p class="doux petit"><?= count($emails) ?> e-mail(s)</p>
    <?php if (!$emails): ?>
      <div class="vide"><i class="ph ph-tray"></i><p><b>Aucun e-mail pour le moment.</b></p><p class="doux">Inscrivez-vous, passez une commande ou cliquez « Mot de passe oublié » : les messages apparaîtront ici.</p></div>
    <?php else: foreach ($emails as $i => $m): ?>
      <details class="dev-email" <?= $i === 0 ? 'open' : '' ?>>
        <summary><b><?= e($m['sujet']) ?></b><small>À : <?= e($m['a']) ?> · <?= e($m['date']) ?></small></summary>
        <div class="dev-email-corps"><?= $liens($m['corps']) ?></div>
      </details>
    <?php endforeach; endif; ?>
  </div>
</main>
<?php require __DIR__ . '/../includes/footer.php'; ?>
