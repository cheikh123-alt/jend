<?php
/**
 * FAUSSE page de paiement (simulation du fournisseur). Réservée au développement.
 * Comme un vrai fournisseur, elle prévient le site par une notification SIGNÉE, puis renvoie le client.
 */
if (!simulation_active()) {
    http_response_code(404);
    require __DIR__ . '/404.php';
    return;
}

$p = requete(
    'SELECT p.*, c.reference AS commande_ref FROM paiements p JOIN commandes c ON c.id = p.commande_id WHERE p.reference_externe = ?',
    [$parametre]
)->fetch();
if (!$p) {
    http_response_code(404);
    require __DIR__ . '/404.php';
    return;
}
$retour = 'paiement/retour/' . $p['commande_ref'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_valide($_POST['csrf'] ?? null)) {
        flash('Session expirée, merci de réessayer.', 'erreur');
        rediriger('paiement/simulation/' . $parametre);
    }
    $choix = $_POST['resultat'] ?? '';
    if ($choix === 'reussi' || $choix === 'echoue') {
        $corps = json_encode(['reference' => $p['reference_externe'], 'statut' => $choix, 'montant' => (int) $p['montant'], 't' => time()]);
        paiement_notification_traiter($corps, paiement_signer($corps));
    }
    // « abandon » : le client quitte sans payer, aucune notification n'est envoyée (comme en vrai)
    rediriger($retour);
}

$noms = ['wave' => 'Wave', 'orange_money' => 'Orange Money', 'free_money' => 'Free Money', 'carte' => 'Carte bancaire'];
$titre = 'Paiement sécurisé (simulation) — Jënd';
require __DIR__ . '/../includes/header.php';
?>
<main class="page">
  <div class="wrap wrap-etroit">
    <div class="sim-bandeau"><i class="ph-fill ph-flask"></i> <b>MODE SIMULATION</b> — aucun argent réel n'est débité.</div>
    <div class="sim-carte">
      <p class="doux">Paiement via <b><?= e($noms[$p['methode']] ?? $p['methode']) ?></b></p>
      <p class="sim-montant"><?= e(fcfa((int) $p['montant'])) ?></p>
      <p class="doux petit">Commande <?= e($p['commande_ref']) ?> · Jënd</p>

      <?php if ($p['statut'] !== 'initie'): ?>
        <p class="alerte alerte-info"><i class="ph ph-info"></i> Ce paiement a déjà été traité ou remplacé par une nouvelle tentative.</p>
        <a class="btn btn-primaire" href="<?= e(url($retour)) ?>">Retour à la commande</a>
      <?php else: ?>
        <form method="post" class="sim-actions">
          <?= csrf_champ() ?>
          <button class="btn btn-primaire" name="resultat" value="reussi" type="submit"><i class="ph ph-check-circle"></i> Simuler un paiement réussi</button>
          <button class="btn btn-contour" name="resultat" value="echoue" type="submit"><i class="ph ph-x-circle"></i> Simuler un échec (solde insuffisant)</button>
          <button class="lien lien-danger" name="resultat" value="abandon" type="submit">Annuler et revenir au site</button>
        </form>
      <?php endif; ?>
    </div>
  </div>
</main>
<?php require __DIR__ . '/../includes/footer.php'; ?>
