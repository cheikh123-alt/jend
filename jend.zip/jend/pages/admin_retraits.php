<?php
exiger_admin();
if (post_verifie('admin/retraits')) {
    $action = $_POST['action'] ?? '';
    if ($action === 'preparer') {                   // versements à date fixe : préparer tout de suite (par exemple si le jour est passé sans visite du site)
        $nb = versements_preparer(true);
        journaliser('versements_prepares', $nb . ' versement(s)');
        flash($nb ? "$nb versement(s) préparé(s) : envoie-les puis marque-les « versé »." : 'Aucun vendeur n\'a de solde à verser (minimum ' . fcfa(RETRAIT_MINIMUM) . ').');
        rediriger('admin/retraits');
    }
    if (in_array($action, ['payer', 'refuser'], true)) {
        // La condition « statut = demande » empêche de traiter deux fois la même demande ; « versé » prévient le vendeur avec la référence du transfert
        $n = $action === 'payer'
            ? (versement_confirmer((int) ($_POST['id'] ?? 0), (string) ($_POST['reference'] ?? '')) ? 1 : 0)
            : requete('UPDATE retraits SET statut = \'refuse\' WHERE id = ? AND statut = \'demande\'', [(int) ($_POST['id'] ?? 0)])->rowCount();
        if ($n) {
            journaliser($action === 'payer' ? 'retrait_verse' : 'retrait_refuse', 'retrait #' . (int) ($_POST['id'] ?? 0));
        }
        flash($n ? ($action === 'payer' ? 'Retrait marqué comme versé.' : 'Retrait refusé : le montant revient dans le solde du vendeur.') : 'Cette demande a déjà été traitée.', $n ? 'ok' : 'erreur');
    }
    rediriger('admin/retraits');
}
$retraits = requete(
    "SELECT r.id, r.montant, r.methode, r.statut, r.created_at, r.automatique, r.paye_le, r.reference_transfert, b.nom AS boutique, b.telephone_paiement, b.telephone_modifie_le
       FROM retraits r JOIN boutiques b ON b.id = r.boutique_id ORDER BY FIELD(r.statut, 'demande', 'paye', 'refuse'), r.id DESC LIMIT 100"
)->fetchAll();
$lib = ['demande' => 'À payer', 'paye' => 'Versé', 'refuse' => 'Refusé'];
$titre = 'Retraits — Administration';
require __DIR__ . '/../includes/header.php';
?>
<main class="page">
  <div class="wrap">
    <nav class="fil" aria-label="Fil d'Ariane"><a href="<?= e(url()) ?>">Accueil</a> / <a href="<?= e(url('admin')) ?>">Administration</a> / <span>Retraits</span></nav>
    <h1 class="titre-page">Administration</h1>
    <?php admin_onglets('retraits'); ?>
    <div class="versements-bandeau">
      <?php if ($jourV = versement_jour()): ?>
        <p><i class="ph ph-calendar-check"></i> <span><b>Versements automatiques chaque <?= e($jourV) ?></b> : prochain le <b><?= e(date_jour_fr((string) prochain_versement())) ?></b>. Ce jour-là, le solde disponible de chaque vendeur (minimum <?= e(fcfa(RETRAIT_MINIMUM)) ?>) apparaît ici « à payer ».</span></p>
      <?php else: ?>
        <p><i class="ph ph-calendar-x"></i> <span><b>Pas de jour de versement fixé</b> : les vendeurs doivent demander leurs retraits. Choisis un jour dans <a class="lien" href="<?= e(url('admin/parametres')) ?>">Paramètres</a> pour les rassurer avec un versement régulier.</span></p>
      <?php endif; ?>
      <form method="post" data-confirm="Préparer maintenant un versement pour chaque vendeur qui a un solde disponible ?"><?= csrf_champ() ?><input type="hidden" name="action" value="preparer"><button class="btn btn-contour" type="submit"><i class="ph ph-hand-coins"></i> Préparer les versements maintenant</button></form>
    </div>
    <?php if (requete("SELECT 1 FROM retraits WHERE statut = 'demande' LIMIT 1")->fetch()): ?><p><a class="btn btn-contour" href="<?= e(url('admin/retraits/export')) ?>"><i class="ph ph-download-simple"></i> Exporter les retraits à payer (CSV)</a></p><?php endif; ?>
    <?php if (!$retraits): ?><div class="vide"><i class="ph ph-bank"></i><p><b>Aucune demande de retrait.</b></p></div><?php else: ?>
    <div class="table-defile"><table class="table">
      <thead><tr><th>Boutique</th><th>Montant</th><th>Envoyer sur</th><th>Date</th><th>Statut</th><th></th></tr></thead>
      <tbody>
      <?php foreach ($retraits as $r): ?>
        <tr>
          <td><?= e($r['boutique']) ?><?= $r['automatique'] ? ' <span class="badge badge-livree" title="Préparé par le versement à date fixe">Auto</span>' : '' ?></td><td><b><?= e(fcfa((int) $r['montant'])) ?></b></td>
          <td><?= e(str_replace('_', ' ', $r['methode'])) ?> · <?= e((string) $r['telephone_paiement']) ?><?php if (!empty($r['telephone_modifie_le']) && strtotime((string) $r['telephone_modifie_le']) > time() - 7 * 86400): ?><br><span class="badge badge-annulee" title="Vérifiez auprès du vendeur avant de payer">Numéro changé le <?= e(date('d/m', strtotime((string) $r['telephone_modifie_le']))) ?></span><?php endif; ?></td>
          <td><?= e(date('d/m/Y', strtotime($r['created_at']))) ?><?php if ($r['paye_le']): ?><br><small class="doux">versé le <?= e(date('d/m', strtotime($r['paye_le']))) ?><?= $r['reference_transfert'] ? ' · réf. ' . e($r['reference_transfert']) : '' ?></small><?php endif; ?></td>
          <td><span class="badge badge-<?= $r['statut'] === 'paye' ? 'confirmee' : ($r['statut'] === 'refuse' ? 'annulee' : 'en_attente') ?>"><?= e($lib[$r['statut']]) ?></span></td>
          <td class="actions-ligne"><?php if ($r['statut'] === 'demande'): ?>
            <form method="post" data-confirm="Avez-vous bien envoyé ce montant au vendeur ?"><?= csrf_champ() ?><input type="hidden" name="id" value="<?= (int) $r['id'] ?>"><input type="hidden" name="action" value="payer"><label class="sr" for="ref<?= (int) $r['id'] ?>">Référence du transfert</label><input id="ref<?= (int) $r['id'] ?>" name="reference" maxlength="60" placeholder="Réf. Wave / OM (conseillé)" class="champ-ref"><button class="btn btn-primaire" type="submit">Marquer versé</button></form>
            <form method="post"><?= csrf_champ() ?><input type="hidden" name="id" value="<?= (int) $r['id'] ?>"><input type="hidden" name="action" value="refuser"><button class="lien lien-danger" type="submit">Refuser</button></form>
          <?php endif; ?></td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table></div>
    <?php endif; ?>
  </div>
</main>
<?php require __DIR__ . '/../includes/footer.php'; ?>
