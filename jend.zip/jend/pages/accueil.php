<?php
$titre = 'Jënd — La marketplace sénégalaise';

// Catégories principales + nombre de produits publiés (sous-catégories comprises).
// Comptés en une passe sur les produits, regroupés par catégorie principale (rapide même avec des dizaines de milliers de produits).
// Grand catalogue (500 produits ou plus) : ces chiffres sont gardés 2 minutes.
$comptes = cache_lire('accueil-categories', 120);
if (!is_array($comptes)) {
    $comptes = requete(
        "SELECT COALESCE(c.parent_id, c.id) AS racine, COUNT(*) AS nb
           FROM produits p JOIN categories c ON c.id = p.categorie_id
          WHERE p.statut = 'publie' AND p.reserve_client_id IS NULL
          GROUP BY racine"
    )->fetchAll(PDO::FETCH_KEY_PAIR);
    if (array_sum($comptes) >= CATALOGUE_TOTAL_CACHE_MIN) {
        cache_ecrire('accueil-categories', $comptes);
    }
}
$categories = requete('SELECT id, nom, slug, icone FROM categories WHERE parent_id IS NULL ORDER BY position, id LIMIT 6')->fetchAll();
foreach ($categories as &$cat) {
    $cat['nb'] = (int) ($comptes[$cat['id']] ?? 0);
}
unset($cat);

$fraisMin = requete('SELECT MIN(frais) FROM zones_livraison WHERE actif = 1')->fetchColumn();
$produits = catalogue_chercher(['tri' => 'recent', 'sans_total' => true], 1)['produits'];
$produits = array_slice($produits, 0, 8);

$animations = true;                  // seule page avec les animations (titre lettre par lettre, apparition des cartes)
require __DIR__ . '/../includes/header.php';
?>
<main>
  <section class="affiche">
    <div class="wrap">
      <div class="affiche-texte">
        <p class="entree-dico"><b>jënd</b> <span>/jɘnd/</span> <i>verbe wolof</i> — acheter.</p>
        <h1 data-splitting>Le marché de chez nous, livré à votre porte.</h1>
        <p class="intro">Des boutiques de <?= e(villes_livrees()) ?>, des prix affichés sans surprise, et un colis qui ne se paie vraiment au vendeur qu'une fois <b>entre vos mains</b>.</p>
        <div class="cta">
          <a href="#produits" class="btn btn-primaire">Voir l'étalage <i class="ph ph-arrow-down"></i></a>
          <a href="#vendre" class="btn btn-contour">Tenir une boutique</a>
        </div>
        <?php if ($fraisMin !== null): ?><p class="mention-livraison"><i class="ph-fill ph-map-pin"></i> Livraison dès <b><?= e(fcfa((int) $fraisMin)) ?></b> selon votre quartier</p><?php endif; ?>
      </div>
      <nav class="plan" aria-label="Les étals par univers">
        <?php foreach ($categories as $i => $c): ?>
          <a href="<?= e(url('categorie/' . $c['slug'])) ?>" class="tuile tuile-<?= $i % 6 ?>">
            <span class="tuile-num"><?= str_pad((string) ($i + 1), 2, '0', STR_PAD_LEFT) ?></span>
            <b><?= e($c['nom']) ?></b>
            <small><?= (int) $c['nb'] > 0 ? (int) $c['nb'] . ' article' . ($c['nb'] > 1 ? 's' : '') : 'bientôt' ?></small>
            <i class="ph ph-arrow-up-right" aria-hidden="true"></i>
          </a>
        <?php endforeach; ?>
      </nav>
    </div>
  </section>

  <section class="bande-confiance" aria-label="Pourquoi acheter sur Jënd">
    <div class="wrap">
      <p><i class="ph-fill ph-shield-check"></i><span><b>Argent protégé</b> jusqu'à la réception</span></p>
      <p><i class="ph-fill ph-truck"></i><span><b>Livraison</b> à <?= e(villes_livrees()) ?></span></p>
      <p><i class="ph-fill ph-device-mobile"></i><span><b>Wave, Orange Money</b> ou carte</span></p>
      <p><i class="ph-fill ph-lifebuoy"></i><span><b>Réponse en <?= LITIGE_DELAI_REPONSE_HEURES ?> h</b> en cas de souci</span></p>
    </div>
  </section>

  <?php if ($fete = fete_en_vitrine()): ?>
  <section class="bandeau-fete" aria-label="Spécial <?= e($fete['nom']) ?>">
    <div class="wrap">
      <i class="ph ph-confetti" aria-hidden="true"></i>
      <div>
        <p class="fete-surtitre">Spécial fête · <?= e(fete_compte($fete)) ?></p>
        <h2><?= e($fete['nom']) ?> — <?= e(date_longue_fr($fete['date_fete'])) ?></h2>
        <?php if (fete_commande_a_temps($fete)): ?><p>Commandez avant le <b><?= e(date_longue_fr($fete['date_limite'])) ?></b> pour être livré à temps.</p><?php endif; ?>
      </div>
      <a class="btn btn-primaire" href="<?= e(url('fete/' . $fete['slug'])) ?>">Voir la sélection <i class="ph ph-arrow-right"></i></a>
    </div>
  </section>
  <?php endif; ?>

  <div class="banderole" aria-hidden="true">
    <div class="piste">
      <?php for ($i = 0; $i < 2; $i++): ?>
        <span>Jënd</span><span class="sep"></span><span>Achetez</span><span class="sep"></span><span>Jaay</span><span class="sep"></span><span>Vendez</span><span class="sep"></span><span>Teranga</span><span class="sep"></span><span>Wave · Orange Money</span><span class="sep"></span>
      <?php endfor; ?>
    </div>
  </div>

  <section class="bloc-section" id="produits">
    <div class="wrap">
      <div class="titre-section"><h2><span class="num-section">01</span> L'étalage du moment</h2><a href="<?= e(url('produits')) ?>">Tout l'étalage <i class="ph ph-arrow-right"></i></a></div>

      <?php if (!$produits): ?>
        <div class="vide etal-vide">
          <i class="ph ph-storefront"></i>
          <p><b>L'étalage est encore vide.</b><br>Les premières boutiques s'installent : revenez très vite, ou ouvrez la vôtre.</p>
          <a href="<?= e(url('vendre')) ?>" class="btn btn-primaire">Ouvrir ma boutique</a>
        </div>
      <?php else: ?>
        <div class="produits" id="produits-grille">
          <?php foreach ($produits as $p): include __DIR__ . '/../includes/carte.php'; endforeach; ?>
        </div>
      <?php endif; ?>
    </div>
  </section>

  <section class="vendre" id="vendre">
    <div class="wrap">
      <div class="affiche-vendre">
        <span class="mot-geant" aria-hidden="true">Jaay</span>
        <div class="vendre-texte">
          <p class="entree-dico entree-dico-clair"><b>jaay</b> <i>verbe wolof</i> — vendre.</p>
          <h2>Vous vendez ? Installez votre étal sur <em>Jënd</em>.</h2>
          <p>Ouvrez votre boutique en quelques minutes, publiez vos produits et recevez vos gains sur Wave ou Orange Money.</p>
          <a href="<?= e(url('vendre')) ?>" class="btn btn-accent">Ouvrir ma boutique <i class="ph ph-arrow-up-right"></i></a>
        </div>
        <ul class="registre">
          <li><span>Ouverture de la boutique</span><i></i><b>gratuite</b></li>
          <li><span>Commission</span><i></i><b><?= commission_defaut() == 0.0 ? '0 % au lancement' : (offre_lancement() ? 'seulement ' . e(commission_texte()) . ' % · offre de lancement' : e(commission_texte()) . ' % sur les ventes livrées') ?></b></li>
          <li><span>Frais de livraison</span><i></i><b>pour vous, si vous livrez</b></li>
          <li><span>Vos gains</span><i></i><b>Wave · Orange Money</b></li>
        </ul>
      </div>
    </div>
  </section>

  <section class="bloc-section">
    <div class="wrap">
      <div class="titre-section"><h2><span class="num-section">02</span> Notre parole</h2><a href="<?= e(url('livraison-retours')) ?>">Les détails <i class="ph ph-arrow-right"></i></a></div>
      <ol class="parole">
        <li><b>Votre argent est protégé.</b> Le vendeur n'est payé qu'après la livraison : vous lui donnez un code de réception <em>quand le colis est dans vos mains</em>.</li>
        <li><b>Un souci ? Dites-le-nous.</b> Signalez un problème avec photos pendant <?= LITIGE_DELAI_SIGNALEMENT_JOURS ?> jours : réponse sous <?= LITIGE_DELAI_REPONSE_HEURES ?> h, remboursement suivi pas à pas.</li>
        <li><b>Le prix affiché est le prix payé.</b> Les frais de livraison, par quartier, sont visibles avant de commander.</li>
        <li><b>Payez comme vous voulez.</b> <?= !paiement_en_ligne_actif() ? 'En espèces, à la livraison, quand le colis est dans vos mains.' : (!paiement_livraison_actif() ? 'Wave, Orange Money ou carte : l\'argent est protégé par Jënd jusqu\'à la livraison.' : (acompte_description() !== '' ? 'À la livraison, un petit acompte confirme la commande ; le reste en espèces.' : 'En ligne ou en espèces à la livraison.')) ?></li>
      </ol>
      <div class="paiements">
        <b>On accepte :</b>
        <?php if (paiement_en_ligne_actif()): ?><span class="chip">Wave</span><span class="chip">Orange Money</span><span class="chip">Free Money</span>
        <span class="chip">Carte bancaire</span><?php endif; ?><?php if (paiement_livraison_actif()): ?><span class="chip">Espèces à la livraison</span><?php endif; ?>
      </div>
    </div>
  </section>
</main>
<?php require __DIR__ . '/../includes/footer.php'; ?>
