<?php
/** Affiche à imprimer (A4 ou A5) : nom et logo de la boutique, promesse « payez en sécurité », QR code vers la boutique. */
[$u, $b] = exiger_vendeur();
$lien = app_url('boutique/' . $b['slug']);
$court = preg_replace('#^https?://(www\.)?#', '', $lien);
$titre = 'Affiche — ' . $b['nom'];
$robots = 'noindex';
require __DIR__ . '/../includes/header.php';
?>
<main class="page affiche-page">
  <div class="wrap">
    <p class="non-imprime affiche-outils"><a class="lien" href="<?= e(url('vendeur/kit')) ?>">← Promouvoir ma boutique</a>
      <button class="btn btn-primaire" type="button" data-imprimer><i class="ph ph-printer"></i> Imprimer</button></p>
    <article class="affiche-a4 couleur-<?= e($b['couleur'] ?: 'terre') ?>">
      <header>
        <span class="vitrine-logo"><?php if ($b['logo_chemin']): ?><img src="<?= e(url(image_miniature($b['logo_chemin']))) ?>" alt=""><?php else: ?><?= e(boutique_initiales($b['nom'])) ?><?php endif; ?></span>
        <div><h1><?= e($b['nom']) ?></h1><?php if ($b['slogan']): ?><p><?= e($b['slogan']) ?></p><?php endif; ?></div>
      </header>
      <p class="affiche-promesse">Payez-moi en toute sécurité sur <b>Jënd</b></p>
      <div class="affiche-qr"><?= qr_svg(lien_source($lien, 'affiche'), '#1B1410', 'QR code de la boutique ' . $b['nom']) ?></div>
      <p class="affiche-scan"><i class="ph ph-camera"></i> Scannez avec l'appareil photo de votre téléphone</p>
      <ul class="affiche-avantages">
        <li><i class="ph-fill ph-shield-check"></i> Votre argent est gardé jusqu'à la réception</li>
        <li><i class="ph-fill ph-device-mobile"></i> Wave, Orange Money ou carte</li>
        <li><i class="ph-fill ph-truck"></i> Livraison chez vous</li>
      </ul>
      <p class="affiche-lien"><?= e($court) ?></p>
      <footer><span class="logo">Jënd<span>.</span></span> la marketplace sénégalaise</footer>
    </article>
  </div>
</main>
<?php require __DIR__ . '/../includes/footer.php'; ?>
