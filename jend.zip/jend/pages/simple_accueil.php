<?php
/** Mode simple : accueil du vendeur — quatre grands boutons avec images, et les chiffres importants en gros. */
[$u, $b] = exiger_vendeur_simple();
$bid = (int) $b['id'];
$aTraiter = (int) requete(
    "SELECT COUNT(*) FROM commande_boutiques cb JOIN commandes c ON c.id = cb.commande_id
      WHERE cb.boutique_id = ? AND c.statut <> 'annulee' AND ((cb.statut = 'a_preparer' AND " . SQL_ENGAGEE . ") OR (cb.statut = 'expediee' AND cb.livre_par = 'vendeur' AND cb.livreur_id IS NULL))",
    [$bid]
)->fetchColumn();
$nbProduits = (int) requete("SELECT COUNT(*) FROM produits WHERE boutique_id = ? AND statut = 'publie' AND reserve_client_id IS NULL", [$bid])->fetchColumn();
$solde = vendeur_gains($bid)['solde'];
$titre = 'Ma boutique — Jënd';
$scripts_extra = ['js/simple.js'];
require __DIR__ . '/../includes/header.php';
?>
<main class="page simple">
  <div class="wrap">
    <?php simple_entete($b['nom'], 'accueil', false); ?>
    <?php if ($b['statut'] !== 'active'): ?>
      <p class="simple-info"><i class="ph-fill ph-hourglass-medium"></i> <span>Votre boutique attend la validation de l'équipe Jënd. Vous pouvez déjà mettre vos produits.</span></p>
    <?php endif; ?>
    <?= rappel_whatsapp($b, true) ?>
    <?= push_bloc(true) ?>
    <nav class="simple-tuiles" aria-label="Ma boutique">
      <a class="simple-tuile simple-tuile-terre" href="<?= e(url('simple/produit')) ?>"><i class="ph-fill ph-camera-plus"></i><b>Mettre un produit</b></a>
      <a class="simple-tuile simple-tuile-vert" href="<?= e(url('simple/commandes')) ?>"><i class="ph-fill ph-package"></i><b>Mes commandes</b><?php if ($aTraiter): ?><span class="simple-pastille" aria-label="<?= $aTraiter ?> à traiter"><?= $aTraiter ?></span><?php endif; ?></a>
      <a class="simple-tuile simple-tuile-safran" href="<?= e(url('simple/argent')) ?>"><i class="ph-fill ph-coins"></i><b>Mon argent</b><span class="simple-chiffre"><?= e(fcfa($solde)) ?></span></a>
      <a class="simple-tuile simple-tuile-encre" href="<?= e(url('simple/produits')) ?>"><i class="ph-fill ph-storefront"></i><b>Mes produits</b><span class="simple-chiffre"><?= $nbProduits ?></span></a>
    </nav>
    <div class="simple-bas">
      <a class="simple-lien" href="<?= e(url('aide')) ?>"><i class="ph ph-lifebuoy"></i> Besoin d'aide ? Écrire à Jënd</a>
      <form method="post" action="<?= e(url('simple/mode')) ?>">
        <?= csrf_champ() ?><input type="hidden" name="mode" value="complet">
        <button class="simple-lien" type="submit"><i class="ph ph-squares-four"></i> Passer au mode complet</button>
      </form>
    </div>
  </div>
</main>
<?php require __DIR__ . '/../includes/footer.php'; ?>
