<?php
/**
 * Notification du fournisseur de paiement (webhook). Appelée par le serveur du fournisseur, pas par un navigateur :
 * pas de session ni de CSRF, la SIGNATURE (en-tête X-Signature) est l'authentification.
 */
header('Content-Type: application/json; charset=UTF-8');
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['message' => 'Méthode non autorisée']);
    exit;
}
if (limite_atteinte('webhook:ip:' . ip_client(), 30, 900)) {
    alerter('webhook-deluge', 'Déluge sur le webhook de paiement', 'Plus de 30 notifications à signature invalide depuis ' . ip_client() . '. Tentative de falsification de paiements possible.');
    http_response_code(429);
    echo json_encode(['message' => 'Trop de requêtes']);
    exit;
}
// Notification IPN de PayTech (formulaire ou JSON) : authentifiée par HMAC-SHA256 (includes/paytech.php)
$donneesPaytech = $_POST ?: (json_decode((string) file_get_contents('php://input'), true) ?: []);
if (paytech_actif() && is_array($donneesPaytech) && paytech_est_notification($donneesPaytech)) {
    [$code, $message] = paytech_notification($donneesPaytech);
    if ($code === 401) {
        limite_enregistrer('webhook:ip:' . ip_client());
    }
    http_response_code($code);
    echo json_encode(['message' => $message]);
    exit;
}
// Webhook UnitechPay (JSON) : authentifié par HMAC-SHA256 (includes/unitech.php)
$brutUnitech = (string) file_get_contents('php://input');
$donneesUnitech = json_decode($brutUnitech, true);
if (unitech_actif() && is_array($donneesUnitech) && unitech_est_notification($donneesUnitech)) {
    [$code, $message] = unitech_notification($brutUnitech, $donneesUnitech, (string) ($_SERVER['HTTP_X_UNITECHPAY_SIGNATURE'] ?? ''));
    if ($code === 401) {
        limite_enregistrer('webhook:ip:' . ip_client());
    }
    http_response_code($code);
    echo json_encode(['message' => $message]);
    exit;
}
if (paydunya_actif() && isset($_POST['data'])) {          // notification IPN de PayDunya (form-urlencoded) : authentifiée par le hash de la clé principale
    [$code, $message] = paydunya_notification($_POST);
    if ($code === 401) {
        limite_enregistrer('webhook:ip:' . ip_client());
    }
    http_response_code($code);
    echo json_encode(['message' => $message]);
    exit;
}
$corps = file_get_contents('php://input', false, null, 0, 10000) ?: '';   // 10 Ko maximum
[$code, $message] = paiement_notification_traiter($corps, (string) ($_SERVER['HTTP_X_SIGNATURE'] ?? ''));
if ($code === 401) {
    limite_enregistrer('webhook:ip:' . ip_client());      // signature invalide : on compte, pour freiner les essais
}
http_response_code($code);
echo json_encode(['message' => $message]);
