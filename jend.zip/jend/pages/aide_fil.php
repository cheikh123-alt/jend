<?php
/**
 * Une conversation d'aide. $parametre = référence (AIDE-XXXXXXXX, utilisateur connecté propriétaire)
 * ou jeton secret de 64 caractères (lien reçu par e-mail, visiteur sans compte). $parSuivi vient du routeur.
 */
$u = utilisateur();
if (!empty($parSuivi)) {
    $m = requete('SELECT * FROM messages_support WHERE jeton_hash = ? AND user_id IS NULL', [hash('sha256', (string) $parametre)])->fetch();
    $ici = 'aide/suivi/' . $parametre;
} else {
    $u = exiger_connexion();
    $m = requete('SELECT * FROM messages_support WHERE reference = ? AND user_id = ?', [strtoupper((string) $parametre), $u['id']])->fetch();
    $ici = 'aide/' . strtoupper((string) $parametre);
}
if (!$m) {
    http_response_code(404);
    require __DIR__ . '/404.php';
    return;
}
if (post_verifie($ici)) {
    try {
        support_ajouter((int) $m['id'], 'client', (string) ($_POST['texte'] ?? ''), $u ? (int) $u['id'] : null);
        flash('Message envoyé : l\'équipe vous répond dans cette conversation.');
    } catch (RuntimeException $e) {
        flash($e->getMessage(), 'erreur');
    }
    // un visiteur garde le même lien tant qu'il est sur la page (le jeton ne change qu'à l'envoi d'un e-mail par l'équipe)
    rediriger($ici);
}
$fil = support_fil($m);
$vueEquipe = false;
$titre = 'Conversation ' . $m['reference'] . ' — Jënd';
require __DIR__ . '/../includes/header.php';
?>
<main class="page">
  <div class="wrap wrap-moyen">
    <nav class="fil" aria-label="Fil d'Ariane"><a href="<?= e(url()) ?>">Accueil</a> / <?php if (empty($parSuivi)): ?><a href="<?= e(url('aide')) ?>">Aide</a> / <?php endif; ?><span><?= e($m['reference']) ?></span></nav>
    <h1 class="titre-page">Aide</h1>
    <article class="offre offre-<?= $m['statut'] === 'resolu' ? 'close' : ($m['statut'] === 'en_cours' ? 'acceptee' : 'en_attente') ?>">
      <header><b><?= e($m['reference']) ?> · <?= e(SUJETS_SUPPORT[$m['sujet']]) ?></b>
        <span class="badge badge-offre-<?= $m['statut'] === 'resolu' ? 'close' : ($m['statut'] === 'en_cours' ? 'acceptee' : 'en_attente') ?>"><?= e(STATUTS_SUPPORT[$m['statut']]) ?></span></header>
      <p class="doux petit">Ouverte le <?= e(date('d/m/Y à H:i', strtotime($m['created_at']))) ?><?= $m['commande_ref'] ? ' · commande ' . e($m['commande_ref']) : '' ?></p>
      <?php require __DIR__ . '/../includes/support_fil.php'; ?>
    <?php if ($m['statut'] === 'resolu'): ?>
      <p class="alerte alerte-info"><i class="ph ph-check-circle"></i> <span>Cette conversation est close : le problème a été réglé. Besoin d'autre chose ? <a class="lien" href="<?= e(url('contact')) ?>">Écrivez-nous un nouveau message</a>.</span></p>
    <?php else: ?>
      <form method="post" class="formulaire formulaire-large">
        <?= csrf_champ() ?>
        <label class="champ"><span>Répondre dans la conversation</span><textarea name="texte" rows="3" maxlength="3000" required></textarea></label>
        <div class="ligne-action"><button class="btn btn-primaire" type="submit"><i class="ph ph-paper-plane-tilt"></i> Envoyer</button></div>
      </form>
    <?php endif; ?>
    </article>
  </div>
</main>
<?php require __DIR__ . '/../includes/footer.php'; ?>
