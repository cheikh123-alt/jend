<?php
[$u, $b] = exiger_vendeur();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_valide($_POST['csrf'] ?? null)) {
        flash('Session expirée, merci de réessayer.', 'erreur');
    } else {
        try {
            sous_commande_avancer((int) ($_POST['id'] ?? 0), (int) $b['id'], trim((string) ($_POST['numero_suivi'] ?? '')), (string) ($_POST['code_livraison'] ?? ''));
            flash('Commande mise à jour.');
        } catch (RuntimeException $e) {
            flash($e->getMessage(), 'erreur');
        }
    }
    rediriger('vendeur/commandes' . (($_GET['vue'] ?? '') === 'terminees' ? '?vue=terminees' : ''));
}

$vue = ($_GET['vue'] ?? '') === 'terminees' ? 'terminees' : 'a_traiter';
$filtre = $vue === 'terminees' ? "cb.statut IN ('livree', 'annulee', 'retournee') OR c.statut = 'annulee'" : "cb.statut IN ('a_preparer', 'expediee') AND c.statut <> 'annulee'";
$commandes = requete(
    "SELECT cb.id, cb.statut, cb.livre_par, cb.frais_part, cb.acompte_part, cb.acompte_acquis, c.acompte, cb.commission, (SELECT l.statut FROM litiges l WHERE l.commande_boutique_id = cb.id) AS litige_statut, cb.numero_suivi, (cb.code_livraison IS NOT NULL) AS a_code, cb.sous_total, cb.net_vendeur, c.reference, c.created_at, c.statut AS statut_commande,
            c.statut_paiement, c.methode_paiement, c.livraison_nom, c.livraison_telephone, c.livraison_zone, c.livraison_adresse, c.livraison_lat, c.livraison_lng, c.cadeau, c.message_cadeau
       FROM commande_boutiques cb JOIN commandes c ON c.id = cb.commande_id
      WHERE cb.boutique_id = ? AND ($filtre) ORDER BY c.created_at DESC, cb.id DESC LIMIT 100",
    [$b['id']]
)->fetchAll();
$lignes = [];
if ($commandes) {
    $in = implode(',', array_fill(0, count($commandes), '?'));
    foreach (requete("SELECT commande_boutique_id, nom, quantite, prix_unitaire, variante_libelle FROM commande_lignes WHERE commande_boutique_id IN ($in)", array_column($commandes, 'id'))->fetchAll() as $l) {
        $lignes[$l['commande_boutique_id']][] = $l;
    }
}
$titre = 'Commandes reçues — Jënd';
require __DIR__ . '/../includes/header.php';
?>
<main class="page">
  <div class="wrap">
    <nav class="fil" aria-label="Fil d'Ariane"><a href="<?= e(url()) ?>">Accueil</a> / <a href="<?= e(url('vendeur')) ?>">Boutique</a> / <span>Commandes</span></nav>
    <h1 class="titre-page"><?= e($b['nom']) ?></h1>
    <?php vendeur_onglets('commandes'); ?>
    <?= push_bloc() ?>
    <div class="filtres-vue">
      <a href="<?= e(url('vendeur/commandes')) ?>" class="<?= $vue === 'a_traiter' ? 'actif' : '' ?>">À traiter</a>
      <a href="<?= e(url('vendeur/commandes?vue=terminees')) ?>" class="<?= $vue === 'terminees' ? 'actif' : '' ?>">Terminées</a>
    </div>

    <?php if (!$commandes): ?>
      <div class="vide"><i class="ph ph-truck"></i><p><b>Aucune commande <?= $vue === 'a_traiter' ? 'à traiter' : 'terminée' ?>.</b></p></div>
    <?php endif; ?>

    <?php foreach ($commandes as $c):
        $paye = commande_engagee($c); ?>
      <article class="commande-vendeur">
        <header>
          <div><b><?= e($c['reference']) ?></b> <span class="doux">· <?= e(date('d/m/Y H:i', strtotime($c['created_at']))) ?></span></div>
          <span><?php if ($c['litige_statut']): ?><span class="badge badge-litige-<?= e($c['litige_statut']) ?>" title="Le client a signalé un problème : les gains de cette livraison sont mis de côté jusqu'à la décision"><i class="ph ph-warning-circle"></i> Signalement : <?= e(STATUTS_LITIGE[$c['litige_statut']]) ?></span> <?php endif; ?>
          <span class="badge badge-<?= e($c['statut']) ?>"><?= e(STATUTS_SOUS_COMMANDE[$c['statut']]) ?></span></span>
        </header>
        <ul class="lignes">
          <?php foreach ($lignes[$c['id']] ?? [] as $l): ?><li><?= (int) $l['quantite'] ?> × <?= e($l['nom']) ?><?= $l['variante_libelle'] ? ' — <b class="variante-choisie">' . e($l['variante_libelle']) . '</b>' : '' ?> <span class="doux">(<?= e(fcfa((int) $l['prix_unitaire'])) ?>)</span></li><?php endforeach; ?>
        </ul>
        <p class="petit"><b>Livrer à :</b> <?= e($c['livraison_nom']) ?> · <?= e($c['livraison_telephone']) ?><br><?= e($c['livraison_adresse']) ?> — <?= e($c['livraison_zone']) ?></p>
        <?php if ($gpsBouton = bouton_itineraire($c, 'Itinéraire GPS jusqu\'au client')): ?><p class="petit"><?= $gpsBouton ?> <span class="doux">position exacte donnée par le client</span></p><?php endif; ?>
        <?php if ((int) $c['cadeau'] === 1): ?><p class="alerte alerte-info petit"><i class="ph ph-gift"></i> <span><b>Cadeau</b> : ne mettez <b>ni prix ni facture</b> dans le colis.<?= $c['message_cadeau'] ? ' Joignez ce mot : « ' . e($c['message_cadeau']) . ' »' : '' ?></span></p><?php endif; ?>
        <?php $cod = $c['methode_paiement'] === 'livraison'; $moi = $c['livre_par'] === 'vendeur'; ?>
        <p class="petit">Total boutique : <b><?= e(fcfa((int) $c['sous_total'])) ?></b>
          <?php if ($moi && $cod): ?>
            · <b>Vous encaissez <?= e(fcfa((int) $c['sous_total'] + (int) $c['frais_part'] - (int) $c['acompte_part'])) ?> en espèces</b> à la livraison (produits + <?= e(fcfa((int) $c['frais_part'])) ?> de livraison, qui vous reviennent<?= (int) $c['acompte_part'] > 0 ? ', moins ' . e(fcfa((int) $c['acompte_part'])) . ' d\'acompte déjà payé en ligne' : '' ?>)<?= (int) $c['commission'] > 0 ? ' · commission à reverser à Jënd : <b>' . e(fcfa((int) $c['commission'])) . '</b>' : '' ?>
          <?php elseif ($moi): ?>
            · Vous recevez : <b><?= e(fcfa((int) $c['net_vendeur'] + (int) $c['frais_part'])) ?></b> <span class="doux">(dont <?= e(fcfa((int) $c['frais_part'])) ?> de livraison)</span>
          <?php else: ?>
            · Vous recevez : <b><?= e(fcfa((int) $c['net_vendeur'])) ?></b><?= $cod ? ' <span class="doux">· paiement à la livraison</span>' : '' ?>
          <?php endif; ?>
          <br><span class="doux"><i class="ph ph-<?= $moi ? 'person-simple-walk' : 'motorcycle' ?>"></i> <?= $moi ? 'Vous livrez cette commande vous-même.' : 'Livraison assurée par un livreur Jënd : préparez le colis, il passera le récupérer.' ?></span></p>
        <?php if ($c['numero_suivi']): ?><p class="petit doux">Suivi n° <?= e($c['numero_suivi']) ?></p><?php endif; ?>
        <?php if ($c['acompte_acquis']): ?><p class="petit"><i class="ph ph-shield-check"></i> Le client était absent ou a refusé : <b>son acompte de <?= e(fcfa((int) $c['acompte_part'])) ?> vous est acquis</b><?= $c['livre_par'] === 'vendeur' ? '' : ' (conservé par Jënd, qui assurait la livraison)' ?>.</p><?php endif; ?>

        <?php if ($vue === 'a_traiter'): ?>
          <?php if (!$paye): ?>
            <p class="alerte alerte-info"><i class="ph ph-hourglass-medium"></i> En attente du <?= $c['methode_paiement'] === 'livraison' ? 'paiement de l\'acompte' : 'paiement' ?> du client : ne préparez pas encore cette commande.</p>
          <?php elseif ($c['statut'] === 'a_preparer'): ?>
            <form method="post" action="<?= e(url('vendeur/commandes')) ?>" class="ligne-action">
              <?= csrf_champ() ?><input type="hidden" name="id" value="<?= (int) $c['id'] ?>">
              <input type="text" name="numero_suivi" maxlength="60" placeholder="N° de suivi (optionnel)" aria-label="Numéro de suivi">
              <button class="btn btn-primaire" type="submit"><i class="ph ph-package"></i> Marquer comme expédiée</button>
            </form>
          <?php elseif ($c['statut'] === 'expediee' && !$moi): ?>
            <p class="alerte alerte-info"><i class="ph ph-motorcycle"></i> Un livreur Jënd s'occupe de la livraison : vous n'avez rien à confirmer.</p>
          <?php elseif ($c['statut'] === 'expediee'): ?>
            <form method="post" action="<?= e(url('vendeur/commandes')) ?>" class="ligne-action" data-confirm="Confirmer que le client a bien reçu cette commande ?">
              <?= csrf_champ() ?><input type="hidden" name="id" value="<?= (int) $c['id'] ?>">
              <?php if ($c['a_code']): ?><input type="text" name="code_livraison" inputmode="numeric" pattern="[0-9]{4}" maxlength="4" placeholder="Code du client (4 chiffres)" aria-label="Code de livraison du client" required><?php endif; ?>
              <button class="btn btn-primaire" type="submit"><i class="ph ph-check-circle"></i> Marquer comme livrée</button>
            </form>
            <p class="doux petit">Le client peut aussi confirmer lui-même la réception sur son compte : la commande passe alors à « livrée » toute seule.</p>
          <?php endif; ?>
        <?php endif; ?>
      </article>
    <?php endforeach; ?>
  </div>
</main>
<?php require __DIR__ . '/../includes/footer.php'; ?>
