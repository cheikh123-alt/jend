<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST' && csrf_valide($_POST['csrf'] ?? null)) {
    deconnecter();
    session_start();
    flash('Vous êtes déconnecté. À bientôt !');
}
rediriger('');
