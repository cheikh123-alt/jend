<?php
[$u, $l] = exiger_livreur();
$courses = requete(SQL_COURSE . " WHERE cb.livreur_id = ? AND (cb.statut = 'livree' OR cb.statut IN ('annulee', 'retournee') OR c.statut = 'annulee')
                                   ORDER BY COALESCE(cb.livre_le, cb.en_route_le, cb.affecte_le) DESC, cb.id DESC LIMIT 100", [$u['id']])->fetchAll();
$jours = [];
foreach ($courses as $c) {
    $jours[date('Y-m-d', (int) strtotime($c['livre_le'] ?? $c['en_route_le'] ?? $c['affecte_le'] ?? $c['created_at']))][] = $c;
}
$libelleJour = function (string $d): string {
    if ($d === date('Y-m-d')) {
        return 'Aujourd\'hui';
    }
    if ($d === date('Y-m-d', strtotime('-1 day'))) {
        return 'Hier';
    }
    $mois = ['', 'janvier', 'février', 'mars', 'avril', 'mai', 'juin', 'juillet', 'août', 'septembre', 'octobre', 'novembre', 'décembre'];
    return (int) date('j', strtotime($d)) . ' ' . $mois[(int) date('n', strtotime($d))];
};
livreur_entete('Historique — Jënd Livreur', 'historique');
?>
<h1 class="app-titre">Historique</h1>
<?php if (!$courses): ?><div class="app-vide"><i class="ph ph-clock-counter-clockwise"></i><b>Rien pour le moment</b><p>Vos courses terminées apparaîtront ici.</p></div><?php endif; ?>
<?php foreach ($jours as $jour => $liste):
    $livrees = array_filter($liste, fn ($c) => course_etape($c) === 'livree');
    $especes = array_sum(array_map('course_a_encaisser', $livrees)); ?>
  <div class="jour-entete"><b><?= e($libelleJour($jour)) ?></b><small><?= count($livrees) ?> livrée(s)<?= $especes > 0 ? ' · ' . e(fcfa($especes)) . ' encaissés' : '' ?></small></div>
  <?php foreach ($liste as $c): $etape = course_etape($c); ?>
    <a class="ligne-histo" href="<?= e(url('livreur/course/' . $c['id'])) ?>">
      <span class="puce puce-<?= e($etape) ?>"><?= e(ETAPES_COURSE[$etape]) ?></span>
      <span class="ligne-histo-texte"><b><?= e($c['boutique']) ?> → <?= e($c['livraison_zone']) ?></b><small><?= e($c['reference']) ?><?= $c['livre_le'] ? ' · ' . e(heure_courte($c['livre_le'])) : '' ?></small></span>
      <i class="ph ph-caret-right"></i>
    </a>
  <?php endforeach; ?>
<?php endforeach; ?>
<?php livreur_pied(); ?>
