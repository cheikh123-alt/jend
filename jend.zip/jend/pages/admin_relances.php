<?php
/**
 * Relances : commandes payées (ou confirmées) que le vendeur n'a pas encore envoyées après RELANCE_HEURES.
 * L'équipe relance le vendeur en un geste : message WhatsApp déjà écrit, ou appel. Utile pour les vendeurs qui lisent peu
 * ou n'ont pas activé les notifications. « C'est fait » note la relance (la commande quitte la pastille pendant RELANCE_HEURES).
 */
exiger_admin();
if (post_verifie('admin/relances')) {
    $n = requete('UPDATE commande_boutiques SET relance_le = NOW() WHERE id = ? AND statut = \'a_preparer\'', [(int) ($_POST['id'] ?? 0)])->rowCount();
    if ($n) {
        journaliser('vendeur_relance', 'livraison #' . (int) ($_POST['id'] ?? 0));
    }
    flash($n ? 'Relance notée.' : 'Cette commande n\'est plus à préparer.', $n ? 'ok' : 'erreur');
    rediriger('admin/relances');
}
$liste = requete(
    "SELECT cb.id, cb.relance_le, cb.vendeur_prevenu_le, c.reference, c.created_at, c.livraison_zone,
            TIMESTAMPDIFF(MINUTE, COALESCE(cb.vendeur_prevenu_le, c.created_at), NOW()) AS attente_min,
            b.nom AS boutique, b.mode_simple, b.contact_whatsapp, b.telephone_paiement, u.id AS user_id, u.nom AS vendeur, u.telephone,
            (SELECT COUNT(*) FROM push_abonnements pa WHERE pa.user_id = u.id) AS appareils
       FROM commande_boutiques cb JOIN commandes c ON c.id = cb.commande_id
       JOIN boutiques b ON b.id = cb.boutique_id JOIN users u ON u.id = b.user_id
      WHERE " . relances_condition() . "
      ORDER BY (cb.relance_le IS NOT NULL), COALESCE(cb.vendeur_prevenu_le, c.created_at) ASC LIMIT 100"
)->fetchAll();
$titre = 'Relances — Administration';
require __DIR__ . '/../includes/header.php';
?>
<main class="page">
  <div class="wrap">
    <nav class="fil" aria-label="Fil d'Ariane"><a href="<?= e(url()) ?>">Accueil</a> / <a href="<?= e(url('admin')) ?>">Administration</a> / <span>Relances</span></nav>
    <h1 class="titre-page">Administration</h1>
    <?php admin_onglets('relances'); ?>
    <p class="doux">Commandes à préparer depuis plus de <b><?= RELANCE_HEURES ?> heures</b> sans que le vendeur l'ait envoyée. Il a déjà reçu un e-mail et, s'il les a activées, une notification sur son téléphone. Relancez-le en un geste :</p>
    <?php if (!$liste): ?>
      <div class="vide"><i class="ph ph-check-circle"></i><p><b>Aucune commande en retard.</b> Tous les vendeurs ont traité leurs commandes.</p></div>
    <?php endif; ?>
    <div class="relances">
      <?php foreach ($liste as $r):
          $r['articles'] = prevenir_articles((int) $r['id']);
          $tel = $r['contact_whatsapp'] ?: ($r['telephone'] ?: $r['telephone_paiement']);
          $wa = simple_lien_whatsapp($tel);
          $h = intdiv((int) $r['attente_min'], 60); ?>
        <article class="relance<?= $r['relance_le'] ? ' relance-faite' : '' ?>">
          <header><b><?= e($r['boutique']) ?></b> <span class="doux">· <?= e($r['vendeur']) ?></span>
            <span class="badge <?= $h >= 24 ? 'badge-litige-ouvert' : 'badge-a_preparer' ?>"><i class="ph ph-clock"></i> <?= $h >= 1 ? $h . ' h' : (int) $r['attente_min'] . ' min' ?></span></header>
          <p><b><?= e($r['reference']) ?></b> · <?= e($r['articles']) ?> · <?= e($r['livraison_zone']) ?></p>
          <p class="petit doux"><?= (int) $r['appareils'] > 0 ? '<i class="ph ph-bell-ringing"></i> Notifications activées (' . (int) $r['appareils'] . ' appareil' . ((int) $r['appareils'] > 1 ? 's' : '') . ')' : '<i class="ph ph-bell-slash"></i> Notifications non activées : proposez-lui de les activer' ?>
            · <?= (int) $r['mode_simple'] === 1 ? 'mode simple' : 'mode complet' ?>
            <?= $r['relance_le'] ? ' · <b>relancé le ' . e(date('d/m à H:i', strtotime((string) $r['relance_le']))) . '</b>' : '' ?></p>
          <div class="relance-actions">
            <?php if ($wa): ?><a class="btn btn-whatsapp" href="<?= e($wa . '?text=' . rawurlencode(relance_message($r))) ?>" target="_blank" rel="noopener"><i class="ph-fill ph-whatsapp-logo"></i> WhatsApp</a><?php endif; ?>
            <?php if ($tel): ?><a class="btn btn-contour" href="tel:<?= e(preg_replace('/[^\d+]/', '', (string) $tel)) ?>"><i class="ph ph-phone"></i> Appeler <?= e((string) $tel) ?></a>
            <?php else: ?><span class="doux petit">Aucun numéro enregistré pour ce vendeur.</span><?php endif; ?>
            <form method="post"><?= csrf_champ() ?><input type="hidden" name="id" value="<?= (int) $r['id'] ?>"><button class="btn btn-contour" type="submit"><i class="ph ph-check"></i> C'est fait</button></form>
          </div>
        </article>
      <?php endforeach; ?>
    </div>
  </div>
</main>
<?php require __DIR__ . '/../includes/footer.php'; ?>
