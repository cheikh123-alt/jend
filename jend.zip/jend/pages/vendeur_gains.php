<?php
[$u, $b] = exiger_vendeur();
$erreurs = [];
$methodes = ['wave' => 'Wave', 'orange_money' => 'Orange Money', 'free_money' => 'Free Money'];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'versement') {      // réglages du versement à date fixe
    if (post_verifie('vendeur/gains')) {
        $m = (string) ($_POST['methode_versement'] ?? 'wave');
        requete('UPDATE boutiques SET versement_auto = ?, methode_versement = ? WHERE id = ?', [!empty($_POST['versement_auto']) ? 1 : 0, isset(METHODES_VERSEMENT[$m]) ? $m : 'wave', $b['id']]);
        flash(!empty($_POST['versement_auto']) ? 'Versement automatique activé.' : 'Versement automatique désactivé : demandez vos retraits vous-même.');
    }
    rediriger('vendeur/gains');
}
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $montant = trim((string) ($_POST['montant'] ?? ''));
    $methode = (string) ($_POST['methode'] ?? '');
    if (!csrf_valide($_POST['csrf'] ?? null)) {
        $erreurs[] = 'Session expirée, merci de réessayer.';
    }
    if ($b['statut'] !== 'active') {
        $erreurs[] = 'Votre boutique doit être validée pour demander un retrait.';
    }
    if (!empty($b['telephone_modifie_le']) && strtotime((string) $b['telephone_modifie_le']) > time() - RETRAIT_DELAI_CHANGEMENT_HEURES * 3600) {
        $erreurs[] = 'Par sécurité, les retraits sont suspendus ' . RETRAIT_DELAI_CHANGEMENT_HEURES . ' h après un changement de numéro de paiement (jusqu\'au ' . date('d/m à H:i', strtotime((string) $b['telephone_modifie_le']) + RETRAIT_DELAI_CHANGEMENT_HEURES * 3600) . ').';
    }
    if (parametre_actif('retrait_2fa', false) && (int) $u['totp_actif'] !== 1) {
        $erreurs[] = 'Pour retirer vos gains, activez d\'abord la double authentification (Mon compte → Sécurité) : elle protège votre argent si votre mot de passe est volé.';
    }
    if (!isset($methodes[$methode])) {
        $erreurs[] = 'Choisissez un moyen de réception.';
    }
    if (!$b['telephone_paiement']) {
        $erreurs[] = 'Renseignez votre numéro de paiement dans « Boutique ».';
    }
    if (!ctype_digit($montant) || (int) $montant < RETRAIT_MINIMUM) {
        $erreurs[] = 'Le retrait minimum est de ' . fcfa(RETRAIT_MINIMUM) . '.';
    }
    if (!$erreurs) {
        $pdo = pdo();
        $pdo->beginTransaction();
        requete('SELECT id FROM boutiques WHERE id = ? FOR UPDATE', [$b['id']]);     // verrou : deux demandes simultanées ne peuvent pas dépasser le solde
        $solde = vendeur_gains((int) $b['id'])['solde'];
        if ((int) $montant > $solde) {
            $pdo->rollBack();
            $erreurs[] = 'Montant supérieur à votre solde disponible (' . fcfa($solde) . ').';
        } else {
            requete('INSERT INTO retraits (boutique_id, montant, methode) VALUES (?, ?, ?)', [$b['id'], (int) $montant, $methode]);
            $pdo->commit();
            envoyer_email((string) $u['email'], 'Demande de retrait de ' . fcfa((int) $montant),
                "Bonjour,\n\nUne demande de retrait de " . fcfa((int) $montant) . " vers le numéro {$b['telephone_paiement']} ({$methodes[$methode]}) vient d'être faite depuis votre boutique.\n\nSi ce n'est PAS vous : changez immédiatement votre mot de passe et écrivez-nous depuis « Aide et contact » : le retrait ne sera pas payé.\n" . app_url('contact'));
            flash('Demande de retrait de ' . fcfa((int) $montant) . ' envoyée.');
            rediriger('vendeur/gains');
        }
    }
}

$g = vendeur_gains((int) $b['id']);
$retraits = requete('SELECT montant, methode, statut, created_at, automatique, paye_le, reference_transfert FROM retraits WHERE boutique_id = ? ORDER BY id DESC LIMIT 20', [$b['id']])->fetchAll();
$libRetrait = ['demande' => 'En cours', 'paye' => 'Versé', 'refuse' => 'Refusé'];
$titre = 'Mes gains — Jënd';
require __DIR__ . '/../includes/header.php';
?>
<main class="page">
  <div class="wrap">
    <nav class="fil" aria-label="Fil d'Ariane"><a href="<?= e(url()) ?>">Accueil</a> / <a href="<?= e(url('vendeur')) ?>">Boutique</a> / <span>Gains</span></nav>
    <h1 class="titre-page"><?= e($b['nom']) ?></h1>
    <?php vendeur_onglets('gains'); ?>

    <div class="stats">
      <div class="stat"><span>Ventes livrées</span><b><?= e(fcfa($g['brut'])) ?></b></div>
      <?php if ($g['en_delai'] > 0): ?><div class="stat"><span>Bientôt retirable (délai de <?= (int) $g['delai'] ?> j après livraison)</span><b><?= e(fcfa($g['en_delai'])) ?></b><small class="doux">le temps que le client puisse signaler un problème</small></div><?php endif; ?>
      <?php if ($g['frais_livraison'] > 0): ?><div class="stat"><span>Frais de livraison gagnés (vous livrez)</span><b>+ <?= e(fcfa($g['frais_livraison'])) ?></b></div><?php endif; ?>
      <?php if ($g['especes'] > 0): ?><div class="stat"><span>Espèces déjà encaissées par vous</span><b><?= e(fcfa($g['especes'])) ?></b><small class="doux">paiements à la livraison que vous avez reçus directement : Jënd ne vous les verse pas</small></div><?php endif; ?>
      <?php if ($g['a_reverser'] > 0): ?><div class="stat"><span>Commission à reverser à Jënd (sur ces espèces)</span><b>− <?= e(fcfa($g['a_reverser'])) ?></b></div><?php endif; ?>
      <?php if ($g['dette'] > 0): ?><div class="stat"><span>Vous devez à Jënd</span><b><?= e(fcfa($g['dette'])) ?></b><small class="doux">commissions sur vos ventes en espèces : elles seront retenues sur vos prochains gains</small></div><?php endif; ?>
      <?php if ($g['bloque'] > 0): ?><div class="stat"><span>En litige (mis de côté)</span><b><?= e(fcfa($g['bloque'])) ?></b></div><?php endif; ?>
      <?php if ($g['rembourse'] > 0): ?><div class="stat"><span>Remboursements clients retenus</span><b>− <?= e(fcfa($g['rembourse'])) ?></b></div><?php endif; ?>
      <div class="stat"><span>Commission Jënd (<?= e((string) $b['commission_pct']) ?> %)</span><b>− <?= e(fcfa($g['commission'])) ?></b></div>
      <div class="stat"><span>Déjà retiré / en cours</span><b>− <?= e(fcfa($g['retire'])) ?></b></div>
      <?php if ($g['regle'] > 0): ?><div class="stat"><span>Commissions réglées à Jënd</span><b>+ <?= e(fcfa($g['regle'])) ?></b><small class="doux">sur vos ventes en espèces</small></div><?php endif; ?>
      <div class="stat stat-fort"><span>Solde disponible</span><b><?= e(fcfa($g['solde'])) ?></b></div>
    </div>
    <p class="doux petit">Seules les commandes <b>livrées et payées</b> comptent dans votre solde.</p>
    <?= reglement_bloc_vendeur($b, $g['dette']) ?>

    <?php $prochain = prochain_versement(); $blocage = versement_bloque($b, $u);
    // Paiement en ligne coupé et rien à retirer : les clients paient le vendeur en espèces, Jënd ne garde pas d'argent pour lui
    $especesSeules = !paiement_en_ligne_actif() && $g['solde'] < RETRAIT_MINIMUM; ?>
    <?php if ($especesSeules): ?>
    <section class="versement-carte">
      <div class="versement-tete">
        <i class="ph ph-hand-coins" aria-hidden="true"></i>
        <div>
          <p class="versement-quand">Vos clients vous paient en espèces</p>
          <p class="doux">Pour l'instant, les clients paient <b>à la livraison, directement à vous</b> : l'argent de vos ventes est <b>déjà dans votre poche</b>. Jënd ne garde rien pour vous, il n'y a donc <b>rien à retirer</b>. Le retrait servira quand le paiement en ligne sera ouvert (Jënd gardera alors l'argent jusqu'à la livraison).</p>
        </div>
        <a class="btn btn-contour" href="<?= e(url('vendeur/releves')) ?>"><i class="ph ph-file-text"></i> Mes relevés</a>
      </div>
    </section>
    <?php else: ?>
    <section class="versement-carte">
      <div class="versement-tete">
        <i class="ph ph-calendar-check" aria-hidden="true"></i>
        <div>
          <?php if ($prochain && (int) $b['versement_auto'] === 1): ?>
            <p class="versement-quand">Prochain versement : <b><?= e(date_jour_fr($prochain)) ?></b></p>
            <p class="doux">Ce jour-là, <b>tout votre solde disponible</b> (<?= e(fcfa($g['solde'])) ?> aujourd'hui, minimum <?= e(fcfa(RETRAIT_MINIMUM)) ?>) est envoyé sur votre <?= e(METHODES_VERSEMENT[$b['methode_versement']] ?? 'Wave') ?> (<?= e((string) $b['telephone_paiement']) ?>). Vous recevez un e-mail avec la référence du transfert.</p>
            <?php if ($blocage): ?><p class="alerte"><i class="ph ph-warning"></i> <span>Versement suspendu : <?= e($blocage) ?>.</span></p><?php endif; ?>
          <?php elseif ($prochain): ?>
            <p class="versement-quand">Versement automatique désactivé</p>
            <p class="doux">Jënd verse chaque <b><?= e((string) versement_jour()) ?></b> : réactivez-le ci-dessous, ou demandez vos retraits vous-même.</p>
          <?php else: ?>
            <p class="versement-quand">Versements sur demande</p>
            <p class="doux">Demandez un retrait ci-dessous : Jënd vous l'envoie dans les meilleurs délais.</p>
          <?php endif; ?>
        </div>
        <a class="btn btn-contour" href="<?= e(url('vendeur/releves')) ?>"><i class="ph ph-file-text"></i> Mes relevés</a>
      </div>
      <?php if ($prochain): ?>
      <form method="post" class="versement-reglages"><?= csrf_champ() ?><input type="hidden" name="action" value="versement">
        <label class="case"><input type="checkbox" name="versement_auto" value="1" <?= (int) $b['versement_auto'] === 1 ? 'checked' : '' ?>> <span>Recevoir automatiquement mon solde chaque <?= e((string) versement_jour()) ?></span></label>
        <label class="ligne-form"><span>sur</span> <select name="methode_versement"><?php foreach (METHODES_VERSEMENT as $k => $l): ?><option value="<?= e($k) ?>" <?= $b['methode_versement'] === $k ? 'selected' : '' ?>><?= e($l) ?></option><?php endforeach; ?></select></label>
        <button class="btn btn-contour" type="submit">Enregistrer</button>
      </form>
      <?php endif; ?>
    </section>
    <?php endif; ?>

    <div class="deux-colonnes">
      <?php if (!$especesSeules): ?>
      <form method="post" class="formulaire formulaire-large" novalidate>
        <?= csrf_champ() ?>
        <h2 class="sous-titre"><?= $prochain ? 'Besoin d\'argent avant ? Demander un retrait' : 'Demander un retrait' ?></h2>
        <?php foreach ($erreurs as $er): ?><p class="alerte" role="alert"><?= e($er) ?></p><?php endforeach; ?>
        <label class="champ"><span>Montant (FCFA) — minimum <?= e(fcfa(RETRAIT_MINIMUM)) ?></span><input type="number" name="montant" min="<?= RETRAIT_MINIMUM ?>" max="<?= $g['solde'] ?>" step="1" required></label>
        <label class="champ"><span>Recevoir sur</span>
          <select name="methode" required>
            <?php foreach ($methodes as $k => $l): ?><option value="<?= $k ?>"><?= e($l) ?> (<?= e((string) $b['telephone_paiement']) ?>)</option><?php endforeach; ?>
          </select>
        </label>
        <button class="btn btn-primaire" type="submit" <?= $g['solde'] < RETRAIT_MINIMUM ? 'disabled' : '' ?>>Demander le retrait</button>
        <?php if ($g['solde'] < RETRAIT_MINIMUM): ?><p class="doux petit">Bouton inactif : votre solde disponible (<?= e(fcfa($g['solde'])) ?>) est inférieur au minimum de <?= e(fcfa(RETRAIT_MINIMUM)) ?>.<?= $g['en_delai'] > 0 ? ' ' . e(fcfa($g['en_delai'])) . ' deviendront retirables après le délai de ' . (int) $g['delai'] . ' jour(s).' : '' ?></p><?php endif; ?>
      </form>
      <?php endif; ?>

      <section>
        <h2 class="sous-titre">Mes retraits</h2>
        <?php if (!$retraits): ?>
          <div class="vide"><i class="ph ph-bank"></i><p><b>Aucun retrait pour le moment.</b></p></div>
        <?php else: foreach ($retraits as $r): ?>
          <div class="adresse-carte"><div><b><?= e(fcfa((int) $r['montant'])) ?></b> <span class="doux">· <?= e($methodes[$r['methode']] ?? $r['methode']) ?> · <?= e(date('d/m/Y', strtotime($r['paye_le'] ?? $r['created_at']))) ?><?= $r['automatique'] ? ' · versement automatique' : '' ?></span>
            <?php if ($r['reference_transfert']): ?><br><small class="doux">Référence du transfert : <b><?= e($r['reference_transfert']) ?></b></small><?php endif; ?></div>
            <span class="badge badge-<?= $r['statut'] === 'paye' ? 'confirmee' : ($r['statut'] === 'refuse' ? 'annulee' : 'en_attente') ?>"><?= e($libRetrait[$r['statut']]) ?></span></div>
        <?php endforeach; endif; ?>
      </section>
    </div>
  </div>
</main>
<?php require __DIR__ . '/../includes/footer.php'; ?>
