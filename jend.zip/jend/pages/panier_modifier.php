<?php
// Met à jour la quantité d'un article ou le retire du panier.
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    rediriger('panier');
}
if (!csrf_valide($_POST['csrf'] ?? null)) {
    flash('Session expirée, merci de réessayer.', 'erreur');
    rediriger('panier');
}

$cle = (string) ($_POST['cle'] ?? $_POST['produit_id'] ?? '');          // « 12 » ou « 12:34 » (produit + taille)
[$id, $varianteId] = panier_cle_lire($cle);
$cle = panier_cle($id, $varianteId);
if (isset($_SESSION['panier'][$cle])) {
    if (($_POST['action'] ?? '') === 'supprimer') {
        unset($_SESSION['panier'][$cle]);
        flash('Article retiré du panier.');
    } else {
        $stock = (int) ($varianteId
            ? requete('SELECT stock FROM produit_variantes WHERE id = ? AND produit_id = ?', [$varianteId, $id])->fetchColumn()
            : requete('SELECT stock FROM produits WHERE id = ?', [$id])->fetchColumn());
        $q = max(1, min(10, $stock, (int) ($_POST['quantite'] ?? 1)));
        $_SESSION['panier'][$cle] = $q;
        flash('Quantité mise à jour.');
    }
}
rediriger('panier');
