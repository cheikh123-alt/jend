<?php
/** 2e étape de connexion : code de l'application d'authentification (ou code de secours). */
$attente = $_SESSION['2fa'] ?? null;
if (!$attente || time() - (int) $attente['t'] > 600) {
    unset($_SESSION['2fa']);
    flash('Délai dépassé : recommencez la connexion.', 'erreur');
    rediriger('connexion');
}
$userId = (int) $attente['id'];
$titre = 'Vérification en deux étapes — Jënd';
$erreur = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $code = trim((string) ($_POST['code'] ?? ''));
    if (!csrf_valide($_POST['csrf'] ?? null)) {
        $erreur = 'Session expirée, merci de réessayer.';
    } elseif (limite_atteinte('2fa:user:' . $userId, 5, 900) || limite_atteinte('2fa:ip:' . ip_client(), 20, 900)) {
        alerter('blocage-2fa', 'Codes de double authentification bloqués', 'Trop d\'essais de codes 2FA depuis ' . ip_client() . ' (compte n° ' . $userId . ').');
        $erreur = 'Trop de tentatives. Réessayez dans 15 minutes.';
    } else {
        $u = requete('SELECT id, totp_secret, totp_dernier_pas FROM users WHERE id = ? AND actif = 1 AND totp_actif = 1', [$userId])->fetch();
        $secret = $u ? dechiffrer((string) $u['totp_secret']) : null;
        $valide = false;
        if ($u && $secret) {
            $pas = totp_verifier($secret, $code, (int) $u['totp_dernier_pas']);
            // Mise à jour conditionnelle : un même code ne peut servir qu'une fois (même avec deux requêtes simultanées)
            if ($pas !== null && requete('UPDATE users SET totp_dernier_pas = ? WHERE id = ? AND totp_dernier_pas < ?', [$pas, $userId, $pas])->rowCount() === 1) {
                $valide = true;
            } elseif ($pas === null && !preg_match('/^\d{6}$/', preg_replace('/\s+/', '', $code))) {
                $valide = code_secours_utiliser($userId, $code);         // un code de secours (usage unique)
            }
        }
        if ($valide) {
            $retour = (string) ($attente['retour'] ?? '');
            connecter($userId);
            limite_effacer('2fa:user:' . $userId);
            $role = (string) requete('SELECT role FROM users WHERE id = ?', [$userId])->fetchColumn();
            header('Location: ' . retour_sur($retour ?: url(espace_du_role($role))));
            exit;
        }
        limite_enregistrer('2fa:user:' . $userId);
        limite_enregistrer('2fa:ip:' . ip_client());
        $erreur = 'Code incorrect ou déjà utilisé.';
    }
}
require __DIR__ . '/../includes/header.php';
?>
<main class="page">
  <div class="wrap wrap-etroit">
    <h1 class="titre-page">Vérification en deux étapes</h1>
    <form method="post" class="formulaire" novalidate>
      <?= csrf_champ() ?>
      <?php if ($erreur): ?><p class="alerte" role="alert"><?= e($erreur) ?></p><?php endif; ?>
      <p class="doux">Entrez le code à 6 chiffres affiché par votre application d'authentification. Téléphone perdu ? Utilisez un de vos codes de secours.</p>
      <label class="champ"><span>Code</span><input type="text" name="code" inputmode="numeric" autocomplete="one-time-code" autofocus required maxlength="20"></label>
      <button class="btn btn-primaire" type="submit">Valider</button>
      <p class="doux"><a class="lien" href="<?= e(url('connexion')) ?>">Annuler</a></p>
    </form>
  </div>
</main>
<?php require __DIR__ . '/../includes/footer.php'; ?>
