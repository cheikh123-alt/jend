<?php
/**
 * Lien de paiement protégé : page d'atterrissage pour un client qui vient de TikTok, WhatsApp ou Instagram.
 * $parametre = slug du produit. Le vendeur partage ce lien ; le client paie sur Jënd et l'argent n'est versé qu'à la réception.
 */
$p = requete(
    "SELECT p.id, p.nom, p.slug, p.prix, p.prix_barre, p.stock, p.option_type, p.description, p.video_url, b.nom AS boutique, b.slug AS boutique_slug, b.verifiee, b.id AS boutique_id,
            COALESCE(c.icone, pc.icone) AS icone,
            (SELECT chemin FROM produit_images i WHERE i.produit_id = p.id ORDER BY i.position LIMIT 1) AS image
       FROM produits p
       JOIN boutiques b ON b.id = p.boutique_id AND b.statut = 'active'
       JOIN categories c ON c.id = p.categorie_id
       LEFT JOIN categories pc ON pc.id = c.parent_id
      WHERE p.slug = ? AND p.statut = 'publie' AND p.reserve_client_id IS NULL",
    [$parametre]
)->fetch();
if (!$p) {
    http_response_code(404);
    require __DIR__ . '/404.php';
    return;
}
$enStock = (int) $p['stock'] > 0;
$maxQte = max(1, min(10, (int) $p['stock']));
$variantes = variantes_produit((int) $p['id']);
$motTaille = option_libelle($p['option_type']);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_valide($_POST['csrf'] ?? null)) {
        flash('Session expirée, merci de réessayer.', 'erreur');
        rediriger('payer/' . $p['slug']);
    }
    if (!$enStock) {
        flash('Ce produit est épuisé pour le moment.', 'erreur');
        rediriger('payer/' . $p['slug']);
    }
    // Le lien sert à payer CE produit : le panier ne contient que lui, puis on passe directement à la commande
    $choisie = null;
    foreach ($variantes as $vr) {
        if ((int) $vr['id'] === (int) ($_POST['variante_id'] ?? 0) && (int) $vr['stock'] > 0) {
            $choisie = $vr;
        }
    }
    if ($variantes && !$choisie) {
        flash('Choisissez votre ' . mb_strtolower($motTaille) . '.', 'erreur');
        rediriger('payer/' . $p['slug']);
    }
    $_SESSION['panier'] = [panier_cle((int) $p['id'], $choisie ? (int) $choisie['id'] : null) => max(1, min($maxQte, (int) ($choisie['stock'] ?? 10), (int) ($_POST['quantite'] ?? 1)))];
    rediriger('commande');
}

$regions = boutique_regions((int) $p['boutique_id']);
$note = boutique_note((int) $p['boutique_id']);
$titre = 'Payer en sécurité : ' . $p['nom'] . ' — Jënd';
$description = 'Payez « ' . $p['nom'] . ' » en toute sécurité sur Jënd : le vendeur n\'est payé qu\'à la réception.';
require __DIR__ . '/../includes/header.php';
?>
<main class="page">
  <div class="wrap wrap-moyen">
    <div class="payer">
      <div class="payer-photo <?= classe_fond((int) $p['id']) ?>">
        <?php if ($p['image']): ?><img src="<?= e(url(image_miniature($p['image']))) ?>" alt="<?= e($p['nom']) ?>"><?php else: ?><i class="ph-fill <?= e($p['icone'] ?: 'ph-package') ?>" aria-hidden="true"></i><?php endif; ?>
      </div>
      <div class="payer-infos">
        <p class="payer-sceau"><i class="ph-fill ph-shield-check"></i> Paiement protégé par Jënd</p>
        <h1><?= e($p['nom']) ?></h1>
        <p class="doux">Vendu par <a class="lien" href="<?= e(url('boutique/' . $p['boutique_slug'])) ?>"><?= e($p['boutique']) ?></a>
          <?php if ($p['verifiee']): ?><span class="badge-verifie"><i class="ph-fill ph-seal-check"></i> Boutique vérifiée</span><?php endif; ?>
          <?php if ($note['nb'] > 0): ?> · <?= e(note_texte($note['note'])) ?>/5 (<?= $note['nb'] ?> avis)<?php endif; ?></p>
        <p class="payer-prix"><?= e(fcfa((int) $p['prix'])) ?></p>
        <p class="doux petit">+ frais de livraison selon votre zone · livre <?= $regions ? 'à : ' . e(implode(', ', $regions)) : 'dans tout le Sénégal' ?></p>

        <?php if ($enStock): ?>
        <form method="post" class="achat">
          <?= csrf_champ() ?>
          <?php if ($variantes): ?>
            <fieldset class="choix-taille"><legend><?= e($motTaille) ?></legend>
              <?php foreach ($variantes as $vr): $epuisee = (int) $vr['stock'] < 1; ?>
                <label class="<?= $epuisee ? 'epuisee' : '' ?>"><input type="radio" name="variante_id" value="<?= (int) $vr['id'] ?>" required <?= $epuisee ? 'disabled' : '' ?>><span><?= e($vr['libelle']) ?></span><?= $epuisee ? '<small>épuisée</small>' : '' ?></label>
              <?php endforeach; ?>
            </fieldset>
          <?php endif; ?>
          <label class="qte"><span class="sr">Quantité</span><input type="number" name="quantite" value="1" min="1" max="<?= $maxQte ?>"></label>
          <button class="btn btn-primaire" type="submit"><i class="ph ph-lock-key"></i> Payer en sécurité</button>
        </form>
        <?php else: ?>
          <p class="stock stock-vide"><i class="ph-fill ph-x-circle"></i> Épuisé pour le moment</p>
        <?php endif; ?>
        <p class="petit"><a class="lien" href="<?= e(url('produit/' . $p['slug'])) ?>">Voir la fiche complète du produit</a><?php if (!empty($p['video_url']) && video_url_valide((string) $p['video_url'])): ?> · <a class="lien" href="<?= e($p['video_url']) ?>" target="_blank" rel="noopener noreferrer nofollow"><i class="ph-fill ph-play-circle"></i> Voir la vidéo</a><?php endif; ?></p>
      </div>
    </div>

    <section class="payer-etapes" aria-label="Comment ça marche">
      <h2 class="sous-titre">Pourquoi payer ici plutôt que par un simple transfert ?</h2>
      <ol>
        <li><i class="ph-fill ph-device-mobile"></i><span><b>1. Vous payez sur Jënd</b> par Wave, Orange Money ou carte.</span></li>
        <li><i class="ph-fill ph-vault"></i><span><b>2. Jënd garde l'argent</b> : le vendeur ne le reçoit pas encore.</span></li>
        <li><i class="ph-fill ph-package"></i><span><b>3. Vous recevez votre colis</b> et vous confirmez la réception.</span></li>
        <li><i class="ph-fill ph-hand-coins"></i><span><b>4. Le vendeur est payé.</b> Un problème ? Vous le signalez et Jënd intervient.</span></li>
      </ol>
    </section>
  </div>
</main>
<?php require __DIR__ . '/../includes/footer.php'; ?>
