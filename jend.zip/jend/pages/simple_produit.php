<?php
/** Mode simple : mettre un produit en vente — 1. photo, 2. ce que c'est (images), 3. prix, 4. combien, 5. voix (facultatif). */
[$u, $b] = exiger_vendeur_simple();
$erreur = null;
$v = ['categorie_id' => '', 'prix' => '', 'stock' => '1', 'nom' => ''];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    foreach ($v as $k => $_) {
        $v[$k] = trim((string) ($_POST[$k] ?? ''));
    }
    $voix = ($_FILES['voix']['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_NO_FILE ? $_FILES['voix'] : null;
    if (!csrf_valide($_POST['csrf'] ?? null)) {
        $erreur = 'La page a expiré : recommencez, s\'il vous plaît.';
    } else {
        try {
            $id = simple_produit_creer($b, (int) $v['categorie_id'], simple_nombre($v['prix']), simple_nombre($v['stock']), $v['nom'], fichiers_envoyes('photos'), $voix);
            alertes_produit_verifier($id);
            flash('✅ Produit mis en vente !');
            rediriger('simple/produits');
        } catch (RuntimeException $e) {
            $erreur = $e->getMessage();
        }
    }
}
$categories = simple_categories();
$titre = 'Mettre un produit — Jënd';
$scripts_extra = ['js/voix.js', 'js/simple.js'];
require __DIR__ . '/../includes/header.php';
?>
<main class="page simple">
  <div class="wrap">
    <?php simple_entete('Mettre un produit', 'produit'); ?>
    <form method="post" enctype="multipart/form-data" class="simple-form" novalidate>
      <?= csrf_champ() ?>
      <?php if ($erreur): ?><p class="simple-erreur" role="alert"><i class="ph-fill ph-warning-circle"></i> <span><?= e($erreur) ?></span></p><?php endif; ?>

      <section class="simple-etape">
        <h2><span class="simple-num">1</span> <i class="ph-fill ph-camera"></i> Photo</h2>
        <div class="simple-photo-choix">
          <label class="simple-gros-btn simple-gros-btn-terre"><i class="ph-fill ph-camera"></i> <span>Prendre une photo</span>
            <input type="file" name="photos[]" accept="image/jpeg,image/png" capture="environment" class="simple-photo-champ" hidden></label>
          <label class="simple-gros-btn simple-gros-btn-contour"><i class="ph-fill ph-images"></i> <span>Choisir dans le téléphone</span>
            <input type="file" name="photos[]" accept="image/jpeg,image/png" multiple class="simple-photo-champ" hidden></label>
        </div>
        <div class="simple-apercus" id="simple-apercus" aria-live="polite"></div>
      </section>

      <section class="simple-etape">
        <h2><span class="simple-num">2</span> <i class="ph-fill ph-tag"></i> C'est quoi ?</h2>
        <div class="simple-categories">
          <?php foreach ($categories as $c): ?>
            <label class="simple-categorie"><input type="radio" name="categorie_id" value="<?= (int) $c['id'] ?>" <?= (string) $c['id'] === $v['categorie_id'] ? 'checked' : '' ?> required>
              <span><i class="ph-fill <?= e($c['icone'] ?: 'ph-tag') ?>"></i><b><?= e($c['nom']) ?></b></span></label>
          <?php endforeach; ?>
        </div>
      </section>

      <section class="simple-etape">
        <h2><span class="simple-num">3</span> <i class="ph-fill ph-money"></i> Prix</h2>
        <label class="simple-prix"><input type="text" name="prix" value="<?= e($v['prix']) ?>" inputmode="numeric" autocomplete="off" placeholder="0" aria-label="Prix en FCFA" required><span>FCFA</span></label>
      </section>

      <section class="simple-etape">
        <h2><span class="simple-num">4</span> <i class="ph-fill ph-stack"></i> Combien ?</h2>
        <div class="simple-compteur">
          <button type="button" class="simple-moins" aria-label="Un de moins"><i class="ph ph-minus"></i></button>
          <input type="text" name="stock" value="<?= e($v['stock']) ?>" inputmode="numeric" autocomplete="off" aria-label="Quantité disponible" required>
          <button type="button" class="simple-plus" aria-label="Un de plus"><i class="ph ph-plus"></i></button>
        </div>
      </section>

      <section class="simple-etape voix-bloc" id="voix-bloc">
        <h2><span class="simple-num">5</span> <i class="ph-fill ph-microphone"></i> Parlez du produit <small>(si vous voulez)</small></h2>
        <div class="voix-enregistreur" hidden>
          <button type="button" class="simple-gros-btn simple-gros-btn-vert" id="voix-demarrer"><i class="ph-fill ph-microphone"></i> <span>Parler</span></button>
          <button type="button" class="simple-gros-btn simple-gros-btn-terre" id="voix-arreter" hidden><i class="ph-fill ph-stop"></i> <span>Arrêter (<span id="voix-chrono">0</span> s)</span></button>
          <audio id="voix-apercu" controls hidden></audio>
        </div>
        <input type="file" name="voix" id="voix-fichier" accept="audio/*,.ogg,.opus,.m4a,.mp3,.webm">
        <small class="doux" id="voix-aide">En wolof, en français… 1 minute maximum. Ou choisissez un message vocal WhatsApp.</small>
      </section>

      <details class="simple-etape simple-facultatif">
        <summary><i class="ph ph-pencil-simple"></i> Nom du produit (facultatif — quelqu'un peut l'écrire pour vous)</summary>
        <label class="champ"><input type="text" name="nom" value="<?= e($v['nom']) ?>" maxlength="190" placeholder="ex. Boubou bazin brodé"></label>
      </details>

      <button class="simple-valider" type="submit"><i class="ph-fill ph-check-circle"></i> Mettre en vente</button>
    </form>
  </div>
</main>
<?php require __DIR__ . '/../includes/footer.php'; ?>
