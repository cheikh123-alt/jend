<?php
/** Variables : $mode ('tous' | 'categorie' | 'recherche'), $parametre (slug de catégorie). */
$q = trim((string) ($_GET['q'] ?? ''));
$q = mb_substr($q, 0, 80);

$categorie = null;
if ($mode === 'categorie') {
    $categorie = requete('SELECT id, parent_id, nom, slug FROM categories WHERE slug = ?', [$parametre])->fetch();
    if (!$categorie) {
        http_response_code(404);
        require __DIR__ . '/404.php';
        return;
    }
}

$triValides = ['recent' => 'Nouveautés', 'populaire' => 'Les plus populaires', 'prix_asc' => 'Prix croissant', 'prix_desc' => 'Prix décroissant'];
$tri = isset($triValides[$_GET['tri'] ?? '']) ? $_GET['tri'] : 'recent';
$prixMin = max(0, (int) ($_GET['prix_min'] ?? 0));
$prixMax = max(0, (int) ($_GET['prix_max'] ?? 0));

$res = catalogue_chercher([
    'categorie_id' => $categorie['id'] ?? null,
    'q'            => $mode === 'recherche' ? $q : '',
    'prix_min'     => $prixMin,
    'prix_max'     => $prixMax,
    'tri'          => $tri,
], (int) ($_GET['page'] ?? 1));

if ($mode === 'categorie') {
    $titrePage = $categorie['nom'];
    // sous-catégories à proposer (celles de la catégorie, ou ses « sœurs » si on est déjà dans une sous-catégorie)
    $racine = $categorie['parent_id'] ?: $categorie['id'];
    $sousCats = requete('SELECT nom, slug FROM categories WHERE parent_id = ? ORDER BY position', [$racine])->fetchAll();
} elseif ($mode === 'recherche') {
    $titrePage = $q !== '' ? "Résultats pour « $q »" : 'Recherche';
    $sousCats = [];
} else {
    $titrePage = 'Tous les produits';
    $sousCats = [];
}

$titre = $titrePage . ' — Jënd';
$description = "Découvrez $titrePage sur Jënd, la marketplace sénégalaise.";
$pageCourante = $res['page'];

require __DIR__ . '/../includes/header.php';
?>
<main class="page">
  <div class="wrap">
    <nav class="fil" aria-label="Fil d'Ariane">
      <a href="<?= e(url()) ?>">Accueil</a> /
      <?php if ($mode === 'categorie' && $categorie['parent_id']):
          $parent = requete('SELECT nom, slug FROM categories WHERE id = ?', [$categorie['parent_id']])->fetch(); ?>
        <a href="<?= e(url('categorie/' . $parent['slug'])) ?>"><?= e($parent['nom']) ?></a> /
      <?php endif; ?>
      <span><?= e($titrePage) ?></span>
    </nav>

    <h1 class="titre-page"><?= e($titrePage) ?></h1>
    <p class="compte"><?= $res['total'] ?> produit<?= $res['total'] > 1 ? 's' : '' ?></p>

    <div class="liste">
      <?php $nbFiltres = ($prixMin ? 1 : 0) + ($prixMax ? 1 : 0) + ($tri !== 'recent' ? 1 : 0); ?>
      <details class="filtres-repli" open<?= $nbFiltres ? ' data-actifs="' . $nbFiltres . '"' : '' ?>>
      <summary><i class="ph ph-sliders-horizontal"></i> Filtrer et trier<?= $nbFiltres ? ' <b class="pastille-onglet">' . $nbFiltres . '</b>' : '' ?></summary>
      <aside class="filtres">
        <form method="get" action="<?= e(parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH)) ?>">
          <?php if ($mode === 'recherche'): ?><input type="hidden" name="q" value="<?= e($q) ?>"><?php endif; ?>

          <?php if ($sousCats): ?>
            <h2>Sous-catégories</h2>
            <ul class="liste-simple">
              <?php foreach ($sousCats as $s): ?>
                <li><a href="<?= e(url('categorie/' . $s['slug'])) ?>" <?= $categorie && $categorie['slug'] === $s['slug'] ? 'class="actif"' : '' ?>><?= e($s['nom']) ?></a></li>
              <?php endforeach; ?>
            </ul>
          <?php endif; ?>

          <h2>Prix (FCFA)</h2>
          <div class="prix-champs">
            <input type="number" name="prix_min" min="0" step="500" placeholder="Min" value="<?= $prixMin ?: '' ?>" aria-label="Prix minimum">
            <span>—</span>
            <input type="number" name="prix_max" min="0" step="500" placeholder="Max" value="<?= $prixMax ?: '' ?>" aria-label="Prix maximum">
          </div>

          <h2>Trier par</h2>
          <select name="tri" aria-label="Trier par">
            <?php foreach ($triValides as $cle => $libelle): ?>
              <option value="<?= e($cle) ?>" <?= $tri === $cle ? 'selected' : '' ?>><?= e($libelle) ?></option>
            <?php endforeach; ?>
          </select>

          <button class="btn btn-primaire" type="submit">Appliquer</button>
          <?php if ($prixMin || $prixMax || $tri !== 'recent'): ?>
            <a class="reinit" href="<?= e(url_avec(['prix_min' => null, 'prix_max' => null, 'tri' => null, 'page' => null])) ?>">Réinitialiser</a>
          <?php endif; ?>
        </form>
      </aside>
      </details>

      <div class="resultats">
        <?php if (!$res['produits']): ?>
          <div class="vide">
            <i class="ph ph-magnifying-glass"></i>
            <p><b>Aucun produit trouvé.</b><br>Essayez d'autres mots ou élargissez vos filtres.</p>
          </div>
        <?php else: ?>
          <div class="produits produits-3">
            <?php foreach ($res['produits'] as $p) { include __DIR__ . '/../includes/carte.php'; } ?>
          </div>

          <?php if ($res['pages'] > 1): ?>
            <nav class="pagination" aria-label="Pagination">
              <?php if ($pageCourante > 1): ?><a href="<?= e(url_avec(['page' => $pageCourante - 1])) ?>" aria-label="Page précédente"><i class="ph ph-caret-left"></i></a><?php endif; ?>
              <?php for ($i = max(1, $pageCourante - 2); $i <= min($res['pages'], $pageCourante + 2); $i++): ?>
                <a href="<?= e(url_avec(['page' => $i])) ?>" <?= $i === $pageCourante ? 'class="actif" aria-current="page"' : '' ?>><?= $i ?></a>
              <?php endfor; ?>
              <?php if ($pageCourante < $res['pages']): ?><a href="<?= e(url_avec(['page' => $pageCourante + 1])) ?>" aria-label="Page suivante"><i class="ph ph-caret-right"></i></a><?php endif; ?>
            </nav>
          <?php endif; ?>
        <?php endif; ?>
      </div>
    </div>
  </div>
</main>
<?php require __DIR__ . '/../includes/footer.php'; ?>
