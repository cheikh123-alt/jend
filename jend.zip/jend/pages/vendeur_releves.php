<?php
/**
 * Relevés mensuels du vendeur : ventes confirmées, commission, frais de livraison gagnés, retenues, versements.
 * ?mois=AAAA-MM ; &format=csv pour l'ouvrir dans Excel ; bouton « Imprimer / PDF » pour le garder.
 */
[$u, $b] = exiger_vendeur();
$disponibles = releve_mois_disponibles((int) $b['id']);
$mois = (string) ($_GET['mois'] ?? $disponibles[0]);
if (!preg_match('/^\d{4}-(0[1-9]|1[0-2])$/', $mois) || $mois > date('Y-m')) {
    $mois = date('Y-m');
}
$r = releve_mois((int) $b['id'], $mois);
$moisFr = preg_replace('/^\d+(er)? /', '', date_longue_fr($mois . '-01'));          // « octobre 2026 »

if (($_GET['format'] ?? '') === 'csv') {
    header('Content-Type: text/csv; charset=UTF-8');
    header('Content-Disposition: attachment; filename="releve-jend-' . $b['slug'] . '-' . $mois . '.csv"');
    $out = fopen('php://output', 'w');
    fwrite($out, "\xEF\xBB\xBF");                      // Excel : accents corrects
    // pas de formule injectée par un nom de produit (« =… ») ; les vrais nombres, même négatifs, restent des nombres pour Excel
    $ligne = fn (array $l) => fputcsv($out, array_map(fn ($v) => (preg_match('/^[=+\-@\t\r]/', (string) $v) && !is_numeric($v)) ? "'" . $v : $v, $l), ';');
    $ligne(['Relevé Jënd', $b['nom'], $moisFr]);
    $ligne([]);
    $ligne(['Date', 'Type', 'Référence', 'Détail', 'Ventes (FCFA)', 'Commission (FCFA)', 'Livraison gagnée (FCFA)', 'Montant pour vous (FCFA)']);
    foreach ($r['ventes'] as $v) {
        $ligne([date('d/m/Y', strtotime($v['date'])), 'Vente livrée', $v['reference'], $v['articles'], $v['sous_total'], $v['commission'], $v['frais'], $v['net']]);
    }
    foreach ($r['retenues'] as $v) {
        $ligne([date('d/m/Y', strtotime($v['date'])), 'Remboursement client retenu', $v['reference'], '', '', '', '', -(int) $v['montant']]);
    }
    foreach ($r['versements'] as $v) {
        $ligne([date('d/m/Y', strtotime($v['date'])), $v['statut'] === 'paye' ? 'Versement envoyé' : 'Versement en préparation', (string) $v['reference_transfert'], METHODES_VERSEMENT[$v['methode']] ?? $v['methode'], '', '', '', -(int) $v['montant']]);
    }
    foreach ($r['reglements'] as $v) {
        $ligne([date('d/m/Y', strtotime($v['date'])), 'Commission réglée à Jënd', (string) $v['reference'], METHODES_REGLEMENT[$v['methode']] ?? $v['methode'], '', '', '', (int) $v['montant']]);
    }
    $ligne([]);
    $ligne(['Totaux', '', '', '', $r['total_ventes'], $r['total_commission'], $r['total_frais'], $r['total_net'] - $r['total_retenues']]);
    $ligne(['Versé ce mois', '', '', '', '', '', '', $r['total_verse']]);
    fclose($out);
    exit;
}
$solde = vendeur_gains((int) $b['id'])['solde'];
$titre = 'Relevé ' . $moisFr . ' — ' . $b['nom'];
$robots = 'noindex';
require __DIR__ . '/../includes/header.php';
?>
<main class="page">
  <div class="wrap">
    <nav class="fil non-imprime" aria-label="Fil d'Ariane"><a href="<?= e(url('vendeur')) ?>">Espace vendeur</a> / <a href="<?= e(url('vendeur/gains')) ?>">Gains</a> / <span>Relevés</span></nav>
    <div class="non-imprime"><h1 class="titre-page">Mes relevés</h1></div>

    <div class="releve-outils non-imprime">
      <form method="get" class="ligne-form"><label for="mois">Mois</label>
        <select id="mois" name="mois"><?php foreach ($disponibles as $m): ?><option value="<?= e($m) ?>" <?= $m === $mois ? 'selected' : '' ?>><?= e(ucfirst(preg_replace('/^\d+(er)? /', '', date_longue_fr($m . '-01')))) ?></option><?php endforeach; ?></select>
        <button class="btn btn-contour" type="submit">Afficher</button></form>
      <div class="zone-actions">
        <button class="btn btn-contour" type="button" data-imprimer><i class="ph ph-printer"></i> Imprimer / PDF</button>
        <a class="btn btn-contour" href="<?= e(url('vendeur/releves?mois=' . $mois . '&format=csv')) ?>"><i class="ph ph-microsoft-excel-logo"></i> Excel (CSV)</a>
      </div>
    </div>

    <article class="releve">
      <header class="releve-entete">
        <div><p class="lit-surtitre">Relevé de compte</p><h2><?= e($b['nom']) ?></h2><p class="doux"><?= e(ucfirst($moisFr)) ?> · édité le <?= e(date('d/m/Y à H:i')) ?></p></div>
        <p class="logo">Jënd<span>.</span></p>
      </header>

      <dl class="releve-totaux">
        <div><dt>Ventes livrées</dt><dd><?= e(fcfa($r['total_ventes'])) ?></dd></div>
        <div><dt>Commission Jënd</dt><dd>− <?= e(fcfa($r['total_commission'])) ?></dd></div>
        <?php if ($r['total_frais']): ?><div><dt>Livraisons faites par vous</dt><dd>+ <?= e(fcfa($r['total_frais'])) ?></dd></div><?php endif; ?>
        <?php if ($r['total_retenues']): ?><div><dt>Remboursements retenus</dt><dd>− <?= e(fcfa($r['total_retenues'])) ?></dd></div><?php endif; ?>
        <div class="releve-fort"><dt>Gagné ce mois</dt><dd><?= e(fcfa($r['total_net'] - $r['total_retenues'])) ?></dd></div>
        <div class="releve-fort"><dt>Versé ce mois</dt><dd><?= e(fcfa($r['total_verse'])) ?></dd></div>
      </dl>
      <?php if ($r['en_cours']): ?><p class="doux petit">+ <?= e(fcfa($r['en_cours'])) ?> en cours de versement.</p><?php endif; ?>

      <h3>Ventes livrées</h3>
      <?php if (!$r['ventes']): ?><p class="doux">Aucune vente livrée ce mois-ci.</p><?php else: ?>
      <div class="table-defile"><table class="table releve-table">
        <thead><tr><th>Date</th><th>Commande</th><th>Articles</th><th>Ventes</th><th>Commission</th><th>Pour vous</th></tr></thead>
        <tbody><?php foreach ($r['ventes'] as $v): ?>
          <tr><td><?= e(date('d/m', strtotime($v['date']))) ?></td><td><?= e($v['reference']) ?></td><td class="releve-articles"><?= e((string) $v['articles']) ?></td>
            <td><?= e(fcfa((int) $v['sous_total'])) ?></td><td>− <?= e(fcfa((int) $v['commission'])) ?></td><td><b><?= e(fcfa((int) $v['net'])) ?></b><?= $v['frais'] ? '<br><small class="doux">dont livraison ' . e(fcfa((int) $v['frais'])) . '</small>' : '' ?></td></tr>
        <?php endforeach; ?></tbody>
      </table></div>
      <?php endif; ?>

      <?php if ($r['retenues']): ?>
      <h3>Remboursements retenus</h3>
      <div class="table-defile"><table class="table releve-table"><tbody><?php foreach ($r['retenues'] as $v): ?>
        <tr><td><?= e(date('d/m', strtotime($v['date']))) ?></td><td>Signalement <?= e($v['reference']) ?></td><td>− <?= e(fcfa((int) $v['montant'])) ?></td></tr>
      <?php endforeach; ?></tbody></table></div>
      <?php endif; ?>

      <h3>Versements</h3>
      <?php if (!$r['versements']): ?><p class="doux">Aucun versement ce mois-ci.</p><?php else: ?>
      <div class="table-defile"><table class="table releve-table">
        <thead><tr><th>Date</th><th>Montant</th><th>Sur</th><th>Référence du transfert</th><th>État</th></tr></thead>
        <tbody><?php foreach ($r['versements'] as $v): ?>
          <tr><td><?= e(date('d/m', strtotime($v['date']))) ?></td><td><b><?= e(fcfa((int) $v['montant'])) ?></b></td><td><?= e(METHODES_VERSEMENT[$v['methode']] ?? $v['methode']) ?></td>
            <td><?= e((string) ($v['reference_transfert'] ?? '—')) ?></td><td><?= $v['statut'] === 'paye' ? 'Envoyé' : 'En préparation' ?><?= $v['automatique'] ? ' (automatique)' : '' ?></td></tr>
        <?php endforeach; ?></tbody>
      </table></div>
      <?php endif; ?>

      <?php if ($r['reglements']): ?>
      <h3>Commissions réglées à Jënd</h3>
      <div class="table-defile"><table class="table releve-table">
        <thead><tr><th>Date</th><th>Montant</th><th>Par</th><th>Référence</th></tr></thead>
        <tbody><?php foreach ($r['reglements'] as $v): ?>
          <tr><td><?= e(date('d/m', strtotime($v['date']))) ?></td><td><b><?= e(fcfa((int) $v['montant'])) ?></b></td><td><?= e(METHODES_REGLEMENT[$v['methode']] ?? $v['methode']) ?></td><td><?= e((string) ($v['reference'] ?? '—')) ?></td></tr>
        <?php endforeach; ?></tbody>
      </table></div>
      <?php endif; ?>

      <p class="releve-pied">Solde disponible aujourd'hui : <b><?= e(fcfa($solde)) ?></b>. Les ventes comptent après la livraison confirmée par le client ; elles deviennent retirables <?= delai_retrait_jours() ?> jour(s) après. Une question sur ce relevé ? Écrivez-nous depuis la page d'aide en citant le mois.</p>
    </article>
  </div>
</main>
<?php require __DIR__ . '/../includes/footer.php'; ?>
