<?php
$u = exiger_connexion();
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    rediriger('compte');
}
$ref = strtoupper((string) ($_POST['reference'] ?? ''));
if (!csrf_valide($_POST['csrf'] ?? null)) {
    flash('Session expirée, merci de réessayer.', 'erreur');
    rediriger('commande/' . $ref);
}
try {
    commande_annuler($ref, (int) $u['id']);
    flash('Commande annulée. Les articles ont été remis en stock.');
} catch (RuntimeException $e) {
    flash($e->getMessage(), 'erreur');
}
rediriger('commande/' . $ref);
