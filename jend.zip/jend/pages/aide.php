<?php
/** « Aide » dans le compte : les conversations avec l'équipe. */
$u = exiger_connexion();
$messages = requete(
    'SELECT m.*, (SELECT COUNT(*) FROM messages_support_reponses r WHERE r.message_id = m.id) AS nb_reponses,
            (SELECT r.auteur FROM messages_support_reponses r WHERE r.message_id = m.id ORDER BY r.id DESC LIMIT 1) AS dernier
       FROM messages_support m WHERE m.user_id = ? ORDER BY (m.statut = \'resolu\'), m.id DESC LIMIT 30',
    [$u['id']]
)->fetchAll();
$titre = 'Aide — Jënd';
require __DIR__ . '/../includes/header.php';
?>
<main class="page">
  <div class="wrap">
    <nav class="fil" aria-label="Fil d'Ariane"><a href="<?= e(url()) ?>">Accueil</a> / <a href="<?= e(url('compte')) ?>">Mon compte</a> / <span>Aide</span></nav>
    <h1 class="titre-page">Mon compte</h1>
    <?php compte_onglets('aide'); ?>
    <p><a class="btn btn-primaire" href="<?= e(url('contact')) ?>"><i class="ph ph-paper-plane-tilt"></i> Nouvelle demande</a></p>
    <?php if (!$messages): ?>
      <div class="tb-vide"><i class="ph ph-lifebuoy"></i><p><b>Aucune conversation pour le moment.</b><br>Une question sur le site, votre compte, un paiement ou votre boutique ? Écrivez-nous.</p></div>
    <?php else: ?>
      <ul class="tb-liste">
        <?php foreach ($messages as $m): ?>
          <li><a href="<?= e(url('aide/' . $m['reference'])) ?>">
            <span><b><?= e(SUJETS_SUPPORT[$m['sujet']]) ?></b> <small class="doux"><?= e($m['reference']) ?> · <?= e(date('d/m/Y', strtotime($m['created_at']))) ?> · <?= (int) $m['nb_reponses'] + 1 ?> message(s)</small><br>
              <small class="doux"><?= e(mb_strimwidth((string) $m['message'], 0, 90, '…')) ?></small></span>
            <span class="badge badge-offre-<?= $m['statut'] === 'resolu' ? 'close' : ($m['statut'] === 'en_cours' ? 'acceptee' : 'en_attente') ?>"><?= e(STATUTS_SUPPORT[$m['statut']]) ?></span></a></li>
        <?php endforeach; ?>
      </ul>
    <?php endif; ?>
  </div>
</main>
<?php require __DIR__ . '/../includes/footer.php'; ?>
