<?php
[$u, $l] = exiger_livreur(true);
$provisoire = (int) requete('SELECT mdp_provisoire FROM users WHERE id = ?', [$u['id']])->fetchColumn() === 1;
$erreurs = [];
if (post_verifie('livreur/mot-de-passe')) {
    $cle = 'mdp-livreur:' . $u['id'];
    $actuel = (string) ($_POST['actuel'] ?? '');
    $nouveau = (string) ($_POST['nouveau'] ?? '');
    $hash = (string) requete('SELECT mot_de_passe FROM users WHERE id = ?', [$u['id']])->fetchColumn();
    if (limite_atteinte($cle, 5, 900)) {
        $erreurs[] = 'Trop d\'essais. Réessayez dans 15 minutes.';
    } elseif (!password_verify($actuel, $hash)) {
        limite_enregistrer($cle);
        $erreurs[] = 'Le mot de passe actuel est incorrect.';
    }
    if ($nouveau === $actuel && $nouveau !== '') {
        $erreurs[] = 'Le nouveau mot de passe doit être différent de l\'actuel.';
    }
    if ($msg = mot_de_passe_faible($nouveau, (string) $u['email'], (string) $u['nom'])) {
        $erreurs[] = $msg;
    }
    if ($nouveau !== (string) ($_POST['nouveau2'] ?? '')) {
        $erreurs[] = 'Les deux nouveaux mots de passe ne correspondent pas.';
    }
    if (!$erreurs) {
        requete('UPDATE users SET mot_de_passe = ?, mdp_provisoire = 0 WHERE id = ?', [password_hash($nouveau, PASSWORD_DEFAULT), $u['id']]);
        session_regenerate_id(true);
        invalider_sessions((int) $u['id']);          // les autres appareils sont déconnectés
        flash('Mot de passe modifié. Vos autres appareils ont été déconnectés.');
        rediriger($provisoire ? 'livreur' : 'livreur/profil');
    }
}
livreur_entete('Mot de passe — Jënd Livreur', '', $provisoire ? null : url('livreur/profil'));
?>
<h1 class="app-titre"><?= $provisoire ? 'Choisissez votre mot de passe' : 'Mot de passe' ?></h1>
<?php if ($provisoire): ?><p class="doux">Le mot de passe que l'administrateur vous a donné est provisoire. Choisissez-en un que vous seul connaissez.</p><?php endif; ?>
<form method="post" class="carte-info formulaire-app" novalidate>
  <?= csrf_champ() ?>
  <?php foreach ($erreurs as $er): ?><p class="app-alerte" role="alert"><?= e($er) ?></p><?php endforeach; ?>
  <label class="champ-app"><span>Mot de passe actuel</span><input type="password" name="actuel" autocomplete="current-password" required></label>
  <label class="champ-app"><span>Nouveau mot de passe (8 caractères minimum)</span><input type="password" name="nouveau" autocomplete="new-password" required></label>
  <label class="champ-app"><span>Confirmer le nouveau mot de passe</span><input type="password" name="nouveau2" autocomplete="new-password" required></label>
  <button class="bouton-principal" type="submit"><i class="ph-fill ph-key"></i> Changer mon mot de passe</button>
</form>
<?php livreur_pied(false); ?>
