<?php
/**
 * Notifications sur le téléphone (appelé par assets/js/notifications.js, réponse JSON) :
 *  action=abonner     : enregistre ce téléphone pour le compte connecté ;
 *  action=desabonner  : le retire ;
 *  action=tester      : envoie une notification d'essai à tous les appareils du compte.
 */
header('Content-Type: application/json; charset=UTF-8');
header('Cache-Control: no-store');
$repondre = function (int $code, array $data): void {
    http_response_code($code);
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
};
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    $repondre(405, ['ok' => false, 'message' => 'Méthode non autorisée']);
}
if (!csrf_valide($_POST['csrf'] ?? null)) {
    $repondre(403, ['ok' => false, 'message' => 'Page expirée : rechargez-la.']);
}
$u = utilisateur();
if (!$u) {
    $repondre(401, ['ok' => false, 'message' => 'Connectez-vous.']);
}
if (!push_disponible()) {
    $repondre(503, ['ok' => false, 'message' => 'Notifications indisponibles sur ce serveur.']);
}
$action = (string) ($_POST['action'] ?? '');
$endpoint = trim((string) ($_POST['endpoint'] ?? ''));
try {
    if ($action === 'abonner') {
        if (limite_atteinte('push-abonner:' . $u['id'], 20, 3600)) {
            $repondre(429, ['ok' => false, 'message' => 'Trop d\'essais, réessayez plus tard.']);
        }
        limite_enregistrer('push-abonner:' . $u['id']);
        push_abonner((int) $u['id'], $endpoint, (string) ($_POST['p256dh'] ?? ''), (string) ($_POST['auth'] ?? ''), (string) ($_SERVER['HTTP_USER_AGENT'] ?? ''));
        $repondre(200, ['ok' => true, 'appareils' => push_nb_appareils((int) $u['id'])]);
    }
    if ($action === 'desabonner') {
        push_desabonner((int) $u['id'], $endpoint);
        $repondre(200, ['ok' => true]);
    }
    if ($action === 'tester') {
        if (limite_atteinte('push-tester:' . $u['id'], 5, 600)) {
            $repondre(429, ['ok' => false, 'message' => 'Déjà testé plusieurs fois : réessayez dans quelques minutes.']);
        }
        limite_enregistrer('push-tester:' . $u['id']);
        $b = requete('SELECT mode_simple FROM boutiques WHERE user_id = ?', [$u['id']])->fetch();
        $n = push_envoyer((int) $u['id'], ['titre' => '🔔 Ça marche !', 'texte' => 'Vous serez prévenu ici à chaque nouvelle commande.',
            'url' => $b ? ((int) $b['mode_simple'] === 1 ? 'simple/commandes' : 'vendeur/commandes') : '', 'tag' => 'essai']);
        $inscrits = push_nb_appareils((int) $u['id']);
        $message = $n > 0 && push_probleme() !== null
            ? 'Notification envoyée à ' . $n . ' appareil(s), mais pas à tous : ' . push_probleme()
            : ($n > 0
            ? 'Notification envoyée' . ($n > 1 ? ' à ' . $n . ' appareils' : '') . '. Rien sur le téléphone après 30 secondes ? Vérifiez que les notifications de Chrome sont autorisées dans les réglages du téléphone (et le mode « Ne pas déranger »).'
            : (push_probleme() ?? ($inscrits === 0 ? 'Ce téléphone n\'est pas enregistré : touchez « Activer ».' : 'Aucun appareil n\'a pu être joint : touchez « Activer » à nouveau.')));
        $repondre(200, ['ok' => $n > 0, 'envoyes' => $n, 'message' => $message]);
    }
} catch (RuntimeException $e) {
    $repondre(422, ['ok' => false, 'message' => $e->getMessage()]);
}
$repondre(400, ['ok' => false, 'message' => 'Action inconnue.']);
