<?php
/** Mode simple : mes produits — grande photo, prix, quantité avec « − » / « + », retirer ou remettre en vente. */
[$u, $b] = exiger_vendeur_simple();
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Appelé par simple.js (« − », « + », retirer, remettre) : réponse JSON, la page ne se recharge pas. Sans JavaScript : la page se recharge.
    $ajax = ($_SERVER['HTTP_X_REQUESTED_WITH'] ?? '') === 'fetch';
    $pid = (int) ($_POST['id'] ?? 0);
    $message = null;
    $erreur = null;
    if (!csrf_valide($_POST['csrf'] ?? null)) {
        $erreur = 'La page a expiré : recommencez, s\'il vous plaît.';
    } else {
        try {
            $message = simple_produit_action((int) $b['id'], $pid, (string) ($_POST['action'] ?? ''));
        } catch (RuntimeException $e) {
            $erreur = $e->getMessage();
        }
    }
    if ($ajax) {
        $etat = requete('SELECT stock, statut FROM produits WHERE id = ? AND boutique_id = ?', [$pid, $b['id']])->fetch();
        header('Content-Type: application/json; charset=UTF-8');
        http_response_code($erreur ? 422 : 200);
        echo json_encode(['ok' => !$erreur, 'message' => $erreur ?? $message, 'stock' => $etat ? (int) $etat['stock'] : null, 'en_vente' => $etat ? $etat['statut'] === 'publie' : null]);
        exit;
    }
    flash($erreur ?? $message, $erreur ? 'erreur' : 'ok');
    rediriger('simple/produits#produit-' . $pid);
}
$produits = requete(
    "SELECT p.id, p.nom, p.prix, p.stock, p.statut, p.slug,
            (SELECT chemin FROM produit_images i WHERE i.produit_id = p.id ORDER BY position, id LIMIT 1) AS photo,
            (SELECT COUNT(*) FROM produit_variantes v WHERE v.produit_id = p.id) AS nb_tailles
       FROM produits p WHERE p.boutique_id = ? AND p.reserve_client_id IS NULL
      ORDER BY p.statut = 'archive', p.created_at DESC, p.id DESC LIMIT 200",
    [$b['id']]
)->fetchAll();
$titre = 'Mes produits — Jënd';
$scripts_extra = ['js/simple.js'];
require __DIR__ . '/../includes/header.php';
?>
<main class="page simple">
  <div class="wrap">
    <?php simple_entete('Mes produits', 'produits'); ?>
    <a class="simple-valider" href="<?= e(url('simple/produit')) ?>"><i class="ph-fill ph-camera-plus"></i> Mettre un produit</a>
    <?php if (!$produits): ?>
      <p class="simple-info"><i class="ph-fill ph-package"></i> <span>Pas encore de produit. Touchez « Mettre un produit ».</span></p>
    <?php endif; ?>
    <div class="simple-produits">
      <?php foreach ($produits as $p):
          $enVente = $p['statut'] === 'publie'; ?>
        <article class="simple-produit<?= $enVente ? '' : ' simple-produit-retire' ?>" id="produit-<?= (int) $p['id'] ?>" data-produit="<?= (int) $p['id'] ?>">
          <div class="simple-produit-photo"><?php if ($p['photo']): ?><img src="<?= e(url(image_miniature($p['photo']))) ?>" alt="" loading="lazy"><?php else: ?><i class="ph ph-image"></i><?php endif; ?>
            <span class="simple-etat"><?= $enVente ? '<i class="ph-fill ph-check-circle"></i> En vente' : '<i class="ph-fill ph-pause-circle"></i> Pas en vente' ?></span></div>
          <p class="simple-produit-prix"><?= e(fcfa((int) $p['prix'])) ?></p>
          <?php if ((int) $p['nb_tailles'] === 0): ?>
            <div class="simple-compteur simple-compteur-petit">
              <form method="post"><?= csrf_champ() ?><input type="hidden" name="id" value="<?= (int) $p['id'] ?>"><button name="action" value="moins" aria-label="Un de moins" <?= (int) $p['stock'] === 0 ? 'disabled' : '' ?>><i class="ph ph-minus"></i></button></form>
              <b class="simple-stock<?= (int) $p['stock'] === 0 ? ' simple-zero' : '' ?>" aria-label="Quantité" aria-live="polite"><?= (int) $p['stock'] ?></b>
              <form method="post"><?= csrf_champ() ?><input type="hidden" name="id" value="<?= (int) $p['id'] ?>"><button name="action" value="plus" aria-label="Un de plus"><i class="ph ph-plus"></i></button></form>
            </div>
          <?php else: ?>
            <p class="simple-produit-stock"><b><?= (int) $p['stock'] ?></b> <span class="doux">(plusieurs tailles)</span></p>
          <?php endif; ?>
          <form method="post" class="simple-produit-action"><?= csrf_champ() ?><input type="hidden" name="id" value="<?= (int) $p['id'] ?>">
            <?php if ($enVente): ?><button name="action" value="retirer" class="simple-petit-btn"><i class="ph ph-pause"></i> Retirer</button>
            <?php else: ?><button name="action" value="vendre" class="simple-petit-btn simple-petit-btn-vert"><i class="ph ph-play"></i> Remettre en vente</button><?php endif; ?>
          </form>
        </article>
      <?php endforeach; ?>
    </div>
  </div>
</main>
<?php require __DIR__ . '/../includes/footer.php'; ?>
