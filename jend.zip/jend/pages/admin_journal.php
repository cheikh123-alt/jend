<?php
exiger_admin();
$entrees = requete(
    'SELECT j.action, j.detail, j.ip, j.created_at, u.nom AS admin
       FROM journal_admin j LEFT JOIN users u ON u.id = j.admin_id ORDER BY j.id DESC LIMIT 200'
)->fetchAll();
$titre = 'Journal — Administration';
require __DIR__ . '/../includes/header.php';
?>
<main class="page">
  <div class="wrap">
    <nav class="fil" aria-label="Fil d'Ariane"><a href="<?= e(url()) ?>">Accueil</a> / <a href="<?= e(url('admin')) ?>">Administration</a> / <span>Journal</span></nav>
    <h1 class="titre-page">Administration</h1>
    <?php admin_onglets('journal'); ?>
    <p class="doux petit">Trace de toutes les actions sensibles de l'administrateur (validation de boutiques, retraits, remboursements…). Non modifiable depuis le site.</p>
    <?php if (!$entrees): ?><div class="vide"><i class="ph ph-scroll"></i><p><b>Aucune action enregistrée.</b></p></div><?php else: ?>
    <div class="table-defile"><table class="table">
      <thead><tr><th>Date</th><th>Administrateur</th><th>Action</th><th>Détail</th><th>IP</th></tr></thead>
      <tbody>
      <?php foreach ($entrees as $j): ?>
        <tr><td><?= e(date('d/m/Y H:i', strtotime($j['created_at']))) ?></td><td><?= e((string) $j['admin']) ?></td>
            <td><code><?= e($j['action']) ?></code></td><td><?= e((string) $j['detail']) ?></td><td class="doux"><?= e((string) $j['ip']) ?></td></tr>
      <?php endforeach; ?>
      </tbody>
    </table></div>
    <?php endif; ?>
  </div>
</main>
<?php require __DIR__ . '/../includes/footer.php'; ?>
