<?php
$u = exiger_connexion();
// La confirmation de l'e-mail n'empêche plus de commander (moins d'abandons) : le paiement est vérifié par PayDunya,
// et un rappel invite à confirmer l'adresse pour recevoir le suivi et le code de réception.
$emailAConfirmer = verification_email_active() && (int) ($u['email_verifie'] ?? 1) === 0;
$panier = panier_charger();
if (!$panier['lignes']) {
    flash('Votre panier est vide.', 'erreur');
    rediriger('panier');
}

$zones = zones_actives();
$mesAdresses = requete('SELECT a.zone_id, a.adresse, a.telephone, a.lat, a.lng, z.nom AS zone FROM adresses a JOIN zones_livraison z ON z.id = a.zone_id AND z.actif = 1 WHERE a.user_id = ? ORDER BY a.id DESC', [$u['id']])->fetchAll();
$zonesParId = array_column($zones, null, 'id');
// Frais réels pour CE panier : chaque boutique facture sa livraison selon ses propres tarifs
$modesPanier = [];
foreach (array_unique(array_column($panier['lignes'], 'boutique_id')) as $bidP) {
    $lp = (string) requete('SELECT livraison_par FROM boutiques WHERE id = ?', [$bidP])->fetchColumn();
    $modesPanier[(int) $bidP] = ($lp === 'jend' && livreurs_jend_actifs()) ? 'jend' : 'vendeur';
}
$fraisZones = frais_panier($modesPanier, $zones);
foreach ($fraisZones as $zid => $fz) {                       // frais de paiement sécurisé (si l'admin les a activés)
    $fraisZones[$zid]['service'] = frais_service($panier['sous_total'] + $fz['frais']);
}

// Pré-remplissage : dernière adresse enregistrée, sinon infos du compte
$derniere = requete('SELECT zone_id, adresse, telephone FROM adresses WHERE user_id = ? ORDER BY id DESC LIMIT 1', [$u['id']])->fetch() ?: [];
$v = [
    'nom'       => $u['nom'],
    'telephone' => $derniere['telephone'] ?? ($u['telephone'] ?? ''),
    'zone_id'   => (string) ($derniere['zone_id'] ?? ''),
    'adresse'   => $derniere['adresse'] ?? '',
    'methode'   => paiement_en_ligne_actif() ? 'wave' : 'livraison',
    'acompte_methode' => 'wave',
    'cadeau'    => isset($_GET['cadeau']) ? '1' : '',
    'message_cadeau' => '',
    'lat' => '', 'lng' => '',
];
// « La dépense du mois » : l'adresse du destinataire enregistrée avec la dépense
$depenseEnCours = !empty($_SESSION['depense_en_cours']) ? depense_du_client((int) $_SESSION['depense_en_cours'], (int) $u['id']) : null;
if ($depenseEnCours) {
    $v = array_merge($v, ['nom' => $depenseEnCours['livraison_nom'], 'telephone' => $depenseEnCours['livraison_telephone'], 'zone_id' => (string) $depenseEnCours['zone_id'],
                          'adresse' => $depenseEnCours['adresse'], 'cadeau' => $depenseEnCours['cadeau'] ? '1' : '', 'lat' => '', 'lng' => '']);
}
$erreurs = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    foreach (['nom', 'telephone', 'zone_id', 'adresse', 'methode', 'acompte_methode', 'message_cadeau', 'lat', 'lng'] as $k) {
        $v[$k] = trim((string) ($_POST[$k] ?? ''));
    }
    $v['cadeau'] = !empty($_POST['cadeau']) ? '1' : '';
    if (mb_strlen($v['message_cadeau']) > 300) {
        $erreurs[] = 'Le petit mot pour votre proche est limité à 300 caractères.';
    }

    if (!csrf_valide($_POST['csrf'] ?? null)) {
        $erreurs[] = 'Session expirée, merci de réessayer.';
    }
    if ($panier['ajuste']) {
        // Le stock a changé depuis l'affichage : on ne valide jamais autre chose que ce que le client a vu.
        $erreurs[] = 'Le stock de certains articles a changé : votre panier a été mis à jour. Vérifiez le récapitulatif puis confirmez à nouveau.';
    }
    if (mb_strlen($v['nom']) < 2 || mb_strlen($v['nom']) > 120) {
        $erreurs[] = 'Indiquez le nom du destinataire.';
    }
    $tel = telephone_valide($v['telephone']);
    if ($tel === null) {
        $erreurs[] = 'Numéro de téléphone invalide (ex : 77 123 45 67) : le livreur doit pouvoir vous joindre.';
    }
    $zone = $zonesParId[(int) $v['zone_id']] ?? null;
    if (!$zone) {
        $erreurs[] = 'Choisissez votre zone de livraison.';
    }
    if (mb_strlen($v['adresse']) < 5 || mb_strlen($v['adresse']) > 255) {
        $erreurs[] = 'Indiquez une adresse de livraison précise (quartier, rue, repère).';
    }
    if (!isset(MOYENS_PAIEMENT[$v['methode']]) || ($v['methode'] === 'livraison' && !paiement_livraison_actif()) || ($v['methode'] !== 'livraison' && !paiement_en_ligne_actif())) {
        $erreurs[] = 'Choisissez un moyen de paiement.';
    } elseif ($v['methode'] === 'livraison' && acompte_description() !== '' && !in_array($v['acompte_methode'], METHODES_EN_LIGNE, true)) {
        $erreurs[] = 'Choisissez avec quel moyen vous réglez l\'acompte (Wave, Orange Money, Free Money ou carte).';
    }

    if (!$erreurs) {
        try {
            $ref = commande_creer((int) $u['id'], ['nom' => $v['nom'], 'telephone' => $tel, 'adresse' => $v['adresse']], $zone, $v['methode'], $v['acompte_methode']);
            $gps = position_valide($v['lat'], $v['lng']);          // « Ma position » (facultatif ; ignorée si hors du Sénégal)
            if ($gps) {
                requete('UPDATE commandes SET livraison_lat = ?, livraison_lng = ? WHERE reference = ? AND client_id = ?', [$gps[0], $gps[1], $ref, $u['id']]);
            }
            unset($_SESSION['depense_en_cours']);
            requete('UPDATE commandes SET source = ? WHERE reference = ? AND client_id = ?', [source_courante(), $ref, $u['id']]);
            if ($v['cadeau']) {                       // « Envoyer à ma famille » : ni prix ni facture dans le colis, petit mot facultatif
                requete('UPDATE commandes SET cadeau = 1, message_cadeau = ? WHERE reference = ? AND client_id = ?', [$v['message_cadeau'] !== '' ? $v['message_cadeau'] : null, $ref, $u['id']]);
            }
            try {                                     // paiement à la livraison sans acompte : la commande est déjà à préparer → vendeurs prévenus tout de suite
                vendeur_prevenir_commande((int) requete('SELECT id FROM commandes WHERE reference = ? AND client_id = ?', [$ref, $u['id']])->fetchColumn());
            } catch (Throwable $e) {
                error_log('Jënd — prévenir les vendeurs : ' . $e->getMessage());
            }
            // On mémorise l'adresse pour la prochaine commande (une seule fois par adresse identique)
            if (!requete('SELECT 1 FROM adresses WHERE user_id = ? AND zone_id = ? AND adresse = ?', [$u['id'], $zone['id'], $v['adresse']])->fetch()) {
                requete('INSERT INTO adresses (user_id, zone_id, adresse, telephone, lat, lng) VALUES (?, ?, ?, ?, ?, ?)', [$u['id'], $zone['id'], $v['adresse'], $tel, $gps[0] ?? null, $gps[1] ?? null]);
            } elseif ($gps) {
                requete('UPDATE adresses SET lat = ?, lng = ? WHERE user_id = ? AND zone_id = ? AND adresse = ?', [$gps[0], $gps[1], $u['id'], $zone['id'], $v['adresse']]);
            }
            if (in_array($v['methode'], METHODES_EN_LIGNE, true)) {
                // « Confirmer et payer » : la page de la commande part aussitôt vers la page de paiement (bouton « Payer maintenant » en secours)
                $_SESSION['payer_auto'] = $ref;
                flash('Commande enregistrée. Redirection vers la page de paiement…');
            } elseif ((int) requete('SELECT acompte FROM commandes WHERE reference = ?', [$ref])->fetchColumn() > 0) {
                $_SESSION['payer_auto'] = $ref;
                flash('Commande enregistrée. Redirection vers le paiement de l\'acompte : le reste se paie en espèces à la livraison.');
            }
            rediriger('commande/' . $ref);
        } catch (RuntimeException $e) {
            $erreurs[] = $e->getMessage();
            $panier = panier_charger();
            if (!$panier['lignes']) {
                flash($e->getMessage(), 'erreur');
                rediriger('panier');
            }
        }
    }
}

$fraisInitial = isset($fraisZones[(int) $v['zone_id']]) ? $fraisZones[(int) $v['zone_id']]['frais'] : 0;
$serviceInitial = isset($fraisZones[(int) $v['zone_id']]) ? $fraisZones[(int) $v['zone_id']]['service'] : frais_service($panier['sous_total']);
$serviceActif = frais_service(100000) > 0;
$titre = 'Finaliser ma commande — Jënd';
$aideFlottante = true;
require __DIR__ . '/../includes/header.php';
?>
<main class="page">
  <div class="wrap">
    <nav class="fil" aria-label="Fil d'Ariane"><a href="<?= e(url()) ?>">Accueil</a> / <a href="<?= e(url('panier')) ?>">Panier</a> / <span>Commande</span></nav>
    <h1 class="titre-page">Finaliser ma commande</h1>
    <ol class="etapes-achat" aria-label="Étapes de la commande">
      <li class="fait"><i class="ph-fill ph-check-circle"></i> Panier</li>
      <li class="courant" aria-current="step"><i class="ph-fill ph-map-pin"></i> Livraison et paiement</li>
      <li><i class="ph ph-seal-check"></i> Confirmation</li>
    </ol>
    <?php if ($emailAConfirmer): ?><p class="alerte alerte-info"><i class="ph ph-envelope-simple"></i> <span>Pensez à confirmer votre e-mail (lien reçu à l'inscription) : c'est là que nous envoyons le suivi de votre commande. <a class="lien" href="<?= e(url('compte')) ?>">Renvoyer le lien</a></span></p><?php endif; ?>

    <form method="post" class="panier-grille" data-sous-total="<?= (int) $panier['sous_total'] ?>" novalidate>
      <?= csrf_champ() ?>
      <div class="formulaire formulaire-large">
        <?php foreach ($erreurs as $er): ?><p class="alerte" role="alert"><?= e($er) ?></p><?php endforeach; ?>

        <h2 class="sous-titre">1. Livraison</h2>
        <?php if ($depenseEnCours): ?><p class="alerte alerte-info"><i class="ph ph-basket"></i> <span>Dépense « <?= e($depenseEnCours['nom']) ?> » : adresse de <?= e($depenseEnCours['livraison_nom']) ?> pré-remplie.</span></p><?php endif; ?>
        <?php if ($mesAdresses): ?>
          <label class="champ"><span>Utiliser une adresse enregistrée</span>
            <select id="adresses-enregistrees">
              <option value="">— Saisir une nouvelle adresse —</option>
              <?php foreach ($mesAdresses as $a): ?>
                <option data-zone="<?= (int) $a['zone_id'] ?>" data-adresse="<?= e($a['adresse']) ?>" data-tel="<?= e($a['telephone']) ?>" data-lat="<?= e((string) $a['lat']) ?>" data-lng="<?= e((string) $a['lng']) ?>"><?= e($a['zone']) ?> — <?= e(mb_strimwidth($a['adresse'], 0, 40, '…')) ?></option>
              <?php endforeach; ?>
            </select>
          </label>
        <?php endif; ?>
        <details class="encart-cadeau"<?= $v['cadeau'] ? ' open' : '' ?>>
          <summary><i class="ph ph-gift"></i> <span><b>C'est pour un proche ?</b> Envoyez un cadeau à votre famille au Sénégal, même depuis l'étranger.</span></summary>
          <label class="case"><input type="checkbox" name="cadeau" value="1" <?= $v['cadeau'] ? 'checked' : '' ?>> <span>Commande pour un proche : le vendeur ne met <b>ni prix ni facture</b> dans le colis</span></label>
          <label class="champ"><span>Petit mot joint au cadeau (facultatif)</span><textarea name="message_cadeau" rows="2" maxlength="300" placeholder="Ex. : Pour maman, avec tout mon amour. Bonne fête !"><?= e($v['message_cadeau']) ?></textarea></label>
          <p class="petit doux">Indiquez ci-dessous le <b>nom, le téléphone et l'adresse de votre proche</b>. Après le paiement, vous lui envoyez le code de réception par WhatsApp en un clic.</p>
        </details>
        <label class="champ"><span>Nom du destinataire</span><input type="text" name="nom" value="<?= e($v['nom']) ?>" autocomplete="name" required></label>
        <label class="champ"><span>Téléphone du destinataire (Sénégal)</span><input type="tel" name="telephone" value="<?= e($v['telephone']) ?>" placeholder="77 123 45 67" autocomplete="tel" required></label>
        <?php
        $restrictions = [];
        foreach (array_unique(array_column($panier['lignes'], 'boutique_id')) as $bidR) {
            $rr = boutique_regions((int) $bidR);
            if ($rr) {
                $nomB = '';
                foreach ($panier['lignes'] as $lg) { if ((int) $lg['boutique_id'] === (int) $bidR) { $nomB = $lg['boutique']; break; } }
                $restrictions[] = [$nomB, $rr];
            }
        }
        ?>
        <?php foreach ($restrictions as [$nomB, $rr]): ?>
          <p class="alerte alerte-info"><i class="ph ph-map-pin"></i> <span><b><?= e($nomB) ?></b> livre uniquement à : <?= e(implode(', ', $rr)) ?>. Choisissez une zone dans l'une de ces villes.</span></p>
        <?php endforeach; ?>
        <label class="champ"><span>Zone de livraison</span>
          <select name="zone_id" id="zone" required>
            <option value="">— Choisir —</option>
            <?php foreach (zones_par_ville($zones) as $ville => $zs): ?>
              <optgroup label="<?= e($ville) ?>">
              <?php foreach ($zs as $z): ?>
                <option value="<?= (int) $z['id'] ?>" data-frais="<?= (int) $fraisZones[(int) $z['id']]['frais'] ?>" data-service="<?= (int) $fraisZones[(int) $z['id']]['service'] ?>" <?= (string) $z['id'] === $v['zone_id'] ? 'selected' : '' ?>>
                  <?= e($z['nom']) ?> — <?= e(fcfa((int) $fraisZones[(int) $z['id']]['frais'])) ?> (<?= (int) $fraisZones[(int) $z['id']]['delai'] ?> j)
                </option>
              <?php endforeach; ?>
              </optgroup>
            <?php endforeach; ?>
          </select>
        </label>
        <label class="champ"><span>Adresse précise</span><textarea name="adresse" rows="3" placeholder="Quartier, rue, numéro, point de repère…" required><?= e($v['adresse']) ?></textarea></label>
        <div class="position-bloc" id="position-bloc">
          <input type="hidden" name="lat" id="pos-lat" value="<?= e($v['lat']) ?>"><input type="hidden" name="lng" id="pos-lng" value="<?= e($v['lng']) ?>">
          <button type="button" class="btn btn-contour" id="pos-bouton"><i class="ph ph-crosshair"></i> Utiliser ma position actuelle</button>
          <p class="petit doux" id="pos-etat" aria-live="polite"><?= position_valide($v['lat'], $v['lng']) ? 'Position enregistrée : le livreur aura l\'itinéraire exact.' : 'Facultatif, mais très utile : le livreur reçoit l\'itinéraire exact jusqu\'à votre porte. Faites-le depuis le lieu de livraison.' ?></p>
          <?php if ($v['cadeau']): ?><p class="petit doux">Pour un proche : laissez vide, vous pourrez lui envoyer un lien pour qu'il partage sa position.</p><?php endif; ?>
        </div>

        <h2 class="sous-titre">2. Paiement</h2>
        <div class="paiement-options">
          <?php if (!paiement_en_ligne_actif()): ?><p class="alerte alerte-info"><i class="ph ph-info"></i> <span>Le paiement en ligne est <b>momentanément indisponible</b> : vous payez <b>en espèces à la livraison</b>, à la réception de votre colis.</span></p><?php endif; ?>
          <?php foreach (MOYENS_PAIEMENT as $cle => [$libelle, $icone, $aide]): if (($cle === 'livraison' && !paiement_livraison_actif()) || ($cle !== 'livraison' && !paiement_en_ligne_actif())) { continue; } ?>
            <label class="paiement-option">
              <input type="radio" name="methode" value="<?= e($cle) ?>" <?= $v['methode'] === $cle ? 'checked' : '' ?>>
              <i class="ph <?= e($icone) ?>"></i>
              <span><b><?= e($libelle) ?></b><small><?= e($cle === 'livraison' && acompte_description() !== '' ? acompte_description() : $aide) ?></small></span>
            </label>
          <?php endforeach; ?>
        </div>
        <?php if (acompte_description() !== ''): ?>
          <label class="champ"><span>Si vous choisissez le paiement à la livraison : régler l'acompte avec</span>
            <select name="acompte_methode">
              <?php foreach (METHODES_EN_LIGNE as $m): ?><option value="<?= e($m) ?>" <?= $v['acompte_methode'] === $m ? 'selected' : '' ?>><?= e(MOYENS_PAIEMENT[$m][0]) ?></option><?php endforeach; ?>
            </select></label>
          <p class="doux petit">Si le colis est refusé ou si vous êtes injoignable à la livraison, l'acompte n'est pas remboursé : il indemnise le vendeur ou le livreur. Il est remboursé si la commande est annulée avant sa préparation ou si le produit n'est pas conforme.</p>
        <?php endif; ?>
      </div>

      <aside class="recap">
        <h2>Votre commande</h2>
        <?php foreach ($panier['lignes'] as $l): ?>
          <div class="recap-ligne"><span><?= (int) $l['quantite'] ?> × <?= e($l['nom']) ?><?= $l['variante_libelle'] ? ' <small class="doux">(' . e($l['variante_libelle']) . ')</small>' : '' ?></span><b><?= e(fcfa((int) $l['total'])) ?></b></div>
        <?php endforeach; ?>
        <hr>
        <div class="recap-ligne"><span>Sous-total</span><b><?= e(fcfa($panier['sous_total'])) ?></b></div>
        <div class="recap-ligne"><span>Livraison<?= count($modesPanier) > 1 ? ' (' . count($modesPanier) . ' boutiques, ' . count($modesPanier) . ' colis)' : '' ?></span><b id="frais"><?= $fraisInitial ? e(fcfa($fraisInitial)) : 'à choisir' ?></b></div>
        <?php if ($serviceActif): ?><div class="recap-ligne"><span>Paiement sécurisé <small class="doux">(argent protégé jusqu'à la réception)</small></span><b id="service"><?= e(fcfa($serviceInitial)) ?></b></div><?php endif; ?>
        <div class="recap-ligne recap-total"><span>Total</span><b id="total"><?= e(fcfa($panier['sous_total'] + $fraisInitial + ($serviceActif ? $serviceInitial : 0))) ?></b></div>
        <button class="btn btn-primaire recap-btn" type="submit"><i class="ph-fill ph-lock-simple"></i> Confirmer et payer</button>
        <p class="doux petit">En confirmant, vous acceptez les <a class="lien" href="<?= e(url('cgv')) ?>">conditions de vente</a>. Le paiement se fait ensuite sur la page sécurisée de notre prestataire.</p>
        <ul class="rassurance-achat rassurance-recap">
          <li><i class="ph-fill ph-shield-check"></i> <span>Votre argent est gardé par Jënd jusqu'à la réception du colis</span></li>
          <li><i class="ph-fill ph-key"></i> <span>Vous confirmez la livraison avec votre code de réception</span></li>
          <li><i class="ph-fill ph-lifebuoy"></i> <span>Un problème ? Réponse de notre équipe sous <?= LITIGE_DELAI_REPONSE_HEURES ?> h</span></li>
        </ul>
      </aside>
    </form>
  </div>
</main>
<script src="<?= e(asset('js/commande.js')) ?>" defer></script>
<?php require __DIR__ . '/../includes/footer.php'; ?>
