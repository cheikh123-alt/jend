<?php
[$u, $b] = exiger_vendeur();
if (simple_actif($b)) {          // vendeur en mode simple : son accueil est l'écran à grands boutons
    rediriger('simple');
}
$titre = 'Espace vendeur — Jënd';
$g = vendeur_gains((int) $b['id']);
$bid = (int) $b['id'];
$n = fn (string $sql, array $p = []) => (int) requete($sql, $p)->fetchColumn();

$nbProduits  = $n("SELECT COUNT(*) FROM produits WHERE boutique_id = ? AND statut = 'publie' AND reserve_client_id IS NULL", [$bid]);
$nbBrouillon = $n("SELECT COUNT(*) FROM produits WHERE boutique_id = ? AND statut = 'brouillon'", [$bid]);
$aPreparer = $n(
    "SELECT COUNT(*) FROM commande_boutiques cb JOIN commandes c ON c.id = cb.commande_id
      WHERE cb.boutique_id = ? AND cb.statut = 'a_preparer' AND c.statut <> 'annulee' AND " . SQL_ENGAGEE,
    [$bid]
);
$aLivrer = $n(
    "SELECT COUNT(*) FROM commande_boutiques cb JOIN commandes c ON c.id = cb.commande_id
      WHERE cb.boutique_id = ? AND cb.statut = 'expediee' AND c.statut <> 'annulee'",
    [$bid]
);
$litiges = $n("SELECT COUNT(*) FROM litiges l JOIN commande_boutiques cb ON cb.id = l.commande_boutique_id WHERE cb.boutique_id = ? AND l.statut IN ('ouvert', 'en_cours')", [$bid]);
$ventes30 = $n("SELECT COALESCE(SUM(sous_total), 0) FROM commande_boutiques WHERE boutique_id = ? AND statut = 'livree' AND livre_le >= (NOW() - INTERVAL 30 DAY)", [$bid]);
$nbLivrees = $n("SELECT COUNT(*) FROM commande_boutiques WHERE boutique_id = ? AND statut = 'livree'", [$bid]);
$stockBas = requete("SELECT id, nom, stock FROM produits WHERE boutique_id = ? AND statut = 'publie' AND reserve_client_id IS NULL AND stock <= 5 ORDER BY stock LIMIT 5", [$bid])->fetchAll();
$recentes = requete(
    "SELECT cb.id, cb.statut, cb.sous_total, c.reference, c.statut AS statut_commande, c.statut_paiement, c.methode_paiement, c.acompte, c.created_at,
            (SELECT GROUP_CONCAT(CONCAT(cl.quantite, ' × ', cl.nom, IF(cl.variante_libelle IS NULL, '', CONCAT(' (', cl.variante_libelle, ')'))) SEPARATOR ', ') FROM commande_lignes cl WHERE cl.commande_boutique_id = cb.id) AS articles
       FROM commande_boutiques cb JOIN commandes c ON c.id = cb.commande_id
      WHERE cb.boutique_id = ? ORDER BY cb.id DESC LIMIT 5",
    [$bid]
)->fetchAll();

// Premiers pas : disparaissent quand tout est fait
$etapes = [
    ['Boutique validée par Jënd', $b['statut'] === 'active', 'vendeur/boutique', 'Votre boutique sera visible une fois validée.'],
    ['Numéro de paiement renseigné', trim((string) $b['telephone_paiement']) !== '', 'vendeur/boutique', 'Wave ou Orange Money : c\'est là que vos gains seront envoyés.'],
    ['Premier produit en ligne', $nbProduits > 0, 'vendeur/produits/nouveau', 'Ajoutez une photo, un prix et un stock.'],
    ['Régions de livraison choisies', count(boutique_regions($bid)) > 0, 'vendeur/boutique#regions', 'Précisez où vous livrez, pour ne recevoir que des commandes que vous pouvez honorer.'],
    ['Première vente livrée', $nbLivrees > 0, 'vendeur/commandes', 'Préparez la commande, puis confirmez la livraison avec le code du client.'],
];
$restantes = array_filter($etapes, fn ($e) => !$e[1]);
$retirable = $g['solde'] >= RETRAIT_MINIMUM;

require __DIR__ . '/../includes/header.php';
?>
<main class="page">
  <div class="wrap">
    <nav class="fil" aria-label="Fil d'Ariane"><a href="<?= e(url()) ?>">Accueil</a> / <a href="<?= e(url('compte')) ?>">Mon compte</a> / <span>Boutique</span></nav>
    <div class="compte-tete">
      <div><h1 class="titre-page"><?= e($b['nom']) ?></h1>
        <p class="compte"><?= e(tb_salutation()) ?> <?= e(explode(' ', $u['nom'])[0]) ?> · <?= e(tb_date_longue()) ?>
          · <span class="badge badge-<?= $b['statut'] === 'active' ? 'confirmee' : ($b['statut'] === 'suspendue' ? 'annulee' : 'en_attente') ?>"><?= e(['active' => 'Boutique active', 'en_attente' => 'En attente de validation', 'suspendue' => 'Suspendue'][$b['statut']] ?? $b['statut']) ?></span></p></div>
      <a class="btn btn-primaire" href="<?= e(url('vendeur/produits/nouveau')) ?>"><i class="ph ph-plus"></i> Ajouter un produit</a>
    </div>
    <?php vendeur_onglets('accueil'); ?>
    <?= rappel_whatsapp($b) ?>
    <?= push_bloc() ?>
    <form method="post" action="<?= e(url('simple/mode')) ?>" class="mode-bascule">
      <?= csrf_champ() ?><input type="hidden" name="mode" value="simple">
      <span><i class="ph-fill ph-hand-pointing"></i> Trop de choses à lire ? Le <b>mode simple</b> : photo, prix, voix et grands boutons.</span>
      <button class="btn btn-contour" type="submit"><i class="ph ph-sparkle"></i> Passer au mode simple</button>
    </form>

    <?php if ($b['statut'] === 'en_attente'): ?>
      <p class="alerte alerte-info"><i class="ph ph-hourglass-medium"></i> <span><b>Boutique en attente de validation.</b> Vos produits ne sont pas encore visibles par les clients. Vous serez prévenu dès la validation ; en attendant, préparez vos produits.</span></p>
    <?php elseif ($b['statut'] === 'suspendue'): ?>
      <p class="alerte" role="alert"><i class="ph ph-warning"></i> Votre boutique est suspendue : vos produits ne sont plus visibles. Contactez le support.</p>
    <?php endif; ?>

    <?php tb_a_faire([
        tb_action('ph-package', $aPreparer > 1 ? 'commandes à préparer' : 'commande à préparer', $aPreparer, 'vendeur/commandes', 'urgent', 'Payées : le client attend. Marquez-les « expédiées » une fois prêtes.', 'Préparer'),
        tb_action('ph-scissors', 'demande(s) sur mesure : devis à envoyer', (int) $b['sur_mesure'] === 1 ? demandes_a_traiter($bid) : 0, 'vendeur/sur-mesure', 'urgent', 'Un client attend votre prix et votre délai.', 'Répondre'),
        tb_action('ph-handshake', 'offre(s) de prix à traiter', offres_a_traiter($bid), 'vendeur/offres', 'urgent', 'Un client vous propose un prix : acceptez, refusez ou contre-proposez sous ' . OFFRE_REPONSE_HEURES . ' h.', 'Répondre'),
        tb_action('ph-truck', 'colis à confirmer à la livraison', $aLivrer, 'vendeur/commandes', 'normal', 'Saisissez le code du client à la remise (ou le client confirme lui-même sur son compte).', 'Confirmer'),
        tb_action('ph-chat-circle-text', 'signalement(s) de clients', $litiges, 'vendeur/commandes', 'urgent', 'Jënd examine chaque cas ; la somme concernée est mise de côté.', 'Voir'),
        tb_action('ph-warning', 'produit(s) bientôt en rupture', count($stockBas), 'vendeur/produits', 'normal', 'Stock de 5 ou moins : réapprovisionnez pour continuer à vendre.', 'Gérer'),
        tb_action('ph-bank', 'retrait possible', $retirable ? 1 : 0, 'vendeur/gains', 'info', 'Votre solde dépasse le minimum de ' . fcfa(RETRAIT_MINIMUM) . '.', 'Retirer'),
    ], 'Tout est à jour. Rien à préparer pour le moment.'); ?>

    <div class="tb-kpis">
      <?= tb_kpi('ph-wallet', 'Solde disponible', fcfa($g['solde']), $retirable ? 'vous pouvez le retirer' : 'minimum de retrait : ' . fcfa(RETRAIT_MINIMUM), 'vendeur/gains', true) ?>
      <?= tb_kpi('ph-hourglass', 'Bientôt retirable', fcfa($g['en_delai']), 'délai de ' . (int) $g['delai'] . ' j après livraison') ?>
      <?= tb_kpi('ph-chart-line-up', 'Ventes des 30 jours', fcfa($ventes30), 'commandes livrées') ?>
      <?= tb_kpi('ph-storefront', 'Produits en ligne', (string) $nbProduits, $nbBrouillon > 0 ? $nbBrouillon . ' brouillon(s)' : '', 'vendeur/produits') ?>
    </div>

    <?php if ($restantes): ?>
    <section class="tb-bloc">
      <h2 class="tb-titre"><i class="ph-fill ph-flag"></i> Pour bien démarrer <small><?= count($etapes) - count($restantes) ?>/<?= count($etapes) ?></small></h2>
      <ol class="tb-etapes">
        <?php foreach ($etapes as [$libelle, $fait, $chemin, $aide]): ?>
          <li class="<?= $fait ? 'fait' : '' ?>"><span class="tb-etape-pastille"><i class="ph <?= $fait ? 'ph-check' : 'ph-circle' ?>"></i></span>
            <span><b><?= e($libelle) ?></b><small><?= e($aide) ?></small></span>
            <?php if (!$fait): ?><a class="lien" href="<?= e(url($chemin)) ?>">Faire</a><?php endif; ?></li>
        <?php endforeach; ?>
      </ol>
    </section>
    <?php endif; ?>

    <div class="tb-deux">
      <section class="tb-bloc">
        <h2 class="tb-titre"><i class="ph-fill ph-receipt"></i> Dernières commandes</h2>
        <?php if (!$recentes): ?>
          <div class="tb-vide"><i class="ph ph-receipt"></i><p>Aucune commande pour le moment. Elles apparaîtront ici dès qu'un client achète chez vous.</p></div>
        <?php else: ?>
          <ul class="tb-liste">
            <?php foreach ($recentes as $r): $impayee = $r['statut_commande'] === 'annulee' ? 'annulee' : ($r['statut'] === 'a_preparer' && !commande_engagee($r) ? 'attente' : null); ?>
              <li><a href="<?= e(url('vendeur/commandes')) ?>"><span><b><?= e($r['reference']) ?></b> <small class="doux"><?= e(date('d/m H:i', strtotime($r['created_at']))) ?></small><br><small class="doux"><?= e(mb_strimwidth((string) $r['articles'], 0, 60, '…')) ?></small></span>
                <span><?= e(fcfa((int) $r['sous_total'])) ?>
                  <?php if ($impayee === 'annulee'): ?><span class="badge badge-annulee">Annulée</span>
                  <?php elseif ($impayee === 'attente'): ?><span class="badge badge-en_attente">Paiement en attente</span>
                  <?php else: ?><span class="badge badge-<?= e($r['statut']) ?>"><?= e(STATUTS_SOUS_COMMANDE[$r['statut']]) ?></span><?php endif; ?></span></a></li>
            <?php endforeach; ?>
          </ul>
          <p class="petit"><a class="lien" href="<?= e(url('vendeur/commandes')) ?>">Toutes les commandes</a></p>
        <?php endif; ?>
      </section>

      <section class="tb-bloc">
        <h2 class="tb-titre"><i class="ph-fill ph-coins"></i> Mon argent en un coup d'œil</h2>
        <ul class="tb-liste tb-liste-simple">
          <li><span>Ventes livrées</span><b><?= e(fcfa($g['brut'])) ?></b></li>
          <li><span>Commission de Jënd (<?= e(commission_texte((float) $b['commission_pct'])) ?> %)</span><b>− <?= e(fcfa($g['commission'])) ?></b></li>
          <?php if ($g['frais_livraison'] > 0): ?><li><span>Frais de livraison gardés</span><b>+ <?= e(fcfa($g['frais_livraison'])) ?></b></li><?php endif; ?>
          <?php if ($g['retire'] > 0): ?><li><span>Déjà retiré ou demandé</span><b>− <?= e(fcfa($g['retire'])) ?></b></li><?php endif; ?>
          <li class="tb-total"><span>Solde disponible</span><b><?= e(fcfa($g['solde'])) ?></b></li>
        </ul>
        <p class="petit"><a class="lien" href="<?= e(url('vendeur/gains')) ?>">Détail et retrait</a> · <a class="lien" href="<?= e(url('paiements-vendeurs')) ?>">Comment suis-je payé ?</a></p>
      </section>
    </div>

    <?php $confiance = boutique_confiance($bid); ?>
    <section class="tb-bloc">
      <h2 class="tb-titre"><i class="ph-fill ph-chart-bar"></i> Ma fiche de confiance <small>vue par les clients</small></h2>
      <?php if ($confiance['assez']): ?>
        <dl class="confiance-chiffres">
          <div><dt>Ventes livrées</dt><dd><?= (int) $confiance['ventes'] ?></dd></div>
          <div><dt>Délai moyen de réception</dt><dd><?= $confiance['delai_heures'] !== null ? e(delai_texte($confiance['delai_heures'])) : '—' ?></dd></div>
          <div><dt>Commandes sans problème</dt><dd><?= (int) $confiance['sans_probleme'] ?> %</dd></div>
        </dl>
      <?php else: ?>
        <p class="doux">Vos chiffres s'afficheront sur votre boutique après <?= CONFIANCE_VENTES_MIN ?> ventes livrées (vous en avez <?= (int) $confiance['ventes'] ?>).</p>
      <?php endif; ?>
      <p class="petit doux">Pour les améliorer : préparez vite vos commandes, décrivez vos produits honnêtement (photos réelles) et répondez aux clients. Ces chiffres sont calculés automatiquement à partir de vos livraisons et des signalements.</p>
    </section>

    <section class="tb-bloc">
      <h2 class="tb-titre"><i class="ph-fill ph-whatsapp-logo"></i> Faire connaître ma boutique</h2>
      <p class="doux">Envoyez le lien de votre boutique à vos clients et contacts : c'est le moyen le plus efficace de vendre.</p>
      <p class="partage-ligne">
        <?= bouton_whatsapp('Découvrez ma boutique « ' . $b['nom'] . ' » sur Jënd : ' . lien_source(app_url('boutique/' . $b['slug']), 'whatsapp'), 'Partager ma boutique') ?>
        <?php if ($b['statut'] === 'active'): ?><a class="btn btn-contour" href="<?= e(url('boutique/' . $b['slug'])) ?>"><i class="ph ph-eye"></i> Voir ma page publique</a><?php endif; ?>
        <?php if ($b['statut'] === 'active'): ?><a class="btn btn-contour" href="<?= e(url('vendeur/statut')) ?>"><i class="ph ph-image"></i> Images pour mon statut</a><?php endif; ?>
      </p>
    </section>

    <?php if ($b['statut'] === 'active' && $b['code_parrain'] && parrainage_jours() > 0):
        $lienParrain = lien_source(app_url('vendre?parrain=' . $b['code_parrain']), 'parrain');
        $nbFilleuls = (int) requete('SELECT COUNT(*) FROM boutiques WHERE parrain_boutique_id = ?', [$bid])->fetchColumn();
        $nbValides = (int) requete("SELECT COUNT(*) FROM boutiques WHERE parrain_boutique_id = ? AND parrainage_recompense = 1", [$bid])->fetchColumn(); ?>
    <section class="tb-bloc">
      <h2 class="tb-titre"><i class="ph-fill ph-gift"></i> Parrainer un vendeur</h2>
      <p class="doux">Invitez un autre vendeur : dès que sa boutique est validée, <b>vous gagnez tous les deux <?= parrainage_jours() ?> jours sans commission</b>.
        <?= $nbFilleuls ?> vendeur(s) invité(s), dont <?= $nbValides ?> validé(s).</p>
      <p class="partage-ligne">
        <?= bouton_whatsapp('Je vends sur Jënd, la marketplace sénégalaise. Ouvre ta boutique gratuitement avec mon lien et gagne ' . parrainage_jours() . ' jours sans commission : ' . $lienParrain, 'Inviter par WhatsApp') ?>
        <button class="btn btn-contour" type="button" data-copier="<?= e($lienParrain) ?>"><i class="ph ph-link"></i> Copier mon lien</button>
        <span class="doux">Mon code : <b><?= e($b['code_parrain']) ?></b></span>
      </p>
    </section>
    <?php endif; ?>

    <section class="tb-bloc">
      <h2 class="tb-titre"><i class="ph-fill ph-user-gear"></i> Mon compte</h2>
      <div class="tb-raccourcis">
        <a href="<?= e(url('vendeur/profil')) ?>"><i class="ph ph-user"></i> Mon profil<small>nom, téléphone</small></a>
        <a href="<?= e(url('vendeur/profil')) ?>"><i class="ph ph-key"></i> Mot de passe<small>le changer en toute sécurité</small></a>
        <a href="<?= e(url('vendeur/boutique')) ?>"><i class="ph ph-storefront"></i> Ma boutique<small>nom, description, paiement</small></a>
        <a href="<?= e(url('compte/securite')) ?>"><i class="ph ph-shield-check"></i> Sécurité<small>double authentification</small></a>
        <a href="<?= e(url('contact?sujet=boutique')) ?>"><i class="ph ph-lifebuoy"></i> Contacter Jënd<small>une question, un problème</small></a>
      </div>
    </section>

    <?php if ($stockBas): ?>
    <section class="tb-bloc">
      <h2 class="tb-titre"><i class="ph-fill ph-warning"></i> Stock bas</h2>
      <ul class="tb-liste">
        <?php foreach ($stockBas as $p): ?>
          <li><a href="<?= e(url('vendeur/produits/' . $p['id'] . '/modifier')) ?>"><span><?= e($p['nom']) ?></span><span><b><?= (int) $p['stock'] ?></b> en stock · <span class="lien">Réapprovisionner</span></span></a></li>
        <?php endforeach; ?>
      </ul>
    </section>
    <?php endif; ?>
  </div>
</main>
<?php require __DIR__ . '/../includes/footer.php'; ?>
