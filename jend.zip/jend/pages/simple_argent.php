<?php
/**
 * Mode simple : mon argent — tout ce que le vendeur doit savoir, en chiffres et en images :
 * ce que Jënd garde pour lui, la commission (taux + exemple concret), le calcul complet de ses gains,
 * les prochains envois sur son téléphone, et le détail de ses dernières ventes.
 * Mêmes chiffres que l'onglet « Gains » du mode complet (vendeur_gains).
 */
[$u, $b] = exiger_vendeur_simple();
$bid = (int) $b['id'];
$g = vendeur_gains($bid);
$pct = (float) $b['commission_pct'];
$gratuit = commission_gratuite_jusqu($b);
$annonce = commission_annonce();
$prochain = prochain_versement();
$methode = METHODES_VERSEMENT[$b['methode_versement']] ?? 'Wave';
$exemple = 10000;
$exempleCommission = $gratuit ? 0 : (int) round($exemple * $pct / 100);
$detteMax = (int) parametre('dette_commission_max', '20000');

$ventes = requete(
    "SELECT cb.sous_total, cb.commission, cb.net_vendeur, cb.frais_part, cb.acompte_part, cb.livre_par, cb.livre_le, c.methode_paiement,
            (SELECT l.statut FROM litiges l WHERE l.commande_boutique_id = cb.id) AS litige,
            (SELECT SUM(l.quantite) FROM commande_lignes l WHERE l.commande_boutique_id = cb.id) AS nb,
            (SELECT i.chemin FROM commande_lignes l JOIN produit_images i ON i.produit_id = l.produit_id WHERE l.commande_boutique_id = cb.id ORDER BY l.id, i.position, i.id LIMIT 1) AS photo
       FROM commande_boutiques cb JOIN commandes c ON c.id = cb.commande_id
      WHERE cb.boutique_id = ? AND cb.statut = 'livree'
      ORDER BY cb.livre_le DESC, cb.id DESC LIMIT 10",
    [$bid]
)->fetchAll();
$versements = requete("SELECT montant, statut, paye_le, reference_transfert, created_at FROM retraits WHERE boutique_id = ? AND statut IN ('demande', 'paye') ORDER BY created_at DESC, id DESC LIMIT 6", [$bid])->fetchAll();

/** Une ligne du calcul : icône, libellé court, montant (signe + ou −), explication facultative. Les lignes à 0 sont cachées (sauf les totaux). */
$ligne = function (string $icone, string $libelle, int $montant, string $signe = '', string $aide = '', string $classe = ''): void {
    if ($montant === 0 && $signe !== '=') {
        return;
    }
    echo '<li class="simple-calcul-ligne ' . e($classe) . '"><i class="ph-fill ' . e($icone) . '"></i><span><b>' . e($libelle) . '</b>'
       . ($aide !== '' ? '<small>' . e($aide) . '</small>' : '') . '</span><strong>' . ($signe !== '=' ? e($signe) . ' ' : '') . e(fcfa($montant)) . '</strong></li>';
};
$titre = 'Mon argent — Jënd';
$scripts_extra = ['js/simple.js'];
require __DIR__ . '/../includes/header.php';
?>
<main class="page simple">
  <div class="wrap">
    <?php simple_entete('Mon argent', 'argent'); ?>

    <section class="simple-solde">
      <p><i class="ph-fill ph-vault"></i> Jënd garde pour vous</p>
      <b><?= e(fcfa($g['solde'])) ?></b>
      <?php if ($g['en_delai'] > 0): ?><p class="simple-solde-plus"><i class="ph-fill ph-hourglass-medium"></i> + <?= e(fcfa($g['en_delai'])) ?> bientôt (ventes livrées il y a moins de <?= (int) $g['delai'] ?> jour<?= $g['delai'] > 1 ? 's' : '' ?>)</p><?php endif; ?>
      <?php if ($g['bloque'] > 0): ?><p class="simple-solde-plus"><i class="ph-fill ph-warning-circle"></i> <?= e(fcfa($g['bloque'])) ?> mis de côté : un client a signalé un problème</p><?php endif; ?>
    </section>

    <?= reglement_bloc_vendeur($b, $g['dette'], true) ?>

    <h2 class="simple-sous-titre"><i class="ph-fill ph-device-mobile"></i> Quand je reçois mon argent ?</h2>
    <?php if (!paiement_en_ligne_actif() && $g['solde'] < RETRAIT_MINIMUM): ?>
      <p class="simple-info simple-info-vert"><i class="ph-fill ph-hand-coins"></i> <span>Vos clients vous paient <b>en espèces, à la livraison</b> : l'argent de vos ventes est <b>déjà dans votre poche</b>. Il n'y a rien à retirer.</span></p>
    <?php elseif ($prochain && (int) $b['versement_auto'] === 1): ?>
      <p class="simple-info simple-info-vert"><i class="ph-fill ph-calendar-check"></i> <span>Prochain envoi : <b><?= e(date_jour_fr($prochain)) ?></b><br>sur votre <b><?= e($methode) ?></b><?= ($m = simple_numero_masque($b['telephone_paiement'])) ? ' <b>' . e($m) . '</b>' : '' ?><br><small>Chaque <?= e((string) versement_jour()) ?>, Jënd envoie tout ce qui est disponible (<?= e(fcfa(RETRAIT_MINIMUM)) ?> minimum).</small></span></p>
    <?php else: ?>
      <p class="simple-info"><i class="ph-fill ph-info"></i> <span>Pour recevoir votre argent sur <?= e($methode) ?>, demandez un retrait dans le mode complet (onglet « Gains »), ou demandez de l'aide à Jënd.</span></p>
    <?php endif; ?>
    <p class="simple-info"><i class="ph-fill ph-clock"></i> <span>L'argent d'une vente est disponible <b><?= $g['delai'] > 0 ? (int) $g['delai'] . ' jour' . ($g['delai'] > 1 ? 's' : '') . ' après la livraison' : 'dès la livraison' ?></b><?= $g['delai'] > 0 ? ' (le temps pour le client de signaler un problème)' : '' ?>.</span></p>

    <h2 class="simple-sous-titre"><i class="ph-fill ph-percent"></i> Combien Jënd prend ?</h2>
    <section class="simple-commission">
      <p class="simple-taux"><b><?= e(commission_texte($gratuit ? 0.0 : $pct)) ?> %</b><span>de chaque vente livrée</span></p>
      <div class="simple-exemple" aria-label="Exemple">
        <div><i class="ph-fill ph-shopping-bag"></i><small>Vous vendez</small><b><?= e(fcfa($exemple)) ?></b></div>
        <i class="ph ph-arrow-right simple-fleche"></i>
        <div><i class="ph-fill ph-hand-coins"></i><small>Jënd prend</small><b><?= e(fcfa($exempleCommission)) ?></b></div>
        <i class="ph ph-arrow-right simple-fleche"></i>
        <div class="simple-exemple-vous"><i class="ph-fill ph-wallet"></i><small>Pour vous</small><b><?= e(fcfa($exemple - $exempleCommission)) ?></b></div>
      </div>
      <ul class="simple-points">
        <li><i class="ph-fill ph-check-circle"></i> <span>Rien à payer pour ouvrir la boutique ni pour mettre des produits.</span></li>
        <li><i class="ph-fill ph-check-circle"></i> <span>Jënd ne prend rien si la vente est annulée ou pas livrée.</span></li>
        <li><i class="ph-fill ph-check-circle"></i> <span>La commission se calcule sur le prix des produits seulement. Si vous livrez vous-même, les frais de livraison sont pour vous, en entier.</span></li>
        <?php if ($gratuit): ?><li class="simple-point-fort"><i class="ph-fill ph-gift"></i> <span><b>Parrainage : 0 % jusqu'au <?= e(date('d/m/Y', strtotime($gratuit))) ?></b> (ensuite <?= e(commission_texte($pct)) ?> %).</span></li>
        <?php elseif ($pct > 0 && offre_lancement()): ?><li class="simple-point-fort"><i class="ph-fill ph-gift"></i> <span><b>Offre de lancement</b> : ce taux est réduit pendant le lancement de Jënd.</span></li><?php endif; ?>
        <li><i class="ph-fill ph-bell-ringing"></i> <span>Si le taux change, vous êtes prévenu <b><?= COMMISSION_PREAVIS_JOURS ?> jours avant</b>.</span></li>
      </ul>
      <?php if ($annonce): ?><p class="simple-attente"><i class="ph-fill ph-megaphone"></i> <span><b>Attention</b> : à partir du <b><?= e(date('d/m/Y', strtotime($annonce['le']))) ?></b>, Jënd prendra <b><?= e(commission_texte($annonce['pct'])) ?> %</b> sur les nouvelles commandes.</span></p><?php endif; ?>
    </section>

    <h2 class="simple-sous-titre"><i class="ph-fill ph-calculator"></i> Le calcul de mon argent</h2>
    <?php if ($g['brut'] === 0 && !$g['acompte_acquis']): ?>
      <p class="simple-info"><i class="ph-fill ph-info"></i> <span>Pas encore de vente livrée. Le calcul apparaîtra ici après votre première livraison.</span></p>
    <?php else: ?>
      <ul class="simple-calcul">
        <?php
        $ligne('ph-shopping-bag', 'Mes ventes livrées', $g['brut'], '+', 'Prix des produits');
        $ligne('ph-truck', 'Livraisons faites par moi', $g['frais_livraison'], '+', 'Frais de livraison payés par les clients');
        $ligne('ph-shield-check', 'Acomptes gardés', $g['acompte_acquis'], '+', 'Client absent ou qui a refusé le colis');
        $ligne('ph-percent', 'Commission de Jënd', $g['commission'], '−', '', 'moins');
        $ligne('ph-coins', 'Ce que j\'ai gagné', $g['net'] + $g['acompte_acquis'], '=', '', 'total');
        $ligne('ph-hand-coins', 'Déjà reçu en espèces', $g['especes'], '−', 'Payé par les clients à la livraison, directement à vous', 'moins');
        $ligne('ph-device-mobile', 'Déjà envoyé sur mon téléphone', $g['retire'], '−', '', 'moins');
        $ligne('ph-hourglass-medium', 'Bientôt disponible', $g['en_delai'], '−', 'Ventes livrées il y a peu', 'moins');
        $ligne('ph-warning-circle', 'Mis de côté (problème signalé)', $g['bloque'], '−', 'Rendu après la décision de Jënd', 'moins');
        $ligne('ph-arrow-u-up-left', 'Remboursé à des clients', $g['rembourse'], '−', '', 'moins');
        $ligne('ph-hand-coins', 'Commission déjà réglée à Jënd', $g['regle'], '+', 'Par Wave ou Orange Money');
        $ligne('ph-vault', 'Jënd garde pour moi', $g['solde'], '=', '', 'total');
        ?>
      </ul>
    <?php endif; ?>

    <?php if ($ventes): ?>
      <h2 class="simple-sous-titre"><i class="ph-fill ph-receipt"></i> Mes dernières ventes</h2>
      <ul class="simple-ventes">
        <?php foreach ($ventes as $v):
            $especesV = $v['methode_paiement'] === 'livraison' && $v['livre_par'] === 'vendeur';
            $pourVous = (int) $v['net_vendeur'] + ($v['livre_par'] === 'vendeur' ? (int) $v['frais_part'] : 0); ?>
          <li>
            <span class="simple-commande-photo"><?php if ($v['photo']): ?><img src="<?= e(url(image_miniature($v['photo']))) ?>" alt="" loading="lazy"><?php else: ?><i class="ph ph-image"></i><?php endif; ?></span>
            <span class="simple-vente-detail">
              <small><?= e(date('d/m', strtotime((string) $v['livre_le']))) ?> · × <?= (int) $v['nb'] ?><?= $especesV ? ' · <i class="ph-fill ph-money"></i> espèces' : '' ?></small>
              <span>Vente <b><?= e(fcfa((int) $v['sous_total'])) ?></b></span>
              <span>Jënd <b>− <?= e(fcfa((int) $v['commission'])) ?></b></span>
              <?php if ($v['livre_par'] === 'vendeur' && (int) $v['frais_part'] > 0): ?><span>Livraison <b>+ <?= e(fcfa((int) $v['frais_part'])) ?></b></span><?php endif; ?>
              <?php if (in_array($v['litige'], ['ouvert', 'en_cours'], true)): ?><span class="simple-zero"><i class="ph-fill ph-warning-circle"></i> problème signalé</span><?php endif; ?>
            </span>
            <strong><?= e(fcfa($pourVous)) ?></strong>
          </li>
        <?php endforeach; ?>
      </ul>
    <?php endif; ?>

    <?php if ($versements): ?>
      <h2 class="simple-sous-titre"><i class="ph-fill ph-clock-counter-clockwise"></i> Envois sur mon téléphone</h2>
      <ul class="simple-versements">
        <?php foreach ($versements as $r): ?>
          <li><b><?= e(fcfa((int) $r['montant'])) ?></b>
            <span><?= $r['statut'] === 'paye' ? '<i class="ph-fill ph-check-circle"></i> envoyé le ' . e(date('d/m', strtotime((string) ($r['paye_le'] ?: $r['created_at'])))) . ($r['reference_transfert'] ? '<br><small>réf. ' . e($r['reference_transfert']) . '</small>' : '') : '<i class="ph-fill ph-hourglass-medium"></i> en cours' ?></span></li>
        <?php endforeach; ?>
      </ul>
    <?php endif; ?>

    <div class="simple-bas">
      <a class="simple-lien" href="<?= e(url('vendeur/releves')) ?>"><i class="ph ph-file-text"></i> Relevé du mois (détaillé)</a>
      <a class="simple-lien" href="<?= e(url('frais-commissions')) ?>"><i class="ph ph-info"></i> Toutes les règles</a>
      <a class="simple-lien" href="<?= e(url('aide')) ?>"><i class="ph ph-lifebuoy"></i> Une question ? Écrire à Jënd</a>
    </div>
  </div>
</main>
<?php require __DIR__ . '/../includes/footer.php'; ?>
