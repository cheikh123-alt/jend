<?php
exiger_admin();

if (post_verifie('admin/tresorerie')) {
    $montant = trim((string) ($_POST['solde'] ?? ''));
    if (($_POST['action'] ?? '') === 'solde_reel' && ctype_digit($montant) && (int) $montant <= 1_000_000_000) {
        parametre_definir('tresorerie_solde_reel', (string) (int) $montant);
        parametre_definir('tresorerie_solde_reel_le', date('Y-m-d H:i'));
        journaliser('tresorerie_solde_saisi', (int) $montant . ' FCFA');
        flash('Solde réel enregistré : la comparaison ci-dessous est à jour.');
    } elseif (($_POST['action'] ?? '') === 'solde_effacer') {
        requete("DELETE FROM parametres WHERE cle IN ('tresorerie_solde_reel', 'tresorerie_solde_reel_le')");
        parametres_charges(true);
        flash('Solde réel effacé.');
    } else {
        flash('Montant invalide : entrez un nombre entier de FCFA (sans espaces ni lettres).', 'erreur');
    }
    rediriger('admin/tresorerie');
}
$t = tresorerie_calculer();
$f = fn (int $v): string => fcfa($v);
$titre = 'Trésorerie — Administration';
require __DIR__ . '/../includes/header.php';
?>
<main class="page">
  <div class="wrap">
    <nav class="fil" aria-label="Fil d'Ariane"><a href="<?= e(url()) ?>">Accueil</a> / <a href="<?= e(url('admin')) ?>">Administration</a> / <span>Trésorerie</span></nav>
    <h1 class="titre-page">Administration</h1>
    <?php admin_onglets('tresorerie'); ?>
    <p class="doux">Où est l'argent encaissé en ligne, à qui il revient, et ce qu'il te reste. Les <b>espèces</b> encaissées par les vendeurs ou les livreurs ne passent pas par ton compte de paiement : elles ne sont pas comptées ici.</p>

    <section class="carte-param">
      <h2><i class="ph ph-arrow-down-left"></i> 1. Ce qui devrait être sur ton compte de paiement</h2>
      <div class="table-defile"><table class="table tresorerie"><tbody>
        <tr><td>Encaissé en ligne (clients)</td><td><?= e($f($t['encaisse'])) ?></td></tr>
        <tr><td>− Remboursé aux clients</td><td>− <?= e($f($t['rembourse'])) ?></td></tr>
        <tr><td>− Versé aux vendeurs (retraits payés)</td><td>− <?= e($f($t['verse_vendeurs'])) ?></td></tr>
        <tr class="total"><td>= Solde théorique, <b>avant frais du prestataire de paiement</b></td><td><?= e($f($t['theorique'])) ?></td></tr>
      </tbody></table></div>
    </section>

    <section class="carte-param">
      <h2><i class="ph ph-hand-coins"></i> 2. Ce que tu dois encore (cet argent n'est pas à toi)</h2>
      <div class="table-defile"><table class="table tresorerie"><tbody>
        <tr><td>Aux vendeurs : gains <b>retirables</b> maintenant</td><td><?= e($f($t['vendeurs_retirable'])) ?></td></tr>
        <tr><td>Aux vendeurs : gains « bientôt retirables » (délai après livraison)</td><td><?= e($f($t['vendeurs_delai'])) ?></td></tr>
        <tr><td>Aux vendeurs : gains mis de côté (signalements ouverts)</td><td><?= e($f($t['vendeurs_bloque'])) ?></td></tr>
        <tr><td>Retraits demandés, pas encore payés</td><td><?= e($f($t['retraits_demandes'])) ?></td></tr>
        <tr><td>Commandes payées, pas encore livrées (reviendront aux vendeurs ou aux clients)</td><td><?= e($f($t['en_cours'])) ?></td></tr>
        <tr><td>Remboursements à envoyer aux clients (commandes annulées, signalements acceptés)</td><td><?= e($f($t['clients_a_rembourser'])) ?></td></tr>
        <tr class="total"><td>= Total que tu dois</td><td><?= e($f($t['dettes'])) ?></td></tr>
      </tbody></table></div>
    </section>

    <?php if ($t['especes_livreurs'] > 0 || $t['dettes_vendeurs'] > 0 || $t['commissions_reglees'] > 0): ?>
    <section class="carte-param">
      <h2><i class="ph ph-hand-coins"></i> À récupérer hors compte de paiement</h2>
      <div class="table-defile"><table class="table tresorerie"><tbody>
        <tr><td>Espèces que les livreurs Jënd doivent te remettre (<a href="<?= e(url('admin/caisse')) ?>">Caisse</a>)</td><td><?= e($f($t['especes_livreurs'])) ?></td></tr>
        <tr><td>Commissions dues par des vendeurs (retenues sur leurs prochains gains, ou à régler : <a class="lien" href="<?= e(url('admin/commissions')) ?>">Commissions dues</a>)</td><td><?= e($f($t['dettes_vendeurs'])) ?></td></tr>
        <?php if ($t['commissions_reglees'] > 0): ?><tr><td>Commissions déjà réglées par les vendeurs (reçues sur ton numéro Wave / Orange Money)</td><td><?= e($f($t['commissions_reglees'])) ?></td></tr><?php endif; ?>
      </tbody></table></div>
    </section>
    <?php endif; ?>

    <section class="carte-param <?= $t['reste_jend'] >= 0 ? 'param-actif' : '' ?>">
      <h2><i class="ph ph-piggy-bank"></i> 3. Ce qui te reste (avant frais)</h2>
      <p class="gros-chiffre"><?= e($f($t['reste_jend'])) ?></p>
      <p class="doux">Solde théorique − ce que tu dois. C'est ta part : commissions et frais de livraison qui te reviennent. <b>Les frais du prestataire de paiement n'y sont pas encore retirés</b> : ils apparaissent quand tu compares avec ton solde réel.</p>
    </section>

    <section class="carte-param">
      <h2><i class="ph ph-scales"></i> 4. Compare avec la réalité</h2>
      <p>Ouvre ton tableau de bord PayDunya, lis ton <b>solde réel</b> et saisis-le ici. L'écart avec le solde théorique correspond aux frais retenus par le prestataire.</p>
      <form method="post" class="ligne-action"><?= csrf_champ() ?><input type="hidden" name="action" value="solde_reel">
        <label class="sr" for="solde">Solde réel en FCFA</label><input id="solde" type="text" name="solde" inputmode="numeric" class="largeur-120" value="<?= $t['reel'] !== null ? (int) $t['reel'] : '' ?>" placeholder="ex : 35600"> FCFA
        <button class="btn btn-primaire" type="submit">Enregistrer</button></form>
      <?php if ($t['reel'] !== null): ?>
        <div class="table-defile"><table class="table tresorerie"><tbody>
          <tr><td>Solde réel saisi (<?= e(date('d/m/Y H:i', strtotime((string) $t['reel_le']))) ?>)</td><td><?= e($f($t['reel'])) ?></td></tr>
          <tr><td>Frais retenus par le prestataire (théorique − réel)</td><td><?= e($f(max(0, $t['frais']))) ?><?= $t['frais_pct'] !== null && $t['frais'] > 0 ? ' <small class="doux">(' . e(str_replace('.', ',', (string) $t['frais_pct'])) . ' % de l\'encaissé)</small>' : '' ?></td></tr>
          <?php if ($t['frais'] < 0): ?><tr><td colspan="2" class="alerte alerte-info">Ton solde réel est supérieur au théorique : un versement a peut-être été oublié dans l'application (retrait payé non marqué, remboursement…).</td></tr><?php endif; ?>
          <tr class="total"><td>= Ce qu'il te reste <b>réellement</b> après avoir tout payé</td><td class="<?= $t['reste_reel'] < 0 ? 'negatif' : '' ?>"><?= e($f($t['reste_reel'])) ?></td></tr>
        </tbody></table></div>
        <?php if ($t['reste_reel'] < 0): ?>
          <p class="alerte" role="alert"><i class="ph ph-warning"></i> <b>Il manque <?= e($f(-$t['reste_reel'])) ?></b> sur ton compte pour pouvoir payer tout ce que tu dois. Les frais du prestataire ont dépassé tes commissions : complète le compte de ta poche, ou augmente la commission.</p>
        <?php else: ?>
          <p class="alerte alerte-info"><i class="ph ph-check-circle"></i> Tu peux payer tout ce que tu dois, et il te reste <b><?= e($f($t['reste_reel'])) ?></b>.</p>
        <?php endif; ?>
        <form method="post" data-confirm="Effacer le solde saisi ?"><?= csrf_champ() ?><input type="hidden" name="action" value="solde_effacer"><button class="lien lien-danger" type="submit">Effacer ce solde</button></form>
      <?php endif; ?>
    </section>
  </div>
</main>
<?php require __DIR__ . '/../includes/footer.php'; ?>
