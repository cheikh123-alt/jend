<?php
$u = exiger_connexion();
$produits = requete(
    'SELECT ' . SQL_PRODUIT_CARTE . ' ' . SQL_PRODUIT_JOINTURES . '
      JOIN favoris f ON f.produit_id = p.id AND f.user_id = ?
     WHERE p.statut = \'publie\' ORDER BY p.id DESC',
    [$u['id']]
)->fetchAll();

$titre = 'Mes favoris — Jënd';
require __DIR__ . '/../includes/header.php';
?>
<main class="page">
  <div class="wrap">
    <nav class="fil" aria-label="Fil d'Ariane"><a href="<?= e(url()) ?>">Accueil</a> / <a href="<?= e(url('compte')) ?>">Mon compte</a> / <span>Favoris</span></nav>
    <h1 class="titre-page">Mon compte</h1>
    <?php compte_onglets('favoris'); ?>

    <?php if (!$produits): ?>
      <div class="vide"><i class="ph ph-heart"></i><p><b>Aucun favori pour le moment.</b><br>Touchez le cœur d'un produit pour le retrouver ici.</p></div>
    <?php else: ?>
      <div class="produits mt15">
        <?php foreach ($produits as $p) { include __DIR__ . '/../includes/carte.php'; } ?>
      </div>
    <?php endif; ?>
  </div>
</main>
<?php require __DIR__ . '/../includes/footer.php'; ?>
