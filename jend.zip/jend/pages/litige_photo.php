<?php
/** Photo d'un signalement, servie seulement à son auteur et à l'administrateur (les fichiers ne sont jamais publics). $parametre = id de la photo. */
$u = exiger_connexion();
$ph = requete('SELECT p.chemin, l.client_id FROM litige_photos p JOIN litiges l ON l.id = p.litige_id WHERE p.id = ?', [(int) $parametre])->fetch();
$fichier = $ph ? dirname(__DIR__) . '/' . $ph['chemin'] : '';
if (!$ph || ((int) $ph['client_id'] !== (int) $u['id'] && $u['role'] !== 'admin') || !preg_match('#^storage/litiges/[a-f0-9]{32}\.(jpg|png)$#', $ph['chemin']) || !is_file($fichier)) {
    http_response_code(404);
    require __DIR__ . '/404.php';
    return;
}
header('Content-Type: ' . (str_ends_with($ph['chemin'], '.png') ? 'image/png' : 'image/jpeg'));
header('Content-Length: ' . filesize($fichier));
header('Cache-Control: private, no-store');
header('Content-Disposition: inline');
readfile($fichier);
