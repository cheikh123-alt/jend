<?php
$titre = 'Toutes les catégories — Jënd';
$parents = requete('SELECT id, nom, slug, icone FROM categories WHERE parent_id IS NULL ORDER BY position')->fetchAll();
$enfants = [];
foreach (requete('SELECT parent_id, nom, slug FROM categories WHERE parent_id IS NOT NULL ORDER BY position')->fetchAll() as $c) {
    $enfants[$c['parent_id']][] = $c;
}
require __DIR__ . '/../includes/header.php';
?>
<main class="page">
  <div class="wrap">
    <nav class="fil" aria-label="Fil d'Ariane"><a href="<?= e(url()) ?>">Accueil</a> / <span>Catégories</span></nav>
    <h1 class="titre-page">Toutes les catégories</h1>
    <div class="cats cats-large">
      <?php foreach ($parents as $c): ?>
        <div class="cat cat-bloc">
          <a href="<?= e(url('categorie/' . $c['slug'])) ?>"><i class="ph <?= e($c['icone'] ?: 'ph-package') ?>"></i><b><?= e($c['nom']) ?></b></a>
          <?php foreach ($enfants[$c['id']] ?? [] as $s): ?>
            <a class="sous" href="<?= e(url('categorie/' . $s['slug'])) ?>"><?= e($s['nom']) ?></a>
          <?php endforeach; ?>
        </div>
      <?php endforeach; ?>
    </div>
  </div>
</main>
<?php require __DIR__ . '/../includes/footer.php'; ?>
