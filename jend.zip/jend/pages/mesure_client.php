<?php
/** « Sur mesure » côté client : ses demandes, les devis reçus, le paiement. */
$u = exiger_connexion();
if (post_verifie('sur-mesure')) {
    try {
        $id = (int) ($_POST['id'] ?? 0);
        $action = (string) ($_POST['action'] ?? '');
        if ($action === 'accepter') {
            $produitId = demande_accepter($id, (int) $u['id'], ctype_digit((string) ($_POST['prix'] ?? '')) ? (int) $_POST['prix'] : -1);
            if ((int) requete('SELECT stock FROM produits WHERE id = ?', [$produitId])->fetchColumn() < 1) {
                throw new RuntimeException('Cette commande sur mesure est déjà passée : retrouvez-la dans « Commandes ».');
            }
            $_SESSION['panier'] = [$produitId => 1];
            rediriger('commande');
        }
        demande_fermer_client($id, (int) $u['id'], $action);
        flash($action === 'refuser' ? 'Devis refusé.' : 'Demande annulée.');
    } catch (RuntimeException $e) {
        flash($e->getMessage(), 'erreur');
    }
    rediriger('sur-mesure');
}
$demandes = requete(
    'SELECT d.*, b.nom AS boutique, b.slug AS boutique_slug FROM demandes_mesure d JOIN boutiques b ON b.id = d.boutique_id WHERE d.client_id = ? ORDER BY d.id DESC LIMIT 40',
    [$u['id']]
)->fetchAll();
$titre = 'Sur mesure — Jënd';
require __DIR__ . '/../includes/header.php';
?>
<main class="page">
  <div class="wrap">
    <nav class="fil" aria-label="Fil d'Ariane"><a href="<?= e(url()) ?>">Accueil</a> / <a href="<?= e(url('compte')) ?>">Mon compte</a> / <span>Sur mesure</span></nav>
    <h1 class="titre-page">Mon compte</h1>
    <?php compte_onglets('mesure'); ?>
    <?php if (!$demandes): ?>
      <div class="tb-vide"><i class="ph ph-scissors"></i><p><b>Aucune demande sur mesure.</b><br>Ouvrez la page d'une boutique qui propose le sur-mesure pour envoyer votre demande.</p></div>
    <?php else: ?>
      <div class="offres">
        <?php foreach ($demandes as $d): $commandee = $d['statut'] === 'acceptee' && demande_commandee($d); ?>
          <article class="offre offre-<?= e(['envoyee' => 'en_attente', 'devis' => 'contre', 'acceptee' => 'acceptee'][$d['statut']] ?? 'close') ?>">
            <header><b><?= e($d['reference']) ?> · <?= e($d['boutique']) ?></b>
              <span class="badge badge-offre-<?= e(['envoyee' => 'en_attente', 'devis' => 'contre', 'acceptee' => 'acceptee'][$d['statut']] ?? 'close') ?>"><?= e($commandee ? 'Commandée' : STATUTS_DEMANDE[$d['statut']]) ?></span></header>
            <p><?= nl2br(e(mb_strimwidth($d['description'], 0, 400, '…'))) ?></p>
            <?php if ($d['prix']): ?>
              <p><b>Devis : <?= e(fcfa((int) $d['prix'])) ?></b> · prêt en <?= (int) $d['delai_jours'] ?> jour(s)<?php if ($d['reponse']): ?><br><span class="doux"><?= nl2br(e($d['reponse'])) ?></span><?php endif; ?></p>
            <?php elseif ($d['statut'] === 'refusee' && $d['reponse']): ?>
              <p class="doux"><?= nl2br(e($d['reponse'])) ?></p>
            <?php endif; ?>
            <div class="ligne-action">
              <?php if ($d['statut'] === 'devis' || ($d['statut'] === 'acceptee' && !$commandee)): ?>
                <form method="post"><?= csrf_champ() ?><input type="hidden" name="id" value="<?= (int) $d['id'] ?>"><input type="hidden" name="action" value="accepter"><input type="hidden" name="prix" value="<?= (int) $d['prix'] ?>"><button class="btn btn-primaire" type="submit"><i class="ph ph-lock-key"></i> <?= $d['statut'] === 'devis' ? 'Accepter et payer ' : 'Payer ' ?><?= e(fcfa((int) $d['prix'])) ?></button></form>
              <?php endif; ?>
              <?php if ($d['statut'] === 'devis'): ?>
                <form method="post"><?= csrf_champ() ?><input type="hidden" name="id" value="<?= (int) $d['id'] ?>"><input type="hidden" name="action" value="refuser"><button class="btn btn-contour" type="submit">Refuser le devis</button></form>
              <?php elseif ($d['statut'] === 'envoyee'): ?>
                <form method="post" data-confirm="Annuler cette demande ?"><?= csrf_champ() ?><input type="hidden" name="id" value="<?= (int) $d['id'] ?>"><input type="hidden" name="action" value="annuler"><button class="lien lien-danger" type="submit">Annuler la demande</button></form>
              <?php endif; ?>
            </div>
          </article>
        <?php endforeach; ?>
      </div>
    <?php endif; ?>
  </div>
</main>
<?php require __DIR__ . '/../includes/footer.php'; ?>
