<?php
if ($deja = utilisateur()) {
    rediriger(espace_du_role((string) $deja['role']));
}
$titre = 'Connexion — Jënd';
$erreur = null;
$email = '';
$retour = $_GET['retour'] ?? $_POST['retour'] ?? '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim((string) ($_POST['email'] ?? ''));
    if (!csrf_valide($_POST['csrf'] ?? null)) {
        $erreur = 'Session expirée, merci de réessayer.';
    } else {
        $erreur = tenter_connexion($email, (string) ($_POST['mot_de_passe'] ?? ''), $retour, url('compte'));
    }
}
require __DIR__ . '/../includes/header.php';
?>
<main class="page">
  <div class="wrap wrap-etroit">
    <h1 class="titre-page">Connexion</h1>
    <?php if (str_contains((string) $retour, 'commande')): ?><p class="alerte alerte-info"><i class="ph ph-shopping-cart"></i> <span><b>Votre panier est gardé.</b> <?= basename(__FILE__) === 'connexion.php' ? 'Connectez-vous' : 'Créez votre compte en une minute' ?> pour finaliser la commande : nous en avons besoin pour vous envoyer le suivi et le code de réception.</span></p><?php endif; ?>
    <form method="post" class="formulaire" novalidate>
      <?= csrf_champ() ?>
      <input type="hidden" name="retour" value="<?= e($retour) ?>">
      <?php if ($erreur): ?><p class="alerte" role="alert"><?= e($erreur) ?></p><?php endif; ?>
      <label class="champ"><span>E-mail</span><input type="email" name="email" value="<?= e($email) ?>" autocomplete="email" required autofocus></label>
      <label class="champ"><span>Mot de passe</span><input type="password" name="mot_de_passe" autocomplete="current-password" required></label>
      <button class="btn btn-primaire" type="submit">Se connecter</button>
      <p class="doux"><a class="lien" href="<?= e(url('mot-de-passe-oublie')) ?>">Mot de passe oublié ?</a></p>
      <p class="doux">Pas encore de compte ? <a class="lien" href="<?= e(url('inscription' . ($retour ? '?retour=' . urlencode($retour) : ''))) ?>">Créer un compte</a></p>
    </form>
  </div>
</main>
<?php require __DIR__ . '/../includes/footer.php'; ?>
