<?php
$titre = 'Page introuvable — Jënd';
require __DIR__ . '/../includes/header.php';
?>
<main>
  <section class="perdu">
    <div class="wrap">
      <span class="perdu-chiffre" aria-hidden="true">404</span>
      <p class="entree-dico"><b>introuvable</b> <i>adj.</i> — ce que l'on cherche à l'étal d'à côté.</p>
      <h1>Oups, cette page s'est perdue au marché.</h1>
      <p class="intro">Le lien est peut-être ancien, ou le produit n'est plus en vente. Revenez à l'étalage, on vous y retrouve.</p>
      <div class="cta"><a href="<?= e(url()) ?>" class="btn btn-primaire">Retour à l'accueil <i class="ph ph-arrow-right"></i></a> <a href="<?= e(url('produits')) ?>" class="btn btn-contour">Voir l'étalage</a></div>
    </div>
  </section>
</main>
<?php require __DIR__ . '/../includes/footer.php'; ?>
