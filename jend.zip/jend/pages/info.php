<?php
// Pages d'information et pages juridiques (contenu : includes/legal.php). Variable reçue du routeur : $doc.
$documents = documents_legaux();
if (!isset($doc, $documents[$doc])) {
    http_response_code(404);
    require __DIR__ . '/404.php';
    return;
}
$titre = $documents[$doc] . ' — Jënd';
require __DIR__ . '/../includes/header.php';
?>
<main class="page">
  <div class="wrap wrap-moyen">
    <h1 class="titre-page"><?= e($documents[$doc]) ?></h1>
    <div class="texte-legal"><?= contenu_document($doc) /* HTML préparé par legal.php : toutes les valeurs dynamiques y sont échappées */ ?></div>
  </div>
</main>
<?php require __DIR__ . '/../includes/footer.php'; ?>
