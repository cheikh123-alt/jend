<?php
/** Création / modification d'un produit. $parametre = id du produit, ou null pour un nouveau. */
[$u, $b] = exiger_vendeur();
$id = $parametre !== null ? (int) $parametre : 0;
$produit = null;
if ($id) {
    $produit = requete('SELECT * FROM produits WHERE id = ? AND boutique_id = ? AND reserve_client_id IS NULL', [$id, $b['id']])->fetch();   // jamais le produit d'un autre vendeur
    if (!$produit) {
        http_response_code(404);
        require __DIR__ . '/404.php';
        return;
    }
}
$images = $id ? requete('SELECT id, chemin FROM produit_images WHERE produit_id = ? ORDER BY position, id', [$id])->fetchAll() : [];
$taillesActuelles = [];                                     // libellé => stock (tailles / pointures déjà enregistrées)
foreach ($id ? variantes_produit($id) : [] as $vr) {
    $taillesActuelles[(string) $vr['libelle']] = (int) $vr['stock'];
}

$v = [
    'nom' => $produit['nom'] ?? '', 'categorie_id' => (string) ($produit['categorie_id'] ?? ''), 'description' => $produit['description'] ?? '',
    'prix' => (string) ($produit['prix'] ?? ''), 'prix_barre' => (string) ($produit['prix_barre'] ?? ''),
    'stock' => (string) ($produit['stock'] ?? '1'), 'statut' => $produit['statut'] ?? 'brouillon',
    'video_url' => (string) ($produit['video_url'] ?? ''),
];
$erreurs = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    foreach ($v as $k => $_) {
        $v[$k] = trim((string) ($_POST[$k] ?? ''));
    }
    if (!csrf_valide($_POST['csrf'] ?? null)) {
        $erreurs[] = 'Session expirée, merci de réessayer.';
    }
    if (mb_strlen($v['nom']) < 3 || mb_strlen($v['nom']) > 190) {
        $erreurs[] = 'Le nom du produit doit faire entre 3 et 190 caractères.';
    }
    if (!requete('SELECT 1 FROM categories WHERE id = ?', [(int) $v['categorie_id']])->fetch()) {
        $erreurs[] = 'Choisissez une catégorie.';
    }
    if (mb_strlen($v['description']) > 5000) {
        $erreurs[] = 'La description est limitée à 5000 caractères.';
    }
    if (!ctype_digit($v['prix']) || (int) $v['prix'] < 100 || (int) $v['prix'] > 100000000) {
        $erreurs[] = 'Le prix doit être un nombre entier de FCFA (100 minimum).';
    }
    $prixBarre = null;
    if ($v['prix_barre'] !== '') {
        if (!ctype_digit($v['prix_barre']) || (int) $v['prix_barre'] <= (int) $v['prix']) {
            $erreurs[] = 'L\'ancien prix (promotion) doit être supérieur au prix actuel.';
        } else {
            $prixBarre = (int) $v['prix_barre'];
        }
    }
    // Tailles / pointures : seulement si la catégorie en propose ; le stock du produit devient la somme des tailles
    $typeTailles = categorie_option((int) $v['categorie_id']);
    $lignesTailles = [];
    if ($typeTailles && !empty($_POST['avec_tailles'])) {
        foreach ((array) ($_POST['variantes'][$typeTailles] ?? []) as $r) {
            $lib = trim(preg_replace('/\s+/u', ' ', (string) ($r['libelle'] ?? '')));
            if (empty($r['actif']) || $lib === '') {
                continue;
            }
            $st = trim((string) ($r['stock'] ?? '')) === '' ? '0' : trim((string) $r['stock']);
            if (mb_strlen($lib) > 20 || !ctype_digit($st) || (int) $st > 100000) {
                $erreurs[] = 'Taille « ' . mb_substr($lib, 0, 25) . ' » : nom de 20 caractères maximum et stock en nombre entier.';
                continue;
            }
            foreach ($lignesTailles as $deja => $_) {
                if (mb_strtolower((string) $deja) === mb_strtolower($lib)) {
                    $erreurs[] = 'La taille « ' . $lib . ' » est indiquée deux fois.';
                    continue 2;
                }
            }
            $lignesTailles[$lib] = $st;
        }
        if (!$lignesTailles && !$erreurs) {
            $erreurs[] = 'Cochez au moins une ' . mb_strtolower(option_libelle($typeTailles)) . ' disponible (ou décochez « Ce produit existe en plusieurs tailles »).';
        }
        if (count($lignesTailles) > VARIANTES_MAX) {
            $erreurs[] = 'Maximum ' . VARIANTES_MAX . ' tailles par produit.';
        }
        $v['stock'] = (string) array_sum(array_map('intval', $lignesTailles));
    }
    if (!ctype_digit($v['stock']) || (int) $v['stock'] > 100000) {
        $erreurs[] = 'Le stock doit être un nombre entier (0 ou plus).';
    }
    if (!in_array($v['statut'], ['brouillon', 'publie'], true) && !($produit && $v['statut'] === 'archive')) {
        $v['statut'] = 'brouillon';
    }

    // Photos : celles à supprimer, puis les nouvelles
    $aSupprimer = array_map('intval', (array) ($_POST['supprimer_images'] ?? []));
    $gardees = array_filter($images, fn($i) => !in_array((int) $i['id'], $aSupprimer, true));
    $video = video_url_valide($v['video_url']);
    if ($video === null) {
        $erreurs[] = 'Lien de vidéo refusé : collez un lien https de TikTok, YouTube, Instagram ou Facebook.';
    }
    $voixEnvoyee = ($_FILES['voix']['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_NO_FILE ? $_FILES['voix'] : null;
    $retirerVoix = !empty($_POST['supprimer_voix']);
    $nouvelles = fichiers_envoyes('photos');
    if (count($gardees) + count($nouvelles) > IMAGES_PAR_PRODUIT) {
        $erreurs[] = 'Maximum ' . IMAGES_PAR_PRODUIT . ' photos par produit.';
    }

    $enregistrees = [];
    $nouvelleVoix = null;
    if (!$erreurs) {
        try {
            foreach ($nouvelles as $f) {
                $enregistrees[] = image_enregistrer($f);
            }
            $nouvelleVoix = $voixEnvoyee ? voix_enregistrer($voixEnvoyee) : null;
        } catch (RuntimeException $e) {
            array_map('image_supprimer', $enregistrees);      // pas de photos orphelines si l'enregistrement vocal est refusé
            $enregistrees = [];
            $erreurs[] = $e->getMessage();
        }
    }

    if (!$erreurs) {
        $pdo = pdo();
        $pdo->beginTransaction();
        try {
            if ($produit) {
                requete('UPDATE produits SET categorie_id = ?, nom = ?, description = ?, prix = ?, prix_barre = ?, stock = ?, statut = ?, video_url = ? WHERE id = ? AND boutique_id = ?',
                    [(int) $v['categorie_id'], $v['nom'], $v['description'] !== '' ? $v['description'] : null, (int) $v['prix'], $prixBarre, (int) $v['stock'], $v['statut'], $video ?: null, $id, $b['id']]);
            } else {
                requete('INSERT INTO produits (boutique_id, categorie_id, nom, slug, description, prix, prix_barre, stock, statut, video_url) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
                    [$b['id'], (int) $v['categorie_id'], $v['nom'], produit_slug_unique($v['nom']), $v['description'] !== '' ? $v['description'] : null, (int) $v['prix'], $prixBarre, (int) $v['stock'], $v['statut'], $video ?: null]);
                $id = (int) $pdo->lastInsertId();
            }
            $retirees = [];
            foreach ($images as $i) {
                if (in_array((int) $i['id'], $aSupprimer, true)) {
                    requete('DELETE FROM produit_images WHERE id = ? AND produit_id = ?', [$i['id'], $id]);
                    $retirees[] = $i['chemin'];
                }
            }
            variantes_enregistrer($id, $typeTailles, $lignesTailles);      // tailles (ou suppression des anciennes) + stock recalculé
            $ancienneVoix = $produit['voix_chemin'] ?? null;
            if ($nouvelleVoix || $retirerVoix) {
                requete('UPDATE produits SET voix_chemin = ? WHERE id = ? AND boutique_id = ?', [$nouvelleVoix, $id, $b['id']]);
            }
            $pos = (int) requete('SELECT COALESCE(MAX(position), -1) + 1 FROM produit_images WHERE produit_id = ?', [$id])->fetchColumn();
            foreach ($enregistrees as $chemin) {
                requete('INSERT INTO produit_images (produit_id, chemin, position) VALUES (?, ?, ?)', [$id, $chemin, $pos++]);
            }
            $pdo->commit();
            foreach ($retirees as $chemin) {
                image_supprimer($chemin);
            }
            if (($nouvelleVoix || $retirerVoix) && $ancienneVoix) {
                voix_supprimer($ancienneVoix);
            }
            alertes_produit_verifier($id);            // « Prévenez-moi » : baisse de prix ou retour en stock
            flash($produit ? 'Produit mis à jour.' : 'Produit créé.');
            rediriger('vendeur/produits');
        } catch (Throwable $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            foreach ($enregistrees as $chemin) {
                image_supprimer($chemin);          // pas de fichiers orphelins si la base refuse
            }
            voix_supprimer($nouvelleVoix);
            if ($e instanceof RuntimeException) {
                $erreurs[] = $e->getMessage();
            } else {
                error_log('Jënd — enregistrement produit : ' . $e->getMessage());
                $erreurs[] = 'Une erreur est survenue, le produit n\'a pas été enregistré.';
            }
        }
    } else {
        foreach ($enregistrees as $chemin) {
            image_supprimer($chemin);
        }
    }
}

$arbre = categories_arbre();
$titre = ($produit ? 'Modifier ' . $produit['nom'] : 'Nouveau produit') . ' — Jënd';
$scripts_extra = ['js/voix.js', 'js/tailles.js'];
require __DIR__ . '/../includes/header.php';
?>
<main class="page">
  <div class="wrap">
    <nav class="fil" aria-label="Fil d'Ariane"><a href="<?= e(url()) ?>">Accueil</a> / <a href="<?= e(url('vendeur/produits')) ?>">Produits</a> / <span><?= $produit ? 'Modifier' : 'Nouveau' ?></span></nav>
    <h1 class="titre-page"><?= $produit ? 'Modifier le produit' : 'Nouveau produit' ?></h1>

    <?php if ($b['statut'] !== 'active'): ?>
      <p class="alerte alerte-info"><i class="ph ph-info"></i> Votre boutique n'est pas encore validée : ce produit ne sera visible qu'après validation.</p>
    <?php endif; ?>

    <form method="post" enctype="multipart/form-data" class="formulaire formulaire-large largeur-720" novalidate>
      <?= csrf_champ() ?>
      <?php foreach ($erreurs as $er): ?><p class="alerte" role="alert"><?= e($er) ?></p><?php endforeach; ?>

      <label class="champ"><span>Nom du produit</span><input type="text" name="nom" value="<?= e($v['nom']) ?>" maxlength="190" required></label>
      <label class="champ"><span>Catégorie</span>
        <select name="categorie_id" required>
          <option value="">— Choisir —</option>
          <?php foreach ($arbre as $c): ?>
            <option value="<?= $c['id'] ?>" data-option="<?= e((string) categorie_option((int) $c['id'])) ?>" <?= (string) $c['id'] === $v['categorie_id'] ? 'selected' : '' ?>><?= e($c['nom']) ?></option>
            <?php foreach ($c['enfants'] as $s): ?>
              <option value="<?= $s['id'] ?>" data-option="<?= e((string) categorie_option((int) $s['id'])) ?>" <?= (string) $s['id'] === $v['categorie_id'] ? 'selected' : '' ?>>&nbsp;&nbsp;↳ <?= e($s['nom']) ?></option>
            <?php endforeach; ?>
          <?php endforeach; ?>
        </select>
      </label>
      <label class="champ"><span>Description</span><textarea name="description" rows="6" maxlength="5000" placeholder="Matière, dimensions, état, garantie…"><?= e($v['description']) ?></textarea></label>

      <div class="trois-champs">
        <label class="champ"><span>Prix (FCFA)</span><input type="number" name="prix" value="<?= e($v['prix']) ?>" min="100" step="1" required>
          <small class="doux"><?= (float) $b['commission_pct'] > 0 ? 'Jënd retient <b>' . e(commission_texte((float) $b['commission_pct'])) . ' %</b> de ce prix quand la commande est livrée et payée (taux modifiable avec ' . COMMISSION_PREAVIS_JOURS . ' jours de préavis).' : 'Aucune commission de Jënd pour le moment (le taux peut évoluer avec ' . COMMISSION_PREAVIS_JOURS . ' jours de préavis).' ?></small></label>
        <label class="champ"><span>Ancien prix (promo)</span><input type="number" name="prix_barre" value="<?= e($v['prix_barre']) ?>" min="0" step="1" placeholder="optionnel"></label>
        <label class="champ" id="champ-stock"><span>Stock</span><input type="number" name="stock" value="<?= e($v['stock']) ?>" min="0" step="1" required>
          <small class="doux" id="stock-tailles" hidden>Avec des tailles, le stock est la somme des stocks de chaque taille.</small></label>
        <label class="champ"><span>Vidéo du produit (facultatif)</span><input type="url" name="video_url" value="<?= e($v['video_url']) ?>" maxlength="255" placeholder="https://www.tiktok.com/@vous/video/…">
          <small class="doux">Collez le lien de votre vidéo TikTok, YouTube, Instagram ou Facebook : un bouton « Voir la vidéo » s'affichera sur la fiche du produit.</small></label>
      </div>

      <?php
      $typeActuel = $v['categorie_id'] !== '' ? categorie_option((int) $v['categorie_id']) : null;
      $avecTailles = $_SERVER['REQUEST_METHOD'] === 'POST' ? !empty($_POST['avec_tailles']) : (bool) $taillesActuelles;
      ?>
      <section class="tailles-bloc" id="tailles-bloc" <?= $typeActuel ? '' : 'hidden' ?>>
        <label class="case"><input type="checkbox" name="avec_tailles" value="1" id="avec-tailles" <?= $avecTailles ? 'checked' : '' ?>>
          <span><b>Ce produit existe en plusieurs tailles</b> : le client devra choisir la sienne (stock suivi taille par taille)</span></label>
        <?php foreach (OPTIONS_PRODUIT as $type => [$mot, $preselection]):
            $postees = $_SERVER['REQUEST_METHOD'] === 'POST' ? (array) ($_POST['variantes'][$type] ?? []) : null;
            $actuelles = ($produit['option_type'] ?? null) === $type ? $taillesActuelles : [];
            $libelles = array_values(array_unique(array_merge($preselection, array_map('strval', array_keys($actuelles)))));
            $i = 0; ?>
          <div class="tailles-grille" data-type="<?= e($type) ?>" <?= $type === $typeActuel ? '' : 'hidden' ?>>
            <p class="doux petit">Cochez les <?= e(mb_strtolower($mot)) ?>s disponibles et indiquez le stock de chacune.</p>
            <?php foreach ($libelles as $lib):
                $coche = $postees !== null ? !empty(array_filter($postees, fn ($r) => ($r['libelle'] ?? '') === $lib && !empty($r['actif']))) : array_key_exists($lib, $actuelles);
                $stockLib = $postees !== null ? (string) (array_values(array_filter($postees, fn ($r) => ($r['libelle'] ?? '') === $lib))[0]['stock'] ?? '') : (string) ($actuelles[$lib] ?? ''); ?>
              <label class="taille-ligne"><input type="checkbox" name="variantes[<?= e($type) ?>][<?= $i ?>][actif]" value="1" <?= $coche ? 'checked' : '' ?>>
                <input type="hidden" name="variantes[<?= e($type) ?>][<?= $i ?>][libelle]" value="<?= e($lib) ?>"><b><?= e($lib) ?></b>
                <input type="number" name="variantes[<?= e($type) ?>][<?= $i++ ?>][stock]" value="<?= e($stockLib) ?>" min="0" step="1" placeholder="stock" aria-label="Stock <?= e($lib) ?>"></label>
            <?php endforeach; ?>
            <?php for ($k = 0; $k < 3; $k++): ?>
              <label class="taille-ligne taille-autre"><input type="checkbox" name="variantes[<?= e($type) ?>][<?= $i ?>][actif]" value="1">
                <input type="text" name="variantes[<?= e($type) ?>][<?= $i ?>][libelle]" maxlength="20" placeholder="Autre (ex. <?= $type === 'pointure' ? '48' : ($type === 'taille' ? 'Taille unique' : '16 ans') ?>)" aria-label="Autre <?= e(mb_strtolower($mot)) ?>">
                <input type="number" name="variantes[<?= e($type) ?>][<?= $i++ ?>][stock]" min="0" step="1" placeholder="stock" aria-label="Stock"></label>
            <?php endfor; ?>
          </div>
        <?php endforeach; ?>
      </section>

      <div class="champ">
        <span>Photos (JPEG ou PNG, 3 Mo max, <?= IMAGES_PAR_PRODUIT ?> maximum)</span>
        <?php if ($images): ?>
          <div class="photos-existantes">
            <?php foreach ($images as $img): ?>
              <label class="photo-existante"><img src="<?= e(url($img['chemin'])) ?>" alt=""><span><input type="checkbox" name="supprimer_images[]" value="<?= (int) $img['id'] ?>"> Supprimer</span></label>
            <?php endforeach; ?>
          </div>
        <?php endif; ?>
        <input type="file" name="photos[]" accept="image/jpeg,image/png" multiple>
      </div>

      <div class="champ voix-bloc" id="voix-bloc">
        <span>Description vocale (facultatif) — parlez de votre produit en wolof, en français… (1 minute maximum)</span>
        <?php if (!empty($produit['voix_chemin'])): ?>
          <div class="voix-actuelle"><audio controls preload="none" src="<?= e(url($produit['voix_chemin'])) ?>"></audio>
            <label class="case"><input type="checkbox" name="supprimer_voix" value="1"> <span>Supprimer cet enregistrement</span></label></div>
        <?php endif; ?>
        <div class="voix-enregistreur" hidden>
          <button type="button" class="btn btn-contour" id="voix-demarrer"><i class="ph ph-microphone"></i> Enregistrer ma voix</button>
          <button type="button" class="btn btn-primaire" id="voix-arreter" hidden><i class="ph ph-stop"></i> Arrêter (<span id="voix-chrono">0</span> s)</button>
          <audio id="voix-apercu" controls hidden></audio>
        </div>
        <input type="file" name="voix" id="voix-fichier" accept="audio/*,.ogg,.opus,.m4a,.mp3,.webm">
        <small class="doux" id="voix-aide">Ou choisissez un fichier audio (par exemple un message vocal WhatsApp enregistré sur votre téléphone). Il remplacera l'enregistrement actuel.</small>
      </div>

      <label class="champ"><span>Statut</span>
        <select name="statut">
          <option value="brouillon" <?= $v['statut'] === 'brouillon' ? 'selected' : '' ?>>Brouillon (non visible)</option>
          <option value="publie" <?= $v['statut'] === 'publie' ? 'selected' : '' ?>>En vente</option>
          <?php if ($produit && $produit['statut'] === 'archive'): ?><option value="archive" selected>Retiré de la vente</option><?php endif; ?>
        </select>
      </label>
      <button class="btn btn-primaire" type="submit"><?= $produit ? 'Enregistrer' : 'Créer le produit' ?></button>
    </form>
  </div>
</main>
<?php require __DIR__ . '/../includes/footer.php'; ?>
