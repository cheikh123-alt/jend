<?php
/** Aide et contact : coordonnées de l'équipe + formulaire (clients, vendeurs, visiteurs). */
$u = utilisateur();
$v = ['nom' => '', 'email' => '', 'telephone' => (string) ($u['telephone'] ?? ''), 'sujet' => (string) ($_GET['sujet'] ?? ''), 'commande' => (string) ($_GET['commande'] ?? ''), 'message' => ''];
if ($u && $u['role'] === 'vendeur' && $v['sujet'] === '') {
    $v['sujet'] = 'boutique';
}
$erreur = null;
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    foreach ($v as $k => $_) {
        $v[$k] = trim((string) ($_POST[$k] ?? ''));
    }
    if (!csrf_valide($_POST['csrf'] ?? null)) {
        $erreur = 'Session expirée, merci de réessayer.';
    } elseif (trim((string) ($_POST['site_web'] ?? '')) !== '') {
        rediriger('contact');                              // champ invisible rempli : robot, on ignore sans rien dire
    } else {
        try {
            $ref = support_envoyer($u, $v['nom'], $v['email'], $v['telephone'], $v['sujet'], $v['commande'], $v['message']);
            flash('Message envoyé (référence ' . $ref . '). Nous vous répondons sous ' . SUPPORT_DELAI_HEURES . ' heures par e-mail' . ($u ? ' et dans cette conversation, où vous pourrez nous répondre.' : ', avec un lien pour suivre la conversation.'));
            rediriger($u ? 'aide/' . $ref : 'contact');
        } catch (RuntimeException $e) {
            $erreur = $e->getMessage();
        }
    }
}
$email = societe('email');
$tel = societe('telephone');
$wa = preg_replace('/\D/', '', $tel);
$titre = 'Aide et contact — Jënd';
require __DIR__ . '/../includes/header.php';
?>
<main class="page">
  <div class="wrap wrap-moyen">
    <nav class="fil" aria-label="Fil d'Ariane"><a href="<?= e(url()) ?>">Accueil</a> / <span>Aide et contact</span></nav>
    <h1 class="titre-page">Aide et contact</h1>
    <p class="doux">Un problème avec le site, votre compte, un paiement ou votre boutique ? Écrivez-nous : nous répondons sous <?= SUPPORT_DELAI_HEURES ?> heures, du lundi au samedi.</p>

    <div class="contact-raccourcis">
      <?php if ($u): ?><a class="contact-carte" href="<?= e(url('litiges')) ?>"><i class="ph-fill ph-package"></i><span><b>Problème avec une livraison ?</b><small>Colis non reçu, abîmé ou non conforme : faites un signalement depuis la commande, c'est plus rapide.</small></span></a><?php endif; ?>
      <?php if ($wa !== ''): ?><a class="contact-carte" href="<?= e('https://wa.me/' . $wa) ?>" target="_blank" rel="noopener noreferrer"><i class="ph-fill ph-whatsapp-logo"></i><span><b>WhatsApp</b><small><?= e($tel) ?></small></span></a><?php endif; ?>
      <?php if ($email !== ''): ?><a class="contact-carte" href="<?= e('mailto:' . $email) ?>"><i class="ph-fill ph-envelope-simple"></i><span><b>E-mail</b><small><?= e($email) ?></small></span></a><?php endif; ?>
    </div>

    <form method="post" class="formulaire formulaire-large" novalidate>
      <?= csrf_champ() ?>
      <h2 class="sous-titre">Nous écrire</h2>
      <?php if ($erreur): ?><p class="alerte" role="alert"><?= e($erreur) ?></p><?php endif; ?>
      <?php if ($u): ?>
        <p class="doux">Vous écrivez en tant que <b><?= e($u['nom']) ?></b> (<?= e($u['email']) ?>).</p>
      <?php else: ?>
        <label class="champ"><span>Votre nom</span><input type="text" name="nom" value="<?= e($v['nom']) ?>" maxlength="120" required autocomplete="name"></label>
        <label class="champ"><span>Votre e-mail (pour la réponse)</span><input type="email" name="email" value="<?= e($v['email']) ?>" maxlength="190" required autocomplete="email"></label>
      <?php endif; ?>
      <label class="champ"><span>Téléphone (facultatif)</span><input type="tel" name="telephone" value="<?= e($v['telephone']) ?>" placeholder="77 123 45 67"></label>
      <label class="champ"><span>Sujet</span><select name="sujet" required><option value="">— Choisir —</option>
        <?php foreach (SUJETS_SUPPORT as $k => $lib): ?><option value="<?= e($k) ?>" <?= $v['sujet'] === $k ? 'selected' : '' ?>><?= e($lib) ?></option><?php endforeach; ?></select></label>
      <label class="champ"><span>Numéro de commande (si ça concerne une commande)</span><input type="text" name="commande" value="<?= e($v['commande']) ?>" maxlength="20" placeholder="JND-261012-A4F2"></label>
      <label class="champ"><span>Votre message</span><textarea name="message" rows="6" maxlength="3000" required><?= e($v['message']) ?></textarea></label>
      <label class="champ champ-cache" aria-hidden="true"><span>Site web</span><input type="text" name="site_web" tabindex="-1" autocomplete="off"></label>
      <p class="doux petit">Ne nous envoyez jamais votre mot de passe ni votre code de livraison : nous ne vous les demanderons jamais.</p>
      <button class="btn btn-primaire" type="submit"><i class="ph ph-paper-plane-tilt"></i> Envoyer</button>
    </form>
  </div>
</main>
<?php require __DIR__ . '/../includes/footer.php'; ?>
