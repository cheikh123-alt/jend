<?php
/** Demandes sur mesure reçues par le vendeur : envoyer un devis (prix + délai) ou décliner. */
[$u, $b] = exiger_vendeur();
if (post_verifie('vendeur/sur-mesure')) {
    try {
        $id = (int) ($_POST['id'] ?? 0);
        $action = (string) ($_POST['action'] ?? '');
        if ($action === 'devis') {
            $prix = trim((string) ($_POST['prix'] ?? ''));
            $delai = trim((string) ($_POST['delai'] ?? ''));
            if (!ctype_digit($prix) || !ctype_digit($delai)) {
                throw new RuntimeException('Indiquez un prix et un délai en nombres entiers.');
            }
            demande_devis($id, (int) $b['id'], (int) $prix, (int) $delai, (string) ($_POST['message'] ?? ''));
            flash('Devis envoyé au client.');
        } elseif ($action === 'refuser') {
            demande_refuser_vendeur($id, (int) $b['id'], (string) ($_POST['message'] ?? ''));
            flash('Demande déclinée.');
        }
    } catch (RuntimeException $e) {
        flash($e->getMessage(), 'erreur');
    }
    rediriger('vendeur/sur-mesure');
}
$demandes = requete(
    "SELECT d.*, u.nom AS client FROM demandes_mesure d JOIN users u ON u.id = d.client_id WHERE d.boutique_id = ? ORDER BY (d.statut = 'envoyee') DESC, d.id DESC LIMIT 60",
    [$b['id']]
)->fetchAll();
$titre = 'Sur mesure — Jënd';
require __DIR__ . '/../includes/header.php';
?>
<main class="page">
  <div class="wrap">
    <nav class="fil" aria-label="Fil d'Ariane"><a href="<?= e(url()) ?>">Accueil</a> / <a href="<?= e(url('vendeur')) ?>">Boutique</a> / <span>Sur mesure</span></nav>
    <h1 class="titre-page"><?= e($b['nom']) ?></h1>
    <?php vendeur_onglets('mesure'); ?>
    <p class="doux">Vos clients vous décrivent ce qu'ils veulent. Répondez par un <b>prix</b> (tout compris, hors livraison) et un <b>délai</b>. Quand le client accepte et paie, la commande apparaît dans « Commandes » comme n'importe quelle vente : préparez-la, puis confirmez la livraison.
      <?php if ((int) $b['sur_mesure'] !== 1): ?><br><b>Le sur-mesure est désactivé</b> pour votre boutique : activez-le dans l'onglet « Boutique » pour recevoir des demandes.<?php endif; ?></p>
    <?php if (!$demandes): ?>
      <div class="tb-vide"><i class="ph ph-scissors"></i><p><b>Aucune demande pour le moment.</b></p></div>
    <?php else: ?>
      <div class="offres">
        <?php foreach ($demandes as $d): $ouverte = in_array($d['statut'], ['envoyee', 'devis'], true); ?>
          <article class="offre offre-<?= e(['envoyee' => 'en_attente', 'devis' => 'contre', 'acceptee' => 'acceptee'][$d['statut']] ?? 'close') ?>">
            <header><b><?= e($d['reference']) ?> · <?= e(explode(' ', $d['client'])[0]) ?></b>
              <span class="badge badge-offre-<?= e(['envoyee' => 'en_attente', 'devis' => 'contre', 'acceptee' => 'acceptee'][$d['statut']] ?? 'close') ?>"><?= e($d['statut'] === 'envoyee' ? 'Devis à envoyer' : ($d['statut'] === 'devis' ? 'Devis envoyé' : STATUTS_DEMANDE[$d['statut']])) ?></span></header>
            <p><?= nl2br(e($d['description'])) ?></p>
            <?php if ($d['mesures']): ?><p class="doux"><b>Mesures :</b> <?= nl2br(e($d['mesures'])) ?></p><?php endif; ?>
            <p class="doux petit"><?= e(date('d/m/Y', strtotime($d['created_at']))) ?><?= $d['budget'] ? ' · budget : ' . e(fcfa((int) $d['budget'])) : '' ?><?= $d['date_souhaitee'] ? ' · souhaité pour le ' . e(date('d/m/Y', strtotime($d['date_souhaitee']))) : '' ?>
              <?php if ($d['prix']): ?> · <b>votre devis : <?= e(fcfa((int) $d['prix'])) ?>, <?= (int) $d['delai_jours'] ?> j</b><?php endif; ?></p>
            <?php if ($ouverte): ?>
              <form method="post" class="formulaire formulaire-large devis-form"><?= csrf_champ() ?><input type="hidden" name="id" value="<?= (int) $d['id'] ?>">
                <div class="devis-champs">
                  <label class="champ"><span>Prix (FCFA)</span><input type="text" name="prix" inputmode="numeric" value="<?= $d['prix'] ? (int) $d['prix'] : '' ?>"></label>
                  <label class="champ"><span>Délai (jours)</span><input type="text" name="delai" inputmode="numeric" value="<?= $d['delai_jours'] ? (int) $d['delai_jours'] : '' ?>"></label>
                </div>
                <label class="champ"><span>Message au client (facultatif)</span><textarea name="message" rows="2" maxlength="1000"><?= e((string) $d['reponse']) ?></textarea></label>
                <div class="ligne-action">
                  <button class="btn btn-primaire" type="submit" name="action" value="devis"><i class="ph ph-paper-plane-tilt"></i> <?= $d['statut'] === 'devis' ? 'Modifier mon devis' : 'Envoyer le devis' ?></button>
                  <button class="lien lien-danger" type="submit" name="action" value="refuser" formnovalidate>Décliner la demande</button>
                </div>
              </form>
            <?php endif; ?>
          </article>
        <?php endforeach; ?>
      </div>
    <?php endif; ?>
  </div>
</main>
<?php require __DIR__ . '/../includes/footer.php'; ?>
