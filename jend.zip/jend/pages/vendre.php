<?php
$titre = 'Vendre sur Jënd';
$u = utilisateur();
if ($u && $u['role'] === 'livreur') {
    flash('Un compte livreur ne peut pas ouvrir de boutique.', 'erreur');
    rediriger('livreur');
}
$existante = $u ? requete('SELECT id FROM boutiques WHERE user_id = ?', [$u['id']])->fetch() : null;
if ($existante) {
    rediriger('vendeur');
}

// Parrainage : le code arrive par le lien (?parrain=CODE) et est gardé en session jusqu'à la création de la boutique
if (isset($_GET['parrain']) && preg_match('/^[A-Z0-9]{6,12}$/', strtoupper((string) $_GET['parrain']))) {
    $_SESSION['parrain'] = strtoupper((string) $_GET['parrain']);
}
$parrain = !empty($_SESSION['parrain']) ? requete("SELECT id, nom FROM boutiques WHERE code_parrain = ? AND statut = 'active'", [$_SESSION['parrain']])->fetch() : null;
$erreurs = [];
$v = ['nom' => '', 'description' => '', 'telephone' => $u['telephone'] ?? ''];
$modeSimple = false;
$whatsapp = true;

if ($u && $_SERVER['REQUEST_METHOD'] === 'POST') {
    exiger_email_confirme($u);
    foreach ($v as $k => $_) {
        $v[$k] = trim((string) ($_POST[$k] ?? ''));
    }
    $tel = telephone_valide($v['telephone']);
    $modeSimple = ($_POST['mode'] ?? '') === 'simple';        // espace vendeur simplifié (photo, prix, voix), modifiable ensuite
    $whatsapp = !empty($_POST['whatsapp']);                  // ce numéro est aussi son WhatsApp : les clients pourront le prévenir de leurs commandes
    if (!csrf_valide($_POST['csrf'] ?? null)) {
        $erreurs[] = 'Session expirée, merci de réessayer.';
    }
    if (mb_strlen($v['nom']) < 3 || mb_strlen($v['nom']) > 80) {
        $erreurs[] = 'Le nom de la boutique doit faire entre 3 et 80 caractères.';
    }
    if (mb_strlen($v['description']) > 1000) {
        $erreurs[] = 'La description est limitée à 1000 caractères.';
    }
    if ($tel === null) {
        $erreurs[] = 'Numéro Wave / Orange Money invalide (ex : 77 123 45 67) : c\'est là que vous recevrez vos gains.';
    }
    if (empty($_POST['accepte'])) {
        $erreurs[] = 'Vous devez accepter les conditions générales des vendeurs.';
    }
    if (!$erreurs) {
        $slug = slugify($v['nom']);
        for ($i = 2; requete('SELECT 1 FROM boutiques WHERE slug = ?', [$slug])->fetch(); $i++) {
            $slug = slugify($v['nom']) . '-' . $i;
        }
        $pdo = pdo();
        $pdo->beginTransaction();
        requete("INSERT INTO boutiques (user_id, nom, slug, description, telephone_paiement, commission_pct, statut, code_parrain, parrain_boutique_id, mode_simple, contact_whatsapp) VALUES (?, ?, ?, ?, ?, ?, 'en_attente', ?, ?, ?, ?)",
            [$u['id'], $v['nom'], $slug, $v['description'] !== '' ? $v['description'] : null, $tel, commission_defaut(), code_parrain_nouveau(), $parrain ? (int) $parrain['id'] : null, $modeSimple ? 1 : 0, $whatsapp ? $tel : null]);
        unset($_SESSION['parrain']);
        if ($u['role'] === 'client') {
            requete("UPDATE users SET role = 'vendeur' WHERE id = ?", [$u['id']]);
        }
        $pdo->commit();
        envoyer_email((string) env('ADMIN_EMAIL', 'admin@jend.local'), 'Nouvelle boutique à valider : ' . $v['nom'],
            "La boutique « {$v['nom']} » vient d'être créée par {$u['nom']} ({$u['email']}).\nValidez-la dans l'administration : " . app_url('admin/boutiques'));
        flash('Boutique créée ! Elle sera visible après validation par notre équipe. Vous pouvez déjà préparer vos produits.');
        rediriger($modeSimple ? 'simple' : 'vendeur');
    }
}
require __DIR__ . '/../includes/header.php';
?>
<?php
$commissionTxt = commission_defaut() == 0.0 ? '0 %' : commission_texte() . ' %';
$jourV = versement_jour();
$cod = paiement_livraison_actif();          // paiement à la livraison activé : on ne promet pas « déjà payé »
$enLigne = paiement_en_ligne_actif();       // paiement en ligne coupé (prestataire pas encore validé) : rien à promettre sur le paiement d'avance
$delaiR = delai_retrait_jours();
$etapes = [
    ['ph-user-plus', 'Créez votre boutique', 'Gratuitement, en quelques minutes, depuis votre téléphone.'],
    ['ph-camera', 'Publiez vos produits', 'Photos, prix, tailles, frais de livraison par zone : vous décidez de tout.'],
    !$enLigne ? ['ph-hand-coins', 'Le client paie à la livraison', 'En espèces, à la réception du colis : vous encaissez directement. Le paiement en ligne arrive bientôt.'] : ['ph-hand-coins', 'Le client paie Jënd', $cod ? 'En ligne (Wave, Orange Money, carte), ou un acompte en ligne et le reste à la livraison.' : 'Wave, Orange Money ou carte. L\'argent est déjà payé avant que vous livriez.'],
    !$enLigne ? ['ph-bank', 'Vous gardez l\'argent', 'Vous encaissez les espèces à la livraison ; la commission de Jënd figure dans votre relevé et se règle sur vos gains suivants.'] : ['ph-bank', 'Vous êtes payé', $jourV ? 'Après la livraison, versé automatiquement chaque ' . $jourV . ' sur votre Wave ou Orange Money.' : 'Après la livraison, sur votre Wave ou Orange Money.'],
];
$avantages = [
    !$enLigne ? ['ph-shield-check', 'Des livraisons prouvées', 'Chaque commande a un code de réception : la remise du colis est prouvée, et chaque vente suivie.'] : ($cod ? ['ph-shield-check', 'Moins d\'impayés', 'Un acompte confirme chaque commande payée à la livraison.']
         : ['ph-shield-check', 'Zéro impayé', 'Le client a payé avant la livraison. Fini les commandes « réservées » qui ne viennent jamais.']),
    ['ph-storefront', 'Une vraie vitrine', 'Logo, bannière, avis, chiffres de confiance : une boutique qui inspire confiance dès le premier regard.'],
    ['ph-qr-code', 'Affiche avec QR code', 'À coller sur votre étal : vos clients scannent et commandent.'],
    ['ph-whatsapp-logo', 'Fait pour WhatsApp et TikTok', 'Images prêtes pour vos statuts, lien de paiement à envoyer, textes à copier.'],
    ['ph-file-text', 'Des comptes clairs', 'Chaque vente, commission et versement détaillés dans un relevé mensuel.'],
    ['ph-scissors', 'Sur mesure et négociation', 'Recevez des demandes de devis et des propositions de prix, si vous le souhaitez.'],
];
$faq = [
    ['Combien ça coûte ?', 'L\'ouverture de la boutique est gratuite. Jënd prend une commission de ' . $commissionTxt . ' sur le prix des produits seulement quand une commande est livrée et payée. Le taux ne peut changer qu\'avec 30 jours de préavis.'],
    ['Quand suis-je payé ?', 'Après la livraison confirmée par le client (code de réception), votre part devient disponible ' . ($delaiR ? $delaiR . ' jour(s) après' : 'aussitôt') . '. ' . ($jourV ? 'Elle vous est versée automatiquement chaque ' . $jourV . ', avec la référence du transfert.' : 'Vous demandez un retrait quand vous voulez.')],
    ['Qui livre ?', 'Vous, ou le transporteur de votre choix. Vous fixez vos frais et vos délais zone par zone, et les régions où vous livrez.'],
    ['Et si un client se plaint ?', 'Il peut signaler un problème avec photos. L\'équipe Jënd examine, vous contacte et tranche de façon juste. Les gains de cette livraison sont mis de côté pendant l\'examen.'],
    ['Faut-il savoir faire un site internet ?', 'Non. Tout se fait depuis votre téléphone, comme sur WhatsApp. Votre boutique a sa propre adresse à partager.'],
];
?>
<main class="page vendre-page">
  <section class="vendre-affiche">
    <div class="wrap">
      <p class="lit-surtitre">Vendeurs, artisans, tailleurs, commerçants</p>
      <h1>Vendez dans tout le Sénégal.<br>Soyez payé sans risque.</h1>
      <p class="vendre-intro"><?= !$enLigne ? 'Vos clients commandent sur Jënd et paient en espèces à la livraison ; chaque commande est suivie et la remise prouvée par un code. Le paiement en ligne sécurisé arrive bientôt.' : ($cod ? 'Vos clients paient en ligne ou laissent un acompte, Jënd garde l\'argent, vous livrez, vous êtes payé.' : 'Vos clients paient en ligne, Jënd garde l\'argent, vous livrez, vous êtes payé. Plus de clients qui disparaissent, plus de « je paie à la livraison » qui ne paie jamais.' )?></p>
      <?php if (commission_defaut() == 0.0): ?><p class="vendre-offre"><i class="ph-fill ph-gift"></i> <b>Offre de lancement : 0 % de commission</b> — vous gardez 100 % de vos ventes.</p>
      <?php elseif (offre_lancement()): ?><p class="vendre-offre"><i class="ph-fill ph-gift"></i> <b>Offre de lancement : seulement <?= e(commission_texte()) ?> % de commission</b> sur les ventes livrées<?= ($annV = commission_annonce()) ? ', jusqu\'au ' . e(date('d/m/Y', strtotime($annV['le'] . ' -1 day'))) . ' (puis ' . e(commission_texte($annV['pct'])) . ' %)' : '' ?>.</p><?php endif; ?>
      <ul class="vendre-badges">
        <li><i class="ph-fill ph-storefront"></i> Boutique gratuite</li>
        <li><i class="ph-fill ph-percent"></i> <?= e($commissionTxt) ?> de commission<?= offre_lancement() ? ' (lancement)' : '' ?></li>
        <?php if ($jourV): ?><li><i class="ph-fill ph-calendar-check"></i> Versé chaque <?= e($jourV) ?></li><?php endif; ?>
        <li><i class="ph-fill ph-device-mobile"></i> Wave &amp; Orange Money</li>
      </ul>
      <a class="btn btn-primaire" href="#ouvrir"><i class="ph ph-arrow-down"></i> Ouvrir ma boutique</a>
    </div>
  </section>

  <div class="wrap">
    <section class="vendre-section">
      <h2 class="sous-titre">Comment ça marche</h2>
      <ol class="vendre-etapes">
        <?php foreach ($etapes as $n => [$icone, $t, $d]): ?><li><span class="vendre-num"><?= $n + 1 ?></span><i class="ph <?= e($icone) ?>"></i><b><?= e($t) ?></b><p><?= e($d) ?></p></li><?php endforeach; ?>
      </ol>
    </section>

    <section class="vendre-section">
      <h2 class="sous-titre">Ce que vous gagnez avec Jënd</h2>
      <div class="vendre-avantages">
        <?php foreach ($avantages as [$icone, $t, $d]): ?><article><i class="ph <?= e($icone) ?>"></i><b><?= e($t) ?></b><p><?= e($d) ?></p></article><?php endforeach; ?>
      </div>
    </section>

    <section class="vendre-section">
      <h2 class="sous-titre">Vendre seul sur WhatsApp, ou avec Jënd ?</h2>
      <div class="table-defile"><table class="table vendre-comparaison">
        <thead><tr><th></th><th>WhatsApp seul</th><th>Avec Jënd</th></tr></thead>
        <tbody>
          <?php if ($enLigne): ?><tr><td>Le client paie avant ?</td><td>Rarement : il a peur d'être arnaqué</td><td><b>Oui</b> : son argent est protégé jusqu'à la réception</td></tr><?php endif; ?>
          <tr><td>Commandes annulées au dernier moment</td><td>Fréquentes</td><td><?= !$enLigne ? 'Commande enregistrée, client et adresse confirmés' : ($cod ? 'Un acompte engage le client' : 'Le client a déjà payé') ?></td></tr>
          <tr><td>Votre boutique</td><td>Des photos perdues dans les statuts</td><td>Une vitrine avec avis, chiffres et recherche</td></tr>
          <tr><td>Vos comptes</td><td>Dans un cahier</td><td>Relevé mensuel détaillé</td></tr>
          <tr><td>Nouveaux clients</td><td>Vos contacts seulement</td><td>Vos contacts + les clients de Jënd partout au Sénégal</td></tr>
        </tbody>
      </table></div>
    </section>

    <section class="vendre-section vendre-ouvrir" id="ouvrir">
      <h2 class="sous-titre">Ouvrir ma boutique</h2>
    <?php if ($parrain && parrainage_jours() > 0): ?>
      <p class="alerte alerte-info"><i class="ph ph-gift"></i> <span>Vous êtes invité par <b><?= e($parrain['nom']) ?></b> : dès que votre boutique sera validée, vous gagnerez <b><?= parrainage_jours() ?> jours sans commission</b>.</span></p>
    <?php endif; ?>
    <?php if (!$u): ?>
      <div class="vide">
        <i class="ph ph-storefront"></i>
        <p><b>Connectez-vous pour ouvrir votre boutique.</b></p>
        <div class="cta centre mt1">
          <a class="btn btn-primaire" href="<?= e(url('inscription?retour=' . urlencode(url('vendre')))) ?>">Créer un compte</a>
          <a class="btn btn-contour" href="<?= e(url('connexion?retour=' . urlencode(url('vendre')))) ?>">Se connecter</a>
        </div>
      </div>
    <?php elseif (verification_email_active() && (int) ($u['email_verifie'] ?? 1) === 0): ?>
      <div class="vide">
        <i class="ph ph-envelope-simple"></i>
        <p><b>Confirmez d'abord votre adresse e-mail.</b></p>
        <p class="doux">Ouvrez le lien que nous vous avons envoyé à <b><?= e($u['email']) ?></b> (regardez aussi dans les indésirables), puis revenez ici pour ouvrir votre boutique.</p>
        <div class="cta centre mt1"><a class="btn btn-primaire" href="<?= e(url('compte')) ?>">Renvoyer le lien de confirmation</a></div>
      </div>
    <?php else: ?>
      <form method="post" class="formulaire formulaire-large" novalidate>
        <?= csrf_champ() ?>
        <?php foreach ($erreurs as $er): ?><p class="alerte" role="alert"><?= e($er) ?></p><?php endforeach; ?>
        <label class="champ"><span>Nom de la boutique</span><input type="text" name="nom" value="<?= e($v['nom']) ?>" maxlength="80" required></label>
        <label class="champ"><span>Présentation (optionnel)</span><textarea name="description" rows="4" maxlength="1000" placeholder="Ce que vous vendez, votre histoire, vos engagements…"><?= e($v['description']) ?></textarea></label>
        <label class="champ"><span>Numéro Wave / Orange Money pour recevoir vos gains</span><input type="tel" name="telephone" value="<?= e($v['telephone']) ?>" placeholder="77 123 45 67" required></label>
        <label class="case"><input type="checkbox" name="whatsapp" value="1" <?= $whatsapp ? 'checked' : '' ?>> <span><i class="ph-fill ph-whatsapp-logo"></i> <b>Ce numéro est aussi mon WhatsApp</b> : mes clients pourront me prévenir de leurs commandes par WhatsApp, et un bouton « Écrire sur WhatsApp » apparaîtra sur ma boutique. <span class="doux">(Modifiable plus tard.)</span></span></label>
        <fieldset class="mode-choix">
          <legend>Comment voulez-vous gérer votre boutique ?</legend>
          <label class="mode-carte"><input type="radio" name="mode" value="simple" <?= $modeSimple ? 'checked' : '' ?>>
            <span><span class="mode-icones"><i class="ph-fill ph-camera"></i><i class="ph-fill ph-money"></i><i class="ph-fill ph-microphone"></i></span>
              <b>Mode simple</b><small>Photo, prix et voix. Grands boutons avec des images, très peu de texte.</small></span></label>
          <label class="mode-carte"><input type="radio" name="mode" value="complet" <?= $modeSimple ? '' : 'checked' ?>>
            <span><span class="mode-icones"><i class="ph-fill ph-squares-four"></i><i class="ph-fill ph-chart-bar"></i></span>
              <b>Mode complet</b><small>Toutes les options : tailles, promotions, offres, statistiques, vitrine…</small></span></label>
          <p class="doux petit">Vous pourrez changer à tout moment. Vos produits, commandes et gains restent les mêmes.</p>
        </fieldset>
        <label class="case"><input type="checkbox" name="accepte" value="1" required> <span>J'ai lu et j'accepte les <a class="lien" href="<?= e(url('conditions-vendeur')) ?>" target="_blank" rel="noopener">conditions des vendeurs</a> (<?= commission_defaut() == 0.0 ? '0 % de commission au lancement' : (offre_lancement() ? 'offre de lancement : ' : '') . 'commission de ' . e(commission_texte()) . ' % sur les ventes livrées' ?><?= ($annV = commission_annonce()) ? ', puis ' . e(commission_texte($annV['pct'])) . ' % à partir du ' . e(date('d/m/Y', strtotime($annV['le']))) : '' ?>, voir <a class="lien" href="<?= e(url('frais-commissions')) ?>" target="_blank" rel="noopener">frais et commissions</a>).</span></label>
        <button class="btn btn-primaire" type="submit">Ouvrir ma boutique</button>
      </form>
    <?php endif; ?>
    </section>

    <section class="vendre-section">
      <h2 class="sous-titre">Questions fréquentes</h2>
      <?php foreach ($faq as [$q, $r]): ?><details class="vendre-faq"><summary><?= e($q) ?></summary><p><?= e($r) ?></p></details><?php endforeach; ?>
      <p class="doux">Une autre question ? <a class="lien" href="<?= e(url('aide')) ?>">Écrivez-nous</a> · <a class="lien" href="<?= e(url('conditions-vendeur')) ?>">Conditions des vendeurs</a> · <a class="lien" href="<?= e(url('paiements-vendeurs')) ?>">Paiements et reversements</a></p>
    </section>
  </div>
</main>
<?php require __DIR__ . '/../includes/footer.php'; ?>
