<?php
/**
 * Le proche qui reçoit un cadeau partage sa position GPS (sans compte), depuis le lien envoyé par l'acheteur.
 * $parametre = jeton secret de la commande. La page ne montre ni les produits ni les prix (c'est un cadeau).
 */
$c = requete("SELECT id, reference, livraison_nom, livraison_lat, client_id, statut FROM commandes WHERE position_jeton = ? AND cadeau = 1", [$parametre])->fetch();
if (!$c || !position_modifiable((int) $c['id'])) {
    http_response_code(404);
    require __DIR__ . '/404.php';
    return;
}
$acheteur = explode(' ', trim((string) requete('SELECT nom FROM users WHERE id = ?', [$c['client_id']])->fetchColumn()))[0];
$prenom = explode(' ', trim((string) $c['livraison_nom']))[0];

if (post_verifie('position/' . $parametre)) {
    $cle = 'position:' . $c['id'];
    $gps = position_valide($_POST['lat'] ?? null, $_POST['lng'] ?? null);
    if (limite_atteinte($cle, 10, 86400)) {
        flash('Trop d\'essais aujourd\'hui. Réessayez demain ou appelez le livreur.', 'erreur');
    } elseif (!$gps) {
        limite_enregistrer($cle);
        flash('Position introuvable ou hors du Sénégal. Autorisez la localisation et réessayez.', 'erreur');
    } else {
        limite_enregistrer($cle);
        requete('UPDATE commandes SET livraison_lat = ?, livraison_lng = ? WHERE id = ?', [$gps[0], $gps[1], $c['id']]);
        flash('Merci ! Votre position est envoyée : le livreur aura l\'itinéraire exact.');
    }
    rediriger('position/' . $parametre);
}
$titre = 'Partager ma position — Jënd';
$robots = 'noindex';
$scripts_extra = ['js/position.js'];
require __DIR__ . '/../includes/header.php';
?>
<main class="page">
  <div class="wrap wrap-moyen">
    <div class="position-carte">
      <i class="ph ph-gift position-icone" aria-hidden="true"></i>
      <h1 class="titre-page">Bonjour <?= e($prenom) ?> !</h1>
      <p><b><?= e($acheteur) ?></b> vous envoie un colis par Jënd. Pour que le livreur vous trouve sans difficulté, partagez votre position depuis l'endroit où vous voulez être livré.</p>
      <?php if ($c['livraison_lat'] !== null): ?>
        <p class="position-ok"><i class="ph-fill ph-map-pin"></i> <span><b>Position déjà enregistrée.</b> Vous pouvez la remplacer si vous n'êtes pas au bon endroit.</span></p>
      <?php endif; ?>
      <form method="post" id="form-position">
        <?= csrf_champ() ?><input type="hidden" name="lat" id="pos-lat"><input type="hidden" name="lng" id="pos-lng">
        <button type="button" class="btn btn-primaire" id="pos-envoyer"><i class="ph ph-crosshair"></i> Envoyer ma position</button>
        <p class="petit doux" id="pos-etat" aria-live="polite">Votre téléphone vous demandera l'autorisation : acceptez-la.</p>
      </form>
      <p class="petit doux">Le jour de la livraison, vérifiez le colis puis donnez au livreur le code de réception que <?= e($acheteur) ?> vous a envoyé.</p>
    </div>
  </div>
</main>
<?php require __DIR__ . '/../includes/footer.php'; ?>
