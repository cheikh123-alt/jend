<?php
// Ajoute/retire un favori. Répond en JSON (appelé par JavaScript).
header('Content-Type: application/json; charset=UTF-8');

function reponse_json(int $code, array $data): void
{
    http_response_code($code);
    echo json_encode($data);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    reponse_json(405, ['erreur' => 'Méthode non autorisée']);
}
if (!csrf_valide($_POST['csrf'] ?? null)) {
    reponse_json(403, ['erreur' => 'Session expirée']);
}
$u = utilisateur();
if (!$u) {
    reponse_json(401, ['erreur' => 'Connexion requise']);
}

$id = (int) ($_POST['produit_id'] ?? 0);
if (!requete("SELECT 1 FROM produits WHERE id = ? AND statut = 'publie' AND reserve_client_id IS NULL", [$id])->fetch()) {
    reponse_json(404, ['erreur' => 'Produit introuvable']);
}

$supprime = requete('DELETE FROM favoris WHERE user_id = ? AND produit_id = ?', [$u['id'], $id])->rowCount();
if ($supprime === 0) {
    requete('INSERT INTO favoris (user_id, produit_id) VALUES (?, ?)', [$u['id'], $id]);
}
reponse_json(200, ['actif' => $supprime === 0]);
