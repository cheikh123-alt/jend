<?php
[$u, $l] = exiger_livreur();
$zone = $l['zone_id'] ? requete('SELECT nom FROM zones_livraison WHERE id = ?', [$l['zone_id']])->fetchColumn() : null;
$tot = requete("SELECT COUNT(*) total, COALESCE(SUM(DATE_FORMAT(livre_le, '%Y-%m') = DATE_FORMAT(NOW(), '%Y-%m')), 0) ce_mois FROM commande_boutiques WHERE livreur_id = ? AND statut = 'livree'", [$u['id']])->fetch();
$initiale = mb_strtoupper(mb_substr($u['nom'], 0, 1));
livreur_entete('Profil — Jënd Livreur', 'profil');
?>
<section class="profil-tete">
  <span class="avatar" aria-hidden="true"><?= e($initiale) ?></span>
  <div><b class="gros"><?= e($u['nom']) ?></b><small><?= e($u['email']) ?><br><?= e($u['telephone'] ?? '') ?></small></div>
</section>

<section class="stats" aria-label="Mes chiffres">
  <div class="stat"><i class="ph ph-check-circle"></i><b><?= (int) $tot['total'] ?></b><span>Livraisons</span></div>
  <div class="stat"><i class="ph ph-calendar-check"></i><b><?= (int) $tot['ce_mois'] ?></b><span>Ce mois-ci</span></div>
  <div class="stat"><i class="ph ph-map-pin"></i><b class="petit-chiffre"><?= e($zone ?? 'Toutes') ?></b><span>Ma zone</span></div>
</section>

<section class="carte-info">
  <h2><i class="ph ph-device-mobile"></i> Installer l'appli</h2>
  <p>Pour l'ouvrir comme une vraie appli : dans le menu de votre navigateur, choisissez <b>« Ajouter à l'écran d'accueil »</b> (ou « Installer l'application »).</p>
</section>

<section class="carte-info">
  <h2><i class="ph ph-gear"></i> Mon compte</h2>
  <div class="raccourcis raccourcis-colonne">
    <a class="raccourci" href="<?= e(url('livreur/mot-de-passe')) ?>"><i class="ph ph-key"></i> Changer mon mot de passe</a>
  </div>
  <form method="post" action="<?= e(url('deconnexion')) ?>" class="deconnexion"><?= csrf_champ() ?><button class="raccourci raccourci-danger" type="submit"><i class="ph ph-sign-out"></i> Me déconnecter</button></form>
</section>
<?php livreur_pied(); ?>
