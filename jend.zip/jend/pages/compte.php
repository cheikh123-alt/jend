<?php
$u = exiger_connexion();
if ($u['role'] === 'livreur') {
    rediriger('livreur');                  // un livreur n'a pas d'espace client : il arrive sur ses courses
}
$titre = 'Mon compte — Jënd';
$commandes = requete(
    "SELECT c.reference, c.total, c.methode_paiement, c.statut, c.statut_paiement, c.acompte, c.created_at,
            (SELECT COUNT(*) FROM commande_boutiques cb WHERE cb.commande_id = c.id) AS nb,
            (SELECT COUNT(*) FROM commande_boutiques cb WHERE cb.commande_id = c.id AND cb.statut = 'expediee') AS nb_exp,
            (SELECT COUNT(*) FROM commande_boutiques cb WHERE cb.commande_id = c.id AND cb.statut = 'livree') AS nb_liv
       FROM commandes c WHERE c.client_id = ? ORDER BY c.created_at DESC, c.id DESC",
    [$u['id']]
)->fetchAll();
$litigesOuverts = (int) requete("SELECT COUNT(*) FROM litiges WHERE client_id = ? AND statut IN ('ouvert', 'en_cours')", [$u['id']])->fetchColumn();

$offresAcceptees = (int) requete("SELECT COUNT(*) FROM offres WHERE client_id = ? AND statut = 'acceptee' AND expire_le > NOW()", [$u['id']])->fetchColumn();
$offresContre = (int) requete("SELECT COUNT(*) FROM offres WHERE client_id = ? AND statut = 'contre' AND expire_le > NOW()", [$u['id']])->fetchColumn();
$enCours = $terminees = [];
$aPayer = $aConfirmer = 0;
$refPayer = $refConfirmer = null;
foreach ($commandes as $c) {
    if (in_array($c['statut'], ['en_attente', 'confirmee'], true)) {
        $enCours[] = $c;
        $paiementDu = $c['statut'] === 'en_attente' && in_array($c['statut_paiement'], ['en_attente', 'echoue'], true) && ($c['methode_paiement'] !== 'livraison' || (int) $c['acompte'] > 0);
        $aPayer += $paiementDu ? 1 : 0;
        $refPayer = $refPayer ?? ($paiementDu ? $c['reference'] : null);
        $aConfirmer += (int) $c['nb_exp'] > 0 ? 1 : 0;
        $refConfirmer = $refConfirmer ?? ((int) $c['nb_exp'] > 0 ? $c['reference'] : null);
    } else {
        $terminees[] = $c;
    }
}
$depense = array_sum(array_map(fn ($c) => $c['statut'] === 'terminee' ? (int) $c['total'] : 0, $commandes));

require __DIR__ . '/../includes/header.php';
?>
<main class="page">
  <div class="wrap">
    <nav class="fil" aria-label="Fil d'Ariane"><a href="<?= e(url()) ?>">Accueil</a> / <span>Mon compte</span></nav>
    <div class="compte-tete">
      <div><h1 class="titre-page"><?= e(tb_salutation()) ?> <?= e(explode(' ', $u['nom'])[0]) ?></h1><p class="compte"><?= e(tb_date_longue()) ?> · <?= e($u['email']) ?></p></div>
      <form method="post" action="<?= e(url('deconnexion')) ?>"><?= csrf_champ() ?><button class="btn btn-contour" type="submit"><i class="ph ph-sign-out"></i> Se déconnecter</button></form>
    </div>

    <?php compte_onglets('commandes'); ?>
    <?php if (verification_email_active() && (int) $u['email_verifie'] === 0): ?>
      <div class="alerte" role="alert"><i class="ph ph-envelope-simple"></i> <span><b>Confirmez votre adresse e-mail</b> (<?= e($u['email']) ?>) : ouvrez le lien que nous vous avons envoyé. Tant que ce n'est pas fait, vous ne pouvez pas commander.
        <form method="post" action="<?= e(url('confirmer-email')) ?>" class="en-ligne"><?= csrf_champ() ?><button class="lien" type="submit">Renvoyer le lien</button></form></span></div>
    <?php endif; ?>

    <?php tb_a_faire([
        tb_action('ph-credit-card', $aPayer > 1 ? 'commandes à payer' : 'commande à payer', $aPayer, $aPayer === 1 ? 'commande/' . $refPayer : 'compte', 'urgent', 'Elle n\'est confirmée qu\'une fois le paiement reçu.', 'Payer'),
        tb_action('ph-package', $aConfirmer > 1 ? 'colis expédiés' : 'colis expédié', $aConfirmer, $aConfirmer === 1 ? 'commande/' . $refConfirmer : 'compte', 'normal', 'Dès que vous l\'avez reçu, confirmez la réception depuis la commande.', 'Ouvrir'),
        tb_action('ph-scissors', 'devis sur mesure reçu(s)', (int) requete("SELECT COUNT(*) FROM demandes_mesure WHERE client_id = ? AND statut = 'devis'", [$u['id']])->fetchColumn(), 'sur-mesure', 'urgent', 'Le vendeur vous a répondu : acceptez ou refusez son devis.', 'Voir'),
        tb_action('ph-handshake', 'offre(s) acceptée(s) par le vendeur', $offresAcceptees, 'offres', 'urgent', 'Achetez au prix convenu avant la fin du délai de ' . OFFRE_VALIDITE_ACHAT_HEURES . ' h.', 'Acheter'),
        tb_action('ph-arrows-left-right', 'contre-proposition(s) à étudier', $offresContre, 'offres', 'normal', 'Le vendeur vous propose un autre prix.', 'Répondre'),
        tb_action('ph-chat-circle-text', $litigesOuverts > 1 ? 'signalements en cours' : 'signalement en cours', $litigesOuverts, 'litiges', 'info', 'Notre équipe vous répond sous 48 h.', 'Suivre'),
    ], 'Rien à faire pour le moment. Bonne visite !'); ?>

    <div class="tb-kpis">
      <?= tb_kpi('ph-receipt', 'Commandes', (string) count($commandes), $enCours ? count($enCours) . ' en cours' : 'aucune en cours') ?>
      <?= tb_kpi('ph-check-circle', 'Livrées', (string) count(array_filter($terminees, fn ($c) => $c['statut'] === 'terminee'))) ?>
      <?= tb_kpi('ph-coins', 'Total acheté', fcfa($depense), 'commandes terminées') ?>
    </div>

    <section class="tb-bloc">
      <h2 class="tb-titre"><i class="ph-fill ph-truck"></i> Mes commandes en cours</h2>
      <?php if (!$enCours): ?>
        <div class="tb-vide"><i class="ph ph-shopping-bag"></i><p><b>Aucune commande en cours.</b></p><a class="btn btn-primaire" href="<?= e(url('produits')) ?>">Découvrir les produits</a></div>
      <?php else: ?>
        <div class="tb-cartes">
          <?php foreach ($enCours as $c): $etape = tb_etape_commande($c); ?>
            <a class="tb-carte" href="<?= e(url('commande/' . $c['reference'])) ?>">
              <span class="tb-carte-tete"><b><?= e($c['reference']) ?></b><span class="badge badge-<?= e($c['statut']) ?>"><?= e(STATUTS_COMMANDE[$c['statut']]) ?></span></span>
              <span class="tb-carte-ligne"><?= e(fcfa((int) $c['total'])) ?> · <?= e(MOYENS_PAIEMENT[$c['methode_paiement']][0]) ?> · <?= e(date('d/m/Y', strtotime($c['created_at']))) ?></span>
              <?= tb_progression($etape) ?>
              <span class="tb-carte-etat"><?= e($c['statut_paiement'] === 'echoue' ? 'Le paiement a échoué : relancez-le depuis la commande.' : ($etape === 1 ? 'En attente de votre paiement.' : ($etape === 2 ? 'Payée : le vendeur prépare votre colis.' : 'Votre colis est en route : confirmez la réception à l\'arrivée.'))) ?></span>
            </a>
          <?php endforeach; ?>
        </div>
      <?php endif; ?>
    </section>

    <?php if ($terminees): ?>
    <section class="tb-bloc">
      <h2 class="tb-titre"><i class="ph-fill ph-clock-counter-clockwise"></i> Historique</h2>
      <ul class="tb-liste">
        <?php foreach ($terminees as $c): ?>
          <li><a href="<?= e(url('commande/' . $c['reference'])) ?>"><span><b><?= e($c['reference']) ?></b> <small class="doux"><?= e(date('d/m/Y', strtotime($c['created_at']))) ?></small></span>
            <span><?= e(fcfa((int) $c['total'])) ?> <span class="badge badge-<?= e($c['statut']) ?>"><?= e(STATUTS_COMMANDE[$c['statut']]) ?></span></span></a></li>
        <?php endforeach; ?>
      </ul>
    </section>
    <?php endif; ?>
  </div>
</main>
<?php require __DIR__ . '/../includes/footer.php'; ?>
