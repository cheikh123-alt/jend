<?php
$u = exiger_connexion();
$zones = zones_actives();
$zonesParId = array_column($zones, null, 'id');
$erreurs = [];
$v = ['zone_id' => '', 'adresse' => '', 'telephone' => $u['telephone'] ?? ''];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_valide($_POST['csrf'] ?? null)) {
        flash('Session expirée, merci de réessayer.', 'erreur');
        rediriger('compte/adresses');
    }

    if (($_POST['action'] ?? '') === 'supprimer') {
        // La condition user_id garantit qu'on ne peut supprimer que SES adresses
        requete('DELETE FROM adresses WHERE id = ? AND user_id = ?', [(int) ($_POST['id'] ?? 0), $u['id']]);
        flash('Adresse supprimée.');
        rediriger('compte/adresses');
    }

    foreach (['zone_id', 'adresse', 'telephone'] as $k) {
        $v[$k] = trim((string) ($_POST[$k] ?? ''));
    }
    $tel = telephone_valide($v['telephone']);
    if (!isset($zonesParId[(int) $v['zone_id']])) {
        $erreurs[] = 'Choisissez une zone de livraison.';
    }
    if (mb_strlen($v['adresse']) < 5 || mb_strlen($v['adresse']) > 255) {
        $erreurs[] = 'Indiquez une adresse précise (quartier, rue, repère).';
    }
    if ($tel === null) {
        $erreurs[] = 'Numéro de téléphone invalide (ex : 77 123 45 67).';
    }
    if (!$erreurs && (int) requete('SELECT COUNT(*) FROM adresses WHERE user_id = ?', [$u['id']])->fetchColumn() >= 5) {
        $erreurs[] = 'Vous avez déjà 5 adresses : supprimez-en une avant d\'en ajouter.';
    }
    if (!$erreurs) {
        requete('INSERT INTO adresses (user_id, zone_id, adresse, telephone) VALUES (?, ?, ?, ?)', [$u['id'], (int) $v['zone_id'], $v['adresse'], $tel]);
        flash('Adresse ajoutée.');
        rediriger('compte/adresses');
    }
}

$adresses = requete(
    'SELECT a.id, a.adresse, a.telephone, z.nom AS zone FROM adresses a JOIN zones_livraison z ON z.id = a.zone_id WHERE a.user_id = ? ORDER BY a.id DESC',
    [$u['id']]
)->fetchAll();

$titre = 'Mes adresses — Jënd';
require __DIR__ . '/../includes/header.php';
?>
<main class="page">
  <div class="wrap">
    <nav class="fil" aria-label="Fil d'Ariane"><a href="<?= e(url()) ?>">Accueil</a> / <a href="<?= e(url('compte')) ?>">Mon compte</a> / <span>Adresses</span></nav>
    <h1 class="titre-page">Mon compte</h1>
    <?php compte_onglets('adresses'); ?>

    <div class="deux-colonnes">
      <section>
        <h2 class="sous-titre">Adresses enregistrées</h2>
        <?php if (!$adresses): ?>
          <div class="vide"><i class="ph ph-map-pin"></i><p><b>Aucune adresse enregistrée.</b></p></div>
        <?php else: foreach ($adresses as $a): ?>
          <div class="adresse-carte">
            <div><b><?= e($a['zone']) ?></b><br><?= e($a['adresse']) ?><br><span class="doux"><?= e($a['telephone']) ?></span></div>
            <form method="post">
              <?= csrf_champ() ?><input type="hidden" name="action" value="supprimer"><input type="hidden" name="id" value="<?= (int) $a['id'] ?>">
              <button class="lien lien-danger" type="submit" aria-label="Supprimer cette adresse"><i class="ph ph-trash"></i> Supprimer</button>
            </form>
          </div>
        <?php endforeach; endif; ?>
      </section>

      <section>
        <h2 class="sous-titre">Ajouter une adresse</h2>
        <form method="post" class="formulaire formulaire-large" novalidate>
          <?= csrf_champ() ?><input type="hidden" name="action" value="ajouter">
          <?php foreach ($erreurs as $er): ?><p class="alerte" role="alert"><?= e($er) ?></p><?php endforeach; ?>
          <label class="champ"><span>Zone de livraison</span>
            <select name="zone_id" required>
              <option value="">— Choisir —</option>
              <?php foreach (zones_par_ville($zones) as $ville => $zs): ?><optgroup label="<?= e($ville) ?>"><?php foreach ($zs as $z): ?><option value="<?= (int) $z['id'] ?>" <?= (string) $z['id'] === $v['zone_id'] ? 'selected' : '' ?>><?= e($z['nom']) ?></option><?php endforeach; ?></optgroup><?php endforeach; ?>
            </select>
          </label>
          <label class="champ"><span>Adresse précise</span><textarea name="adresse" rows="3" placeholder="Quartier, rue, numéro, repère…" required><?= e($v['adresse']) ?></textarea></label>
          <label class="champ"><span>Téléphone</span><input type="tel" name="telephone" value="<?= e($v['telephone']) ?>" placeholder="77 123 45 67" required></label>
          <button class="btn btn-primaire" type="submit">Enregistrer l'adresse</button>
        </form>
      </section>
    </div>
  </div>
</main>
<?php require __DIR__ . '/../includes/footer.php'; ?>
