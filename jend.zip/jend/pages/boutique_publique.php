<?php
/**
 * Vitrine publique d'une boutique (partageable par WhatsApp, TikTok…). $parametre = slug de la boutique.
 * Bannière + logo, chiffres de confiance, produits avec recherche et catégories propres à la boutique, À propos, Livraison, Avis.
 */
$b = requete("SELECT * FROM boutiques WHERE slug = ? AND statut = 'active'", [$parametre])->fetch();
if (!$b) {
    http_response_code(404);
    require __DIR__ . '/404.php';
    return;
}
$bid = (int) $b['id'];
$triValides = ['recent' => 'Nouveautés', 'populaire' => 'Les plus populaires', 'prix_asc' => 'Prix croissant', 'prix_desc' => 'Prix décroissant'];
$tri = isset($triValides[$_GET['tri'] ?? '']) ? $_GET['tri'] : 'recent';
$q = mb_substr(trim((string) ($_GET['q'] ?? '')), 0, 80);
$categories = boutique_categories($bid);
$catId = (int) ($_GET['cat'] ?? 0);
if ($catId && !in_array($catId, array_map('intval', array_column($categories, 'id')), true)) {
    $catId = 0;
}
$res = catalogue_chercher(['boutique_id' => $bid, 'tri' => $tri, 'q' => $q, 'categorie_id' => $catId ?: null], (int) ($_GET['page'] ?? 1));
$pageCourante = $res['page'];
$nbTotal = (int) requete("SELECT COUNT(*) FROM produits WHERE boutique_id = ? AND statut = 'publie' AND stock > 0 AND reserve_client_id IS NULL", [$bid])->fetchColumn();
$note = boutique_note($bid);
$confiance = boutique_confiance($bid);
$regions = boutique_regions($bid);
$avis = boutique_avis($bid);
$lienBoutique = app_url('boutique/' . $b['slug']);
// Livraison : frais et délais de CETTE boutique, zone par zone (ou frais de référence)
$propres = frais_boutiques([$bid]);
$zonesLivrees = array_values(array_filter(zones_actives(), fn ($z) => !$regions || in_array($z['region'], $regions, true)));
$parJend = $b['livraison_par'] === 'jend' && livreurs_jend_actifs();
$lignesLivraison = [];
foreach ($zonesLivrees as $z) {
    $f = frais_livraison($bid, $z, $parJend, $propres);
    $lignesLivraison[$z['region']][] = ['zone' => $z['nom'], 'frais' => $f['frais'], 'delai' => $f['delai']];
}
$numWa = $b['contact_whatsapp'] ? preg_replace('/\D/', '', (string) $b['contact_whatsapp']) : '';
$reseaux = array_filter(['tiktok' => $b['reseau_tiktok'], 'instagram' => $b['reseau_instagram'], 'facebook' => $b['reseau_facebook']]);
$titre = $b['nom'] . ' — Jënd';
$description = ($b['slogan'] ? $b['slogan'] . ' · ' : '') . 'Boutique ' . $b['nom'] . ' sur Jënd : paiement protégé jusqu\'à la réception.';
require __DIR__ . '/../includes/header.php';
?>
<main class="vitrine couleur-<?= e($b['couleur'] ?: 'terre') ?>">
  <section class="vitrine-couverture">
    <div class="vitrine-banniere">
      <?php if ($b['banniere_chemin']): ?><img src="<?= e(url($b['banniere_chemin'])) ?>" alt="" fetchpriority="high"><?php endif; ?>
    </div>
    <div class="wrap vitrine-identite">
      <span class="vitrine-logo"><?php if ($b['logo_chemin']): ?><img src="<?= e(url(image_miniature($b['logo_chemin']))) ?>" alt="Logo de <?= e($b['nom']) ?>"><?php else: ?><?= e(boutique_initiales($b['nom'])) ?><?php endif; ?></span>
      <div class="vitrine-titre">
        <nav class="fil" aria-label="Fil d'Ariane"><a href="<?= e(url()) ?>">Accueil</a> / <span>Boutique</span></nav>
        <h1><?= e($b['nom']) ?><?php if ($b['verifiee']): ?> <i class="ph-fill ph-seal-check vitrine-verifie" title="Boutique vérifiée par Jënd" aria-label="Boutique vérifiée"></i><?php endif; ?></h1>
        <?php if ($b['slogan']): ?><p class="vitrine-slogan"><?= e($b['slogan']) ?></p><?php endif; ?>
        <p class="vitrine-meta">
          <?php if ($b['ville']): ?><span><i class="ph ph-map-pin"></i> <?= e($b['ville']) ?></span><?php endif; ?>
          <span><i class="ph ph-calendar-blank"></i> Sur Jënd depuis <?= e(anciennete_texte((string) $b['created_at'])) ?></span>
          <?php if ($b['verifiee']): ?><span class="badge-verifie"><i class="ph-fill ph-seal-check"></i> Boutique vérifiée</span><?php endif; ?>
        </p>
      </div>
      <div class="vitrine-actions">
        <?php if ($numWa !== ''): ?><a class="btn btn-whatsapp" href="<?= e('https://wa.me/' . $numWa . '?text=' . rawurlencode('Bonjour ' . $b['nom'] . ', je vous ai trouvé sur Jënd : ' . $lienBoutique)) ?>" target="_blank" rel="noopener noreferrer"><i class="ph-fill ph-whatsapp-logo"></i> Écrire</a><?php endif; ?>
        <?php if ((int) $b['sur_mesure'] === 1): ?><a class="btn btn-primaire" href="<?= e(url('sur-mesure/' . $b['slug'])) ?>"><i class="ph ph-scissors"></i> Commander du sur-mesure</a><?php endif; ?>
        <?= bouton_whatsapp('Découvrez la boutique « ' . $b['nom'] . ' » sur Jënd : ' . lien_source($lienBoutique, 'whatsapp'), 'Partager') ?>
        <?php foreach ($reseaux as $cle => $lien): ?><a class="vitrine-reseau" href="<?= e((string) $lien) ?>" target="_blank" rel="noopener noreferrer nofollow" aria-label="<?= e(RESEAUX_BOUTIQUE[$cle][0]) ?>"><i class="ph-fill <?= e(RESEAUX_BOUTIQUE[$cle][2]) ?>"></i></a><?php endforeach; ?>
      </div>
    </div>
  </section>

  <div class="wrap">
    <?php
    // Seulement les vrais chiffres (pas de « — » vides pour une boutique qui démarre)
    $chiffres = [];
    if ($note['nb'] > 0) { $chiffres[] = [e(note_texte($note['note'])) . ' <i class="ph-fill ph-star"></i>', (int) $note['nb'] . ' avis']; }
    if ($confiance['assez']) {
        $chiffres[] = [(string) (int) $confiance['ventes'], 'ventes livrées'];
        if ($confiance['delai_heures'] !== null) { $chiffres[] = [e(delai_texte($confiance['delai_heures'])), 'pour recevoir, en moyenne']; }
        $chiffres[] = [(int) $confiance['sans_probleme'] . ' %', 'commandes sans problème'];
    } else {
        $chiffres[] = ['<i class="ph-fill ph-sparkle"></i> Nouvelle', 'boutique sur Jënd'];
    }
    $chiffres[] = [(string) $nbTotal, 'produit' . ($nbTotal > 1 ? 's' : '') . ' en vente'];
    ?>
    <ul class="vitrine-chiffres" aria-label="La boutique en chiffres">
      <?php foreach ($chiffres as [$valeur, $libelle]): ?><li><b><?= $valeur ?></b><span><?= e($libelle) ?></span></li><?php endforeach; ?>
    </ul>

    <nav class="vitrine-onglets" aria-label="Sections de la boutique">
      <a href="#produits">Produits</a><a href="#a-propos">À propos</a><a href="#livraison">Livraison</a><?php if ($avis): ?><a href="#avis">Avis</a><?php endif; ?>
    </nav>

    <section id="produits" class="vitrine-section">
      <form method="get" class="vitrine-recherche" role="search">
        <span class="recherche"><i class="ph ph-magnifying-glass" aria-hidden="true"></i><input type="search" name="q" value="<?= e($q) ?>" placeholder="Chercher dans <?= e($b['nom']) ?>…" aria-label="Chercher dans la boutique"><?php if ($catId): ?><input type="hidden" name="cat" value="<?= $catId ?>"><?php endif; ?></span>
        <select name="tri" aria-label="Trier par"><?php foreach ($triValides as $cle => $libelle): ?><option value="<?= e($cle) ?>" <?= $tri === $cle ? 'selected' : '' ?>><?= e($libelle) ?></option><?php endforeach; ?></select>
        <button class="btn btn-contour" type="submit">OK</button>
      </form>
      <?php if (count($categories) > 1): ?>
        <div class="vitrine-cats" aria-label="Catégories de la boutique">
          <a href="<?= e(url_avec(['cat' => null, 'page' => null])) ?>" class="<?= !$catId ? 'actif' : '' ?>">Tout <small><?= $nbTotal ?></small></a>
          <?php foreach ($categories as $c): ?><a href="<?= e(url_avec(['cat' => (int) $c['id'], 'page' => null])) ?>" class="<?= $catId === (int) $c['id'] ? 'actif' : '' ?>"><?= e($c['nom']) ?> <small><?= (int) $c['nb'] ?></small></a><?php endforeach; ?>
        </div>
      <?php endif; ?>
      <?php if (!$res['produits']): ?>
        <div class="vide"><i class="ph ph-package"></i><p><b><?= $q !== '' || $catId ? 'Aucun produit ne correspond.' : 'Aucun produit disponible pour le moment.' ?></b></p>
          <?php if ($q !== '' || $catId): ?><p><a class="lien" href="<?= e(url('boutique/' . $b['slug'])) ?>">Voir tous les produits</a></p><?php endif; ?></div>
      <?php else: ?>
        <p class="compte"><?= $res['total'] ?> produit<?= $res['total'] > 1 ? 's' : '' ?><?= $q !== '' ? ' pour « ' . e($q) . ' »' : '' ?></p>
        <div class="produits produits-3">
          <?php foreach ($res['produits'] as $p) { include __DIR__ . '/../includes/carte.php'; } ?>
        </div>
        <?php if ($res['pages'] > 1): ?>
          <nav class="pagination" aria-label="Pagination">
            <?php if ($pageCourante > 1): ?><a href="<?= e(url_avec(['page' => $pageCourante - 1])) ?>" aria-label="Page précédente"><i class="ph ph-caret-left"></i></a><?php endif; ?>
            <?php for ($i = max(1, $pageCourante - 2); $i <= min($res['pages'], $pageCourante + 2); $i++): ?>
              <a href="<?= e(url_avec(['page' => $i])) ?>" <?= $i === $pageCourante ? 'class="actif" aria-current="page"' : '' ?>><?= $i ?></a>
            <?php endfor; ?>
            <?php if ($pageCourante < $res['pages']): ?><a href="<?= e(url_avec(['page' => $pageCourante + 1])) ?>" aria-label="Page suivante"><i class="ph ph-caret-right"></i></a><?php endif; ?>
          </nav>
        <?php endif; ?>
      <?php endif; ?>
    </section>

    <div class="vitrine-colonnes">
      <section id="a-propos" class="vitrine-section vitrine-carte">
        <h2><i class="ph ph-storefront"></i> À propos</h2>
        <?php if ($b['description']): ?><p class="boutique-desc"><?= nl2br(e($b['description'])) ?></p><?php else: ?><p class="doux">Cette boutique n'a pas encore écrit sa présentation.</p><?php endif; ?>
        <ul class="vitrine-garanties">
          <li><i class="ph-fill ph-shield-check"></i> <span>Votre argent est gardé par Jënd jusqu'à la réception</span></li>
          <li><i class="ph-fill ph-key"></i> <span>Vous confirmez la livraison avec votre code de réception</span></li>
          <li><i class="ph-fill ph-lifebuoy"></i> <span>Un souci ? Signalement pendant <?= LITIGE_DELAI_SIGNALEMENT_JOURS ?> jours, réponse sous <?= LITIGE_DELAI_REPONSE_HEURES ?> h</span></li>
          <?php if ((int) $b['offres_actives'] === 1): ?><li><i class="ph-fill ph-handshake"></i> <span>Accepte les propositions de prix</span></li><?php endif; ?>
        </ul>
        <?php require __DIR__ . '/../includes/confiance.php'; ?>
      </section>

      <section id="livraison" class="vitrine-section vitrine-carte">
        <h2><i class="ph ph-truck"></i> Livraison</h2>
        <p class="doux">Livre <?= $regions ? 'à : <b>' . e(implode(', ', $regions)) . '</b>' : 'dans <b>tout le Sénégal</b>' ?>. Frais et délais fixés par la boutique, affichés avant de payer.</p>
        <?php foreach ($lignesLivraison as $region => $lignes): ?>
          <details class="region-livraison"<?= count($lignesLivraison) === 1 ? ' open' : '' ?>>
            <summary><b><?= e($region) ?></b><span>dès <?= e(fcfa(min(array_column($lignes, 'frais')))) ?></span></summary>
            <div class="table-defile"><table class="table"><tbody>
              <?php foreach ($lignes as $l): ?><tr><td><?= e($l['zone']) ?></td><td><b><?= e(fcfa((int) $l['frais'])) ?></b></td><td class="doux"><?= (int) $l['delai'] ?> j</td></tr><?php endforeach; ?>
            </tbody></table></div>
          </details>
        <?php endforeach; ?>
      </section>
    </div>

    <?php if ($avis): ?>
    <section id="avis" class="vitrine-section">
      <h2 class="sous-titre">Ce que disent les clients</h2>
      <ul class="vitrine-avis">
        <?php foreach ($avis as $a): ?>
          <li>
            <span class="vitrine-etoiles" aria-label="<?= (int) $a['note'] ?> sur 5"><?= str_repeat('★', (int) $a['note']) ?><span class="vides"><?= str_repeat('★', 5 - (int) $a['note']) ?></span></span>
            <p>« <?= e(mb_strimwidth((string) $a['commentaire'], 0, 280, '…')) ?> »</p>
            <small><?= e(explode(' ', trim((string) $a['client']))[0]) ?> · <a class="lien" href="<?= e(url('produit/' . $a['slug'])) ?>"><?= e($a['produit']) ?></a> · <?= e(date('m/Y', strtotime($a['created_at']))) ?></small>
          </li>
        <?php endforeach; ?>
      </ul>
    </section>
    <?php endif; ?>
  </div>
</main>
<?php require __DIR__ . '/../includes/footer.php'; ?>
