<?php
[$u, $l] = exiger_livreur();

if (post_verifie('livreur')) {
    if (($_POST['action'] ?? '') === 'disponibilite') {
        $dispo = !empty($_POST['disponible']) ? 1 : 0;
        requete('UPDATE livreurs SET disponible = ? WHERE user_id = ?', [$dispo, $u['id']]);
        flash($dispo ? 'Vous êtes disponible : on peut vous confier des courses.' : 'Vous êtes indisponible : aucune nouvelle course ne vous sera confiée.');
    }
    rediriger('livreur');
}

$actives = requete(SQL_COURSE . " WHERE cb.livreur_id = ? AND cb.statut IN ('a_preparer', 'expediee') AND c.statut <> 'annulee' ORDER BY cb.affecte_le, cb.id", [$u['id']])->fetchAll();
$jour = requete(SQL_COURSE . " WHERE cb.livreur_id = ? AND cb.statut = 'livree' AND DATE(cb.livre_le) = CURDATE()", [$u['id']])->fetchAll();
$especes = array_sum(array_map('course_a_encaisser', $jour));
$zone = $l['zone_id'] ? requete('SELECT nom FROM zones_livraison WHERE id = ?', [$l['zone_id']])->fetchColumn() : null;
$heure = (int) date('G');
$salut = $heure < 5 || $heure >= 18 ? 'Bonsoir' : 'Bonjour';
const RANG_ETAPE = ['affectee' => 1, 'recuperee' => 2, 'en_route' => 3, 'livree' => 4];

livreur_entete('Mes courses — Jënd Livreur', 'courses');
?>
<h1 class="app-titre"><?= $salut ?> <?= e(explode(' ', $u['nom'])[0]) ?></h1>

<form method="post" class="dispo-carte <?= $l['disponible'] ? 'dispo' : '' ?>">
  <?= csrf_champ() ?><input type="hidden" name="action" value="disponibilite">
  <div class="dispo-texte">
    <b><?= $l['disponible'] ? 'Vous êtes disponible' : 'Vous êtes indisponible' ?></b>
    <small><?= $zone ? 'Zone : ' . e($zone) : 'Toutes les zones' ?></small>
  </div>
  <button class="interrupteur" type="submit" name="disponible" value="<?= $l['disponible'] ? '0' : '1' ?>" role="switch" aria-checked="<?= $l['disponible'] ? 'true' : 'false' ?>" aria-label="Disponibilité">
    <span class="curseur-i"></span>
  </button>
</form>

<section class="stats" aria-label="Aujourd'hui">
  <div class="stat"><i class="ph ph-package"></i><b><?= count($actives) ?></b><span>À faire</span></div>
  <div class="stat"><i class="ph ph-check-circle"></i><b><?= count($jour) ?></b><span>Livrées aujourd'hui</span></div>
  <div class="stat"><i class="ph ph-coins"></i><b><?= e(number_format($especes, 0, ',', ' ')) ?></b><span>FCFA encaissés</span></div>
  <div class="stat"><i class="ph ph-hand-coins"></i><b><?= e(number_format(livreur_especes((int) utilisateur()['id'])['a_remettre'], 0, ',', ' ')) ?></b><span>FCFA à remettre à Jënd</span></div>
</section>

<h2 class="app-sous-titre">Courses en cours</h2>
<?php if (!$actives): ?>
  <div class="app-vide"><i class="ph ph-motorcycle"></i><b>Aucune course pour le moment</b>
    <p><?= $l['disponible'] ? 'Restez disponible : une nouvelle course apparaîtra ici automatiquement.' : 'Passez en « disponible » pour recevoir des courses.' ?></p></div>
<?php endif; ?>
<?php foreach ($actives as $c): $etape = course_etape($c); $rang = RANG_ETAPE[$etape] ?? 1; $enc = course_a_encaisser($c); ?>
  <a class="course" href="<?= e(url('livreur/course/' . $c['id'])) ?>">
    <div class="course-haut">
      <span class="puce puce-<?= e($etape) ?>"><?= e(ETAPES_COURSE[$etape]) ?></span>
      <small><?= e($c['reference']) ?> · <?= e(il_y_a($c['affecte_le'])) ?></small>
    </div>
    <div class="trajet">
      <span><i class="ph ph-storefront"></i> <?= e($c['boutique']) ?></span>
      <i class="ph ph-arrow-down"></i>
      <span><i class="ph ph-map-pin"></i> <b><?= e($c['livraison_zone']) ?></b></span>
      <small class="trajet-client">Client : <?= e($c['livraison_nom']) ?></small>
    </div>
    <div class="progres progres-<?= $rang ?>" aria-hidden="true"><i></i><i></i><i></i><i></i></div>
    <div class="course-bas">
      <?= $enc > 0 ? '<span class="encaisser"><i class="ph-fill ph-hand-coins"></i> À encaisser <b>' . e(fcfa($enc)) . '</b></span>' : '<span class="paye"><i class="ph-fill ph-seal-check"></i> Déjà payé en ligne</span>' ?>
      <i class="ph ph-caret-right"></i>
    </div>
  </a>
<?php endforeach; ?>
<?php livreur_pied(); ?>
