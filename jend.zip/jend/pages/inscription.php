<?php
if (utilisateur()) {
    rediriger('compte');
}
$titre = 'Créer un compte — Jënd';
$erreurs = [];
$v = ['nom' => '', 'email' => '', 'telephone' => ''];
$retour = $_GET['retour'] ?? $_POST['retour'] ?? '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $v['nom']       = trim((string) ($_POST['nom'] ?? ''));
    $v['email']     = trim((string) ($_POST['email'] ?? ''));
    $v['telephone'] = trim((string) ($_POST['telephone'] ?? ''));
    $mdp  = (string) ($_POST['mot_de_passe'] ?? '');
    $mdp2 = (string) ($_POST['mot_de_passe2'] ?? '');

    if (!csrf_valide($_POST['csrf'] ?? null)) {
        $erreurs[] = 'Session expirée, merci de réessayer.';
    } elseif (limite_atteinte('inscription:ip:' . ip_client(), 5, 3600)) {
        $erreurs[] = 'Trop d\'inscriptions depuis votre connexion. Réessayez plus tard.';
    } else {
        limite_enregistrer('inscription:ip:' . ip_client());     // chaque tentative compte : empêche aussi de sonder les e-mails existants
    }
    if (mb_strlen($v['nom']) < 2 || mb_strlen($v['nom']) > 120) {
        $erreurs[] = 'Indiquez votre nom (2 caractères minimum).';
    }
    if (!filter_var($v['email'], FILTER_VALIDATE_EMAIL) || mb_strlen($v['email']) > 190) {
        $erreurs[] = 'Adresse e-mail invalide.';
    }
    $tel = $v['telephone'] !== '' ? telephone_valide($v['telephone']) : null;
    if ($v['telephone'] !== '' && $tel === null) {
        $erreurs[] = 'Numéro de téléphone invalide (ex : 77 123 45 67).';
    }
    if (empty($_POST['accepte'])) {
        $erreurs[] = 'Vous devez accepter les conditions d\'utilisation et la politique de confidentialité.';
    }
    if ($msg = mot_de_passe_faible($mdp, $v['email'], $v['nom'])) {
        $erreurs[] = $msg;
    }
    if ($mdp !== $mdp2) {
        $erreurs[] = 'Les deux mots de passe ne correspondent pas.';
    }
    if (!$erreurs && requete('SELECT 1 FROM users WHERE email = ?', [$v['email']])->fetch()) {
        $erreurs[] = 'Cette adresse e-mail est déjà utilisée. Essayez de vous connecter.';
    }

    if (!$erreurs) {
        requete('INSERT INTO users (nom, email, telephone, mot_de_passe, role, email_verifie) VALUES (?, ?, ?, ?, ?, ?)',
            [$v['nom'], $v['email'], $tel, password_hash($mdp, PASSWORD_DEFAULT), 'client', verification_email_active() ? 0 : 1]);
        $nouvelId = (int) pdo()->lastInsertId();
        requete('UPDATE users SET source = ? WHERE id = ?', [source_courante(), $nouvelId]);      // marketing : canal d'arrivée
        connecter($nouvelId);
        if (verification_email_active()) {
            email_confirmation_envoyer($nouvelId);
            flash('Bienvenue sur Jënd, ' . explode(' ', $v['nom'])[0] . ' ! Un lien de confirmation vient d\'être envoyé à ' . $v['email'] . ' : ouvrez-le pour pouvoir commander.');
        } else {
            flash('Bienvenue sur Jënd, ' . explode(' ', $v['nom'])[0] . ' !');
        }
        header('Location: ' . retour_sur($retour ?: url()));
        exit;
    }
}
require __DIR__ . '/../includes/header.php';
?>
<main class="page">
  <div class="wrap wrap-etroit">
    <h1 class="titre-page">Créer un compte</h1>
    <?php if (str_contains((string) $retour, 'commande')): ?><p class="alerte alerte-info"><i class="ph ph-shopping-cart"></i> <span><b>Votre panier est gardé.</b> <?= basename(__FILE__) === 'connexion.php' ? 'Connectez-vous' : 'Créez votre compte en une minute' ?> pour finaliser la commande : nous en avons besoin pour vous envoyer le suivi et le code de réception.</span></p><?php endif; ?>
    <form method="post" class="formulaire" novalidate>
      <?= csrf_champ() ?>
      <input type="hidden" name="retour" value="<?= e($retour) ?>">
      <?php foreach ($erreurs as $er): ?><p class="alerte" role="alert"><?= e($er) ?></p><?php endforeach; ?>
      <label class="champ"><span>Nom complet</span><input type="text" name="nom" value="<?= e($v['nom']) ?>" autocomplete="name" required></label>
      <label class="champ"><span>E-mail</span><input type="email" name="email" value="<?= e($v['email']) ?>" autocomplete="email" required></label>
      <label class="champ"><span>Téléphone (optionnel)</span><input type="tel" name="telephone" value="<?= e($v['telephone']) ?>" placeholder="77 123 45 67" autocomplete="tel"></label>
      <label class="champ"><span>Mot de passe (8 caractères minimum)</span><input type="password" name="mot_de_passe" autocomplete="new-password" required></label>
      <label class="champ"><span>Confirmer le mot de passe</span><input type="password" name="mot_de_passe2" autocomplete="new-password" required></label>
      <label class="case"><input type="checkbox" name="accepte" value="1" required> <span>J'ai lu et j'accepte les <a class="lien" href="<?= e(url('cgu')) ?>" target="_blank" rel="noopener">conditions d'utilisation</a>, les <a class="lien" href="<?= e(url('cgv')) ?>" target="_blank" rel="noopener">conditions de vente</a> et la <a class="lien" href="<?= e(url('confidentialite')) ?>" target="_blank" rel="noopener">politique de confidentialité</a>.</span></label>
      <button class="btn btn-primaire" type="submit">Créer mon compte</button>
      <p class="doux">Déjà inscrit ? <a class="lien" href="<?= e(url('connexion')) ?>">Se connecter</a></p>
    </form>
  </div>
</main>
<?php require __DIR__ . '/../includes/footer.php'; ?>
