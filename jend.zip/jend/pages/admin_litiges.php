<?php
exiger_admin();

if (post_verifie('admin/litiges')) {
    $id = (int) ($_POST['id'] ?? 0);
    try {
        litige_traiter($id, (string) ($_POST['action'] ?? ''), (string) ($_POST['message'] ?? ''), (int) ($_POST['montant'] ?? 0), !empty($_POST['a_charge_vendeur']));
        journaliser('litige_' . preg_replace('/[^a-z_]/', '', (string) $_POST['action']), '#' . $id . ((int) ($_POST['montant'] ?? 0) > 0 ? ' · ' . (int) $_POST['montant'] . ' FCFA' : ''));
        flash('Signalement mis à jour. Le client a été prévenu par e-mail.');
    } catch (RuntimeException $e) {
        flash($e->getMessage(), 'erreur');
    }
    rediriger('admin/litiges?id=' . $id);
}

$detail = null;
if (isset($_GET['id'])) {
    $detail = requete('SELECT l.*, u.nom AS client_nom, u.email AS client_email FROM litiges l JOIN users u ON u.id = l.client_id WHERE l.id = ?', [(int) $_GET['id']])->fetch() ?: null;
}
$vue = in_array($_GET['vue'] ?? '', ['clos', 'tous'], true) ? $_GET['vue'] : 'ouverts';
$filtre = ['ouverts' => "WHERE l.statut IN ('ouvert', 'en_cours')", 'clos' => "WHERE l.statut IN ('rembourse', 'remplace', 'rejete')", 'tous' => ''][$vue];
$liste = requete(
    "SELECT l.*, c.reference AS commande_ref, b.nom AS boutique, u.nom AS client_nom FROM litiges l
       JOIN commande_boutiques cb ON cb.id = l.commande_boutique_id JOIN commandes c ON c.id = cb.commande_id JOIN boutiques b ON b.id = cb.boutique_id JOIN users u ON u.id = l.client_id
     $filtre ORDER BY (l.statut IN ('ouvert', 'en_cours')) DESC, l.created_at LIMIT 200"
)->fetchAll();
$titre = 'Signalements — Administration';
require __DIR__ . '/../includes/header.php';
?>
<main class="page">
  <div class="wrap">
    <nav class="fil" aria-label="Fil d'Ariane"><a href="<?= e(url()) ?>">Accueil</a> / <a href="<?= e(url('admin')) ?>">Administration</a> / <span>Signalements</span></nav>
    <h1 class="titre-page">Administration</h1>
    <?php admin_onglets('litiges'); ?>

    <?php if ($detail): $l = litige_livraison((int) $detail['commande_boutique_id']); $photos = requete('SELECT id FROM litige_photos WHERE litige_id = ?', [$detail['id']])->fetchAll();
          $clos = in_array($detail['statut'], ['rembourse', 'remplace', 'rejete'], true); $retard = litige_en_retard($detail); ?>
      <p><a class="lien" href="<?= e(url('admin/litiges')) ?>">← Tous les signalements</a></p>
      <header class="lit-entete">
        <div>
          <p class="lit-surtitre">Dossier de signalement · <?= e($detail['client_nom']) ?></p>
          <h2 class="titre-page"><?= e($detail['reference']) ?></h2>
          <p class="doux">Ouvert le <?= e(date('d/m/Y à H:i', strtotime($detail['created_at']))) ?> · <?= e(MOTIFS_LITIGE[$detail['motif']]) ?> · <a class="lien" href="<?= e(url('litige/' . $detail['reference'])) ?>">vue du client</a></p>
        </div>
        <span class="badge badge-grand badge-litige-<?= e($detail['statut']) ?>"><?= e(STATUTS_LITIGE[$detail['statut']]) ?></span>
      </header>
      <?php $lit = $detail; $evenements = litige_evenements((int) $detail['id']); $vueEquipe = true; $nomClient = $detail['client_nom'];
            $partie = 'avancement'; require __DIR__ . '/../includes/litige_suivi.php'; ?>
      <div class="deux-colonnes">
        <section>
          <h3 class="sous-titre">Description initiale</h3>
          <p><?= nl2br(e($detail['description'])) ?></p>
          <?php if ($photos): ?><div class="photos-litige"><?php foreach ($photos as $ph): ?><a href="<?= e(url('litige/photo/' . $ph['id'])) ?>" target="_blank" rel="noopener"><img src="<?= e(url('litige/photo/' . $ph['id'])) ?>" alt="Photo jointe" loading="lazy"></a><?php endforeach; ?></div><?php endif; ?>
          <div class="recap recap-pleine">
            <h3>La livraison</h3>
            <p>Client : <b><?= e($detail['client_nom']) ?></b> (<?= e($detail['client_email']) ?>)<br>
               Commande : <b><?= e($l['commande_ref']) ?></b> · paiement <?= e(MOYENS_PAIEMENT[$l['methode_paiement']][0]) ?> (<?= e(STATUTS_PAIEMENT[$l['statut_paiement']]) ?>)<br>
               Boutique : <b><?= e($l['boutique']) ?></b> · statut livraison : <?= e(STATUTS_SOUS_COMMANDE[$l['statut']]) ?><br>
               Produits : <?= e(fcfa((int) $l['sous_total'])) ?> · livraison de la commande : <?= e(fcfa((int) $l['frais_livraison'])) ?></p>
          </div>
          <?php if ($detail['statut'] === 'rembourse'): ?>
            <p class="alerte alerte-info"><i class="ph ph-bank"></i> Remboursement de <b><?= e(fcfa((int) $detail['montant_rembourse'])) ?></b> accepté<?= $detail['a_charge_vendeur'] ? ' (retenu sur les gains du vendeur)' : ' (à la charge de Jënd)' ?>.
              <?php if ($detail['rembourse_le']): ?> Argent renvoyé le <?= e(heure_courte($detail['rembourse_le'])) ?>.<?php else: ?> <b>Argent pas encore renvoyé</b> : envoyez-le par Wave / Orange Money au numéro du client, puis confirmez ci-dessous.<?php endif; ?></p>
            <?php if (!$detail['rembourse_le']): ?>
              <form method="post" data-confirm="Confirmer que l'argent a bien été renvoyé au client ?"><?= csrf_champ() ?><input type="hidden" name="id" value="<?= (int) $detail['id'] ?>"><input type="hidden" name="action" value="confirmer_envoi"><button class="btn btn-primaire" type="submit">J'ai renvoyé l'argent au client</button></form>
            <?php endif; ?>
          <?php endif; ?>
        </section>
        <?php if (!$clos): ?>
        <form method="post" class="formulaire formulaire-large" novalidate>
          <?= csrf_champ() ?><input type="hidden" name="id" value="<?= (int) $detail['id'] ?>">
          <h2 class="sous-titre">Répondre au client</h2>
          <label class="champ"><span>Message (le client le lit sur son signalement et le reçoit par e-mail)</span><textarea name="message" rows="5" maxlength="2000" required></textarea></label>
          <label class="champ"><span>Montant à rembourser (FCFA, si remboursement)</span><input type="number" name="montant" min="0" max="<?= (int) $l['sous_total'] + (int) $l['frais_livraison'] ?>" value="<?= (int) $l['sous_total'] ?>"></label>
          <label class="case"><input type="checkbox" name="a_charge_vendeur" value="1" checked> <span>À la charge du vendeur (retenu sur ses gains s'il a déjà été crédité)</span></label>
          <div class="zone-actions">
            <button class="btn btn-contour" type="submit" name="action" value="repondre">Répondre (en cours d'examen)</button>
            <button class="btn btn-primaire" type="submit" name="action" value="rembourser" data-confirm="Accepter le remboursement ?">Rembourser</button>
            <button class="btn btn-contour" type="submit" name="action" value="remplacer" data-confirm="Accepter le remplacement ?">Remplacer</button>
            <button class="btn btn-contour" type="submit" name="action" value="rejeter" data-confirm="Refuser ce signalement ?">Refuser</button>
          </div>
        </form>
        <?php endif; ?>
      </div>
      <?php $partie = 'chronologie'; require __DIR__ . '/../includes/litige_suivi.php'; ?>
    <?php else: ?>
      <div class="filtres-vue">
        <a href="<?= e(url('admin/litiges')) ?>" class="<?= $vue === 'ouverts' ? 'actif' : '' ?>">À traiter</a>
        <a href="<?= e(url('admin/litiges?vue=clos')) ?>" class="<?= $vue === 'clos' ? 'actif' : '' ?>">Traités</a>
        <a href="<?= e(url('admin/litiges?vue=tous')) ?>" class="<?= $vue === 'tous' ? 'actif' : '' ?>">Tous</a>
      </div>
      <?php if (!$liste): ?><div class="vide"><i class="ph ph-chat-circle-text"></i><p><b>Aucun signalement.</b></p></div><?php else: ?>
      <div class="table-defile"><table class="table">
        <thead><tr><th>Référence</th><th>Client</th><th>Boutique</th><th>Motif</th><th>Statut</th><th>Délai (48 h)</th><th></th></tr></thead>
        <tbody>
        <?php foreach ($liste as $l): $retard = litige_en_retard($l); ?>
          <tr>
            <td><b><?= e($l['reference']) ?></b><br><span class="doux petit"><?= e($l['commande_ref']) ?></span></td>
            <td><?= e($l['client_nom']) ?></td><td><?= e($l['boutique']) ?></td><td><?= e(MOTIFS_LITIGE[$l['motif']]) ?></td>
            <td><span class="badge badge-litige-<?= e($l['statut']) ?>"><?= e(STATUTS_LITIGE[$l['statut']]) ?></span>
              <?= $l['statut'] === 'rembourse' && !$l['rembourse_le'] ? '<br><span class="petit">argent à renvoyer</span>' : '' ?></td>
            <td><?= $retard ? '<span class="badge badge-annulee">En retard</span>' : ($l['repondu_le'] ? 'répondu' : e(litige_echeance($l))) ?></td>
            <td><a class="btn btn-contour" href="<?= e(url('admin/litiges?id=' . $l['id'])) ?>">Ouvrir</a></td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table></div>
      <?php endif; ?>
    <?php endif; ?>
  </div>
</main>
<?php require __DIR__ . '/../includes/footer.php'; ?>
