<?php
[$u, $b] = exiger_vendeur();
$titre = 'Ma boutique — Jënd';
$erreurs = [];
$v = ['nom' => $b['nom'], 'description' => (string) $b['description'], 'telephone' => (string) $b['telephone_paiement']];

$disponibles = regions_disponibles();
$mesRegions = boutique_regions((int) $b['id']);
// Frais de livraison de la boutique, zone par zone (vide = frais de référence de Jënd)
$zonesBoutique = array_values(array_filter(zones_actives(), fn ($z) => !$mesRegions || in_array($z['region'], $mesRegions, true)));
$mesFrais = frais_boutiques([(int) $b['id']])[(int) $b['id']] ?? [];
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'frais') {
    if (!csrf_valide($_POST['csrf'] ?? null)) {
        flash('Session expirée, merci de réessayer.', 'erreur');
        rediriger('vendeur/boutique');
    }
    $saisis = (array) ($_POST['frais'] ?? []);
    $delais = (array) ($_POST['delai'] ?? []);
    $erreursFrais = [];
    $aEnregistrer = [];
    foreach (zones_actives() as $z) {
        $f = trim((string) ($saisis[$z['id']] ?? ''));
        $d = trim((string) ($delais[$z['id']] ?? ''));
        if ($f === '' && $d === '') {
            continue;                                   // rien de saisi : frais de référence
        }
        if ($f !== '' && (!ctype_digit($f) || (int) $f > FRAIS_LIVRAISON_MAX) || $d !== '' && (!ctype_digit($d) || (int) $d < 1 || (int) $d > 30)) {
            $erreursFrais[] = $z['nom'];
            continue;
        }
        $aEnregistrer[] = [(int) $z['id'], $f !== '' ? (int) $f : (int) $z['frais'], $d !== '' ? (int) $d : null];
    }
    if ($erreursFrais) {
        flash('Valeurs invalides pour : ' . implode(', ', $erreursFrais) . '. Frais : nombre entier en FCFA (0 à ' . fcfa(FRAIS_LIVRAISON_MAX) . ') ; délai : 1 à 30 jours.', 'erreur');
    } else {
        $pdo = pdo();
        $pdo->beginTransaction();
        requete('DELETE FROM boutique_frais WHERE boutique_id = ?', [$b['id']]);
        foreach ($aEnregistrer as [$zid, $f, $d]) {
            requete('INSERT INTO boutique_frais (boutique_id, zone_id, frais, delai_jours) VALUES (?, ?, ?, ?)', [$b['id'], $zid, $f, $d]);
        }
        $pdo->commit();
        flash('Vos frais de livraison sont enregistrés : ils s\'appliquent aux prochaines commandes.');
    }
    rediriger('vendeur/boutique#frais');
}
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'vitrine') {        // vitrine : logo, bannière, accroche, réseaux, WhatsApp
    if (!csrf_valide($_POST['csrf'] ?? null)) {
        flash('Session expirée, merci de réessayer.', 'erreur');
        rediriger('vendeur/boutique#vitrine');
    }
    $err = [];
    $slogan = trim((string) ($_POST['slogan'] ?? ''));
    $ville = trim((string) ($_POST['ville'] ?? ''));
    $couleur = (string) ($_POST['couleur'] ?? 'terre');
    $wa = trim((string) ($_POST['contact_whatsapp'] ?? ''));
    $waOk = $wa === '' ? null : telephone_valide($wa);
    if (mb_strlen($slogan) > 120) { $err[] = 'L\'accroche est limitée à 120 caractères.'; }
    if (mb_strlen($ville) > 80) { $err[] = 'La ville est limitée à 80 caractères.'; }
    if (!isset(COULEURS_BOUTIQUE[$couleur])) { $couleur = 'terre'; }
    if ($wa !== '' && $waOk === null) { $err[] = 'Numéro WhatsApp invalide (ex : 77 123 45 67).'; }
    $reseaux = [];
    foreach (RESEAUX_BOUTIQUE as $cle => [$nomR]) {
        $r = reseau_url_valide((string) ($_POST['reseau_' . $cle] ?? ''), $cle);
        if ($r === null) { $err[] = "Lien $nomR refusé : collez l'adresse https de votre page $nomR."; }
        $reseaux[$cle] = $r ?: null;
    }
    $nouvelles = [];
    if (!$err) {
        try {
            foreach (['logo', 'banniere'] as $champ) {
                if (($_FILES[$champ]['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_NO_FILE) {
                    $nouvelles[$champ] = image_enregistrer($_FILES[$champ], 'uploads/boutiques');
                }
            }
        } catch (RuntimeException $e) {
            array_map('image_supprimer', $nouvelles);
            $err[] = $e->getMessage();
        }
    }
    if ($err) {
        flash(implode(' ', $err), 'erreur');
        rediriger('vendeur/boutique#vitrine');
    }
    $logo = $nouvelles['logo'] ?? (!empty($_POST['retirer_logo']) ? null : $b['logo_chemin']);
    $banniere = $nouvelles['banniere'] ?? (!empty($_POST['retirer_banniere']) ? null : $b['banniere_chemin']);
    requete('UPDATE boutiques SET slogan = ?, ville = ?, couleur = ?, contact_whatsapp = ?, reseau_tiktok = ?, reseau_instagram = ?, reseau_facebook = ?, logo_chemin = ?, banniere_chemin = ? WHERE id = ?',
        [$slogan ?: null, $ville ?: null, $couleur, $waOk, $reseaux['tiktok'], $reseaux['instagram'], $reseaux['facebook'], $logo, $banniere, $b['id']]);
    foreach (['logo_chemin' => $logo, 'banniere_chemin' => $banniere] as $col => $nouveau) {
        if ($b[$col] && $b[$col] !== $nouveau) {
            image_supprimer((string) $b[$col]);                 // l'ancienne image ne reste pas sur le disque
        }
    }
    flash('Vitrine mise à jour.', 'ok', ['url' => url('boutique/' . $b['slug']), 'texte' => 'Voir ma boutique']);
    rediriger('vendeur/boutique#vitrine');
}
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'regions') {
    if (!csrf_valide($_POST['csrf'] ?? null)) {
        flash('Session expirée, merci de réessayer.', 'erreur');
    } else {
        $choisies = array_values(array_unique(array_filter((array) ($_POST['regions'] ?? []), fn ($r) => is_string($r) && in_array($r, $disponibles, true))));
        $pdo = pdo();
        $pdo->beginTransaction();
        requete('DELETE FROM boutique_regions WHERE boutique_id = ?', [$b['id']]);
        if (!empty($_POST['toutes']) || !$choisies || count($choisies) === count($disponibles)) {
            $choisies = [];                            // aucune ligne = la boutique livre partout
        }
        foreach ($choisies as $r) {
            requete('INSERT INTO boutique_regions (boutique_id, region) VALUES (?, ?)', [$b['id'], $r]);
        }
        $pdo->commit();
        flash($choisies ? 'Vous livrez maintenant à : ' . implode(', ', $choisies) . '.' : 'Vous livrez dans toutes les régions desservies par Jënd.');
    }
    rediriger('vendeur/boutique');
}
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    foreach ($v as $k => $_) {
        $v[$k] = trim((string) ($_POST[$k] ?? ''));
    }
    $tel = telephone_valide($v['telephone']);
    if (!csrf_valide($_POST['csrf'] ?? null)) {
        $erreurs[] = 'Session expirée, merci de réessayer.';
    }
    if (mb_strlen($v['nom']) < 3 || mb_strlen($v['nom']) > 80) {
        $erreurs[] = 'Le nom de la boutique doit faire entre 3 et 80 caractères.';
    }
    if (mb_strlen($v['description']) > 1000) {
        $erreurs[] = 'La description est limitée à 1000 caractères.';
    }
    if ($tel === null) {
        $erreurs[] = 'Numéro Wave / Orange Money invalide (ex : 77 123 45 67).';
    }
    if (!$erreurs) {
        $numeroChange = $tel !== (string) $b['telephone_paiement'];
        requete('UPDATE boutiques SET nom = ?, description = ?, telephone_paiement = ?, offres_actives = ?, sur_mesure = ? WHERE id = ?',
            [$v['nom'], $v['description'] !== '' ? $v['description'] : null, $tel, !empty($_POST['offres_actives']) ? 1 : 0, !empty($_POST['sur_mesure']) ? 1 : 0, $b['id']]);
        if ($numeroChange && (string) $b['telephone_paiement'] !== '') {
            // Sécurité : un compte piraté changerait d'abord le numéro de versement. Le vrai vendeur est prévenu, et les retraits sont suspendus 48 h.
            requete('UPDATE boutiques SET telephone_modifie_le = NOW() WHERE id = ?', [$b['id']]);
            envoyer_email((string) $u['email'], 'Numéro de paiement modifié — Jënd',
                "Bonjour,\n\nLe numéro qui reçoit les gains de votre boutique « {$v['nom']} » vient d'être changé en $tel.\nPar sécurité, les retraits sont suspendus pendant " . RETRAIT_DELAI_CHANGEMENT_HEURES . " heures.\n\nSi ce n'est PAS vous : changez immédiatement votre mot de passe et écrivez-nous depuis « Aide et contact ».\n" . app_url('contact'));
            flash('Boutique mise à jour. Votre numéro de paiement a changé : par sécurité, les retraits sont suspendus ' . RETRAIT_DELAI_CHANGEMENT_HEURES . ' heures, et un e-mail de contrôle vous a été envoyé.');
            rediriger('vendeur/boutique');
        }
        flash('Boutique mise à jour.');
        rediriger('vendeur/boutique');
    }
}
require __DIR__ . '/../includes/header.php';
?>
<main class="page">
  <div class="wrap">
    <nav class="fil" aria-label="Fil d'Ariane"><a href="<?= e(url()) ?>">Accueil</a> / <a href="<?= e(url('vendeur')) ?>">Boutique</a> / <span>Réglages</span></nav>
    <h1 class="titre-page"><?= e($b['nom']) ?></h1>
    <?php vendeur_onglets('boutique'); ?>
    <form method="post" class="formulaire formulaire-large largeur-640" novalidate>
      <?= csrf_champ() ?>
      <?php foreach ($erreurs as $er): ?><p class="alerte" role="alert"><?= e($er) ?></p><?php endforeach; ?>
      <label class="champ"><span>Nom de la boutique</span><input type="text" name="nom" value="<?= e($v['nom']) ?>" maxlength="80" required></label>
      <label class="champ"><span>Présentation</span><textarea name="description" rows="4" maxlength="1000"><?= e($v['description']) ?></textarea></label>
      <label class="champ"><span>Numéro Wave / Orange Money (versement des gains)</span><input type="tel" name="telephone" value="<?= e($v['telephone']) ?>" required></label>
      <label class="case"><input type="checkbox" name="offres_actives" value="1" <?= (int) $b['offres_actives'] === 1 ? 'checked' : '' ?>> <span>Accepter les <b>propositions de prix</b> des clients (vous restez libre d'accepter, de refuser ou de contre-proposer)</span></label>
      <label class="case"><input type="checkbox" name="sur_mesure" value="1" <?= (int) $b['sur_mesure'] === 1 ? 'checked' : '' ?>> <span>Je fais du <b>sur-mesure</b> (tailleur, couturier, artisan…) : les clients peuvent me demander un devis</span></label>
      <p class="doux petit">Statut : <b><?= e(['en_attente' => 'en attente de validation', 'active' => 'active', 'suspendue' => 'suspendue'][$b['statut']]) ?></b> · Commission : <?= e((string) $b['commission_pct']) ?> %</p>
      <button class="btn btn-primaire" type="submit">Enregistrer</button>
    </form>

    <form method="post" enctype="multipart/form-data" class="formulaire formulaire-large largeur-640 vitrine-form" id="vitrine" novalidate>
      <?= csrf_champ() ?><input type="hidden" name="action" value="vitrine">
      <h2 class="sous-titre">Ma vitrine</h2>
      <p class="doux">Ce que voient vos clients en ouvrant votre boutique. Une belle bannière et un logo donnent confiance : c'est votre devanture.
        <?php if ($b['statut'] === 'active'): ?><a class="lien" href="<?= e(url('boutique/' . $b['slug'])) ?>">Voir ma boutique</a><?php endif; ?></p>
      <div class="vitrine-apercu couleur-<?= e($b['couleur'] ?: 'terre') ?>">
        <div class="vitrine-apercu-banniere"><?php if ($b['banniere_chemin']): ?><img src="<?= e(url(image_miniature($b['banniere_chemin']))) ?>" alt=""><?php endif; ?></div>
        <span class="vitrine-logo"><?php if ($b['logo_chemin']): ?><img src="<?= e(url(image_miniature($b['logo_chemin']))) ?>" alt=""><?php else: ?><?= e(boutique_initiales($b['nom'])) ?><?php endif; ?></span>
      </div>
      <label class="champ"><span>Logo (carré, JPEG ou PNG, 3 Mo max)</span><input type="file" name="logo" accept="image/jpeg,image/png">
        <?php if ($b['logo_chemin']): ?><label class="case"><input type="checkbox" name="retirer_logo" value="1"> <span>Retirer le logo</span></label><?php endif; ?></label>
      <label class="champ"><span>Bannière (photo large, idéalement 1600 × 500)</span><input type="file" name="banniere" accept="image/jpeg,image/png">
        <?php if ($b['banniere_chemin']): ?><label class="case"><input type="checkbox" name="retirer_banniere" value="1"> <span>Retirer la bannière</span></label><?php endif; ?></label>
      <label class="champ"><span>Accroche (une phrase sous le nom)</span><input type="text" name="slogan" maxlength="120" value="<?= e((string) $b['slogan']) ?>" placeholder="Ex. : Le wax de qualité, cousu main à Touba depuis 2015"></label>
      <label class="champ"><span>Ville</span><input type="text" name="ville" maxlength="80" value="<?= e((string) $b['ville']) ?>" placeholder="Ex. : Touba, Darou Khoudoss"></label>
      <fieldset class="champ choix-couleurs"><legend>Couleur de la vitrine (si pas de bannière)</legend>
        <?php foreach (COULEURS_BOUTIQUE as $cle => $nomC): ?><label class="couleur-<?= e($cle) ?>"><input type="radio" name="couleur" value="<?= e($cle) ?>" <?= ($b['couleur'] ?: 'terre') === $cle ? 'checked' : '' ?>> <span><?= e($nomC) ?></span></label><?php endforeach; ?>
      </fieldset>
      <label class="champ"><span>Numéro WhatsApp pour les clients (facultatif : affiche un bouton « Écrire sur WhatsApp »)</span><input type="tel" name="contact_whatsapp" value="<?= e((string) $b['contact_whatsapp']) ?>" placeholder="77 123 45 67">
        <small class="doux">Rappel : la commande et le paiement doivent se faire sur Jënd (argent protégé), jamais par simple transfert.</small></label>
      <?php foreach (RESEAUX_BOUTIQUE as $cle => [$nomR]): ?>
        <label class="champ"><span>Page <?= e($nomR) ?> (facultatif)</span><input type="url" name="reseau_<?= e($cle) ?>" maxlength="255" value="<?= e((string) $b['reseau_' . $cle]) ?>" placeholder="https://www.<?= e(RESEAUX_BOUTIQUE[$cle][1][0]) ?>/…"></label>
      <?php endforeach; ?>
      <button class="btn btn-primaire" type="submit">Enregistrer ma vitrine</button>
    </form>

    <form method="post" class="formulaire formulaire-large largeur-640" id="regions">
      <?= csrf_champ() ?><input type="hidden" name="action" value="regions">
      <h2 class="sous-titre">Où livrez-vous ?</h2>
      <p class="doux">Cochez les villes et régions où vous pouvez livrer (vous-même ou par un transporteur). Un client d'une autre région ne pourra pas commander vos produits. Rien de coché, ou tout coché : vous livrez partout.</p>
      <div class="regions-grille">
        <?php foreach ($disponibles as $r): ?>
          <label class="case"><input type="checkbox" name="regions[]" value="<?= e($r) ?>" <?= in_array($r, $mesRegions, true) ? 'checked' : '' ?>> <span><?= e($r) ?></span></label>
        <?php endforeach; ?>
      </div>
      <p class="petit"><label class="case"><input type="checkbox" name="toutes" value="1" <?= !$mesRegions ? 'checked' : '' ?>> <span><b>Je livre partout</b> (ignore les cases ci-dessus)</span></label></p>
      <button class="btn btn-primaire" type="submit">Enregistrer mes zones de livraison</button>
    </form>

    <form method="post" class="formulaire formulaire-large largeur-640" id="frais">
      <?= csrf_champ() ?><input type="hidden" name="action" value="frais">
      <h2 class="sous-titre">Mes frais de livraison</h2>
      <p class="doux">Fixez ce que vous facturez au client pour livrer dans chaque zone : <b>ces frais vous reviennent en entier</b> (aucune commission dessus). Laissez vide pour appliquer les <b>frais de référence</b> de Jënd, indiqués en gris.<?= $b['livraison_par'] === 'jend' && livreurs_jend_actifs() ? ' <b>Vos commandes sont livrées par les livreurs Jënd : ce sont alors les frais de référence qui s\'appliquent.</b>' : '' ?></p>
      <?php if (!$zonesBoutique): ?><p class="doux">Aucune zone : choisissez d'abord où vous livrez ci-dessus.</p><?php else: ?>
      <div class="table-defile"><table class="table tableau-frais">
        <thead><tr><th>Zone</th><th>Mes frais (FCFA)</th><th>Mon délai (jours)</th></tr></thead>
        <tbody>
        <?php foreach (zones_par_ville($zonesBoutique) as $ville => $zs): ?>
          <tr class="ligne-ville"><td colspan="3"><b><?= e($ville) ?></b></td></tr>
          <?php foreach ($zs as $z): $mf = $mesFrais[(int) $z['id']] ?? null; ?>
            <tr><td><?= e($z['nom']) ?></td>
              <td><input type="text" inputmode="numeric" name="frais[<?= (int) $z['id'] ?>]" value="<?= $mf ? (int) $mf['frais'] : '' ?>" placeholder="<?= (int) $z['frais'] ?>" class="largeur-120" aria-label="Frais pour <?= e($z['nom']) ?>"></td>
              <td><input type="text" inputmode="numeric" name="delai[<?= (int) $z['id'] ?>]" value="<?= $mf && $mf['delai'] !== null ? (int) $mf['delai'] : '' ?>" placeholder="<?= (int) $z['delai_jours'] ?>" class="largeur-90" aria-label="Délai pour <?= e($z['nom']) ?>"></td></tr>
          <?php endforeach; ?>
        <?php endforeach; ?>
        </tbody></table></div>
      <button class="btn btn-primaire" type="submit">Enregistrer mes frais de livraison</button>
      <?php endif; ?>
    </form>
  </div>
</main>
<?php require __DIR__ . '/../includes/footer.php'; ?>
