<?php
[$u, $l] = exiger_livreur();
$id = (int) $parametre;
$c = requete(SQL_COURSE . ' WHERE cb.id = ? AND cb.livreur_id = ?', [$id, $u['id']])->fetch();
if (!$c) {                                  // une course qui n'est pas à vous n'existe pas
    http_response_code(404);
    require __DIR__ . '/404.php';
    return;
}

if (post_verifie('livreur/course/' . $id)) {
    try {
        course_avancer($id, (int) $u['id'], (string) ($_POST['action'] ?? ''), (string) ($_POST['code'] ?? ''));
        flash(['recuperer' => 'Colis récupéré. Bonne route !', 'en_route' => 'En route vers le client.', 'livrer' => 'Livraison confirmée, merci !'][$_POST['action']] ?? 'Course mise à jour.');
    } catch (RuntimeException $e) {
        flash($e->getMessage(), 'erreur');
    }
    rediriger('livreur/course/' . $id);
}

$lignes = requete('SELECT nom, quantite, variante_libelle FROM commande_lignes WHERE commande_boutique_id = ?', [$id])->fetchAll();
$etape = course_etape($c);
$enc = course_a_encaisser($c);
$telClient = preg_replace('/[^\d+]/', '', (string) $c['livraison_telephone']);
$telVendeur = preg_replace('/[^\d+]/', '', (string) $c['tel_vendeur']);
$waClient = 'https://wa.me/' . preg_replace('/\D/', '', $telClient);
$adresseComplete = $c['livraison_adresse'] . ', ' . $c['livraison_zone'];
$frise = [
    ['affectee', 'Course reçue', $c['affecte_le'], 'ph-bell-ringing'],
    ['recuperee', 'Colis récupéré chez le vendeur', $c['recupere_le'], 'ph-package'],
    ['en_route', 'En route vers le client', $c['en_route_le'], 'ph-motorcycle'],
    ['livree', 'Livré au client', $c['livre_le'], 'ph-check-circle'],
];
$rang = ['affectee' => 1, 'recuperee' => 2, 'en_route' => 3, 'livree' => 4, 'annulee' => 0][$etape];
$actionPrincipale = ['affectee' => ['recuperer', 'J\'ai récupéré le colis', 'ph-package'], 'recuperee' => ['en_route', 'Je pars chez le client', 'ph-motorcycle']][$etape] ?? null;

livreur_entete('Course ' . $c['reference'] . ' — Jënd Livreur', '', url('livreur'));
?>
<section class="resume">
  <div><small><?= e($c['reference']) ?></small><b class="resume-montant"><?= $enc > 0 ? e(fcfa($enc)) : 'Payé' ?></b>
    <small><?= $enc > 0 ? 'à encaisser auprès du client' : 'en ligne : ne demandez aucun argent' ?></small></div>
  <span class="puce puce-<?= e($etape) ?>"><?= e(ETAPES_COURSE[$etape]) ?></span>
</section>

<?php if ($etape === 'annulee'): ?>
  <p class="app-alerte"><i class="ph-fill ph-warning"></i> Cette commande est annulée : <b>ne livrez pas ce colis</b>.</p>
<?php endif; ?>

<ol class="frise" aria-label="Avancement">
  <?php foreach ($frise as $k => [$cle, $libelle, $quand, $icone]): $n = $k + 1; $fait = $rang >= $n && $etape !== 'annulee'; ?>
    <li class="<?= $fait ? 'fait' : '' ?> <?= $rang + 1 === $n && $etape !== 'annulee' && $etape !== 'livree' ? 'suivant' : '' ?>">
      <span class="frise-point"><i class="ph<?= $fait ? '-fill' : '' ?> <?= e($icone) ?>"></i></span>
      <div><b><?= e($libelle) ?></b><small><?= $quand ? e(heure_courte($quand)) : 'À venir' ?></small></div>
    </li>
  <?php endforeach; ?>
</ol>

<?php if ($etape === 'en_route'): ?>
  <form method="post" class="carte-info carte-code" id="form-livraison">
    <?= csrf_champ() ?><input type="hidden" name="action" value="livrer">
    <h2><i class="ph ph-password"></i> Code de livraison</h2>
    <p class="doux">Le client vous donne ce code à 4 chiffres <b>quand il a reçu son colis</b>. Ne le demandez pas avant.</p>
    <input class="saisie-code" type="text" name="code" inputmode="numeric" pattern="\d{4}" maxlength="4" autocomplete="off" placeholder="0000" aria-label="Code de livraison à 4 chiffres" required>
    <?php if ($enc > 0): ?><label class="case-espece"><input type="checkbox" required> J'ai encaissé <b><?= e(fcfa($enc)) ?></b></label><?php endif; ?>
  </form>
<?php endif; ?>

<section class="carte-info">
  <h2><i class="ph ph-storefront"></i> À récupérer chez</h2>
  <p class="gros"><?= e($c['boutique']) ?></p>
  <ul class="articles"><?php foreach ($lignes as $li): ?><li><b><?= (int) $li['quantite'] ?>×</b> <?= e($li['nom']) ?><?= $li['variante_libelle'] ? ' — <b>' . e($li['variante_libelle']) . '</b>' : '' ?></li><?php endforeach; ?></ul>
  <?php if ($telVendeur !== ''): ?><div class="raccourcis"><a class="raccourci" href="tel:<?= e($telVendeur) ?>"><i class="ph ph-phone"></i> Appeler le vendeur</a></div><?php endif; ?>
</section>

<section class="carte-info">
  <h2><i class="ph ph-map-pin"></i> À livrer à</h2>
  <p class="gros"><?= e($c['livraison_nom']) ?></p>
  <p><?= e($c['livraison_adresse']) ?><br><span class="doux"><?= e($c['livraison_zone']) ?></span></p>
  <div class="raccourcis">
    <a class="raccourci" href="tel:<?= e($telClient) ?>"><i class="ph ph-phone"></i> Appeler</a>
    <a class="raccourci" href="<?= e($waClient) ?>" target="_blank" rel="noopener noreferrer"><i class="ph ph-whatsapp-logo"></i> WhatsApp</a>
    <a class="raccourci" href="<?= e(lien_itineraire($c)) ?>" target="_blank" rel="noopener noreferrer"><i class="ph ph-navigation-arrow"></i> Itinéraire</a>
    <button class="raccourci" type="button" data-copier="<?= e($adresseComplete) ?>"><i class="ph ph-copy"></i> Copier</button>
  </div>
</section>


<?php if ($etape === 'livree'): ?>
  <p class="app-succes"><i class="ph-fill ph-check-circle"></i> Course terminée<?= $c['livre_le'] ? ' · ' . e(heure_courte($c['livre_le'])) : '' ?>. Merci !</p>
<?php endif; ?>

<?php if ($actionPrincipale || $etape === 'en_route'): ?>
  <div class="barre-action">
    <?php if ($actionPrincipale): ?>
      <form method="post"><?= csrf_champ() ?><button class="bouton-principal" type="submit" name="action" value="<?= e($actionPrincipale[0]) ?>"><i class="ph-fill <?= e($actionPrincipale[2]) ?>"></i> <?= e($actionPrincipale[1]) ?></button></form>
    <?php else: ?>
      <button class="bouton-principal" type="submit" form="form-livraison"><i class="ph-fill ph-check-circle"></i> Confirmer la livraison</button>
    <?php endif; ?>
  </div>
<?php endif; ?>
<?php livreur_pied(false); ?>
