<?php
$titre = 'Mon panier — Jënd';
commandes_expirer();                 // libère le stock des commandes jamais payées (voir includes/commandes.php)
$panier = panier_charger();
$aideFlottante = true;
require __DIR__ . '/../includes/header.php';
?>
<main class="page">
  <div class="wrap">
    <nav class="fil" aria-label="Fil d'Ariane"><a href="<?= e(url()) ?>">Accueil</a> / <span>Panier</span></nav>
    <h1 class="titre-page">Mon panier</h1>

    <?php if ($panier['ajuste']): ?>
      <p class="alerte">Certains articles ont été ajustés ou retirés car leur stock a changé.</p>
    <?php endif; ?>

    <?php if (!$panier['lignes']): ?>
      <div class="vide">
        <i class="ph ph-shopping-bag"></i>
        <p><b>Votre panier est vide.</b><br>Parcourez le catalogue pour trouver votre bonheur.</p>
        <a href="<?= e(url('produits')) ?>" class="btn btn-primaire mt1">Voir les produits</a>
      </div>
    <?php else: ?>
      <div class="panier-grille">
        <div class="panier-lignes">
          <?php foreach ($panier['lignes'] as $l): ?>
            <article class="panier-ligne">
              <a href="<?= e(url('produit/' . $l['slug'])) ?>" class="panier-photo <?= classe_fond((int) $l['id']) ?>">
                <?php if ($l['image']): ?><img src="<?= e(url(image_miniature($l['image']))) ?>" alt=""><?php else: ?><i class="ph-fill <?= e($l['icone'] ?: 'ph-package') ?>"></i><?php endif; ?>
              </a>
              <div class="panier-infos">
                <span class="vendeur"><i class="ph-fill ph-seal-check"></i> <?= e($l['boutique']) ?></span>
                <h2><a href="<?= e(url('produit/' . $l['slug'])) ?>"><?= e($l['nom']) ?></a></h2>
                <?php if ($l['variante_libelle']): ?><span class="variante-choisie"><?= e($l['variante_libelle']) ?></span><?php endif; ?>
                <span class="doux"><?= e(fcfa((int) $l['prix'])) ?> l'unité<?php if ((int) $l['prix'] < (int) $l['prix_affiche']): ?> <span class="badge-verifie"><i class="ph-fill <?= $l['promo_fete'] ? 'ph-confetti' : 'ph-handshake' ?>"></i> <?= $l['promo_fete'] ? 'promo fête −' . (int) $l['promo_pct'] . ' %' : 'prix négocié' ?></span> <s><?= e(fcfa((int) $l['prix_affiche'])) ?></s><?php elseif ((int) $l['offre_max'] > 0): ?> <small>(prix négocié valable jusqu'à <?= (int) $l['offre_max'] ?> article(s))</small><?php endif; ?></span>
                <div class="panier-actions">
                  <form method="post" action="<?= e(url('panier/modifier')) ?>" class="qte-form">
                    <?= csrf_champ() ?>
                    <input type="hidden" name="cle" value="<?= e($l['cle']) ?>">
                    <input type="hidden" name="action" value="maj">
                    <label class="sr" for="q<?= e(str_replace(':', '-', $l['cle'])) ?>">Quantité</label>
                    <input id="q<?= e(str_replace(':', '-', $l['cle'])) ?>" type="number" name="quantite" value="<?= (int) $l['quantite'] ?>" min="1" max="<?= min(10, (int) $l['stock']) ?>">
                    <button class="lien" type="submit">Mettre à jour</button>
                  </form>
                  <form method="post" action="<?= e(url('panier/modifier')) ?>">
                    <?= csrf_champ() ?>
                    <input type="hidden" name="cle" value="<?= e($l['cle']) ?>">
                    <input type="hidden" name="action" value="supprimer">
                    <button class="lien lien-danger" type="submit"><i class="ph ph-trash"></i> Retirer</button>
                  </form>
                </div>
              </div>
              <b class="panier-total"><?= e(fcfa((int) $l['total'])) ?></b>
            </article>
          <?php endforeach; ?>
        </div>

        <aside class="recap">
          <h2>Récapitulatif</h2>
          <div class="recap-ligne"><span>Sous-total</span><b><?= e(fcfa($panier['sous_total'])) ?></b></div>
          <div class="recap-ligne doux"><span>Livraison</span><span>calculée à l'étape suivante</span></div>
          <a href="<?= e(url('commande')) ?>" class="btn btn-primaire recap-btn">Passer la commande <i class="ph ph-arrow-right"></i></a>
          <a href="<?= e(url('produits')) ?>" class="reinit">Continuer mes achats</a>
          <ul class="rassurance-achat rassurance-recap">
            <li><i class="ph-fill ph-shield-check"></i> <span>Paiement sécurisé : Wave, Orange Money ou carte</span></li>
            <li><i class="ph-fill ph-hand-coins"></i> <span>Le vendeur n'est payé qu'après votre réception</span></li>
          </ul>
          <?php if (utilisateur()): ?><a href="<?= e(url('depense/nouvelle')) ?>" class="btn btn-contour recap-btn"><i class="ph ph-basket"></i> Enregistrer comme dépense du mois</a>
          <small class="doux">Recevez un rappel chaque mois pour la recommander en un clic, pour vous ou pour votre famille.</small><?php endif; ?>
        </aside>
      </div>
    <?php endif; ?>
  </div>
</main>
<?php require __DIR__ . '/../includes/footer.php'; ?>
