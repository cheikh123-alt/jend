<?php
/**
 * Confirmation de l'adresse e-mail. GET confirmer-email/{jeton} : lien reçu par e-mail. POST confirmer-email : renvoyer le lien.
 */
if ($parametre === null) {
    $u = exiger_connexion();
    if (post_verifie('compte')) {
        if (limite_atteinte('email-confirm:' . $u['id'], 3, 3600)) {
            flash('Vous avez déjà demandé plusieurs liens : vérifiez vos e-mails (et les indésirables), ou réessayez dans une heure.', 'erreur');
        } else {
            limite_enregistrer('email-confirm:' . $u['id']);
            flash(email_confirmation_envoyer((int) $u['id']) ? 'Nouveau lien envoyé à ' . $u['email'] . '.' : 'Votre adresse est déjà confirmée.');
        }
    }
    rediriger('compte');
}
$hash = hash('sha256', (string) $parametre);
$cible = requete('SELECT id FROM users WHERE email_jeton_hash = ? AND email_jeton_expire > NOW() AND email_verifie = 0', [$hash])->fetch();
if ($cible) {
    requete('UPDATE users SET email_verifie = 1, email_jeton_hash = NULL, email_jeton_expire = NULL WHERE id = ?', [$cible['id']]);
    flash('Adresse e-mail confirmée. Votre compte est actif : vous pouvez commander.');
} else {
    flash('Ce lien de confirmation est invalide ou a expiré. Connectez-vous, puis demandez un nouveau lien depuis « Mon compte ».', 'erreur');
}
rediriger(utilisateur() ? 'compte' : 'connexion');
