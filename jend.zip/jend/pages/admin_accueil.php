<?php
exiger_admin();
$titre = 'Administration — Jënd';
$n = fn (string $sql, array $p = []) => (int) requete($sql, $p)->fetchColumn();

$attente     = $n("SELECT COUNT(*) FROM boutiques WHERE statut = 'en_attente'");
$retraits    = $n("SELECT COUNT(*) FROM retraits WHERE statut = 'demande'");
$retraitsMt  = $n("SELECT COALESCE(SUM(montant), 0) FROM retraits WHERE statut = 'demande'");
$rembourser  = $n("SELECT COUNT(*) FROM commandes WHERE statut = 'annulee' AND statut_paiement = 'paye'");
$litiges     = $n("SELECT COUNT(*) FROM litiges WHERE statut IN ('ouvert', 'en_cours')");
$litigesRetard = $n("SELECT COUNT(*) FROM litiges WHERE statut IN ('ouvert', 'en_cours') AND repondu_le IS NULL AND created_at < (NOW() - INTERVAL " . LITIGE_DELAI_REPONSE_HEURES . " HOUR)");
$pdAttente   = paydunya_actif() ? $n("SELECT COUNT(DISTINCT commande_id) FROM paiements WHERE fournisseur = 'paydunya' AND statut = 'initie' AND reference_externe IS NOT NULL AND created_at > (NOW() - INTERVAL 3 DAY)") : 0;
$coursesLibres = livreurs_jend_actifs() ? $n("SELECT COUNT(*) FROM commande_boutiques cb JOIN commandes c ON c.id = cb.commande_id
                                               WHERE cb.livre_par = 'jend' AND cb.statut IN ('a_preparer', 'expediee') AND cb.livreur_id IS NULL AND c.statut <> 'annulee' AND " . SQL_ENGAGEE) : 0;

$boutiques   = $n("SELECT COUNT(*) FROM boutiques WHERE statut = 'active'");
$produits    = $n("SELECT COUNT(*) FROM produits WHERE statut = 'publie'");
$clients     = $n("SELECT COUNT(*) FROM users WHERE role = 'client'");
$ca          = $n("SELECT COALESCE(SUM(total), 0) FROM commandes WHERE statut_paiement = 'paye'");
$ca7         = $n("SELECT COALESCE(SUM(total), 0) FROM commandes WHERE statut_paiement = 'paye' AND created_at >= (NOW() - INTERVAL 7 DAY)");
$cmd7        = $n("SELECT COUNT(*) FROM commandes WHERE created_at >= (NOW() - INTERVAL 7 DAY)");
$commission  = $n("SELECT COALESCE(SUM(cb.commission), 0) FROM commande_boutiques cb JOIN commandes c ON c.id = cb.commande_id WHERE cb.statut = 'livree' AND c.statut_paiement = 'paye'");

$recentes = requete(
    "SELECT c.reference, c.total, c.statut, c.statut_paiement, c.created_at, u.nom
       FROM commandes c JOIN users u ON u.id = c.client_id ORDER BY c.id DESC LIMIT 6"
)->fetchAll();
$journal = requete('SELECT j.action, j.detail, j.created_at, u.nom FROM journal_admin j LEFT JOIN users u ON u.id = j.admin_id ORDER BY j.id DESC LIMIT 5')->fetchAll();
$modeTest = paydunya_actif() && paydunya_mode_test();

require __DIR__ . '/../includes/header.php';
?>
<main class="page">
  <div class="wrap">
    <nav class="fil" aria-label="Fil d'Ariane"><a href="<?= e(url()) ?>">Accueil</a> / <span>Administration</span></nav>
    <div class="compte-tete">
      <div><h1 class="titre-page">Administration</h1><p class="compte"><?= e(tb_salutation()) ?> · <?= e(tb_date_longue()) ?></p></div>
      <a class="btn btn-contour" href="<?= e(url('admin/tresorerie')) ?>"><i class="ph ph-vault"></i> Trésorerie</a>
    </div>
    <?php admin_onglets('accueil'); ?>

    <?php if ($modeTest): ?>
      <p class="alerte alerte-info"><i class="ph ph-flask"></i> <span><b>Paiements PayDunya en mode TEST</b> : aucun argent réel n'est encaissé. Passez en mode « live » (clés de production) pour ouvrir les vrais paiements.</span></p>
    <?php endif; ?>

    <?php tb_a_faire([
        tb_action('ph-storefront', 'boutique(s) à valider', $attente, 'admin/boutiques', 'urgent', 'Les vendeurs attendent votre validation pour être visibles.', 'Valider'),
        tb_action('ph-chat-circle-text', 'signalement(s) de clients', $litiges, 'admin/litiges', $litigesRetard > 0 ? 'urgent' : 'normal', $litigesRetard > 0 ? $litigesRetard . ' en retard sur le délai de réponse de 48 h.' : 'Réponse promise sous 48 h.', 'Traiter'),
        tb_action('ph-tray', 'message(s) d\'aide à traiter', support_a_traiter(), 'admin/messages', 'urgent', 'Clients, vendeurs ou visiteurs vous ont écrit (réponse promise sous ' . SUPPORT_DELAI_HEURES . ' h).', 'Répondre'),
        tb_action('ph-bank', $retraits > 1 ? 'demandes de retrait à payer' : 'demande de retrait à payer', $retraits, 'admin/retraits', 'normal', 'Total à envoyer : ' . fcfa($retraitsMt) . '.', 'Payer'),
        tb_action('ph-arrow-u-up-left', 'remboursement(s) client à faire', $rembourser, 'admin/commandes?vue=rembourser', 'urgent', 'Commandes annulées déjà payées.', 'Rembourser'),
        tb_action('ph-hourglass', 'paiement(s) PayDunya à vérifier', $pdAttente, 'admin/commandes?vue=attente', 'normal', 'Payés côté client mais pas encore confirmés : cliquez sur « Vérifier ».', 'Vérifier'),
        tb_action('ph-motorcycle', 'course(s) sans livreur', $coursesLibres, 'admin/courses', 'urgent', 'Affectez un livreur pour que la livraison démarre.', 'Affecter'),
    ], 'Tout est à jour : aucune validation, aucun retrait ni signalement en attente.'); ?>

    <div class="tb-kpis">
      <?= tb_kpi('ph-coins', 'Encaissé (total payé)', fcfa($ca), fcfa($ca7) . ' sur 7 jours', 'admin/tresorerie', true) ?>
      <?= tb_kpi('ph-percent', 'Commissions (livré)', fcfa($commission), 'part de Jënd', 'admin/tresorerie') ?>
      <?= tb_kpi('ph-receipt', 'Commandes (7 jours)', (string) $cmd7, 'toutes confondues', 'admin/commandes') ?>
      <?= tb_kpi('ph-storefront', 'Boutiques actives', (string) $boutiques, $produits . ' produit(s) en vente', 'admin/boutiques') ?>
      <?= tb_kpi('ph-users', 'Clients inscrits', (string) $clients) ?>
      <?= tb_kpi('ph-handshake', 'Offres de prix (7 jours)', (string) $n("SELECT COUNT(*) FROM offres WHERE created_at >= (NOW() - INTERVAL 7 DAY)"), $n("SELECT COUNT(*) FROM demandes_mesure WHERE created_at >= (NOW() - INTERVAL 7 DAY)") . ' demande(s) sur mesure', 'admin/offres') ?>
    </div>

    <div class="tb-deux">
      <section class="tb-bloc">
        <h2 class="tb-titre"><i class="ph-fill ph-receipt"></i> Dernières commandes</h2>
        <?php if (!$recentes): ?>
          <div class="tb-vide"><i class="ph ph-receipt"></i><p>Aucune commande pour le moment.</p></div>
        <?php else: ?>
          <ul class="tb-liste">
            <?php foreach ($recentes as $r): ?>
              <li><a href="<?= e(url('commande/' . $r['reference'])) ?>"><span><b><?= e($r['reference']) ?></b> <small class="doux"><?= e(date('d/m H:i', strtotime($r['created_at']))) ?></small><br><small class="doux"><?= e($r['nom']) ?></small></span>
                <span><?= e(fcfa((int) $r['total'])) ?> <span class="badge badge-<?= e($r['statut']) ?>"><?= e(STATUTS_COMMANDE[$r['statut']]) ?></span><br><small class="doux"><?= e(STATUTS_PAIEMENT[$r['statut_paiement']]) ?></small></span></a></li>
            <?php endforeach; ?>
          </ul>
          <p class="petit"><a class="lien" href="<?= e(url('admin/commandes')) ?>">Toutes les commandes</a></p>
        <?php endif; ?>
      </section>

      <section class="tb-bloc">
        <h2 class="tb-titre"><i class="ph-fill ph-scroll"></i> Dernières actions</h2>
        <?php if (!$journal): ?>
          <div class="tb-vide"><i class="ph ph-scroll"></i><p>Aucune action enregistrée.</p></div>
        <?php else: ?>
          <ul class="tb-liste">
            <?php foreach ($journal as $j): ?>
              <li><span><b><?= e(str_replace('_', ' ', $j['action'])) ?></b><br><small class="doux"><?= e((string) $j['detail']) ?></small></span>
                <span class="doux petit"><?= e(date('d/m H:i', strtotime($j['created_at']))) ?></span></li>
            <?php endforeach; ?>
          </ul>
          <p class="petit"><a class="lien" href="<?= e(url('admin/journal')) ?>">Journal complet</a></p>
        <?php endif; ?>
      </section>
    </div>

    <section class="tb-bloc">
      <h2 class="tb-titre"><i class="ph-fill ph-compass"></i> Raccourcis</h2>
      <div class="tb-raccourcis">
        <a href="<?= e(url('admin/parametres')) ?>"><i class="ph ph-sliders"></i> Paramètres<small>commission, acompte, retraits</small></a>
        <a href="<?= e(url('admin/produits')) ?>"><i class="ph ph-package"></i> Produits<small>modérer le catalogue</small></a>
        <a href="<?= e(url('admin/zones')) ?>"><i class="ph ph-map-pin"></i> Zones<small>quartiers et frais de livraison</small></a>
        <a href="<?= e(url('frais-commissions')) ?>"><i class="ph ph-scales"></i> Frais publics<small>ce que voient les vendeurs</small></a>
      </div>
    </section>
  </div>
</main>
<?php require __DIR__ . '/../includes/footer.php'; ?>
