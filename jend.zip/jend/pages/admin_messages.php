<?php
/** Boîte de réception de l'administrateur : conversations « Aide et contact ». */
exiger_admin();
$retour = 'admin/messages' . (($_GET['vue'] ?? '') === 'closes' ? '?vue=closes' : '');
if (post_verifie('admin/messages')) {
    $id = (int) ($_POST['id'] ?? 0);
    try {
        $action = (string) ($_POST['action'] ?? '');
        if ($action === 'repondre') {
            support_ajouter($id, 'equipe', (string) ($_POST['texte'] ?? ''), (int) utilisateur()['id']);
            journaliser('support_reponse', '#' . $id);
            flash('Réponse envoyée : la personne peut vous répondre dans la même conversation.');
        } elseif ($action === 'clore' || $action === 'rouvrir') {
            support_clore($id, $action === 'clore');
            journaliser($action === 'clore' ? 'support_clos' : 'support_rouvert', '#' . $id);
            flash($action === 'clore' ? 'Conversation close.' : 'Conversation rouverte.');
        }
    } catch (RuntimeException $e) {
        flash($e->getMessage(), 'erreur');
    }
    rediriger($retour);
}
$closes = ($_GET['vue'] ?? '') === 'closes';
$messages = requete('SELECT m.*, u.role FROM messages_support m LEFT JOIN users u ON u.id = m.user_id WHERE m.statut ' . ($closes ? "= 'resolu'" : "<> 'resolu'")
    . " ORDER BY (m.statut = 'nouveau') DESC, m.id DESC LIMIT 100")->fetchAll();
$roles = ['client' => 'Client', 'vendeur' => 'Vendeur', 'admin' => 'Admin', 'livreur' => 'Livreur'];
$vueEquipe = true;
$titre = 'Messages — Administration';
require __DIR__ . '/../includes/header.php';
?>
<main class="page">
  <div class="wrap">
    <nav class="fil" aria-label="Fil d'Ariane"><a href="<?= e(url()) ?>">Accueil</a> / <a href="<?= e(url('admin')) ?>">Administration</a> / <span>Messages</span></nav>
    <h1 class="titre-page">Administration</h1>
    <?php admin_onglets('messages'); ?>
    <p class="doux">Chaque demande est une <b>conversation</b> : vous échangez dans le même fil jusqu'à ce que tout soit réglé, puis vous la <b>closez</b>. Vos réponses partent aussi par e-mail. Délai annoncé : <?= SUPPORT_DELAI_HEURES ?> heures.</p>
    <nav class="onglets" aria-label="Filtrer"><a href="<?= e(url('admin/messages')) ?>" <?= $closes ? '' : 'class="actif"' ?>>En cours</a><a href="<?= e(url('admin/messages?vue=closes')) ?>" <?= $closes ? 'class="actif"' : '' ?>>Closes</a></nav>
    <?php if (!$messages): ?>
      <div class="tb-vide"><i class="ph ph-tray"></i><p><b><?= $closes ? 'Aucune conversation close.' : 'Aucune conversation en cours.' ?></b></p></div>
    <?php else: ?>
      <div class="offres">
        <?php foreach ($messages as $m): $fil = support_fil($m); $retard = $m['statut'] === 'nouveau' && strtotime(end($fil)['created_at']) < time() - SUPPORT_DELAI_HEURES * 3600; ?>
          <article class="offre offre-<?= $m['statut'] === 'nouveau' ? 'contre' : ($m['statut'] === 'resolu' ? 'close' : 'en_attente') ?>">
            <header><b><?= e($m['reference']) ?> · <?= e(SUJETS_SUPPORT[$m['sujet']]) ?></b>
              <span class="badge badge-offre-<?= $m['statut'] === 'nouveau' ? 'contre' : ($m['statut'] === 'resolu' ? 'close' : 'en_attente') ?>"><?= e($retard ? 'En retard' : ['nouveau' => 'À répondre', 'en_cours' => 'En attente du client', 'resolu' => 'Close'][$m['statut']]) ?></span></header>
            <p class="doux petit"><?= e($m['nom']) ?> · <a class="lien" href="<?= e('mailto:' . $m['email']) ?>"><?= e($m['email']) ?></a><?= $m['telephone'] ? ' · ' . e($m['telephone']) : '' ?>
              · <?= e($m['role'] ? ($roles[$m['role']] ?? $m['role']) : 'Visiteur') ?>
              <?php if ($m['commande_ref']): ?> · commande <a class="lien" href="<?= e(url('commande/' . $m['commande_ref'])) ?>"><?= e($m['commande_ref']) ?></a><?php endif; ?></p>
            <?php $nomClient = (string) $m['nom']; require __DIR__ . '/../includes/support_fil.php'; ?>
            <?php if ($m['statut'] !== 'resolu'): ?>
              <form method="post" class="formulaire formulaire-large"><?= csrf_champ() ?><input type="hidden" name="id" value="<?= (int) $m['id'] ?>"><input type="hidden" name="action" value="repondre">
                <label class="champ"><span>Répondre dans la conversation</span><textarea name="texte" rows="3" maxlength="3000" required></textarea></label>
                <div class="ligne-action"><button class="btn btn-primaire" type="submit"><i class="ph ph-paper-plane-tilt"></i> Envoyer</button></div>
              </form>
              <form method="post" class="m0" data-confirm="Clore cette conversation ? La personne ne pourra plus y répondre."><?= csrf_champ() ?><input type="hidden" name="id" value="<?= (int) $m['id'] ?>"><input type="hidden" name="action" value="clore"><button class="btn btn-contour" type="submit"><i class="ph ph-check-circle"></i> Tout est réglé : clore</button></form>
            <?php else: ?>
              <form method="post" class="m0"><?= csrf_champ() ?><input type="hidden" name="id" value="<?= (int) $m['id'] ?>"><input type="hidden" name="action" value="rouvrir"><button class="lien" type="submit">Rouvrir la conversation</button></form>
            <?php endif; ?>
          </article>
        <?php endforeach; ?>
      </div>
    <?php endif; ?>
  </div>
</main>
<?php require __DIR__ . '/../includes/footer.php'; ?>
