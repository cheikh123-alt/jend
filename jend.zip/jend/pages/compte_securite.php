<?php
$u = exiger_connexion();
$titre = 'Sécurité du compte — Jënd';
$ligne = requete('SELECT totp_secret, totp_actif, totp_dernier_pas, mot_de_passe FROM users WHERE id = ?', [$u['id']])->fetch();
$actif = (int) $ligne['totp_actif'] === 1;
$erreur = null;
$codesAffiches = $_SESSION['codes_secours_affichage'] ?? null;
unset($_SESSION['codes_secours_affichage']);          // affichés UNE seule fois

/** Vérifie un code 2FA (ou de secours) avec limitation des essais. Retourne true/false. */
$verifier_code = function (string $saisi) use ($u, $ligne): bool {
    if (limite_atteinte('2fa:gestion:' . $u['id'], 5, 900)) {
        return false;
    }
    $secret = $ligne['totp_secret'] ? dechiffrer((string) $ligne['totp_secret']) : null;
    $ok = false;
    if ($secret) {
        $pas = totp_verifier($secret, $saisi, (int) $ligne['totp_dernier_pas']);
        if ($pas !== null && requete('UPDATE users SET totp_dernier_pas = ? WHERE id = ? AND totp_dernier_pas < ?', [$pas, $u['id'], $pas])->rowCount() === 1) {
            $ok = true;
        } elseif ($pas === null && !preg_match('/^\d{6}$/', preg_replace('/\s+/', '', $saisi))) {
            $ok = code_secours_utiliser((int) $u['id'], $saisi);
        }
    }
    if (!$ok) {
        limite_enregistrer('2fa:gestion:' . $u['id']);
    }
    return $ok;
};

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $code = trim((string) ($_POST['code'] ?? ''));
    if (!csrf_valide($_POST['csrf'] ?? null)) {
        flash('Session expirée, merci de réessayer.', 'erreur');
        rediriger('compte/securite');
    }

    if ($action === 'demarrer' && !$actif) {
        // Nouveau secret, CHIFFRÉ en base ; la 2FA ne sera active qu'après confirmation par un premier code
        requete('UPDATE users SET totp_secret = ?, totp_actif = 0, totp_dernier_pas = 0 WHERE id = ?', [chiffrer(totp_nouveau_secret()), $u['id']]);
        rediriger('compte/securite');
    } elseif ($action === 'activer' && !$actif && $ligne['totp_secret']) {
        $secret = dechiffrer((string) $ligne['totp_secret']);
        if (limite_atteinte('2fa:gestion:' . $u['id'], 5, 900)) {
            $erreur = 'Trop de tentatives. Réessayez dans 15 minutes.';
        } elseif ($secret && ($pas = totp_verifier($secret, $code)) !== null) {
            requete('UPDATE users SET totp_actif = 1, totp_dernier_pas = ? WHERE id = ?', [$pas, $u['id']]);
            $_SESSION['codes_secours_affichage'] = codes_secours_generer((int) $u['id']);
            flash('Double authentification activée.');
            rediriger('compte/securite');
        } else {
            limite_enregistrer('2fa:gestion:' . $u['id']);
            $erreur = 'Code incorrect. Vérifiez l\'heure de votre téléphone et réessayez.';
        }
    } elseif ($action === 'regenerer' && $actif) {
        if ($verifier_code($code)) {
            $_SESSION['codes_secours_affichage'] = codes_secours_generer((int) $u['id']);
            flash('Nouveaux codes de secours générés : les anciens ne fonctionnent plus.');
            rediriger('compte/securite');
        }
        $erreur = 'Code incorrect ou trop de tentatives.';
    } elseif ($action === 'desactiver' && $actif) {
        if (!password_verify((string) ($_POST['mot_de_passe'] ?? ''), (string) $ligne['mot_de_passe'])) {
            $erreur = 'Mot de passe incorrect.';
        } elseif (!$verifier_code($code)) {
            $erreur = 'Code incorrect ou trop de tentatives.';
        } else {
            requete('UPDATE users SET totp_secret = NULL, totp_actif = 0, totp_dernier_pas = 0 WHERE id = ?', [$u['id']]);
            requete('DELETE FROM codes_secours WHERE user_id = ?', [$u['id']]);
            flash('Double authentification désactivée.');
            rediriger('compte/securite');
        }
    } elseif ($action === 'annuler' && !$actif) {
        requete('UPDATE users SET totp_secret = NULL WHERE id = ? AND totp_actif = 0', [$u['id']]);
        rediriger('compte/securite');
    }
}

$enAttente = !$actif && $ligne['totp_secret'] ? dechiffrer((string) $ligne['totp_secret']) : null;
$restants = $actif ? (int) requete('SELECT COUNT(*) FROM codes_secours WHERE user_id = ? AND utilise = 0', [$u['id']])->fetchColumn() : 0;
require __DIR__ . '/../includes/header.php';
?>
<main class="page">
  <div class="wrap">
    <nav class="fil" aria-label="Fil d'Ariane"><a href="<?= e(url()) ?>">Accueil</a> / <a href="<?= e(url('compte')) ?>">Mon compte</a> / <span>Sécurité</span></nav>
    <h1 class="titre-page">Mon compte</h1>
    <?php compte_onglets('securite'); ?>

    <?php if ($erreur): ?><p class="alerte" role="alert"><?= e($erreur) ?></p><?php endif; ?>

    <?php if ($codesAffiches): ?>
      <section class="formulaire formulaire-large codes-secours">
        <h2 class="sous-titre">Vos codes de secours</h2>
        <p class="alerte alerte-info"><i class="ph ph-warning"></i> <span><b>Notez-les maintenant, ils ne seront plus affichés.</b> Chaque code ne sert qu'une fois, si vous perdez votre téléphone.</span></p>
        <ul class="liste-codes"><?php foreach ($codesAffiches as $c): ?><li><code><?= e($c) ?></code></li><?php endforeach; ?></ul>
      </section>
    <?php endif; ?>

    <h2 class="sous-titre">Double authentification (2FA)</h2>
    <?php if ($actif): ?>
      <p class="alerte alerte-info"><i class="ph ph-shield-check"></i> <span><b>Activée.</b> Un code de votre téléphone est demandé à chaque connexion. Codes de secours restants : <b><?= $restants ?></b>.</span></p>
      <div class="deux-colonnes">
        <form method="post" class="formulaire formulaire-large" novalidate>
          <?= csrf_champ() ?><input type="hidden" name="action" value="regenerer">
          <h3>Régénérer les codes de secours</h3>
          <label class="champ"><span>Code actuel</span><input type="text" name="code" inputmode="numeric" autocomplete="one-time-code" required></label>
          <button class="btn btn-contour" type="submit">Générer de nouveaux codes</button>
        </form>
        <form method="post" class="formulaire formulaire-large" data-confirm="Désactiver la double authentification ? Votre compte sera moins protégé." novalidate>
          <?= csrf_champ() ?><input type="hidden" name="action" value="desactiver">
          <h3>Désactiver la 2FA</h3>
          <label class="champ"><span>Mot de passe</span><input type="password" name="mot_de_passe" autocomplete="current-password" required></label>
          <label class="champ"><span>Code actuel</span><input type="text" name="code" inputmode="numeric" autocomplete="one-time-code" required></label>
          <button class="btn btn-contour" type="submit">Désactiver</button>
        </form>
      </div>
    <?php elseif ($enAttente): ?>
      <form method="post" class="formulaire formulaire-large" novalidate>
        <?= csrf_champ() ?><input type="hidden" name="action" value="activer">
        <p>1. Dans votre application d'authentification (Google Authenticator, Microsoft Authenticator, Aegis, Authy…), choisissez <b>« Saisir une clé »</b> et entrez :</p>
        <p class="cle-secrete"><code><?= e(implode(' ', str_split($enAttente, 4))) ?></code></p>
        <p class="doux petit">Type : basé sur l'heure · Compte : <?= e($u['email']) ?> · ou ouvrez ce lien depuis votre téléphone : <a class="lien" href="<?= e(totp_uri($enAttente, $u['email'])) ?>">ajouter à l'application</a></p>
        <p>2. Entrez le code à 6 chiffres affiché pour confirmer :</p>
        <label class="champ"><span>Code</span><input type="text" name="code" inputmode="numeric" autocomplete="one-time-code" maxlength="7" required autofocus></label>
        <button class="btn btn-primaire" type="submit">Activer la double authentification</button>
      </form>
      <form method="post"><?= csrf_champ() ?><input type="hidden" name="action" value="annuler"><button class="lien lien-danger" type="submit">Annuler</button></form>
    <?php else: ?>
      <p>Protégez votre compte avec un second facteur : même si votre mot de passe est volé, il faudra aussi le code de votre téléphone.
        <?php if ($u['role'] === 'admin'): ?><b>Obligatoire pour l'administrateur en production.</b><?php endif; ?></p>
      <form method="post"><?= csrf_champ() ?><input type="hidden" name="action" value="demarrer"><button class="btn btn-primaire" type="submit"><i class="ph ph-shield-check"></i> Activer la double authentification</button></form>
    <?php endif; ?>
  </div>
</main>
<?php require __DIR__ . '/../includes/footer.php'; ?>
