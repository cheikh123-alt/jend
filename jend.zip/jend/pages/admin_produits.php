<?php
exiger_admin();
$q = trim((string) ($_GET['q'] ?? ''));
if (post_verifie('admin/produits')) {
    $id = (int) ($_POST['id'] ?? 0);
    $p = requete('SELECT id, nom, statut FROM produits WHERE id = ?', [$id])->fetch();
    if ($p) {
        $nouveau = $p['statut'] === 'archive' ? 'publie' : 'archive';
        requete('UPDATE produits SET statut = ? WHERE id = ?', [$nouveau, $id]);
        journaliser($nouveau === 'archive' ? 'produit_retire' : 'produit_remis_en_vente', $p['nom'] . ' (#' . $id . ')');
        flash($nouveau === 'archive' ? '« ' . $p['nom'] . ' » retiré de la vente.' : '« ' . $p['nom'] . ' » remis en vente.');
    }
    rediriger('admin/produits' . ($q !== '' ? '?q=' . urlencode($q) : ''));
}
$params = [];
$where = '';
if ($q !== '') {
    $where = 'WHERE p.nom LIKE ? OR b.nom LIKE ?';
    $params = ['%' . addcslashes($q, '%_\\') . '%', '%' . addcslashes($q, '%_\\') . '%'];
}
$produits = requete("SELECT p.id, p.nom, p.slug, p.prix, p.stock, p.statut, b.nom AS boutique FROM produits p JOIN boutiques b ON b.id = p.boutique_id $where ORDER BY p.id DESC LIMIT 100", $params)->fetchAll();
$titre = 'Produits — Administration';
require __DIR__ . '/../includes/header.php';
?>
<main class="page">
  <div class="wrap">
    <nav class="fil" aria-label="Fil d'Ariane"><a href="<?= e(url()) ?>">Accueil</a> / <a href="<?= e(url('admin')) ?>">Administration</a> / <span>Produits</span></nav>
    <h1 class="titre-page">Administration</h1>
    <?php admin_onglets('produits'); ?>
    <form method="get" class="ligne-action my1"><input type="search" name="q" value="<?= e($q) ?>" placeholder="Rechercher un produit ou une boutique" aria-label="Rechercher"><button class="btn btn-contour" type="submit">Rechercher</button></form>
    <div class="table-defile"><table class="table">
      <thead><tr><th>Produit</th><th>Boutique</th><th>Prix</th><th>Stock</th><th>Statut</th><th></th></tr></thead>
      <tbody>
      <?php foreach ($produits as $p): ?>
        <tr>
          <td><a class="lien" href="<?= e(url('produit/' . $p['slug'])) ?>"><?= e($p['nom']) ?></a></td>
          <td><?= e($p['boutique']) ?></td><td><?= e(fcfa((int) $p['prix'])) ?></td><td><?= (int) $p['stock'] ?></td>
          <td><span class="badge badge-<?= $p['statut'] === 'publie' ? 'confirmee' : ($p['statut'] === 'archive' ? 'annulee' : 'en_attente') ?>"><?= e(['brouillon' => 'Brouillon', 'publie' => 'En vente', 'archive' => 'Retiré'][$p['statut']]) ?></span></td>
          <td><form method="post"><?= csrf_champ() ?><input type="hidden" name="id" value="<?= (int) $p['id'] ?>"><button class="lien lien-danger" type="submit"><?= $p['statut'] === 'archive' ? 'Remettre en vente' : 'Retirer' ?></button></form></td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table></div>
  </div>
</main>
<?php require __DIR__ . '/../includes/footer.php'; ?>
