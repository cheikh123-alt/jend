<?php
/** Demande de commande sur mesure à une boutique. $parametre = slug de la boutique. */
$b = requete("SELECT id, nom, slug, user_id, sur_mesure, verifiee FROM boutiques WHERE slug = ? AND statut = 'active'", [$parametre])->fetch();
if (!$b || (int) $b['sur_mesure'] !== 1) {
    http_response_code(404);
    require __DIR__ . '/404.php';
    return;
}
$u = exiger_connexion();
exiger_email_confirme($u);
$v = ['description' => '', 'mesures' => '', 'budget' => '', 'date' => ''];
$erreur = null;
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    foreach ($v as $k => $_) {
        $v[$k] = trim((string) ($_POST[$k] ?? ''));
    }
    if (!csrf_valide($_POST['csrf'] ?? null)) {
        $erreur = 'Session expirée, merci de réessayer.';
    } elseif ($v['budget'] !== '' && !ctype_digit($v['budget'])) {
        $erreur = 'Indiquez votre budget en FCFA (nombre entier), ou laissez vide.';
    } else {
        try {
            $ref = demande_creer((int) $u['id'], (int) $b['id'], $v['description'], $v['mesures'], $v['budget'] !== '' ? (int) $v['budget'] : null, $v['date'] !== '' ? $v['date'] : null);
            flash('Demande ' . $ref . ' envoyée à « ' . $b['nom'] . ' ». Vous recevrez son devis (prix et délai) dans « Sur mesure ».');
            rediriger('sur-mesure');
        } catch (RuntimeException $e) {
            $erreur = $e->getMessage();
        }
    }
}
$titre = 'Commande sur mesure — ' . $b['nom'] . ' — Jënd';
require __DIR__ . '/../includes/header.php';
?>
<main class="page">
  <div class="wrap wrap-moyen">
    <nav class="fil" aria-label="Fil d'Ariane"><a href="<?= e(url()) ?>">Accueil</a> / <a href="<?= e(url('boutique/' . $b['slug'])) ?>"><?= e($b['nom']) ?></a> / <span>Sur mesure</span></nav>
    <h1 class="titre-page">Commande sur mesure</h1>
    <p class="doux">Décrivez ce que vous voulez à <b><?= e($b['nom']) ?></b>. Le vendeur vous répond avec un <b>prix</b> et un <b>délai</b>. Si le devis vous convient, vous payez sur Jënd : l'argent n'est versé au vendeur qu'à la réception.</p>
    <form method="post" class="formulaire formulaire-large" novalidate>
      <?= csrf_champ() ?>
      <?php if ($erreur): ?><p class="alerte" role="alert"><?= e($erreur) ?></p><?php endif; ?>
      <label class="champ"><span>Ce que je veux (modèle, tissu, couleur, occasion…)</span><textarea name="description" rows="5" maxlength="2000" required placeholder="Ex : un boubou brodé pour homme, bazin bleu nuit, broderie dorée au col, pour un mariage"><?= e($v['description']) ?></textarea></label>
      <label class="champ"><span>Mes mesures (facultatif)</span><textarea name="mesures" rows="4" maxlength="1000" placeholder="Ex : tour de poitrine 104 cm, longueur 140 cm, manches 62 cm, tour de cou 41 cm"><?= e($v['mesures']) ?></textarea>
        <small class="doux">Vous pouvez aussi les donner au vendeur plus tard.</small></label>
      <label class="champ"><span>Mon budget en FCFA (facultatif)</span><input type="text" name="budget" inputmode="numeric" value="<?= e($v['budget']) ?>" placeholder="25000"></label>
      <label class="champ"><span>Pour quelle date ? (facultatif)</span><input type="date" name="date" value="<?= e($v['date']) ?>" min="<?= e(date('Y-m-d')) ?>"></label>
      <button class="btn btn-primaire" type="submit"><i class="ph ph-paper-plane-tilt"></i> Envoyer ma demande</button>
    </form>
  </div>
</main>
<?php require __DIR__ . '/../includes/footer.php'; ?>
