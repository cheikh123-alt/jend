<?php
/**
 * « Promouvoir ma boutique » : le kit du vendeur — affiche à imprimer avec le QR code de sa boutique,
 * textes prêts à copier pour ses statuts WhatsApp, idées de vidéos TikTok, liens à partager (chacun marqué pour savoir ce qui marche).
 */
[$u, $b] = exiger_vendeur();
$lien = app_url('boutique/' . $b['slug']);
$lienStatut = lien_source($lien, 'whatsapp');
$nbProduits = (int) requete("SELECT COUNT(*) FROM produits WHERE boutique_id = ? AND statut = 'publie' AND reserve_client_id IS NULL", [$b['id']])->fetchColumn();
$textes = [
    'Lancement' => "🛍️ Ma boutique « {$b['nom']} » est sur Jënd !\nCommandez en toute sécurité : vous ne payez le vendeur qu'une fois le colis dans vos mains.\n👉 $lienStatut",
    'Confiance' => "Vous avez peur de payer en ligne et de ne rien recevoir ? 🙅🏾\nSur Jënd, votre argent est protégé jusqu'à la réception. Vous donnez votre code au livreur seulement quand vous avez le colis.\nMa boutique : $lienStatut",
    'Nouveautés' => "✨ Nouveautés chez {$b['nom']} ! Venez voir avant qu'il n'y en ait plus.\nPaiement Wave / Orange Money, argent protégé jusqu'à la livraison.\n👉 $lienStatut",
    'Diaspora' => "🌍 Vous êtes à l'étranger ? Faites plaisir à votre famille au Sénégal : commandez chez {$b['nom']} sur Jënd, on livre chez eux, sans prix dans le colis.\n👉 $lienStatut",
    'Avis' => "Merci à tous nos clients 🙏🏾 Vos avis comptent : après votre livraison, laissez une note sur Jënd. Et pour vos prochains achats : $lienStatut",
];
$videos = [
    ['Le déballage', 'Filmez un client (avec son accord) ou vous-même qui ouvre un colis Jënd et montre le produit. Terminez par : « payé seulement à la réception ».'],
    ['Avant / après', 'Un tissu, puis la tenue terminée (couture), ou un produit avant et après utilisation. 15 secondes suffisent.'],
    ['Les coulisses', 'Votre atelier, votre étal, vos mains au travail. Les gens achètent à quelqu\'un qu\'ils voient.'],
    ['Le code de réception', 'Expliquez en wolof en 20 secondes : « Vous payez, l\'argent est gardé, vous donnez le code au livreur quand vous avez le colis. »'],
    ['Le prix du jour', 'Montrez un produit, son prix, et dites « lien dans ma bio ». Mettez le lien de votre boutique dans la bio TikTok.'],
];
$titre = 'Promouvoir ma boutique — Jënd';
require __DIR__ . '/../includes/header.php';
?>
<main class="page">
  <div class="wrap">
    <nav class="fil" aria-label="Fil d'Ariane"><a href="<?= e(url('vendeur')) ?>">Espace vendeur</a> / <span>Promouvoir</span></nav>
    <h1 class="titre-page">Espace vendeur</h1>
    <?php vendeur_onglets('kit'); ?>
    <h2 class="sous-titre">Promouvoir ma boutique</h2>
    <p class="doux">Vos clients sont déjà dans vos contacts WhatsApp et vos abonnés TikTok. Voici tout ce qu'il faut pour les amener sur votre boutique, où ils paient en sécurité.</p>
    <?php if ($b['statut'] !== 'active'): ?><p class="alerte alerte-info"><i class="ph ph-hourglass"></i> <span>Votre boutique doit être validée par Jënd avant d'être visible : préparez votre promotion en attendant.</span></p><?php endif; ?>

    <div class="kit-grille">
      <section class="kit-carte kit-affiche">
        <h3><i class="ph ph-qr-code"></i> Votre affiche avec QR code</h3>
        <p class="doux">À coller sur votre étal, votre atelier, vos sacs. Le client scanne avec son téléphone et arrive directement sur votre boutique.</p>
        <div class="kit-qr"><?= qr_svg(lien_source($lien, 'affiche'), '#1B1410', 'QR code de la boutique ' . $b['nom']) ?></div>
        <a class="btn btn-primaire" href="<?= e(url('vendeur/affiche')) ?>" target="_blank" rel="noopener"><i class="ph ph-printer"></i> Ouvrir l'affiche à imprimer</a>
      </section>

      <section class="kit-carte">
        <h3><i class="ph ph-link"></i> Vos liens</h3>
        <p><b>Votre boutique</b> — à mettre dans votre bio TikTok, Instagram, Facebook :</p>
        <p class="kit-lien"><code><?= e($lien) ?></code> <button class="btn btn-contour" type="button" data-copier="<?= e(lien_source($lien, 'tiktok')) ?>"><i class="ph ph-copy"></i> Copier</button></p>
        <ul class="kit-astuces">
          <li><i class="ph ph-image"></i> <a class="lien" href="<?= e(url('vendeur/statut')) ?>">Images pour mon statut</a> : une belle image par produit, prête à publier.</li>
          <li><i class="ph ph-shield-check"></i> <a class="lien" href="<?= e(url('vendeur/produits')) ?>">Lien de paiement protégé</a> : quand un client vous écrit sur WhatsApp, envoyez-lui ce lien plutôt que de demander un transfert.</li>
          <li><i class="ph ph-gift"></i> <a class="lien" href="<?= e(url('vendeur')) ?>">Parrainage</a> : invitez d'autres vendeurs et gagnez des jours sans commission.</li>
          <?php if ($nbProduits < 5): ?><li><i class="ph ph-warning"></i> <span>Vous avez <?= $nbProduits ?> produit(s) : visez au moins <b>5 produits avec de vraies photos</b> avant de faire votre publicité.</span></li><?php endif; ?>
        </ul>
      </section>
    </div>

    <section class="kit-section">
      <h3 class="sous-titre"><i class="ph ph-whatsapp-logo"></i> Textes pour vos statuts WhatsApp</h3>
      <p class="doux">Copiez, collez dans WhatsApp, ajoutez une photo. Un statut par jour suffit.</p>
      <div class="kit-textes">
        <?php foreach ($textes as $nom => $texte): ?>
          <article class="kit-texte"><h4><?= e($nom) ?></h4><p><?= nl2br(e($texte)) ?></p>
            <button class="btn btn-contour" type="button" data-copier="<?= e($texte) ?>"><i class="ph ph-copy"></i> Copier</button></article>
        <?php endforeach; ?>
      </div>
    </section>

    <section class="kit-section">
      <h3 class="sous-titre"><i class="ph ph-video-camera"></i> 5 idées de vidéos TikTok</h3>
      <p class="doux">Vidéos courtes (15 à 30 secondes), filmées au téléphone, en wolof ou en français. Régularité plutôt que perfection : 3 vidéos par semaine.</p>
      <ol class="kit-videos">
        <?php foreach ($videos as [$nom, $conseil]): ?><li><b><?= e($nom) ?></b><span><?= e($conseil) ?></span></li><?php endforeach; ?>
      </ol>
    </section>
  </div>
</main>
<?php require __DIR__ . '/../includes/footer.php'; ?>
