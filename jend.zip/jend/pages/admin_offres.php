<?php
/** Vue de l'administrateur sur les négociations : offres de prix et demandes sur mesure. Lecture seule : il n'intervient pas dans la négociation. */
exiger_admin();
$vue = in_array($_GET['vue'] ?? '', ['en_cours', 'conclues'], true) ? $_GET['vue'] : 'toutes';
$filtre = ['toutes' => '1', 'en_cours' => "o.statut IN ('en_attente', 'contre') AND o.expire_le > NOW()", 'conclues' => "o.statut IN ('acceptee', 'utilisee')"][$vue];
$offres = requete(
    "SELECT o.*, p.nom AS produit, p.slug, b.nom AS boutique, u.nom AS client
       FROM offres o JOIN produits p ON p.id = o.produit_id JOIN boutiques b ON b.id = o.boutique_id JOIN users u ON u.id = o.client_id
      WHERE $filtre ORDER BY o.id DESC LIMIT 100"
)->fetchAll();
$n = fn (string $sql) => requete($sql)->fetchColumn();
$total = (int) $n('SELECT COUNT(*) FROM offres');
$conclues = (int) $n("SELECT COUNT(*) FROM offres WHERE statut IN ('acceptee', 'utilisee')");
$achetees = (int) $n("SELECT COUNT(*) FROM offres WHERE statut = 'utilisee'");
$remise = (float) $n("SELECT COALESCE(AVG((prix_initial - prix_final) / prix_initial * 100), 0) FROM offres WHERE prix_final IS NOT NULL AND prix_initial > 0");
$demandes = requete(
    'SELECT d.reference, d.statut, d.prix, d.delai_jours, d.created_at, d.produit_id, b.nom AS boutique, u.nom AS client
       FROM demandes_mesure d JOIN boutiques b ON b.id = d.boutique_id JOIN users u ON u.id = d.client_id ORDER BY d.id DESC LIMIT 30'
)->fetchAll();
$titre = 'Offres et sur-mesure — Administration';
require __DIR__ . '/../includes/header.php';
?>
<main class="page">
  <div class="wrap">
    <nav class="fil" aria-label="Fil d'Ariane"><a href="<?= e(url()) ?>">Accueil</a> / <a href="<?= e(url('admin')) ?>">Administration</a> / <span>Offres</span></nav>
    <h1 class="titre-page">Administration</h1>
    <?php admin_onglets('offres'); ?>
    <p class="doux">Les clients et les vendeurs négocient entre eux : tu n'as rien à valider. Cette page te permet de <b>voir ce qui se passe</b> : utile pour trancher un signalement (« le vendeur avait accepté ce prix »), repérer un abus, ou savoir si la fonction sert.</p>

    <div class="tb-kpis">
      <?= tb_kpi('ph-handshake', 'Offres faites', (string) $total) ?>
      <?= tb_kpi('ph-check-circle', 'Prix convenus', (string) $conclues, $total ? round($conclues / $total * 100) . ' % des offres' : '') ?>
      <?= tb_kpi('ph-shopping-bag', 'Suivies d\'un achat', (string) $achetees) ?>
      <?= tb_kpi('ph-percent', 'Remise moyenne accordée', str_replace('.', ',', (string) round($remise, 1)) . ' %', 'sur les prix convenus') ?>
    </div>

    <nav class="onglets" aria-label="Filtrer">
      <?php foreach (['toutes' => 'Toutes', 'en_cours' => 'En cours', 'conclues' => 'Prix convenus'] as $k => $lib): ?>
        <a href="<?= e(url('admin/offres' . ($k === 'toutes' ? '' : '?vue=' . $k))) ?>" <?= $vue === $k ? 'class="actif" aria-current="page"' : '' ?>><?= e($lib) ?></a>
      <?php endforeach; ?>
    </nav>
    <?php if (!$offres): ?>
      <div class="tb-vide"><i class="ph ph-handshake"></i><p>Aucune offre dans cette vue.</p></div>
    <?php else: ?>
      <div class="table-defile"><table class="table">
        <thead><tr><th>Date</th><th>Produit</th><th>Boutique</th><th>Client</th><th>Prix affiché</th><th>Offre</th><th>Contre</th><th>Convenu</th><th>État</th></tr></thead>
        <tbody>
        <?php foreach ($offres as $o): ?>
          <tr>
            <td><?= e(date('d/m H:i', strtotime($o['created_at']))) ?></td>
            <td><a class="lien" href="<?= e(url('produit/' . $o['slug'])) ?>"><?= e($o['produit']) ?></a> × <?= (int) $o['quantite'] ?></td>
            <td><?= e($o['boutique']) ?></td>
            <td><?= e($o['client']) ?></td>
            <td><?= e(fcfa((int) $o['prix_initial'])) ?></td>
            <td><?= e(fcfa((int) $o['prix_propose'])) ?></td>
            <td><?= $o['contre_prix'] ? e(fcfa((int) $o['contre_prix'])) : '—' ?></td>
            <td><?= $o['prix_final'] ? '<b>' . e(fcfa((int) $o['prix_final'])) . '</b>' : '—' ?></td>
            <td><?= e(offre_libelle($o)) ?></td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table></div>
    <?php endif; ?>

    <section class="tb-bloc">
      <h2 class="tb-titre"><i class="ph-fill ph-scissors"></i> Demandes sur mesure récentes</h2>
      <?php if (!$demandes): ?>
        <div class="tb-vide"><i class="ph ph-scissors"></i><p>Aucune demande sur mesure.</p></div>
      <?php else: ?>
        <div class="table-defile"><table class="table">
          <thead><tr><th>Date</th><th>Référence</th><th>Boutique</th><th>Client</th><th>Devis</th><th>État</th></tr></thead>
          <tbody>
          <?php foreach ($demandes as $d): ?>
            <tr><td><?= e(date('d/m H:i', strtotime($d['created_at']))) ?></td><td><?= e($d['reference']) ?></td><td><?= e($d['boutique']) ?></td><td><?= e($d['client']) ?></td>
              <td><?= $d['prix'] ? e(fcfa((int) $d['prix'])) . ' · ' . (int) $d['delai_jours'] . ' j' : '—' ?></td>
              <td><?= e($d['statut'] === 'acceptee' && demande_commandee($d) ? 'Commandée' : STATUTS_DEMANDE[$d['statut']]) ?></td></tr>
          <?php endforeach; ?>
          </tbody>
        </table></div>
      <?php endif; ?>
    </section>
  </div>
</main>
<?php require __DIR__ . '/../includes/footer.php'; ?>
