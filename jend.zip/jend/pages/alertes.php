<?php
/** « Alertes prix » : produits suivis par le client (baisse de prix, retour en stock). */
$u = exiger_connexion();
if (post_verifie('alertes')) {
    requete('DELETE FROM alertes_produit WHERE id = ? AND user_id = ?', [(int) ($_POST['id'] ?? 0), $u['id']]);
    flash('Alerte retirée.');
    rediriger('alertes');
}
$alertes = requete(
    "SELECT a.id, a.prix_vu, a.epuise, a.created_at, p.nom, p.slug, p.prix, p.stock, " . SQL_PROMO_FETE . " AS promo_pct,
            (SELECT chemin FROM produit_images i WHERE i.produit_id = p.id ORDER BY i.position LIMIT 1) AS image
       FROM alertes_produit a JOIN produits p ON p.id = a.produit_id WHERE a.user_id = ? ORDER BY a.created_at DESC",
    [$u['id']]
)->fetchAll();
$titre = 'Alertes prix — Jënd';
require __DIR__ . '/../includes/header.php';
?>
<main class="page">
  <div class="wrap wrap-moyen">
    <nav class="fil" aria-label="Fil d'Ariane"><a href="<?= e(url('compte')) ?>">Mon compte</a> / <span>Alertes prix</span></nav>
    <h1 class="titre-page">Mon compte</h1>
    <?php compte_onglets('alertes'); ?>
    <h2 class="sous-titre">Alertes prix et retour en stock</h2>
    <p class="doux">Sur la page d'un produit, appuyez sur « Prévenez-moi » : nous vous écrivons dès que son prix baisse (ou qu'une promotion de fête commence), ou dès qu'il revient en stock.</p>
    <?php if (!$alertes): ?>
      <div class="vide"><i class="ph ph-bell-ringing"></i><p><b>Aucun produit suivi.</b></p></div>
    <?php else: ?>
      <div class="depense-lignes">
        <?php foreach ($alertes as $a): $prix = prix_promo((int) $a['prix'], (int) $a['promo_pct']); ?>
          <div class="depense-ligne alerte-ligne">
            <?php if ($a['image']): ?><img src="<?= e(url(image_miniature($a['image']))) ?>" alt="" loading="lazy"><?php else: ?><span class="fete-sans-photo"><i class="ph ph-package"></i></span><?php endif; ?>
            <span><a href="<?= e(url('produit/' . $a['slug'])) ?>"><b><?= e($a['nom']) ?></b></a>
              <small><?= $a['epuise'] ? 'Épuisé quand vous l\'avez suivi' : 'Suivi à ' . e(fcfa((int) $a['prix_vu'])) ?> · aujourd'hui <?= (int) $a['stock'] > 0 ? e(fcfa($prix)) : 'épuisé' ?></small></span>
            <form method="post"><?= csrf_champ() ?><input type="hidden" name="id" value="<?= (int) $a['id'] ?>"><button class="lien lien-danger" type="submit"><i class="ph ph-trash"></i> Retirer</button></form>
          </div>
        <?php endforeach; ?>
      </div>
    <?php endif; ?>
  </div>
</main>
<?php require __DIR__ . '/../includes/footer.php'; ?>
