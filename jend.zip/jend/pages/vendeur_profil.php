<?php
/** Profil et mot de passe du vendeur, dans son espace vendeur : mêmes formulaires et mêmes protections que « Mon compte → Profil ». */
[$u, $b] = exiger_vendeur();
$espaceVendeur = true;
require __DIR__ . '/compte_profil.php';
