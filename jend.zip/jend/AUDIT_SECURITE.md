# Audit de sécurité de Jënd (étape 10)

Audit du code par recherche automatique de motifs dangereux, relecture des points sensibles, puis corrections vérifiées par
des tests de bout en bout (`python3 tests/run_all.py`).

## Ce qui a été contrôlé et jugé sain

| Sujet | Résultat |
|---|---|
| Fonctions dangereuses (`eval`, `exec`, `shell_exec`, `unserialize`, `include` dynamique…) | Aucune. Seul `extract()` apparaît, et il ne reçoit que la table de routes du site. |
| Injection SQL | Toutes les requêtes passent par des requêtes préparées. Les 2 requêtes où une variable est insérée dans le texte SQL sont sûres : l'une ne reçoit que des `?` générés, l'autre une chaîne fixe. |
| Failles XSS | Tout affichage passe par `e()`. Les descriptions sont affichées en `nl2br(e(...))`. |
| CSRF | Toutes les pages qui modifient des données exigent un jeton, sauf le webhook de paiement, protégé par sa signature HMAC. |
| Contrôle d'accès | Chaque page vendeur/admin a un garde. Un vendeur ne peut ni voir ni modifier les produits, commandes ou retraits d'un autre. L'admin est invisible aux autres (404). |
| Mots de passe | `password_hash` (bcrypt), vérification en temps constant, session régénérée à la connexion. |
| Paiement | Seule la notification signée valide un paiement ; montant vérifié ; rejeu ignoré ; horodatage limité à 15 min. Les données de carte ne passent jamais par le site. |
| Photos envoyées | Type lu dans le contenu, image ré-encodée (tout code caché disparaît), nom aléatoire, `uploads/` n'exécute aucun script. |

## Faiblesses trouvées et corrigées

| # | Constat | Gravité | Correction | Vérifié par |
|---|---|---|---|---|
| 1 | Le blocage des tentatives de connexion était lié à la session : un robot le contournait en changeant de cookie | Élevée | Blocage **en base de données**, par e-mail (5 / 15 min) **et** par IP (20 / 15 min). Idem pour l'inscription (5 / h), « mot de passe oublié » et les signatures de webhook invalides. L'en-tête `X-Forwarded-For` n'est cru que derrière un proxy déclaré (`TRUSTED_PROXY`). | tests : e-mail, IP, X-Forwarded-For falsifié, inscriptions, webhook |
| 2 | Pas de politique de sécurité de contenu (CSP) : un script injecté aurait pu s'exécuter | Élevée | CSP stricte : aucun script en ligne, scripts limités à `self` et aux 3 CDN utilisés, `object-src 'none'`, `form-action`, `frame-ancestors`. Les 9 gestionnaires en ligne ont été remplacés. | test sur 25 pages + contrôle dans un vrai navigateur (a révélé que les icônes venaient de jsDelivr : corrigé) |
| 3 | Aucune redirection HTTPS ni HSTS | Élevée (en prod) | Redirection 301 vers l'adresse officielle `APP_URL` (jamais vers l'en-tête `Host` du visiteur), HSTS, cookie `__Host-…` + `Secure` | tests : redirection, Host falsifié, proxy |
| 4 | Un identifiant de session choisi par un attaquant aurait été accepté (fixation de session) | Moyenne | `session.use_strict_mode`, cookies seulement | test : identifiant forgé refusé |
| 5 | Erreur interne = écran blanc (ou détails techniques selon la configuration) | Moyenne | Page d'erreur propre ; détails seulement dans le journal serveur ; tout ce qui n'est pas `APP_ENV=dev` est traité comme la production | tests : panne de base, exception, secret manquant |
| 6 | Sessions ouvertes indéfiniment ; pages de compte conservées en cache | Moyenne | Déconnexion après inactivité (30 min admin, 2 h autres), `Cache-Control: no-store` pour les utilisateurs connectés | tests |
| 7 | Actions de l'administrateur non tracées | Moyenne | Journal (qui, quoi, quand, IP), consultable dans l'onglet « Journal » | tests |
| 8 | Dossier `scripts/` seulement protégé par le garde interne de chaque script | Faible | Bloqué aussi au niveau du serveur | test |
| 9 | Adresse expéditeur par défaut invalide sur `localhost` : **aucun e-mail ne partait** | Moyenne | Corrigé (bug introduit pendant cette étape et attrapé par le test « mot de passe oublié ») | test |
| 10 | Le message « session expirée » était écrasé par « connectez-vous » | Faible | Corrigé | test |
| 11 | Un mot de passe d'administrateur volé donnait tous les pouvoirs | Élevée | **Double authentification (2FA)** par application (norme RFC 6238, testée contre les vecteurs officiels), 8 codes de secours à usage unique, rejeu d'un code impossible, essais limités. Secret **chiffré** en base (AES-256-GCM). **Obligatoire pour l'admin en production.** | 46 tests dédiés |
| 12 | Changer de mot de passe ne coupait pas les autres sessions (session volée toujours valable) | Moyenne | « Version de session » : changement ou réinitialisation du mot de passe → tous les autres appareils sont déconnectés | tests : 3 appareils, réinitialisation par e-mail |
| 13 | Le vendeur pouvait déclarer une livraison fictive (et être payé) | Moyenne | **Code de livraison** à 4 chiffres donné au client, que le vendeur doit saisir ; jamais montré au vendeur ni à l'admin ; 5 essais maximum puis blocage + alerte | 13 tests |
| 14 | Aucune alerte en cas d'erreur grave ou de paiement anormal | Moyenne | E-mail à l'administrateur (1 par type et par heure) : erreur 500, paiement incohérent, paiement sur commande annulée, double paiement, déluge sur le webhook, force brute, codes 2FA ou de livraison devinés | 7 tests |
| 15 | `/admin` accessible depuis n'importe où | Moyenne | `ADMIN_IPS` (liste d'adresses ou plages) : les autres IP voient une page 404 même avec le bon mot de passe | tests : 16 cas de filtrage + accès réel |
| 16 | Sauvegardes en clair | Moyenne | `BACKUP_PASSPHRASE` : chiffrement AES-256-GCM par blocs. Toute modification, troncature, permutation de blocs ou ajout est détecté. Outil de déchiffrement fourni, restauration testée. | 17 tests |
| 17 | `style-src 'unsafe-inline'` dans la CSP | Faible | Les 21 styles en ligne sont devenus des classes CSS ; l'exception est supprimée. Contrôlé dans un vrai navigateur (animations GSAP et couleurs intactes) | test sur 25 pages + navigateur |
| 18 | Seuils de blocage figés | Faible | Réglables : `LIMITE_CONNEXION_IP`, `LIMITE_CONNEXION_EMAIL` | test |
| 19 | **Bibliothèques chargées depuis des CDN** (GSAP, Lenis, Splitting, icônes, polices) : un CDN piraté aurait pu injecter un script sur toutes les pages, y compris celle de paiement | Élevée | **Toutes hébergées sur le site** (`assets/vendor/`, 16 fichiers, 688 Ko), versions épinglées, chacune recoupée sur **deux sources indépendantes** avant installation. La CSP est réduite à `'self'` partout : plus aucun domaine externe autorisé. Les empreintes SHA-256 sont contrôlées par le vérificateur : une bibliothèque **modifiée** sur le serveur est détectée. | tests : CSP sans domaine externe, 25 pages sans ressource externe, empreintes, altération détectée ; navigateur : seul hôte contacté = le site |
| 20 | Le texte du site n'était **jamais** en Satoshi (l'API Fontshare ne renvoie que la 1re famille demandée) | Cosmétique | Polices récupérées une famille à la fois : Satoshi (texte) et Clash Display (titres) se chargent maintenant toutes les deux | navigateur : 7 polices actives |
| 21 | Mot de passe **provisoire** des livreurs (donné par l'admin, parfois transmis par WhatsApp) valable indéfiniment | Moyenne | Drapeau `mdp_provisoire` : tant qu'il n'est pas changé, **tout l'espace livreur est bloqué** et le livreur est renvoyé vers « choisir mon mot de passe » (qui doit être différent du provisoire). | tests : blocage, refus du même mot de passe, déblocage |
| 22 | Code de livraison à 4 chiffres : 5 essais par 15 min = ~480 essais/jour, soit un code deviné en quelques semaines par un livreur ou vendeur de mauvaise foi | Moyenne | **Plafond de 15 codes faux par 24 h** et par livraison : verrouillage + alerte à l'administrateur | test : plafond atteint → refus même avec le bon code |
| 23 | Méthodes HTTP inutiles (PUT, DELETE, OPTIONS…) acceptées | Faible | Seules GET, HEAD et POST sont traitées (405 sinon) | test |
| 24 | Version de PHP annoncée (`X-Powered-By`) ; fichiers statiques (`sw.js`, manifest) sans `X-Content-Type-Options` | Faible | En-tête retiré ; `nosniff` ajouté pour les fichiers servis par Apache ; `sw.js` jamais mis en cache | test + contrôle des en-têtes |
| 25 | Un compte livreur pouvait ouvrir une boutique via `/vendre` | Faible | Refusé | test |
| 26 | Signalements clients (« Signaler un problème ») : photos envoyées par les clients | Moyenne | Mêmes contrôles que les photos de produits (type lu dans le contenu, ré-encodage, nom aléatoire) mais stockées dans `storage/litiges/`, **jamais en accès direct** : une page contrôle l'accès (auteur ou administrateur seulement, `no-store`). 3 photos, 5 signalements par jour et par client, un seul signalement par livraison. | tests : fichier PHP déguisé refusé, accès direct 403/404, autre client / vendeur / visiteur refusés |
| 27 | Remboursement et argent du vendeur : risque de payer deux fois ou de rembourser sans contrôle | Moyenne | Les gains d'une livraison en litige sont **mis de côté** jusqu'à la décision ; un remboursement accepté est retenu sur les gains (ou la livraison non remise passe « retournée »). Un signalement traité ne peut plus être modifié ; l'envoi de l'argent se confirme une seule fois ; toutes les décisions sont dans le journal admin. | tests : gains bloqués puis déduits, décision refusée après traitement |
| 28 | Paiement à la livraison livré par le vendeur : il encaissait les espèces **et** voyait la vente créditée sur son solde retirable (double paiement) | Moyenne | Le solde ne contient plus les ventes en espèces que le vendeur a lui-même encaissées ; la commission est retenue. Un remboursement par Jënd de ces espèces est refusé (Jënd ne les détient pas). | tests : solde, commission à reverser, refus du remboursement |
| 29 | Commandes payées à la livraison sans engagement : refus, commandes fantaisistes, déplacements perdus | Moyenne (business) | **Acompte en ligne obligatoire** (20 % par défaut) : la commande n'est confirmée, préparée ou livrée qu'après une notification de paiement **signée** pour le montant exact de l'acompte (un montant différent est refusé). Acompte conservé en cas d'absence ou de refus, remboursé si annulation avant préparation. | tests : montant truqué refusé, rejeu ignoré, vendeur bloqué avant paiement |
| 30 | Paiement réel (PayDunya) : fausses notifications, montants truqués, retours falsifiés | Élevée | Rien n'est cru sur parole : une commande n'est payée que si **le serveur interroge PayDunya** (clé privée) et reçoit « completed » pour **le montant exact** attendu et la **bonne commande**. L'IPN est de plus authentifiée par le hash de la clé principale ; un retour du client (`?status=completed`) ne change rien ; les clés ne sont que dans `.env`, envoyées en en-têtes ; adresse de paiement validée (https + paydunya.com) ; l'adresse de l'API ne peut pas être détournée hors développement. | 38 tests avec faux serveur PayDunya |

## Risques qui restent (à connaître)

| Risque | Explication | Recommandation |
|---|---|---|
| Bibliothèques hébergées : mises à jour à suivre | Les copies locales ne se mettent pas à jour toutes seules : une faille découverte plus tard dans GSAP, Lenis, etc. ne serait pas corrigée automatiquement. | Consulter de temps en temps les nouvelles versions et relancer `scripts/installer-bibliotheques.py` (procédure dans `DEPLOIEMENT.md`). |
| Blocage par IP : un réseau partagé (cybercafé, entreprise) peut être bloqué par les échecs d'une seule personne | Compromis assumé : 20 échecs / 15 min par IP, 5 par e-mail. | Seuils réglables dans `.env` ; à ajuster selon l'usage réel. |
| L'inscription révèle si une adresse e-mail existe déjà | Compromis courant pour une bonne expérience. La limite par IP freine l'exploitation. | Acceptable ; à revoir si vous gérez des données très sensibles. |
| 2FA : pas de QR code, saisie manuelle de la clé | Un QR code demande une bibliothèque ou un service externe (qui verrait le secret : à éviter). | Le lien `otpauth://` s'ouvre directement depuis un téléphone. Une bibliothèque QR hébergée chez vous pourra être ajoutée. |
| 2FA : perte du téléphone **et** des codes de secours | L'utilisateur ne peut plus se connecter. | Prévoir une procédure de récupération par l'administrateur (vérification d'identité, puis désactivation en base). Pour l'admin lui-même : accès à la base par l'hébergeur. |
| **`APP_KEY` perdue = secrets 2FA inutilisables** | La clé chiffre les secrets 2FA en base. | La sauvegarder **ailleurs que sur le serveur**, avec la phrase de sauvegarde. |
| Sauvegardes : la phrase secrète n'est pas récupérable | Perdue, les sauvegardes chiffrées sont perdues. | Gardez-la dans un gestionnaire de mots de passe, séparée des sauvegardes. |
| Alertes par e-mail uniquement | Pas de tableau de bord ni de surveillance externe de disponibilité. | Ajouter un service de supervision (ping du site) ; l'e-mail d'alerte doit être consulté. |
| Paiement réel, SMTP chiffré (TLS), Nginx, HTTPS réel | Non testables sans serveur ni comptes. | Voir `DEPLOIEMENT.md`, §« Ce qui n'a pas pu être testé ». |
| Code de livraison : le client peut le communiquer trop tôt | Si le client donne le code avant la remise, le vendeur peut marquer « livrée » à tort. | Rappel affiché au client ; un litige reste possible via l'admin (journal, historique). |
| Un vendeur ayant déjà retiré ses gains avant un remboursement | La retenue ne peut pas rendre le solde négatif : si le vendeur a déjà tout retiré, la perte reste à la charge de Jënd. | Garder un petit délai avant retrait (ex : 7 jours après livraison, comme le délai de signalement) quand le volume le justifiera. |
| Méthode `TRACE` encore acceptée par Apache | Elle ne se désactive que dans la configuration du serveur (pas dans `.htaccess`). Risque faible : les cookies sont `HttpOnly`. | Ajouter `TraceEnable off` dans `httpd.conf` en local ; sur un hébergement mutualisé, c'est le rôle de l'hébergeur. |
| Espèces encaissées par les livreurs | Suivies dans Administration → Caisse (encaissé / remis / à remettre), mais la remise reste saisie à la main par l'admin. | Pointer chaque soir avec les livreurs. |
| Mot de passe provisoire transmis par un autre canal (WhatsApp, oral) | Il est affiché une seule fois à l'admin, puis doit être changé à la première connexion. | Le transmettre à part du lien de connexion ; ne jamais le renvoyer par e-mail. |
| Double authentification facultative pour vendeurs et livreurs | Seule l'administration l'exige. Un compte vendeur piraté permet de détourner des gains (retrait). | Rendre la 2FA obligatoire pour les vendeurs avant de gros volumes ; ajouter une confirmation par e-mail sur les retraits. |
| Politique de mots de passe | 8 caractères minimum, liste intégrée de mots de passe courants refusés (pas de contrôle des mots de passe déjà fuités en ligne). | Allonger à 10 si besoin. |
| Liens WhatsApp et itinéraire (livreur) | Appuyer dessus transmet l'adresse de livraison à WhatsApp / Google Maps. Le téléphone du client n'est jamais mis dans le message WhatsApp. | Acceptable ; à mentionner dans la politique de confidentialité si besoin. |
| Environnement local ancien | PHP 8.0.28 (fin de support), Apache/OpenSSL anciens, MariaDB `root` sans mot de passe : acceptable en développement uniquement. | En production : PHP 8.2+ à jour, utilisateur de base dédié et mot de passe long (voir `DEPLOIEMENT.md`). |

## Relecture avant production (octobre 2026)

Corrigé dans cette passe :

| Problème | Correction |
|---|---|
| Aucune limite d'essais sur le champ « mot de passe actuel » (Mon compte) : un attaquant avec une session volée pouvait le deviner | 5 essais par 15 minutes, comme pour la connexion |
| Mots de passe triviaux acceptés (`12345678`, `password`…) ; mot de passe de plus de 72 caractères silencieusement tronqué par bcrypt | Fonction `mot_de_passe_faible()` : refus des mots de passe courants, de l'e-mail, du nom, des suites triviales ; maximum 72 caractères. Appliquée à l'inscription, la réinitialisation, le changement de mot de passe et l'espace livreur |
| Un client pouvait bloquer tout le stock avec des commandes jamais payées (réservation indéfinie) | Maximum 5 commandes en attente de paiement par client, 15 commandes par heure et par client (30 par IP) ; les commandes non payées depuis 48 h sont annulées et le stock remis (au passage des clients, sans tâche planifiée) |
| Réinitialisation du mot de passe d'un livreur par e-mail : le drapeau « mot de passe provisoire » restait actif | Remis à zéro |
| Images : limite de 40 millions de pixels (jusqu'à ~160 Mo en mémoire au décodage) | Limite abaissée à 24 millions de pixels |
| `.htaccess` : seuls `.env`, `.sql`, `.md`, `.log`… étaient interdits | Ajout de `.bak`, `.old`, `.ini`, `.zip`, `.sh`, `.yml`, `.json`, `.example`… (sauvegardes oubliées) |

Relu sans trouver de faille : requêtes SQL (toutes préparées), échappement des sorties, CSRF sur tous les formulaires, contrôle d'accès des pages (admin / vendeur / livreur / propriétaire de la commande), envoi de photos (ré-encodage GD, dossiers privés), webhooks de paiement (hash + confirmation serveur à serveur + contrôle du montant), sessions, 2FA, en-têtes de sécurité, envoi d'e-mails.

Limites connues restantes : `JEND_ENV_FILE` (variable d'environnement du serveur) peut désigner un autre fichier de configuration : sans risque sur un hébergement mutualisé, mais à ne pas définir en production ; le message « adresse e-mail déjà utilisée » à l'inscription révèle l'existence d'un compte (limité à 5 essais par heure et par IP).

## Relecture des nouveautés (16 octobre 2026)

Fonctions relues : tableaux de bord, page boutique publique, partage WhatsApp, régions par boutique, badge « vérifiée », lien de paiement, offres de prix, vidéo du produit, parrainage, commande sur mesure, vue admin des offres.

Corrigé dans cette passe :

| Problème | Correction |
|---|---|
| Lien vidéo : une adresse du type `https://site-pirate\@tiktok.com` passait le contrôle du domaine alors qu'un navigateur l'ouvre sur un autre site | Barre oblique inversée, identifiants (`utilisateur@`) et port refusés ; le `@` reste permis dans le chemin (`tiktok.com/@compte`) |
| Sur-mesure : le vendeur pouvait modifier son devis pendant que le client lisait l'ancien ; un clic acceptait alors le nouveau prix | Le prix affiché au client est renvoyé avec l'acceptation et comparé au devis en base : s'il a changé, l'acceptation est refusée |
| Sur-mesure : après l'accord, le vendeur pouvait modifier le prix ou supprimer le produit réservé depuis « Mes produits » | Un produit réservé n'est plus modifiable ni supprimable |
| Page boutique : le tri utilisait `onchange` en ligne, bloqué par la politique de sécurité (le tri ne fonctionnait pas) | Remplacé par un bouton « Trier » |

Relu sans trouver de faille : accès aux pages (toutes les pages admin et vendeur ont leur garde), CSRF sur tous les formulaires (seul le webhook de paiement n'en a pas : il est authentifié par signature), requêtes SQL préparées, sorties échappées, offres (bornes de prix, propriété, usage unique, prix négocié relu en base), produits réservés invisibles pour les autres clients, parrainage (récompense seulement à la validation par l'administrateur, une fois).

Limite connue : le parrainage repose sur la vigilance de l'administrateur. Un vendeur qui crée de fausses boutiques avec d'autres comptes n'est récompensé que si l'administrateur les valide.

## Authentification (16 octobre 2026)

| Problème | Correction |
|---|---|
| L'empreinte factice (vérifiée quand l'e-mail n'existe pas) était écrite en dur avec un coût fixe : sur un serveur dont le réglage par défaut est plus élevé (PHP 8.4), le temps de réponse aurait révélé quels e-mails ont un compte | Empreinte factice créée avec le réglage du serveur et gardée en base ; mise à niveau automatique des empreintes à la connexion |
| Confirmation de l'e-mail absente : on pouvait créer un compte avec l'adresse d'un autre | Lien de confirmation (48 h, usage unique, seule l'empreinte du jeton est gardée) ; sans confirmation, impossible de commander, d'ouvrir une boutique ou de négocier ; renvoi limité à 3 par heure ; désactivable par l'admin si l'hébergeur n'envoie pas d'e-mails |

## Risques restants traités (16 octobre 2026)

| Risque | Ce qui a été fait |
|---|---|
| Frais du prestataire supérieurs à la commission | Réglage « Frais de paiement sécurisé » payés par le client (affichés avant paiement, dans les CGV, remboursés en cas d'annulation, 0 % par défaut) |
| Retrait détourné par un compte vendeur piraté | E-mail de contrôle à chaque demande de retrait et à chaque changement de numéro ; retraits suspendus 48 h après un changement de numéro ; alerte « Numéro changé » chez l'admin ; option « 2FA obligatoire pour retirer » |
| E-mails non envoyés | État de l'envoi et bouton « M'envoyer un e-mail de test » dans les Paramètres ; guide SMTP |
| Version d'Apache affichée | `ServerSignature Off` et pages d'erreur neutres dans `.htaccess` ; `TraceEnable off` et `ServerTokens Prod` à demander à l'hébergeur |
| PHP 8.4 | Code vérifié (aucun paramètre implicitement nullable) ; à confirmer avec `diagnostic.php` sur le serveur |
| Cadre légal (BCEAO) | Hors code : questions à poser listées dans `DOSSIER-JURIDIQUE-ET-HEBERGEMENT.md` |

## Comment re-vérifier

```
python3 scripts/tester-en-isolation.py                      # toute la batterie de bout en bout, sur une COPIE jetable avec sa propre base (vos données ne sont jamais touchées)
php scripts/verifier-production.php --url=https://site.sn   # sur le serveur de production
```
