-- Frais de paiement sécurisé payés par le client (réglables par l'admin, 0 par défaut) : ils couvrent les frais du prestataire de paiement.
ALTER TABLE commandes ADD COLUMN frais_service INT UNSIGNED NOT NULL DEFAULT 0;

-- Sécurité des retraits : date du dernier changement du numéro de paiement de la boutique (retraits bloqués 48 h ensuite).
ALTER TABLE boutiques ADD COLUMN telephone_modifie_le DATETIME NULL;
