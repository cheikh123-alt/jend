-- Étape 10 : limitation des tentatives (anti force-brute) et journal des actions de l'administrateur

CREATE TABLE IF NOT EXISTS limites (
  id          BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  cle         VARCHAR(120) NOT NULL,                 -- ex : login:ip:203.0.113.5
  created_at  TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_limites (cle, created_at)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS journal_admin (
  id          BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  admin_id    INT UNSIGNED NULL,
  action      VARCHAR(60) NOT NULL,
  detail      VARCHAR(255) NULL,
  ip          VARCHAR(45) NULL,
  created_at  TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_journal_date (created_at),
  FOREIGN KEY (admin_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB;
