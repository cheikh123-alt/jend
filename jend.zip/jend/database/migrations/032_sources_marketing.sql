-- Marketing : d'où viennent les clients et les commandes (partage WhatsApp, statut, lien de paiement, affiche QR, TikTok…).
ALTER TABLE commandes ADD COLUMN source VARCHAR(30) NULL;
ALTER TABLE users ADD COLUMN source VARCHAR(30) NULL;
CREATE INDEX idx_commandes_source ON commandes (source, created_at);
