-- Aide et contact : messages des clients, vendeurs et visiteurs à l'équipe Jënd, avec réponse et suivi.
CREATE TABLE IF NOT EXISTS messages_support (
  id          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  reference   VARCHAR(20) NOT NULL UNIQUE,                 -- ex : AIDE-9F3A1C2B
  user_id     INT UNSIGNED NULL,                           -- vide pour un visiteur non connecté
  nom         VARCHAR(120) NOT NULL,
  email       VARCHAR(190) NOT NULL,
  telephone   VARCHAR(20) NULL,
  sujet       ENUM('commande','paiement','compte','boutique','technique','autre') NOT NULL,
  commande_ref VARCHAR(20) NULL,
  message     TEXT NOT NULL,
  statut      ENUM('nouveau','en_cours','resolu') NOT NULL DEFAULT 'nouveau',
  reponse     TEXT NULL,
  repondu_le  DATETIME NULL,
  created_at  TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_support_statut (statut, created_at),
  INDEX idx_support_user (user_id),
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB;
