-- « Faire une offre » (waxale) : le client propose un prix, le vendeur accepte, refuse ou contre-propose.
CREATE TABLE IF NOT EXISTS offres (
  id           INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  produit_id   INT UNSIGNED NOT NULL,
  boutique_id  INT UNSIGNED NOT NULL,
  client_id    INT UNSIGNED NOT NULL,
  quantite     TINYINT UNSIGNED NOT NULL DEFAULT 1,
  prix_initial INT UNSIGNED NOT NULL,                 -- prix affiché du produit au moment de l'offre
  prix_propose INT UNSIGNED NOT NULL,                 -- prix unitaire proposé par le client
  contre_prix  INT UNSIGNED NULL,                     -- contre-proposition du vendeur
  prix_final   INT UNSIGNED NULL,                     -- prix unitaire convenu (offre acceptée)
  statut       ENUM('en_attente','contre','acceptee','refusee','utilisee','annulee') NOT NULL DEFAULT 'en_attente',
  expire_le    DATETIME NOT NULL,                     -- sans réponse (ou sans achat après accord) : l'offre tombe
  created_at   TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_offres_boutique (boutique_id, statut),
  INDEX idx_offres_client (client_id, statut),
  FOREIGN KEY (produit_id)  REFERENCES produits(id)  ON DELETE CASCADE,
  FOREIGN KEY (boutique_id) REFERENCES boutiques(id) ON DELETE CASCADE,
  FOREIGN KEY (client_id)   REFERENCES users(id)     ON DELETE CASCADE
) ENGINE=InnoDB;

-- Chaque boutique choisit si elle accepte les propositions de prix (oui par défaut).
ALTER TABLE boutiques ADD COLUMN offres_actives TINYINT(1) NOT NULL DEFAULT 1;
