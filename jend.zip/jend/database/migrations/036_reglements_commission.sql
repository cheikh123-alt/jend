-- Jënd — migration 036 : règlement des commissions par les vendeurs.
-- Quand le client paie en espèces au vendeur, Jënd ne touche pas l'argent : la commission devient une dette du vendeur.
-- Le vendeur la règle par Wave / Orange Money au numéro de Jënd ; l'administrateur enregistre chaque règlement ici.
CREATE TABLE IF NOT EXISTS reglements_commission (
  id          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  boutique_id INT UNSIGNED NOT NULL,
  montant     INT UNSIGNED NOT NULL,
  methode     VARCHAR(20) NOT NULL,                   -- wave | orange_money | free_money | especes | autre
  reference   VARCHAR(60) NULL,                       -- référence du transfert reçu
  admin_id    INT UNSIGNED NULL,
  created_at  TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (boutique_id) REFERENCES boutiques(id) ON DELETE CASCADE,
  FOREIGN KEY (admin_id) REFERENCES users(id) ON DELETE SET NULL,
  INDEX idx_reglements_boutique (boutique_id, created_at)
) ENGINE=InnoDB;
