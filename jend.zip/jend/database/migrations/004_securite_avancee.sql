-- Étape 10 bis : double authentification (2FA), invalidation des sessions, code de livraison

ALTER TABLE users
  ADD COLUMN session_version   INT UNSIGNED NOT NULL DEFAULT 1,       -- +1 à chaque changement de mot de passe : coupe les autres sessions
  ADD COLUMN totp_secret       VARCHAR(255) NULL,                      -- secret 2FA, CHIFFRÉ (jamais en clair en base)
  ADD COLUMN totp_actif        TINYINT(1) NOT NULL DEFAULT 0,
  ADD COLUMN totp_dernier_pas  BIGINT UNSIGNED NOT NULL DEFAULT 0;     -- empêche de réutiliser le même code deux fois

CREATE TABLE codes_secours (
  id          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id     INT UNSIGNED NOT NULL,
  code_hash   CHAR(64) NOT NULL,                                       -- empreinte SHA-256 : le code lui-même n'est jamais stocké
  utilise     TINYINT(1) NOT NULL DEFAULT 0,
  created_at  TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_codes_user (user_id),
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

ALTER TABLE commande_boutiques
  ADD COLUMN code_livraison CHAR(4) NULL;                              -- code que le CLIENT donne à la réception : le vendeur doit le saisir pour marquer « livrée »

-- Commandes déjà en cours au moment de la migration : on leur attribue un code
UPDATE commande_boutiques SET code_livraison = LPAD(FLOOR(RAND() * 10000), 4, '0')
 WHERE code_livraison IS NULL AND statut IN ('a_preparer', 'expediee');
