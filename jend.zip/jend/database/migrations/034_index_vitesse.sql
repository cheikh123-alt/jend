-- Jënd — migration 034 : index pour garder le catalogue rapide avec beaucoup de produits (tri par date, par prix, par avis).
-- Mesuré sur 20 000 produits : la liste « récents » ne parcourt plus tout le catalogue pour en afficher 12.
ALTER TABLE produits
  ADD INDEX idx_produits_recents (statut, created_at),
  ADD INDEX idx_produits_prix (statut, prix),
  ADD INDEX idx_produits_populaires (statut, nb_avis);
