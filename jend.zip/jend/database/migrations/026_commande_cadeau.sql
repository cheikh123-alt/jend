-- « Envoyer à ma famille » : commande passée pour un proche (souvent depuis l'étranger).
-- Le vendeur ne met ni prix ni facture dans le colis ; un petit mot peut accompagner le cadeau ; l'acheteur transmet le code de réception à son proche.
ALTER TABLE commandes ADD COLUMN cadeau TINYINT(1) NOT NULL DEFAULT 0;
ALTER TABLE commandes ADD COLUMN message_cadeau VARCHAR(300) NULL;
