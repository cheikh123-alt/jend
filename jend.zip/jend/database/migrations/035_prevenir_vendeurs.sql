-- Jënd — migration 035 : prévenir le vendeur d'une nouvelle commande, même s'il n'est pas connecté.
--  - notifications sur le téléphone (abonnements « push » du navigateur) ;
--  - date où le vendeur a été prévenu (e-mail + notification), et date de relance par l'équipe Jënd (WhatsApp / appel).
ALTER TABLE commande_boutiques
  ADD COLUMN vendeur_prevenu_le DATETIME NULL AFTER livre_le,
  ADD COLUMN relance_le DATETIME NULL AFTER vendeur_prevenu_le;

-- Les commandes déjà passées ne déclenchent pas de notification après coup
UPDATE commande_boutiques SET vendeur_prevenu_le = NOW() WHERE vendeur_prevenu_le IS NULL;

CREATE TABLE IF NOT EXISTS push_abonnements (
  id            INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id       INT UNSIGNED NOT NULL,
  endpoint      VARCHAR(600) NOT NULL,                  -- adresse fournie par le navigateur (Google, Mozilla, Apple…)
  endpoint_hash CHAR(64) NOT NULL UNIQUE,
  cle_p256dh    VARCHAR(120) NOT NULL,                  -- clés de chiffrement du téléphone (le contenu est illisible pour le service de notification)
  cle_auth      VARCHAR(40) NOT NULL,
  appareil      VARCHAR(120) NULL,
  dernier_envoi DATETIME NULL,
  created_at    TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  INDEX idx_push_user (user_id)
) ENGINE=InnoDB;
