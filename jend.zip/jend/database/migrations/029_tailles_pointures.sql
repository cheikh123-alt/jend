-- Tailles et pointures : certaines catégories (vêtements, chaussures, enfants) proposent au vendeur d'indiquer
-- les tailles disponibles, chacune avec son propre stock ; le client doit alors en choisir une.
ALTER TABLE categories ADD COLUMN option_type VARCHAR(20) NULL;          -- taille | pointure | taille_enfant (NULL : pas de choix)
ALTER TABLE produits ADD COLUMN option_type VARCHAR(20) NULL;            -- type choisi pour ce produit (NULL : aucune taille)

CREATE TABLE produit_variantes (
  id          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  produit_id  INT UNSIGNED NOT NULL,
  libelle     VARCHAR(20) NOT NULL,                 -- « M », « 42 », « 2 ans »
  stock       INT UNSIGNED NOT NULL DEFAULT 0,
  position    TINYINT UNSIGNED NOT NULL DEFAULT 0,
  UNIQUE KEY uniq_variante (produit_id, libelle),
  FOREIGN KEY (produit_id) REFERENCES produits(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- La taille choisie est copiée dans la ligne de commande (elle reste lisible même si le vendeur la retire ensuite)
ALTER TABLE commande_lignes ADD COLUMN variante_id INT UNSIGNED NULL, ADD COLUMN variante_libelle VARCHAR(40) NULL,
  ADD CONSTRAINT fk_ligne_variante FOREIGN KEY (variante_id) REFERENCES produit_variantes(id) ON DELETE SET NULL;

-- « La dépense du mois » garde aussi la taille choisie (0 : produit sans taille)
ALTER TABLE depense_lignes ADD COLUMN variante_id INT UNSIGNED NOT NULL DEFAULT 0, DROP PRIMARY KEY, ADD PRIMARY KEY (depense_id, produit_id, variante_id);

-- Réglages de départ (modifiables dans Administration → Catégories)
UPDATE categories SET option_type = 'taille' WHERE slug IN ('mode-wax', 'vetements', 'boubous-tenues');
UPDATE categories SET option_type = 'taille_enfant' WHERE slug = 'enfants';
UPDATE categories SET option_type = 'pointure' WHERE slug IN ('chaussures');
