-- Vidéo du produit : lien vers une vidéo déjà publiée (TikTok, YouTube, Instagram, Facebook).
ALTER TABLE produits ADD COLUMN video_url VARCHAR(255) NULL;

-- Parrainage entre vendeurs : chaque boutique a un code ; le parrain et le filleul gagnent une période sans commission
-- quand la boutique parrainée est validée par l'administrateur.
ALTER TABLE boutiques
  ADD COLUMN code_parrain VARCHAR(12) NULL UNIQUE,
  ADD COLUMN parrain_boutique_id INT UNSIGNED NULL,
  ADD COLUMN parrainage_recompense TINYINT(1) NOT NULL DEFAULT 0,
  ADD COLUMN commission_gratuite_jusqu DATE NULL;
UPDATE boutiques SET code_parrain = UPPER(SUBSTRING(MD5(CONCAT(id, '-', RAND(), '-', NOW())), 1, 8)) WHERE code_parrain IS NULL;
