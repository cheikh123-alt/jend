-- Espace livreur : nouveau rôle, fiche livreur (disponibilité, zone) et suivi de chaque course.
-- Une « course » = une sous-commande (commande_boutiques) à récupérer chez un vendeur et à livrer au client.
ALTER TABLE users MODIFY role ENUM('client','vendeur','admin','livreur') NOT NULL DEFAULT 'client';

CREATE TABLE IF NOT EXISTS livreurs (
  user_id     INT UNSIGNED PRIMARY KEY,
  zone_id     SMALLINT UNSIGNED NULL,                    -- zone habituelle (NULL = toutes les zones)
  disponible  TINYINT(1) NOT NULL DEFAULT 0,             -- le livreur se déclare disponible / indisponible
  created_at  TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (zone_id) REFERENCES zones_livraison(id) ON DELETE SET NULL
) ENGINE=InnoDB;

ALTER TABLE commande_boutiques
  ADD COLUMN livreur_id   INT UNSIGNED NULL,
  ADD COLUMN affecte_le   DATETIME NULL,
  ADD COLUMN recupere_le  DATETIME NULL,                 -- le livreur a récupéré le colis chez le vendeur
  ADD COLUMN en_route_le  DATETIME NULL,
  ADD INDEX idx_cb_livreur (livreur_id, statut),
  ADD CONSTRAINT fk_cb_livreur FOREIGN KEY (livreur_id) REFERENCES users(id) ON DELETE SET NULL;
