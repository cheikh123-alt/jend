-- Paramètres du site modifiables par l'administrateur (« fonctionnalités à activer quand le site grandit »).
CREATE TABLE IF NOT EXISTS parametres (
  cle         VARCHAR(60) PRIMARY KEY,
  valeur      VARCHAR(255) NOT NULL,
  updated_at  TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;
