-- Livraison dans tout le Sénégal (en plus des quartiers de Touba).
-- Réactive les zones d'origine (Dakar, Thiès, Kaolack, Saint-Louis, Ziguinchor…) et ajoute les autres régions.
-- Les frais et délais sont des valeurs de DÉPART : l'administrateur les ajuste dans /admin/zones.
-- Relançable sans risque : rien n'est dupliqué.
UPDATE zones_livraison SET actif = 1
 WHERE nom IN ('Dakar Plateau / Médina', 'Dakar — Almadies / Ngor / Yoff', 'Guédiawaye / Pikine / Parcelles', 'Rufisque / Bargny',
               'Thiès', 'Mbour / Saly', 'Kaolack', 'Saint-Louis', 'Ziguinchor');

INSERT INTO zones_livraison (nom, region, frais, delai_jours)
SELECT v.nom, v.region, v.frais, v.delai FROM (
  SELECT 'Dakar Plateau / Médina' AS nom, 'Dakar' AS region, 1500 AS frais, 1 AS delai UNION ALL
  SELECT 'Dakar — Almadies / Ngor / Yoff', 'Dakar', 2000, 1 UNION ALL
  SELECT 'Guédiawaye / Pikine / Parcelles', 'Dakar', 2000, 2 UNION ALL
  SELECT 'Rufisque / Bargny', 'Dakar', 2500, 2 UNION ALL
  SELECT 'Thiès', 'Thiès', 3500, 3 UNION ALL
  SELECT 'Mbour / Saly', 'Thiès', 3500, 3 UNION ALL
  SELECT 'Diourbel', 'Diourbel', 3500, 3 UNION ALL
  SELECT 'Mbacké', 'Diourbel', 3000, 2 UNION ALL
  SELECT 'Kaolack', 'Kaolack', 4500, 4 UNION ALL
  SELECT 'Saint-Louis', 'Saint-Louis', 4500, 4 UNION ALL
  SELECT 'Louga', 'Louga', 4500, 4 UNION ALL
  SELECT 'Fatick', 'Fatick', 4500, 4 UNION ALL
  SELECT 'Kaffrine', 'Kaffrine', 5000, 4 UNION ALL
  SELECT 'Tambacounda', 'Tambacounda', 7000, 6 UNION ALL
  SELECT 'Kolda', 'Kolda', 6500, 5 UNION ALL
  SELECT 'Sédhiou', 'Sédhiou', 6500, 5 UNION ALL
  SELECT 'Matam', 'Matam', 7000, 6 UNION ALL
  SELECT 'Kédougou', 'Kédougou', 8000, 7 UNION ALL
  SELECT 'Ziguinchor', 'Ziguinchor', 6000, 5
) v WHERE NOT EXISTS (SELECT 1 FROM zones_livraison z WHERE z.nom = v.nom);
