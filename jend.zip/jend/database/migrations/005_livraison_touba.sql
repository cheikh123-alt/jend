-- Livraison limitée à Touba : les anciennes zones (Dakar, Thiès, ...) sont DÉSACTIVÉES (pas supprimées :
-- des adresses et l'historique des commandes y font référence) et les quartiers de Touba sont ajoutés.
-- L'administrateur gère ensuite les zones depuis /admin/zones. Relançable sans risque : rien n'est dupliqué.
UPDATE zones_livraison SET actif = 0 WHERE region <> 'Touba';

INSERT INTO zones_livraison (nom, region, frais, delai_jours)
SELECT v.nom, 'Touba', v.frais, v.delai FROM (
  SELECT 'Touba — Centre / Grande Mosquée' AS nom, 500 AS frais, 1 AS delai UNION ALL
  SELECT 'Darou Marnane', 500, 1 UNION ALL
  SELECT 'Darou Khoudoss', 700, 1 UNION ALL
  SELECT 'Darou Miname', 700, 1 UNION ALL
  SELECT 'Touba Bogo', 700, 1 UNION ALL
  SELECT 'Gouye Mbind', 1000, 1 UNION ALL
  SELECT 'Ndamatou', 1000, 1 UNION ALL
  SELECT 'Khaïra', 1000, 2 UNION ALL
  SELECT 'Touba Ouadiour', 1500, 2
) v WHERE NOT EXISTS (SELECT 1 FROM zones_livraison z WHERE z.nom = v.nom);
