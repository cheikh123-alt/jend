-- Étape 7 : liens de réinitialisation de mot de passe
-- On ne stocke que l'empreinte (SHA-256) du jeton : un vol de la base ne permet pas de réinitialiser un compte.
CREATE TABLE IF NOT EXISTS reinitialisations_mdp (
  id          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id     INT UNSIGNED NOT NULL,
  token_hash  CHAR(64) NOT NULL,
  expire_le   DATETIME NOT NULL,
  created_at  TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uniq_token (token_hash),
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;
