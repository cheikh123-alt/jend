-- Vitrine professionnelle de la boutique : logo, bannière, accroche, ville, couleur, réseaux sociaux, bouton WhatsApp.
ALTER TABLE boutiques ADD COLUMN logo_chemin VARCHAR(255) NULL,
                      ADD COLUMN banniere_chemin VARCHAR(255) NULL,
                      ADD COLUMN slogan VARCHAR(120) NULL,
                      ADD COLUMN ville VARCHAR(80) NULL,
                      ADD COLUMN couleur VARCHAR(20) NOT NULL DEFAULT 'terre',
                      ADD COLUMN contact_whatsapp VARCHAR(20) NULL,
                      ADD COLUMN reseau_tiktok VARCHAR(255) NULL,
                      ADD COLUMN reseau_instagram VARCHAR(255) NULL,
                      ADD COLUMN reseau_facebook VARCHAR(255) NULL;
