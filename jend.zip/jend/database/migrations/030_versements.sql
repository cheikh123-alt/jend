-- Versements à date fixe (comme les grandes marketplaces) : le jour choisi par l'administrateur, le solde disponible
-- de chaque vendeur est préparé automatiquement en versement ; l'administrateur l'envoie puis indique la référence du transfert.
ALTER TABLE retraits ADD COLUMN automatique TINYINT(1) NOT NULL DEFAULT 0,
                     ADD COLUMN paye_le DATETIME NULL,
                     ADD COLUMN reference_transfert VARCHAR(60) NULL;
ALTER TABLE boutiques ADD COLUMN versement_auto TINYINT(1) NOT NULL DEFAULT 1,
                      ADD COLUMN methode_versement VARCHAR(20) NOT NULL DEFAULT 'wave';
-- Reprise : les retraits déjà versés gardent leur date de demande comme date de versement
UPDATE retraits SET paye_le = created_at WHERE statut = 'paye' AND paye_le IS NULL;
