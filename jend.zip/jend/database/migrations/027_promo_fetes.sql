-- Promotion de fête facultative, choisie par le vendeur pour chaque produit de la vitrine (0 = pas de promotion).
-- Elle s'applique automatiquement du début de la vitrine jusqu'au jour de la fête, puis le prix normal revient tout seul.
ALTER TABLE produit_fetes ADD COLUMN remise_pct TINYINT UNSIGNED NOT NULL DEFAULT 0;
