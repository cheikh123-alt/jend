-- Chaque boutique fixe ses frais (et son délai) de livraison par zone. Sans ligne : les frais de référence de la zone.
CREATE TABLE IF NOT EXISTS boutique_frais (
  boutique_id INT UNSIGNED NOT NULL,
  zone_id     SMALLINT UNSIGNED NOT NULL,
  frais       INT UNSIGNED NOT NULL,
  delai_jours TINYINT UNSIGNED NULL,
  PRIMARY KEY (boutique_id, zone_id),
  FOREIGN KEY (boutique_id) REFERENCES boutiques(id) ON DELETE CASCADE,
  FOREIGN KEY (zone_id) REFERENCES zones_livraison(id) ON DELETE CASCADE
) ENGINE=InnoDB;
