-- 1. « Ma position » : point GPS de livraison (commande et adresses enregistrées) ; lien que le proche (commande cadeau) ouvre pour envoyer sa position.
ALTER TABLE commandes ADD COLUMN livraison_lat DECIMAL(9,6) NULL, ADD COLUMN livraison_lng DECIMAL(9,6) NULL, ADD COLUMN position_jeton CHAR(32) NULL UNIQUE;
ALTER TABLE adresses ADD COLUMN lat DECIMAL(9,6) NULL, ADD COLUMN lng DECIMAL(9,6) NULL;

-- 2. « La dépense du mois » : panier qui revient chaque mois (pour soi ou pour sa famille), avec un rappel par e-mail.
CREATE TABLE depenses (
  id               INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  client_id        INT UNSIGNED NOT NULL,
  nom              VARCHAR(80) NOT NULL,
  jour             TINYINT UNSIGNED NOT NULL,          -- jour du mois du rappel (1 à 28)
  livraison_nom    VARCHAR(120) NOT NULL,
  livraison_telephone VARCHAR(20) NOT NULL,
  zone_id          SMALLINT UNSIGNED NOT NULL,
  adresse          VARCHAR(255) NOT NULL,
  cadeau           TINYINT(1) NOT NULL DEFAULT 0,
  actif            TINYINT(1) NOT NULL DEFAULT 1,
  prochain_rappel  DATE NOT NULL,
  dernier_rappel   DATE NULL,
  created_at       TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_depenses_rappel (actif, prochain_rappel),
  FOREIGN KEY (client_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (zone_id) REFERENCES zones_livraison(id)
) ENGINE=InnoDB;

CREATE TABLE depense_lignes (
  depense_id  INT UNSIGNED NOT NULL,
  produit_id  INT UNSIGNED NOT NULL,
  quantite    TINYINT UNSIGNED NOT NULL,
  PRIMARY KEY (depense_id, produit_id),
  FOREIGN KEY (depense_id) REFERENCES depenses(id) ON DELETE CASCADE,
  FOREIGN KEY (produit_id) REFERENCES produits(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- 3. Description vocale d'un produit (enregistrée par le vendeur).
ALTER TABLE produits ADD COLUMN voix_chemin VARCHAR(255) NULL;

-- 4. « Prévenez-moi » : baisse de prix ou retour en stock.
CREATE TABLE alertes_produit (
  id          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id     INT UNSIGNED NOT NULL,
  produit_id  INT UNSIGNED NOT NULL,
  prix_vu     INT UNSIGNED NOT NULL,                 -- prix au moment de la demande (on prévient s'il baisse)
  epuise      TINYINT(1) NOT NULL DEFAULT 0,         -- 1 : produit épuisé au moment de la demande (on prévient à son retour)
  created_at  TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uniq_alerte (user_id, produit_id),
  INDEX idx_alertes_produit (produit_id),
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (produit_id) REFERENCES produits(id) ON DELETE CASCADE
) ENGINE=InnoDB;
