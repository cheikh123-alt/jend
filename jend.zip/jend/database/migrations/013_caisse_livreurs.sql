-- Caisse des livreurs Jënd : chaque remise d'espèces (le livreur rapporte à Jënd l'argent encaissé à la livraison) est notée ici.
-- À remettre = espèces encaissées sur ses courses livrées − remises enregistrées.
CREATE TABLE IF NOT EXISTS caisse_livreurs (
  id          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  livreur_id  INT UNSIGNED NOT NULL,
  montant     INT UNSIGNED NOT NULL,
  note        VARCHAR(190) NULL,
  admin_id    INT UNSIGNED NULL,
  created_at  TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_caisse_livreur (livreur_id),
  FOREIGN KEY (livreur_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (admin_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB;
