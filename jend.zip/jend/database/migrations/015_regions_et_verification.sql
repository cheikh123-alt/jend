-- Régions desservies par chaque boutique : sans ligne, la boutique livre partout (comportement d'avant).
CREATE TABLE IF NOT EXISTS boutique_regions (
  boutique_id INT UNSIGNED NOT NULL,
  region      VARCHAR(60)  NOT NULL,
  PRIMARY KEY (boutique_id, region),
  FOREIGN KEY (boutique_id) REFERENCES boutiques(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- Badge « boutique vérifiée » : attribué par l'administrateur après contrôle (identité, produits réels).
ALTER TABLE boutiques ADD COLUMN verifiee TINYINT(1) NOT NULL DEFAULT 0;
