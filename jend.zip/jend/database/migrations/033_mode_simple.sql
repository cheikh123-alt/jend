-- Jënd — migration 033 : « mode simple » de l'espace vendeur (photo, prix, voix ; grands boutons ; aide audio).
-- Le mode est choisi à l'ouverture de la boutique et modifiable à tout moment. Rien d'autre ne change.
ALTER TABLE boutiques
  ADD COLUMN mode_simple TINYINT(1) NOT NULL DEFAULT 0 AFTER verifiee;
