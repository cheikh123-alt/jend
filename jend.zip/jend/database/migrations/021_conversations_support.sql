-- « Aide et contact » en conversation : l'équipe et le client échangent dans le même fil, l'administrateur le clôt une fois réglé.
CREATE TABLE IF NOT EXISTS messages_support_reponses (
  id          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  message_id  INT UNSIGNED NOT NULL,
  auteur      ENUM('client','equipe') NOT NULL,
  user_id     INT UNSIGNED NULL,
  texte       TEXT NOT NULL,
  created_at  TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_reponses_message (message_id, id),
  FOREIGN KEY (message_id) REFERENCES messages_support(id) ON DELETE CASCADE,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- Lien secret de suivi pour un visiteur sans compte (seule l'empreinte est gardée).
ALTER TABLE messages_support ADD COLUMN jeton_hash CHAR(64) NULL;

-- Les réponses déjà données deviennent le premier message de l'équipe dans le fil.
INSERT INTO messages_support_reponses (message_id, auteur, texte, created_at)
SELECT m.id, 'equipe', m.reponse, COALESCE(m.repondu_le, m.created_at) FROM messages_support m
 WHERE m.reponse IS NOT NULL AND NOT EXISTS (SELECT 1 FROM messages_support_reponses r WHERE r.message_id = m.id);
