-- Confirmation de l'adresse e-mail à l'inscription. Les comptes existants sont considérés comme confirmés.
ALTER TABLE users
  ADD COLUMN email_verifie TINYINT(1) NOT NULL DEFAULT 1,
  ADD COLUMN email_jeton_hash CHAR(64) NULL,
  ADD COLUMN email_jeton_expire DATETIME NULL;
