-- Historique détaillé de chaque signalement (litige) : qui a fait quoi, quand. Affiché au client et à l'équipe sous forme de chronologie.
CREATE TABLE litige_evenements (
  id         INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  litige_id  INT UNSIGNED NOT NULL,
  type       VARCHAR(30) NOT NULL,                   -- cree, message_client, examen, message_equipe, rembourse, remplace, rejete, argent_envoye
  auteur     ENUM('client','equipe','systeme') NOT NULL,
  texte      TEXT NULL,
  montant    INT UNSIGNED NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_litige_evenements (litige_id, created_at),
  FOREIGN KEY (litige_id) REFERENCES litiges(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- Reprise des signalements existants (à partir des dates déjà connues)
INSERT INTO litige_evenements (litige_id, type, auteur, texte, created_at)
  SELECT id, 'cree', 'client', description, created_at FROM litiges;
INSERT INTO litige_evenements (litige_id, type, auteur, texte, created_at)
  SELECT id, 'examen', 'equipe', IF(statut = 'en_cours', reponse_admin, NULL), repondu_le FROM litiges WHERE repondu_le IS NOT NULL;
INSERT INTO litige_evenements (litige_id, type, auteur, texte, montant, created_at)
  SELECT id, statut, 'equipe', reponse_admin, IF(statut = 'rembourse', montant_rembourse, NULL), resolu_le FROM litiges
   WHERE resolu_le IS NOT NULL AND statut IN ('rembourse', 'remplace', 'rejete');
INSERT INTO litige_evenements (litige_id, type, auteur, montant, created_at)
  SELECT id, 'argent_envoye', 'equipe', montant_rembourse, rembourse_le FROM litiges WHERE rembourse_le IS NOT NULL;
