-- Espace livreur : date/heure de livraison (pour l'historique du livreur et ses totaux du jour).
ALTER TABLE commande_boutiques ADD COLUMN livre_le DATETIME NULL AFTER en_route_le;
