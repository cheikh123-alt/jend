-- Sécurité : un mot de passe donné par l'administrateur (comptes livreurs) est provisoire : il doit être changé à la première connexion.
ALTER TABLE users ADD COLUMN mdp_provisoire TINYINT(1) NOT NULL DEFAULT 0;
