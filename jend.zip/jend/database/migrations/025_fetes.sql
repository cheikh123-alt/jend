-- « Spécial fêtes » (Magal, Tabaski, Korité, Gamou…) : l'administrateur saisit chaque année la date de la fête ;
-- les vendeurs y rattachent leurs produits ; une vitrine dédiée s'affiche avant la fête.
CREATE TABLE fetes (
  id           INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  nom          VARCHAR(80) NOT NULL,
  slug         VARCHAR(90) NOT NULL UNIQUE,
  date_fete    DATE NOT NULL,
  date_limite  DATE NULL,                              -- « commandez avant le … pour être livré à temps »
  vitrine_des  DATE NOT NULL,                          -- début de l'affichage de la vitrine
  texte        VARCHAR(300) NULL,
  actif        TINYINT(1) NOT NULL DEFAULT 1,
  created_at   TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_fetes_dates (actif, vitrine_des, date_fete)
) ENGINE=InnoDB;

CREATE TABLE produit_fetes (
  produit_id INT UNSIGNED NOT NULL,
  fete_id    INT UNSIGNED NOT NULL,
  PRIMARY KEY (produit_id, fete_id),
  INDEX idx_produit_fetes_fete (fete_id),
  FOREIGN KEY (produit_id) REFERENCES produits(id) ON DELETE CASCADE,
  FOREIGN KEY (fete_id) REFERENCES fetes(id) ON DELETE CASCADE
) ENGINE=InnoDB;
