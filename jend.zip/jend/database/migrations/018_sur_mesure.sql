-- Commande sur mesure (tailleurs, artisans) : le client décrit sa demande, le vendeur répond par un devis (prix + délai),
-- le client accepte et paie par le circuit habituel (argent protégé jusqu'à la réception).
ALTER TABLE boutiques ADD COLUMN sur_mesure TINYINT(1) NOT NULL DEFAULT 0;

-- Produit réservé à un client : créé automatiquement quand un devis est accepté ; invisible dans le catalogue.
ALTER TABLE produits ADD COLUMN reserve_client_id INT UNSIGNED NULL;

CREATE TABLE IF NOT EXISTS demandes_mesure (
  id             INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  reference      VARCHAR(20) NOT NULL UNIQUE,                -- ex : SM-9F3A1C2B
  boutique_id    INT UNSIGNED NOT NULL,
  client_id      INT UNSIGNED NOT NULL,
  description    TEXT NOT NULL,                              -- ce que le client veut (modèle, tissu, couleur…)
  mesures        TEXT NULL,                                  -- ses mesures, en texte libre
  budget         INT UNSIGNED NULL,
  date_souhaitee DATE NULL,
  statut         ENUM('envoyee','devis','acceptee','refusee','annulee') NOT NULL DEFAULT 'envoyee',
  prix           INT UNSIGNED NULL,                          -- devis du vendeur
  delai_jours    SMALLINT UNSIGNED NULL,
  reponse        TEXT NULL,
  produit_id     INT UNSIGNED NULL,                          -- produit réservé créé à l'acceptation du devis
  created_at     TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_dm_boutique (boutique_id, statut),
  INDEX idx_dm_client (client_id, statut),
  FOREIGN KEY (boutique_id) REFERENCES boutiques(id) ON DELETE CASCADE,
  FOREIGN KEY (client_id)   REFERENCES users(id)     ON DELETE CASCADE
) ENGINE=InnoDB;
