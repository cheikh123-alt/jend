-- Suivi client et litiges : « Signaler un problème » avec photos, délai de réponse, décision et remboursement visibles du client.
CREATE TABLE IF NOT EXISTS litiges (
  id                    INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  reference             VARCHAR(20) NOT NULL UNIQUE,                 -- ex : LIT-9F3A1C2B
  commande_boutique_id  INT UNSIGNED NOT NULL,                       -- la livraison concernée (un seul litige par livraison)
  client_id             INT UNSIGNED NOT NULL,
  motif                 ENUM('non_recu','non_conforme','defectueux','endommage','autre') NOT NULL,
  description           TEXT NOT NULL,
  statut                ENUM('ouvert','en_cours','rembourse','remplace','rejete') NOT NULL DEFAULT 'ouvert',
  reponse_admin         TEXT NULL,                                   -- dernière réponse de l'équipe, lue par le client
  montant_rembourse     INT UNSIGNED NOT NULL DEFAULT 0,
  a_charge_vendeur      TINYINT(1) NOT NULL DEFAULT 1,               -- 1 : le remboursement est retenu sur les gains du vendeur
  rembourse_le          DATETIME NULL,                               -- l'argent a réellement été renvoyé au client
  repondu_le            DATETIME NULL,                               -- première réponse de l'équipe (délai promis : 48 h)
  resolu_le             DATETIME NULL,
  created_at            TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uniq_litige_livraison (commande_boutique_id),
  INDEX idx_litiges_statut (statut, created_at),
  FOREIGN KEY (commande_boutique_id) REFERENCES commande_boutiques(id) ON DELETE CASCADE,
  FOREIGN KEY (client_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS litige_photos (
  id         INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  litige_id  INT UNSIGNED NOT NULL,
  chemin     VARCHAR(255) NOT NULL,                                  -- storage/litiges/… (jamais accessible directement : servi après contrôle d'accès)
  FOREIGN KEY (litige_id) REFERENCES litiges(id) ON DELETE CASCADE
) ENGINE=InnoDB;
