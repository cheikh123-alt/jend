-- Qui livre ? Au démarrage, chaque vendeur livre ses commandes lui-même et touche le frais de livraison.
-- L'administrateur peut confier une boutique à des livreurs Jënd (page Boutiques) ; Jënd garde alors le frais de livraison.
ALTER TABLE boutiques ADD COLUMN livraison_par ENUM('vendeur','jend') NOT NULL DEFAULT 'vendeur';

-- Photographie du mode de livraison au moment de la commande (changer le réglage plus tard ne touche pas aux commandes en cours),
-- et part du frais de livraison de la commande qui revient à cette livraison.
-- Les commandes déjà passées gardent le fonctionnement d'avant (livraison Jënd, frais conservés par Jënd).
ALTER TABLE commande_boutiques
  ADD COLUMN livre_par ENUM('vendeur','jend') NOT NULL DEFAULT 'jend',
  ADD COLUMN frais_part INT UNSIGNED NOT NULL DEFAULT 0;
