-- Acompte : pour une commande à payer à la livraison, le client règle d'abord une partie en ligne (réglable dans .env : ACOMPTE_POURCENT, ACOMPTE_MINIMUM).
-- Le reste est payé en espèces à la réception. Si le client refuse ou est injoignable, l'acompte est conservé (indemnise le vendeur ou les livreurs).
ALTER TABLE commandes
  MODIFY statut_paiement ENUM('en_attente','acompte','paye','echoue','rembourse') NOT NULL DEFAULT 'en_attente',   -- « acompte » : acompte payé, reste dû à la livraison
  ADD COLUMN acompte         INT UNSIGNED NOT NULL DEFAULT 0,
  ADD COLUMN acompte_methode ENUM('wave','orange_money','free_money','carte') NULL;

ALTER TABLE commande_boutiques
  ADD COLUMN acompte_part   INT UNSIGNED NOT NULL DEFAULT 0,          -- part de l'acompte qui correspond à cette livraison
  ADD COLUMN acompte_acquis TINYINT(1) NOT NULL DEFAULT 0;            -- 1 : client absent / refus, acompte conservé
