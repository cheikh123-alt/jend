-- ============================================================
-- Jënd — schéma MySQL 8 / MariaDB 10.4+
-- Montants en FCFA : entiers (pas de centimes au Sénégal)
-- ============================================================

CREATE DATABASE IF NOT EXISTS jend CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE jend;

SET FOREIGN_KEY_CHECKS = 0;
DROP TABLE IF EXISTS produit_variantes, alertes_produit, depense_lignes, depenses, produit_fetes, fetes, litige_evenements, boutique_frais, messages_support_reponses, messages_support, demandes_mesure, offres, boutique_regions, caisse_livreurs, parametres, litige_photos, litiges, livreurs, codes_secours, journal_admin, limites, reinitialisations_mdp, retraits, avis, favoris, panier_lignes, paniers, paiements,
  commande_lignes, commande_boutiques, commandes, produit_images, produits,
  categories, boutiques, adresses, zones_livraison, users;
SET FOREIGN_KEY_CHECKS = 1;

-- ---------- Utilisateurs ----------
CREATE TABLE users (
  id            INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  nom           VARCHAR(120) NOT NULL,
  email         VARCHAR(190) NOT NULL UNIQUE,
  telephone     VARCHAR(20)  NULL,
  mot_de_passe  VARCHAR(255) NOT NULL,                 -- password_hash() PHP
  role          ENUM('client','vendeur','admin','livreur') NOT NULL DEFAULT 'client',
  actif         TINYINT(1) NOT NULL DEFAULT 1,
  mdp_provisoire   TINYINT(1) NOT NULL DEFAULT 0,       -- 1 : mot de passe donné par l'admin, à changer à la première connexion
  session_version  INT UNSIGNED NOT NULL DEFAULT 1,     -- +1 à chaque changement de mot de passe : coupe les autres sessions
  totp_secret      VARCHAR(255) NULL,                   -- secret 2FA, CHIFFRÉ
  totp_actif       TINYINT(1) NOT NULL DEFAULT 0,
  totp_dernier_pas BIGINT UNSIGNED NOT NULL DEFAULT 0,  -- empêche de réutiliser le même code deux fois
  source           VARCHAR(30) NULL,                    -- canal d'arrivée (marketing)
  email_verifie    TINYINT(1) NOT NULL DEFAULT 1,       -- 0 : inscrit, adresse e-mail pas encore confirmée
  email_jeton_hash CHAR(64) NULL,                       -- empreinte du lien de confirmation envoyé par e-mail
  email_jeton_expire DATETIME NULL,
  created_at    TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_users_role (role)
) ENGINE=InnoDB;

-- ---------- Livraison ----------
CREATE TABLE zones_livraison (
  id          SMALLINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  nom         VARCHAR(100) NOT NULL,                   -- ex: Dakar Plateau
  region      VARCHAR(60)  NOT NULL,
  frais       INT UNSIGNED NOT NULL DEFAULT 0,
  delai_jours TINYINT UNSIGNED NOT NULL DEFAULT 2,
  actif       TINYINT(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB;

CREATE TABLE parametres (
  cle         VARCHAR(60) PRIMARY KEY,
  valeur      VARCHAR(255) NOT NULL,
  updated_at  TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE livreurs (
  user_id     INT UNSIGNED PRIMARY KEY,
  zone_id     SMALLINT UNSIGNED NULL,                    -- zone habituelle (NULL = toutes les zones)
  disponible  TINYINT(1) NOT NULL DEFAULT 0,             -- le livreur se déclare disponible / indisponible
  created_at  TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (zone_id) REFERENCES zones_livraison(id) ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE caisse_livreurs (
  id          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  livreur_id  INT UNSIGNED NOT NULL,
  montant     INT UNSIGNED NOT NULL,
  note        VARCHAR(190) NULL,
  admin_id    INT UNSIGNED NULL,
  created_at  TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_caisse_livreur (livreur_id),
  FOREIGN KEY (livreur_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (admin_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE adresses (
  id         INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id    INT UNSIGNED NOT NULL,
  libelle    VARCHAR(60) NOT NULL DEFAULT 'Domicile',
  zone_id    SMALLINT UNSIGNED NOT NULL,
  adresse    VARCHAR(255) NOT NULL,
  telephone  VARCHAR(20) NOT NULL,
  lat        DECIMAL(9,6) NULL,
  lng        DECIMAL(9,6) NULL,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (zone_id) REFERENCES zones_livraison(id)
) ENGINE=InnoDB;

-- ---------- Boutiques (vendeurs) ----------
CREATE TABLE boutiques (
  id              INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id         INT UNSIGNED NOT NULL UNIQUE,        -- 1 boutique par vendeur
  nom             VARCHAR(120) NOT NULL,
  slug            VARCHAR(140) NOT NULL UNIQUE,
  description     TEXT NULL,
  logo            VARCHAR(255) NULL,
  telephone_paiement VARCHAR(20) NULL,                 -- Wave / Orange Money du vendeur
  versement_auto    TINYINT(1) NOT NULL DEFAULT 1,      -- reçoit le versement à date fixe
  methode_versement VARCHAR(20) NOT NULL DEFAULT 'wave', -- wave | orange_money | free_money
  logo_chemin      VARCHAR(255) NULL,                  -- vitrine : uploads/boutiques/…
  banniere_chemin  VARCHAR(255) NULL,
  slogan           VARCHAR(120) NULL,
  ville            VARCHAR(80) NULL,
  couleur          VARCHAR(20) NOT NULL DEFAULT 'terre', -- terre | vert | safran | encre
  contact_whatsapp VARCHAR(20) NULL,                   -- bouton « Écrire sur WhatsApp » (facultatif)
  reseau_tiktok    VARCHAR(255) NULL,
  reseau_instagram VARCHAR(255) NULL,
  reseau_facebook  VARCHAR(255) NULL,
  statut          ENUM('en_attente','active','suspendue') NOT NULL DEFAULT 'en_attente',
  commission_pct  DECIMAL(4,2) NOT NULL DEFAULT 8.00,  -- % prélevé par Jënd
  livraison_par   ENUM('vendeur','jend') NOT NULL DEFAULT 'vendeur',   -- qui livre : le vendeur (frais pour lui) ou les livreurs Jënd
  code_parrain    VARCHAR(12) NULL UNIQUE,                             -- code de parrainage de la boutique
  parrain_boutique_id INT UNSIGNED NULL,                               -- boutique qui l'a parrainée
  parrainage_recompense TINYINT(1) NOT NULL DEFAULT 0,                 -- récompense de parrainage déjà attribuée
  commission_gratuite_jusqu DATE NULL,                                 -- aucune commission jusqu'à cette date (parrainage)
  sur_mesure      TINYINT(1) NOT NULL DEFAULT 0,
  telephone_modifie_le DATETIME NULL,                                  -- dernier changement du numéro de paiement (retraits bloqués 48 h)                       -- la boutique accepte les commandes sur mesure
  offres_actives  TINYINT(1) NOT NULL DEFAULT 1,                       -- accepte les propositions de prix (« faire une offre »)
  verifiee        TINYINT(1) NOT NULL DEFAULT 0,                       -- badge « boutique vérifiée » (attribué par l'administrateur)
  mode_simple     TINYINT(1) NOT NULL DEFAULT 0,                       -- espace vendeur simplifié (photo, prix, voix, grands boutons)
  created_at      TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  INDEX idx_boutiques_statut (statut)
) ENGINE=InnoDB;

-- ---------- Catalogue ----------
CREATE TABLE categories (
  id         SMALLINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  parent_id  SMALLINT UNSIGNED NULL,
  nom        VARCHAR(100) NOT NULL,
  slug       VARCHAR(120) NOT NULL UNIQUE,
  icone      VARCHAR(40) NULL,                         -- classe Phosphor
  option_type VARCHAR(20) NULL,                    -- taille | pointure | taille_enfant : le vendeur peut indiquer les tailles
  position   SMALLINT NOT NULL DEFAULT 0,
  FOREIGN KEY (parent_id) REFERENCES categories(id) ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE boutique_regions (
  boutique_id INT UNSIGNED NOT NULL,
  region      VARCHAR(60)  NOT NULL,                  -- sans ligne : la boutique livre dans toutes les régions
  PRIMARY KEY (boutique_id, region),
  FOREIGN KEY (boutique_id) REFERENCES boutiques(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE boutique_frais (
  boutique_id INT UNSIGNED NOT NULL,
  zone_id     SMALLINT UNSIGNED NOT NULL,
  frais       INT UNSIGNED NOT NULL,                    -- frais de livraison fixés par la boutique pour cette zone
  delai_jours TINYINT UNSIGNED NULL,                    -- délai annoncé par la boutique (sinon celui de la zone)
  PRIMARY KEY (boutique_id, zone_id),
  FOREIGN KEY (boutique_id) REFERENCES boutiques(id) ON DELETE CASCADE,
  FOREIGN KEY (zone_id) REFERENCES zones_livraison(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE produits (
  id            INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  boutique_id   INT UNSIGNED NOT NULL,
  categorie_id  SMALLINT UNSIGNED NOT NULL,
  nom           VARCHAR(190) NOT NULL,
  slug          VARCHAR(210) NOT NULL UNIQUE,
  description   TEXT NULL,
  prix          INT UNSIGNED NOT NULL,
  prix_barre    INT UNSIGNED NULL,                     -- ancien prix (promo)
  stock         INT UNSIGNED NOT NULL DEFAULT 0,
  reserve_client_id INT UNSIGNED NULL,                          -- produit réservé à un client (devis sur mesure accepté) : invisible dans le catalogue
  video_url     VARCHAR(255) NULL,                              -- lien vers une vidéo du produit (TikTok, YouTube, Instagram, Facebook)
  voix_chemin VARCHAR(255) NULL,                   -- description vocale (uploads/voix/…)
  option_type VARCHAR(20) NULL,                    -- tailles / pointures proposées (voir produit_variantes)
  statut        ENUM('brouillon','publie','archive') NOT NULL DEFAULT 'brouillon',
  note_moyenne  DECIMAL(2,1) NOT NULL DEFAULT 0,
  nb_avis       INT UNSIGNED NOT NULL DEFAULT 0,
  created_at    TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (boutique_id)  REFERENCES boutiques(id)  ON DELETE CASCADE,
  FOREIGN KEY (categorie_id) REFERENCES categories(id),
  INDEX idx_produits_liste (statut, categorie_id),
  INDEX idx_produits_recents (statut, created_at),           -- tri « récents » (migration 034)
  INDEX idx_produits_prix (statut, prix),
  INDEX idx_produits_populaires (statut, nb_avis),
  FULLTEXT idx_produits_recherche (nom, description)
) ENGINE=InnoDB;

CREATE TABLE offres (
  id           INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  produit_id   INT UNSIGNED NOT NULL,
  boutique_id  INT UNSIGNED NOT NULL,
  client_id    INT UNSIGNED NOT NULL,
  quantite     TINYINT UNSIGNED NOT NULL DEFAULT 1,
  prix_initial INT UNSIGNED NOT NULL,                 -- prix affiché du produit au moment de l'offre
  prix_propose INT UNSIGNED NOT NULL,                 -- prix unitaire proposé par le client
  contre_prix  INT UNSIGNED NULL,                     -- contre-proposition du vendeur
  prix_final   INT UNSIGNED NULL,                     -- prix unitaire convenu (offre acceptée)
  statut       ENUM('en_attente','contre','acceptee','refusee','utilisee','annulee') NOT NULL DEFAULT 'en_attente',
  expire_le    DATETIME NOT NULL,
  created_at   TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_offres_boutique (boutique_id, statut),
  INDEX idx_offres_client (client_id, statut),
  FOREIGN KEY (produit_id)  REFERENCES produits(id)  ON DELETE CASCADE,
  FOREIGN KEY (boutique_id) REFERENCES boutiques(id) ON DELETE CASCADE,
  FOREIGN KEY (client_id)   REFERENCES users(id)     ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE demandes_mesure (
  id             INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  reference      VARCHAR(20) NOT NULL UNIQUE,                -- ex : SM-9F3A1C2B
  boutique_id    INT UNSIGNED NOT NULL,
  client_id      INT UNSIGNED NOT NULL,
  description    TEXT NOT NULL,
  mesures        TEXT NULL,
  budget         INT UNSIGNED NULL,
  date_souhaitee DATE NULL,
  statut         ENUM('envoyee','devis','acceptee','refusee','annulee') NOT NULL DEFAULT 'envoyee',
  prix           INT UNSIGNED NULL,
  delai_jours    SMALLINT UNSIGNED NULL,
  reponse        TEXT NULL,
  produit_id     INT UNSIGNED NULL,
  created_at     TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_dm_boutique (boutique_id, statut),
  INDEX idx_dm_client (client_id, statut),
  FOREIGN KEY (boutique_id) REFERENCES boutiques(id) ON DELETE CASCADE,
  FOREIGN KEY (client_id)   REFERENCES users(id)     ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE messages_support (
  id          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  reference   VARCHAR(20) NOT NULL UNIQUE,                 -- ex : AIDE-9F3A1C2B
  user_id     INT UNSIGNED NULL,                           -- vide pour un visiteur non connecté
  nom         VARCHAR(120) NOT NULL,
  email       VARCHAR(190) NOT NULL,
  telephone   VARCHAR(20) NULL,
  sujet       ENUM('commande','paiement','compte','boutique','technique','autre') NOT NULL,
  commande_ref VARCHAR(20) NULL,
  message     TEXT NOT NULL,
  statut      ENUM('nouveau','en_cours','resolu') NOT NULL DEFAULT 'nouveau',
  reponse     TEXT NULL,
  repondu_le  DATETIME NULL,
  jeton_hash  CHAR(64) NULL,                               -- lien secret de suivi (visiteur sans compte), empreinte seulement
  created_at  TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_support_statut (statut, created_at),
  INDEX idx_support_user (user_id),
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE messages_support_reponses (
  id          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  message_id  INT UNSIGNED NOT NULL,
  auteur      ENUM('client','equipe') NOT NULL,
  user_id     INT UNSIGNED NULL,
  texte       TEXT NOT NULL,
  created_at  TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_reponses_message (message_id, id),
  FOREIGN KEY (message_id) REFERENCES messages_support(id) ON DELETE CASCADE,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE produit_variantes (
  id          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  produit_id  INT UNSIGNED NOT NULL,
  libelle     VARCHAR(20) NOT NULL,                 -- « M », « 42 », « 2 ans »
  stock       INT UNSIGNED NOT NULL DEFAULT 0,
  position    TINYINT UNSIGNED NOT NULL DEFAULT 0,
  UNIQUE KEY uniq_variante (produit_id, libelle),
  FOREIGN KEY (produit_id) REFERENCES produits(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE produit_images (
  id          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  produit_id  INT UNSIGNED NOT NULL,
  chemin      VARCHAR(255) NOT NULL,
  position    TINYINT UNSIGNED NOT NULL DEFAULT 0,
  FOREIGN KEY (produit_id) REFERENCES produits(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------- Panier (clients connectés ; invités = session PHP) ----------
CREATE TABLE paniers (
  id         INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id    INT UNSIGNED NOT NULL UNIQUE,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE panier_lignes (
  panier_id   INT UNSIGNED NOT NULL,
  produit_id  INT UNSIGNED NOT NULL,
  quantite    SMALLINT UNSIGNED NOT NULL DEFAULT 1,
  PRIMARY KEY (panier_id, produit_id),
  FOREIGN KEY (panier_id)  REFERENCES paniers(id)  ON DELETE CASCADE,
  FOREIGN KEY (produit_id) REFERENCES produits(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE favoris (
  user_id    INT UNSIGNED NOT NULL,
  produit_id INT UNSIGNED NOT NULL,
  PRIMARY KEY (user_id, produit_id),
  FOREIGN KEY (user_id)    REFERENCES users(id)    ON DELETE CASCADE,
  FOREIGN KEY (produit_id) REFERENCES produits(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------- Commandes ----------
-- 1 commande client = 1 paiement, éclatée en 1 sous-commande par boutique.
CREATE TABLE commandes (
  id               INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  reference        VARCHAR(20) NOT NULL UNIQUE,        -- ex: JND-260106-A4F2
  client_id        INT UNSIGNED NOT NULL,
  -- copie de l'adresse au moment de l'achat (l'adresse d'origine peut changer)
  livraison_nom       VARCHAR(120) NOT NULL,
  livraison_telephone VARCHAR(20)  NOT NULL,
  livraison_zone      VARCHAR(100) NOT NULL,
  livraison_adresse   VARCHAR(255) NOT NULL,
  sous_total       INT UNSIGNED NOT NULL,
  frais_livraison  INT UNSIGNED NOT NULL DEFAULT 0,
  frais_service    INT UNSIGNED NOT NULL DEFAULT 0,          -- frais de paiement sécurisé payés par le client (pour Jënd)
  cadeau          TINYINT(1) NOT NULL DEFAULT 0,          -- commande pour un proche : ni prix ni facture dans le colis
  message_cadeau  VARCHAR(300) NULL,                       -- petit mot joint au cadeau
  livraison_lat   DECIMAL(9,6) NULL,                       -- point GPS de livraison (« Ma position »)
  livraison_lng   DECIMAL(9,6) NULL,
  position_jeton  CHAR(32) NULL UNIQUE,                    -- lien envoyé au proche pour qu'il partage sa position (commande cadeau)
  source          VARCHAR(30) NULL,                        -- d'où vient le client (whatsapp, statut, lien, affiche, tiktok…)
  total            INT UNSIGNED NOT NULL,
  methode_paiement ENUM('wave','orange_money','free_money','carte','livraison') NOT NULL,
  statut_paiement  ENUM('en_attente','acompte','paye','echoue','rembourse') NOT NULL DEFAULT 'en_attente',   -- « acompte » : acompte payé, reste dû à la livraison
  acompte          INT UNSIGNED NOT NULL DEFAULT 0,          -- acompte demandé pour un paiement à la livraison
  acompte_methode  ENUM('wave','orange_money','free_money','carte') NULL,
  statut           ENUM('en_attente','confirmee','annulee','terminee') NOT NULL DEFAULT 'en_attente',
  created_at       TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (client_id) REFERENCES users(id),
  INDEX idx_commandes_client (client_id, created_at)
) ENGINE=InnoDB;

CREATE TABLE commande_boutiques (
  id            INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  commande_id   INT UNSIGNED NOT NULL,
  boutique_id   INT UNSIGNED NOT NULL,
  sous_total    INT UNSIGNED NOT NULL,
  commission    INT UNSIGNED NOT NULL,                 -- part de Jënd
  net_vendeur   INT UNSIGNED NOT NULL,                 -- sous_total - commission
  statut        ENUM('a_preparer','expediee','livree','annulee','retournee') NOT NULL DEFAULT 'a_preparer',
  numero_suivi  VARCHAR(60) NULL,
  code_livraison CHAR(4) NULL,                         -- donné par le client à la réception, saisi par le livreur (ou le vendeur s'il livre lui-même)
  livre_par     ENUM('vendeur','jend') NOT NULL DEFAULT 'jend',   -- mode de livraison au moment de la commande
  acompte_part  INT UNSIGNED NOT NULL DEFAULT 0,       -- part de l'acompte qui correspond à cette livraison
  acompte_acquis TINYINT(1) NOT NULL DEFAULT 0,        -- 1 : client absent ou refus, acompte conservé
  frais_part    INT UNSIGNED NOT NULL DEFAULT 0,       -- part du frais de livraison qui revient au vendeur quand il livre lui-même
  livreur_id    INT UNSIGNED NULL,                     -- livreur affecté par l'administrateur
  affecte_le    DATETIME NULL,
  recupere_le   DATETIME NULL,                         -- colis récupéré chez le vendeur
  en_route_le   DATETIME NULL,
  livre_le      DATETIME NULL,                         -- livraison confirmée (code du client saisi)
  vendeur_prevenu_le DATETIME NULL,                    -- vendeur prévenu (e-mail + notification) de la commande à préparer
  relance_le    DATETIME NULL,                         -- relancé par l'équipe Jënd (WhatsApp / appel)
  FOREIGN KEY (livreur_id) REFERENCES users(id) ON DELETE SET NULL,
  INDEX idx_cb_livreur (livreur_id, statut),
  FOREIGN KEY (commande_id) REFERENCES commandes(id) ON DELETE CASCADE,
  FOREIGN KEY (boutique_id) REFERENCES boutiques(id),
  INDEX idx_cb_boutique (boutique_id, statut)
) ENGINE=InnoDB;

CREATE TABLE commande_lignes (
  id                    INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  commande_boutique_id  INT UNSIGNED NOT NULL,
  produit_id            INT UNSIGNED NULL,             -- NULL si produit supprimé plus tard
  nom                   VARCHAR(190) NOT NULL,         -- copie au moment de l'achat
  prix_unitaire         INT UNSIGNED NOT NULL,
  quantite              SMALLINT UNSIGNED NOT NULL,
  variante_id           INT UNSIGNED NULL,             -- taille / pointure choisie
  variante_libelle      VARCHAR(40) NULL,              -- copie : « Taille : M »
  FOREIGN KEY (commande_boutique_id) REFERENCES commande_boutiques(id) ON DELETE CASCADE,
  FOREIGN KEY (produit_id) REFERENCES produits(id) ON DELETE SET NULL,
  CONSTRAINT fk_ligne_variante FOREIGN KEY (variante_id) REFERENCES produit_variantes(id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- ---------- Litiges (« Signaler un problème ») ----------
CREATE TABLE litiges (
  id                    INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  reference             VARCHAR(20) NOT NULL UNIQUE,                 -- ex : LIT-9F3A1C2B
  commande_boutique_id  INT UNSIGNED NOT NULL,                       -- la livraison concernée (un seul litige par livraison)
  client_id             INT UNSIGNED NOT NULL,
  motif                 ENUM('non_recu','non_conforme','defectueux','endommage','autre') NOT NULL,
  description           TEXT NOT NULL,
  statut                ENUM('ouvert','en_cours','rembourse','remplace','rejete') NOT NULL DEFAULT 'ouvert',
  reponse_admin         TEXT NULL,                                   -- dernière réponse de l'équipe, lue par le client
  montant_rembourse     INT UNSIGNED NOT NULL DEFAULT 0,
  a_charge_vendeur      TINYINT(1) NOT NULL DEFAULT 1,               -- 1 : le remboursement est retenu sur les gains du vendeur
  rembourse_le          DATETIME NULL,                               -- l'argent a réellement été renvoyé au client
  repondu_le            DATETIME NULL,                               -- première réponse de l'équipe (délai promis : 48 h)
  resolu_le             DATETIME NULL,
  created_at            TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uniq_litige_livraison (commande_boutique_id),
  INDEX idx_litiges_statut (statut, created_at),
  FOREIGN KEY (commande_boutique_id) REFERENCES commande_boutiques(id) ON DELETE CASCADE,
  FOREIGN KEY (client_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE litige_photos (
  id         INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  litige_id  INT UNSIGNED NOT NULL,
  chemin     VARCHAR(255) NOT NULL,                                  -- storage/litiges/… (jamais accessible directement : servi après contrôle d'accès)
  FOREIGN KEY (litige_id) REFERENCES litiges(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- Chronologie d'un signalement (affichée au client et à l'équipe)
CREATE TABLE litige_evenements (
  id         INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  litige_id  INT UNSIGNED NOT NULL,
  type       VARCHAR(30) NOT NULL,                   -- cree, message_client, examen, message_equipe, rembourse, remplace, rejete, argent_envoye
  auteur     ENUM('client','equipe','systeme') NOT NULL,
  texte      TEXT NULL,
  montant    INT UNSIGNED NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_litige_evenements (litige_id, created_at),
  FOREIGN KEY (litige_id) REFERENCES litiges(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------- Spécial fêtes ----------
CREATE TABLE fetes (
  id           INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  nom          VARCHAR(80) NOT NULL,
  slug         VARCHAR(90) NOT NULL UNIQUE,
  date_fete    DATE NOT NULL,
  date_limite  DATE NULL,                              -- « commandez avant le … pour être livré à temps »
  vitrine_des  DATE NOT NULL,                          -- début de l'affichage de la vitrine
  texte        VARCHAR(300) NULL,
  actif        TINYINT(1) NOT NULL DEFAULT 1,
  created_at   TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_fetes_dates (actif, vitrine_des, date_fete)
) ENGINE=InnoDB;

CREATE TABLE produit_fetes (
  produit_id INT UNSIGNED NOT NULL,
  fete_id    INT UNSIGNED NOT NULL,
  remise_pct TINYINT UNSIGNED NOT NULL DEFAULT 0,       -- promotion de fête choisie par le vendeur (0 = aucune)
  PRIMARY KEY (produit_id, fete_id),
  INDEX idx_produit_fetes_fete (fete_id),
  FOREIGN KEY (produit_id) REFERENCES produits(id) ON DELETE CASCADE,
  FOREIGN KEY (fete_id) REFERENCES fetes(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------- Dépense du mois, alertes ----------
CREATE TABLE depenses (
  id               INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  client_id        INT UNSIGNED NOT NULL,
  nom              VARCHAR(80) NOT NULL,
  jour             TINYINT UNSIGNED NOT NULL,          -- jour du mois du rappel (1 à 28)
  livraison_nom    VARCHAR(120) NOT NULL,
  livraison_telephone VARCHAR(20) NOT NULL,
  zone_id          SMALLINT UNSIGNED NOT NULL,
  adresse          VARCHAR(255) NOT NULL,
  cadeau           TINYINT(1) NOT NULL DEFAULT 0,
  actif            TINYINT(1) NOT NULL DEFAULT 1,
  prochain_rappel  DATE NOT NULL,
  dernier_rappel   DATE NULL,
  created_at       TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_depenses_rappel (actif, prochain_rappel),
  FOREIGN KEY (client_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (zone_id) REFERENCES zones_livraison(id)
) ENGINE=InnoDB;

CREATE TABLE depense_lignes (
  depense_id  INT UNSIGNED NOT NULL,
  produit_id  INT UNSIGNED NOT NULL,
  quantite    TINYINT UNSIGNED NOT NULL,
  variante_id INT UNSIGNED NOT NULL DEFAULT 0,       -- taille choisie (0 : produit sans taille)
  PRIMARY KEY (depense_id, produit_id, variante_id),
  FOREIGN KEY (depense_id) REFERENCES depenses(id) ON DELETE CASCADE,
  FOREIGN KEY (produit_id) REFERENCES produits(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE reglements_commission (
  id          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  boutique_id INT UNSIGNED NOT NULL,
  montant     INT UNSIGNED NOT NULL,
  methode     VARCHAR(20) NOT NULL,                   -- wave | orange_money | free_money | especes | autre
  reference   VARCHAR(60) NULL,                       -- référence du transfert reçu
  admin_id    INT UNSIGNED NULL,
  created_at  TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (boutique_id) REFERENCES boutiques(id) ON DELETE CASCADE,
  FOREIGN KEY (admin_id) REFERENCES users(id) ON DELETE SET NULL,
  INDEX idx_reglements_boutique (boutique_id, created_at)
) ENGINE=InnoDB;

CREATE TABLE push_abonnements (
  id            INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id       INT UNSIGNED NOT NULL,
  endpoint      VARCHAR(600) NOT NULL,                  -- adresse fournie par le navigateur (Google, Mozilla, Apple…)
  endpoint_hash CHAR(64) NOT NULL UNIQUE,
  cle_p256dh    VARCHAR(120) NOT NULL,                  -- clés de chiffrement du téléphone
  cle_auth      VARCHAR(40) NOT NULL,
  appareil      VARCHAR(120) NULL,
  dernier_envoi DATETIME NULL,
  created_at    TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  INDEX idx_push_user (user_id)
) ENGINE=InnoDB;

CREATE TABLE alertes_produit (
  id          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id     INT UNSIGNED NOT NULL,
  produit_id  INT UNSIGNED NOT NULL,
  prix_vu     INT UNSIGNED NOT NULL,                 -- prix au moment de la demande (on prévient s'il baisse)
  epuise      TINYINT(1) NOT NULL DEFAULT 0,         -- 1 : produit épuisé au moment de la demande (on prévient à son retour)
  created_at  TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uniq_alerte (user_id, produit_id),
  INDEX idx_alertes_produit (produit_id),
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (produit_id) REFERENCES produits(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------- Paiements ----------
CREATE TABLE paiements (
  id              INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  commande_id     INT UNSIGNED NOT NULL,
  methode         ENUM('wave','orange_money','free_money','carte','livraison') NOT NULL,
  montant         INT UNSIGNED NOT NULL,
  statut          ENUM('initie','reussi','echoue','rembourse') NOT NULL DEFAULT 'initie',
  fournisseur     VARCHAR(30) NULL,                    -- paydunya, cinetpay…
  reference_externe VARCHAR(100) NULL UNIQUE,          -- id transaction du fournisseur
  reponse_brute   JSON NULL,                           -- webhook reçu (audit)
  created_at      TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (commande_id) REFERENCES commandes(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- Versements aux vendeurs
CREATE TABLE retraits (
  id           INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  boutique_id  INT UNSIGNED NOT NULL,
  montant      INT UNSIGNED NOT NULL,
  methode      ENUM('wave','orange_money','free_money','virement') NOT NULL,
  statut       ENUM('demande','paye','refuse') NOT NULL DEFAULT 'demande',
  automatique  TINYINT(1) NOT NULL DEFAULT 0,          -- 1 : préparé par le versement à date fixe
  paye_le      DATETIME NULL,                          -- date où l'argent a été envoyé
  reference_transfert VARCHAR(60) NULL,                -- référence Wave / Orange Money donnée au vendeur
  created_at   TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (boutique_id) REFERENCES boutiques(id)
) ENGINE=InnoDB;

-- ---------- Avis ----------
CREATE TABLE avis (
  id          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  produit_id  INT UNSIGNED NOT NULL,
  user_id     INT UNSIGNED NOT NULL,
  note        TINYINT UNSIGNED NOT NULL,
  commentaire TEXT NULL,
  created_at  TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uniq_avis (produit_id, user_id),          -- 1 avis par client et produit
  CONSTRAINT chk_note CHECK (note BETWEEN 1 AND 5),
  FOREIGN KEY (produit_id) REFERENCES produits(id) ON DELETE CASCADE,
  FOREIGN KEY (user_id)    REFERENCES users(id)    ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------- Réinitialisation de mot de passe (étape 7) ----------
-- On ne stocke que l'empreinte (SHA-256) du jeton : un vol de la base ne permet pas de réinitialiser un compte.
CREATE TABLE reinitialisations_mdp (
  id          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id     INT UNSIGNED NOT NULL,
  token_hash  CHAR(64) NOT NULL,
  expire_le   DATETIME NOT NULL,
  created_at  TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uniq_token (token_hash),
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------- Sécurité (étape 10) : limitation des tentatives + journal admin ----------
CREATE TABLE limites (
  id          BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  cle         VARCHAR(120) NOT NULL,                 -- ex : login:ip:203.0.113.5
  created_at  TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_limites (cle, created_at)
) ENGINE=InnoDB;

CREATE TABLE journal_admin (
  id          BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  admin_id    INT UNSIGNED NULL,
  action      VARCHAR(60) NOT NULL,
  detail      VARCHAR(255) NULL,
  ip          VARCHAR(45) NULL,
  created_at  TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_journal_date (created_at),
  FOREIGN KEY (admin_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- ---------- Double authentification (étape 10 bis) ----------
CREATE TABLE codes_secours (
  id          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id     INT UNSIGNED NOT NULL,
  code_hash   CHAR(64) NOT NULL,                       -- empreinte SHA-256 : le code lui-même n'est jamais stocké
  utilise     TINYINT(1) NOT NULL DEFAULT 0,
  created_at  TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_codes_user (user_id),
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;
