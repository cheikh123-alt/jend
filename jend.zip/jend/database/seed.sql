-- Données de départ : zones de livraison (quartiers de Touba + principales villes du Sénégal ; frais et délais ajustables depuis /admin/zones) et catégories
USE jend;

INSERT INTO zones_livraison (nom, region, frais, delai_jours) VALUES
('Touba — Centre / Grande Mosquée', 'Touba', 500, 1),
('Darou Marnane', 'Touba', 500, 1),
('Darou Khoudoss', 'Touba', 700, 1),
('Darou Miname', 'Touba', 700, 1),
('Touba Bogo', 'Touba', 700, 1),
('Gouye Mbind', 'Touba', 1000, 1),
('Ndamatou', 'Touba', 1000, 1),
('Khaïra', 'Touba', 1000, 2),
('Touba Ouadiour', 'Touba', 1500, 2),
('Dakar Plateau / Médina', 'Dakar', 1500, 1),
('Dakar — Almadies / Ngor / Yoff', 'Dakar', 2000, 1),
('Guédiawaye / Pikine / Parcelles', 'Dakar', 2000, 2),
('Rufisque / Bargny', 'Dakar', 2500, 2),
('Thiès', 'Thiès', 3500, 3),
('Mbour / Saly', 'Thiès', 3500, 3),
('Diourbel', 'Diourbel', 3500, 3),
('Mbacké', 'Diourbel', 3000, 2),
('Kaolack', 'Kaolack', 4500, 4),
('Saint-Louis', 'Saint-Louis', 4500, 4),
('Louga', 'Louga', 4500, 4),
('Fatick', 'Fatick', 4500, 4),
('Kaffrine', 'Kaffrine', 5000, 4),
('Tambacounda', 'Tambacounda', 7000, 6),
('Kolda', 'Kolda', 6500, 5),
('Sédhiou', 'Sédhiou', 6500, 5),
('Matam', 'Matam', 7000, 6),
('Kédougou', 'Kédougou', 8000, 7),
('Ziguinchor', 'Ziguinchor', 6000, 5);

INSERT INTO categories (nom, slug, icone, position) VALUES
('Mode & Wax',    'mode-wax',     'ph-t-shirt',          1),
('Électronique',  'electronique', 'ph-device-mobile',    2),
('Maison',        'maison',       'ph-armchair',         3),
('Beauté',        'beaute',       'ph-flower-lotus',     4),
('Alimentation',  'alimentation', 'ph-orange-slice',     5),
('Artisanat',     'artisanat',    'ph-paint-brush-broad',6),
('Enfants',       'enfants',      'ph-baby',             7),
('Auto & Moto',   'auto-moto',    'ph-car',              8),
('Services',      'services',     'ph-wrench',           9);

-- Sous-catégories d'exemple
INSERT INTO categories (parent_id, nom, slug, position)
SELECT id, 'Tissus wax', 'tissus-wax', 1 FROM categories WHERE slug = 'mode-wax';
INSERT INTO categories (parent_id, nom, slug, position)
SELECT id, 'Boubous & tenues', 'boubous-tenues', 2 FROM categories WHERE slug = 'mode-wax';
INSERT INTO categories (parent_id, nom, slug, position)
SELECT id, 'Téléphones', 'telephones', 1 FROM categories WHERE slug = 'electronique';
INSERT INTO categories (parent_id, nom, slug, position)
SELECT id, 'Accessoires', 'accessoires-electronique', 2 FROM categories WHERE slug = 'electronique';

-- Tailles proposées aux vendeurs (Administration → Catégories pour changer)
UPDATE categories SET option_type = 'taille' WHERE slug IN ('mode-wax', 'boubous-tenues');
UPDATE categories SET option_type = 'taille_enfant' WHERE slug = 'enfants';

-- Le compte administrateur est créé par le script d'installation PHP (étape 4),
-- afin que le mot de passe soit haché avec password_hash() et jamais écrit ici.
