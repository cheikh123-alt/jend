// Service worker de Jënd : il rend l'appli livreur installable sur l'écran d'accueil,
// et affiche les notifications des vendeurs (« Nouvelle commande ») même quand le site est fermé.
// Volontairement AUCUN cache de pages : elles contiennent des données de clients (adresses, téléphones)
// et le téléphone d'un livreur peut être partagé. Hors connexion, on affiche seulement un message clair.
self.addEventListener('install', () => self.skipWaiting());
self.addEventListener('activate', e => e.waitUntil(self.clients.claim()));
self.addEventListener('fetch', e => {
  if (e.request.mode !== 'navigate') return;
  e.respondWith(fetch(e.request).catch(() => new Response(
    '<!doctype html><html lang="fr"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Hors connexion</title>' +
    '<body style="font-family:system-ui;background:#FAF3E7;color:#1B1410;display:grid;place-items:center;min-height:100vh;margin:0;text-align:center;padding:24px">' +
    '<div><h1 style="color:#C2471F">Pas de connexion</h1><p>Vérifiez vos données mobiles ou le Wi-Fi, puis rouvrez l\'appli.</p></div></body></html>',
    { status: 503, headers: { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store' } })));
});

// Notification reçue (envoyée chiffrée par le serveur : includes/push.php)
self.addEventListener('push', e => {
  let d = {};
  try { d = e.data ? e.data.json() : {}; } catch (_) { d = { texte: e.data ? e.data.text() : '' }; }
  e.waitUntil(self.registration.showNotification(d.titre || 'Jënd', {
    body: d.texte || '',
    icon: 'assets/img/pwa-192.png',
    badge: 'assets/img/pwa-192.png',
    tag: d.tag || 'jend',
    renotify: true,
    requireInteraction: true,
    vibrate: [300, 120, 300, 120, 300],
    data: { url: d.url || './' }
  }));
});

// Toucher la notification : ouvre (ou ramène au premier plan) la page indiquée, seulement sur ce site
self.addEventListener('notificationclick', e => {
  e.notification.close();
  let cible = new URL(e.notification.data && e.notification.data.url || './', self.registration.scope);
  if (cible.origin !== self.location.origin) cible = new URL('./', self.registration.scope);
  e.waitUntil(self.clients.matchAll({ type: 'window', includeUncontrolled: true }).then(fen => {
    for (const f of fen) { if (f.url === cible.href && 'focus' in f) return f.focus(); }
    return self.clients.openWindow(cible.href);
  }));
});

