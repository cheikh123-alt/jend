-- Jënd : installation pour hébergement sans terminal — généré le 2026-10-09 17:04
-- À importer dans une base VIDE (phpMyAdmin → Importer). Aucune instruction de création ou de suppression de base.

SET NAMES utf8mb4;

CREATE TABLE users (
  id            INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  nom           VARCHAR(120) NOT NULL,
  email         VARCHAR(190) NOT NULL UNIQUE,
  telephone     VARCHAR(20)  NULL,
  mot_de_passe  VARCHAR(255) NOT NULL,                 -- password_hash() PHP
  role          ENUM('client','vendeur','admin','livreur') NOT NULL DEFAULT 'client',
  actif         TINYINT(1) NOT NULL DEFAULT 1,
  mdp_provisoire   TINYINT(1) NOT NULL DEFAULT 0,       -- 1 : mot de passe donné par l'admin, à changer à la première connexion
  session_version  INT UNSIGNED NOT NULL DEFAULT 1,     -- +1 à chaque changement de mot de passe : coupe les autres sessions
  totp_secret      VARCHAR(255) NULL,                   -- secret 2FA, CHIFFRÉ
  totp_actif       TINYINT(1) NOT NULL DEFAULT 0,
  totp_dernier_pas BIGINT UNSIGNED NOT NULL DEFAULT 0,  -- empêche de réutiliser le même code deux fois
  created_at    TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_users_role (role)
) ENGINE=InnoDB;

CREATE TABLE zones_livraison (
  id          SMALLINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  nom         VARCHAR(100) NOT NULL,                   -- ex: Dakar Plateau
  region      VARCHAR(60)  NOT NULL,
  frais       INT UNSIGNED NOT NULL DEFAULT 0,
  delai_jours TINYINT UNSIGNED NOT NULL DEFAULT 2,
  actif       TINYINT(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB;

CREATE TABLE parametres (
  cle         VARCHAR(60) PRIMARY KEY,
  valeur      VARCHAR(255) NOT NULL,
  updated_at  TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE livreurs (
  user_id     INT UNSIGNED PRIMARY KEY,
  zone_id     SMALLINT UNSIGNED NULL,                    -- zone habituelle (NULL = toutes les zones)
  disponible  TINYINT(1) NOT NULL DEFAULT 0,             -- le livreur se déclare disponible / indisponible
  created_at  TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (zone_id) REFERENCES zones_livraison(id) ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE caisse_livreurs (
  id          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  livreur_id  INT UNSIGNED NOT NULL,
  montant     INT UNSIGNED NOT NULL,
  note        VARCHAR(190) NULL,
  admin_id    INT UNSIGNED NULL,
  created_at  TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_caisse_livreur (livreur_id),
  FOREIGN KEY (livreur_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (admin_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE adresses (
  id         INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id    INT UNSIGNED NOT NULL,
  libelle    VARCHAR(60) NOT NULL DEFAULT 'Domicile',
  zone_id    SMALLINT UNSIGNED NOT NULL,
  adresse    VARCHAR(255) NOT NULL,
  telephone  VARCHAR(20) NOT NULL,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (zone_id) REFERENCES zones_livraison(id)
) ENGINE=InnoDB;

CREATE TABLE boutiques (
  id              INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id         INT UNSIGNED NOT NULL UNIQUE,        -- 1 boutique par vendeur
  nom             VARCHAR(120) NOT NULL,
  slug            VARCHAR(140) NOT NULL UNIQUE,
  description     TEXT NULL,
  logo            VARCHAR(255) NULL,
  telephone_paiement VARCHAR(20) NULL,                 -- Wave / Orange Money du vendeur
  statut          ENUM('en_attente','active','suspendue') NOT NULL DEFAULT 'en_attente',
  commission_pct  DECIMAL(4,2) NOT NULL DEFAULT 8.00,  -- % prélevé par Jënd
  livraison_par   ENUM('vendeur','jend') NOT NULL DEFAULT 'vendeur',   -- qui livre : le vendeur (frais pour lui) ou les livreurs Jënd
  created_at      TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  INDEX idx_boutiques_statut (statut)
) ENGINE=InnoDB;

CREATE TABLE categories (
  id         SMALLINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  parent_id  SMALLINT UNSIGNED NULL,
  nom        VARCHAR(100) NOT NULL,
  slug       VARCHAR(120) NOT NULL UNIQUE,
  icone      VARCHAR(40) NULL,                         -- classe Phosphor
  position   SMALLINT NOT NULL DEFAULT 0,
  FOREIGN KEY (parent_id) REFERENCES categories(id) ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE produits (
  id            INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  boutique_id   INT UNSIGNED NOT NULL,
  categorie_id  SMALLINT UNSIGNED NOT NULL,
  nom           VARCHAR(190) NOT NULL,
  slug          VARCHAR(210) NOT NULL UNIQUE,
  description   TEXT NULL,
  prix          INT UNSIGNED NOT NULL,
  prix_barre    INT UNSIGNED NULL,                     -- ancien prix (promo)
  stock         INT UNSIGNED NOT NULL DEFAULT 0,
  statut        ENUM('brouillon','publie','archive') NOT NULL DEFAULT 'brouillon',
  note_moyenne  DECIMAL(2,1) NOT NULL DEFAULT 0,
  nb_avis       INT UNSIGNED NOT NULL DEFAULT 0,
  created_at    TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (boutique_id)  REFERENCES boutiques(id)  ON DELETE CASCADE,
  FOREIGN KEY (categorie_id) REFERENCES categories(id),
  INDEX idx_produits_liste (statut, categorie_id),
  FULLTEXT idx_produits_recherche (nom, description)
) ENGINE=InnoDB;

CREATE TABLE produit_images (
  id          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  produit_id  INT UNSIGNED NOT NULL,
  chemin      VARCHAR(255) NOT NULL,
  position    TINYINT UNSIGNED NOT NULL DEFAULT 0,
  FOREIGN KEY (produit_id) REFERENCES produits(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE paniers (
  id         INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id    INT UNSIGNED NOT NULL UNIQUE,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE panier_lignes (
  panier_id   INT UNSIGNED NOT NULL,
  produit_id  INT UNSIGNED NOT NULL,
  quantite    SMALLINT UNSIGNED NOT NULL DEFAULT 1,
  PRIMARY KEY (panier_id, produit_id),
  FOREIGN KEY (panier_id)  REFERENCES paniers(id)  ON DELETE CASCADE,
  FOREIGN KEY (produit_id) REFERENCES produits(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE favoris (
  user_id    INT UNSIGNED NOT NULL,
  produit_id INT UNSIGNED NOT NULL,
  PRIMARY KEY (user_id, produit_id),
  FOREIGN KEY (user_id)    REFERENCES users(id)    ON DELETE CASCADE,
  FOREIGN KEY (produit_id) REFERENCES produits(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE commandes (
  id               INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  reference        VARCHAR(20) NOT NULL UNIQUE,        -- ex: JND-260106-A4F2
  client_id        INT UNSIGNED NOT NULL,

  livraison_nom       VARCHAR(120) NOT NULL,
  livraison_telephone VARCHAR(20)  NOT NULL,
  livraison_zone      VARCHAR(100) NOT NULL,
  livraison_adresse   VARCHAR(255) NOT NULL,
  sous_total       INT UNSIGNED NOT NULL,
  frais_livraison  INT UNSIGNED NOT NULL DEFAULT 0,
  total            INT UNSIGNED NOT NULL,
  methode_paiement ENUM('wave','orange_money','free_money','carte','livraison') NOT NULL,
  statut_paiement  ENUM('en_attente','acompte','paye','echoue','rembourse') NOT NULL DEFAULT 'en_attente',   -- « acompte » : acompte payé, reste dû à la livraison
  acompte          INT UNSIGNED NOT NULL DEFAULT 0,          -- acompte demandé pour un paiement à la livraison
  acompte_methode  ENUM('wave','orange_money','free_money','carte') NULL,
  statut           ENUM('en_attente','confirmee','annulee','terminee') NOT NULL DEFAULT 'en_attente',
  created_at       TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (client_id) REFERENCES users(id),
  INDEX idx_commandes_client (client_id, created_at)
) ENGINE=InnoDB;

CREATE TABLE commande_boutiques (
  id            INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  commande_id   INT UNSIGNED NOT NULL,
  boutique_id   INT UNSIGNED NOT NULL,
  sous_total    INT UNSIGNED NOT NULL,
  commission    INT UNSIGNED NOT NULL,                 -- part de Jënd
  net_vendeur   INT UNSIGNED NOT NULL,                 -- sous_total - commission
  statut        ENUM('a_preparer','expediee','livree','annulee','retournee') NOT NULL DEFAULT 'a_preparer',
  numero_suivi  VARCHAR(60) NULL,
  code_livraison CHAR(4) NULL,                         -- donné par le client à la réception, saisi par le livreur (ou le vendeur s'il livre lui-même)
  livre_par     ENUM('vendeur','jend') NOT NULL DEFAULT 'jend',   -- mode de livraison au moment de la commande
  acompte_part  INT UNSIGNED NOT NULL DEFAULT 0,       -- part de l'acompte qui correspond à cette livraison
  acompte_acquis TINYINT(1) NOT NULL DEFAULT 0,        -- 1 : client absent ou refus, acompte conservé
  frais_part    INT UNSIGNED NOT NULL DEFAULT 0,       -- part du frais de livraison qui revient au vendeur quand il livre lui-même
  livreur_id    INT UNSIGNED NULL,                     -- livreur affecté par l'administrateur
  affecte_le    DATETIME NULL,
  recupere_le   DATETIME NULL,                         -- colis récupéré chez le vendeur
  en_route_le   DATETIME NULL,
  livre_le      DATETIME NULL,                         -- livraison confirmée (code du client saisi)
  FOREIGN KEY (livreur_id) REFERENCES users(id) ON DELETE SET NULL,
  INDEX idx_cb_livreur (livreur_id, statut),
  FOREIGN KEY (commande_id) REFERENCES commandes(id) ON DELETE CASCADE,
  FOREIGN KEY (boutique_id) REFERENCES boutiques(id),
  INDEX idx_cb_boutique (boutique_id, statut)
) ENGINE=InnoDB;

CREATE TABLE commande_lignes (
  id                    INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  commande_boutique_id  INT UNSIGNED NOT NULL,
  produit_id            INT UNSIGNED NULL,             -- NULL si produit supprimé plus tard
  nom                   VARCHAR(190) NOT NULL,         -- copie au moment de l'achat
  prix_unitaire         INT UNSIGNED NOT NULL,
  quantite              SMALLINT UNSIGNED NOT NULL,
  FOREIGN KEY (commande_boutique_id) REFERENCES commande_boutiques(id) ON DELETE CASCADE,
  FOREIGN KEY (produit_id) REFERENCES produits(id) ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE litiges (
  id                    INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  reference             VARCHAR(20) NOT NULL UNIQUE,                 -- ex : LIT-9F3A1C2B
  commande_boutique_id  INT UNSIGNED NOT NULL,                       -- la livraison concernée (un seul litige par livraison)
  client_id             INT UNSIGNED NOT NULL,
  motif                 ENUM('non_recu','non_conforme','defectueux','endommage','autre') NOT NULL,
  description           TEXT NOT NULL,
  statut                ENUM('ouvert','en_cours','rembourse','remplace','rejete') NOT NULL DEFAULT 'ouvert',
  reponse_admin         TEXT NULL,                                   -- dernière réponse de l'équipe, lue par le client
  montant_rembourse     INT UNSIGNED NOT NULL DEFAULT 0,
  a_charge_vendeur      TINYINT(1) NOT NULL DEFAULT 1,               -- 1 : le remboursement est retenu sur les gains du vendeur
  rembourse_le          DATETIME NULL,                               -- l'argent a réellement été renvoyé au client
  repondu_le            DATETIME NULL,                               -- première réponse de l'équipe (délai promis : 48 h)
  resolu_le             DATETIME NULL,
  created_at            TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uniq_litige_livraison (commande_boutique_id),
  INDEX idx_litiges_statut (statut, created_at),
  FOREIGN KEY (commande_boutique_id) REFERENCES commande_boutiques(id) ON DELETE CASCADE,
  FOREIGN KEY (client_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE litige_photos (
  id         INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  litige_id  INT UNSIGNED NOT NULL,
  chemin     VARCHAR(255) NOT NULL,                                  -- storage/litiges/… (jamais accessible directement : servi après contrôle d'accès)
  FOREIGN KEY (litige_id) REFERENCES litiges(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE paiements (
  id              INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  commande_id     INT UNSIGNED NOT NULL,
  methode         ENUM('wave','orange_money','free_money','carte','livraison') NOT NULL,
  montant         INT UNSIGNED NOT NULL,
  statut          ENUM('initie','reussi','echoue','rembourse') NOT NULL DEFAULT 'initie',
  fournisseur     VARCHAR(30) NULL,                    -- paydunya, cinetpay…
  reference_externe VARCHAR(100) NULL UNIQUE,          -- id transaction du fournisseur
  reponse_brute   JSON NULL,                           -- webhook reçu (audit)
  created_at      TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (commande_id) REFERENCES commandes(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE retraits (
  id           INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  boutique_id  INT UNSIGNED NOT NULL,
  montant      INT UNSIGNED NOT NULL,
  methode      ENUM('wave','orange_money','free_money','virement') NOT NULL,
  statut       ENUM('demande','paye','refuse') NOT NULL DEFAULT 'demande',
  created_at   TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (boutique_id) REFERENCES boutiques(id)
) ENGINE=InnoDB;

CREATE TABLE avis (
  id          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  produit_id  INT UNSIGNED NOT NULL,
  user_id     INT UNSIGNED NOT NULL,
  note        TINYINT UNSIGNED NOT NULL,
  commentaire TEXT NULL,
  created_at  TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uniq_avis (produit_id, user_id),          -- 1 avis par client et produit
  CONSTRAINT chk_note CHECK (note BETWEEN 1 AND 5),
  FOREIGN KEY (produit_id) REFERENCES produits(id) ON DELETE CASCADE,
  FOREIGN KEY (user_id)    REFERENCES users(id)    ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE reinitialisations_mdp (
  id          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id     INT UNSIGNED NOT NULL,
  token_hash  CHAR(64) NOT NULL,
  expire_le   DATETIME NOT NULL,
  created_at  TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uniq_token (token_hash),
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE limites (
  id          BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  cle         VARCHAR(120) NOT NULL,                 -- ex : login:ip:203.0.113.5
  created_at  TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_limites (cle, created_at)
) ENGINE=InnoDB;

CREATE TABLE journal_admin (
  id          BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  admin_id    INT UNSIGNED NULL,
  action      VARCHAR(60) NOT NULL,
  detail      VARCHAR(255) NULL,
  ip          VARCHAR(45) NULL,
  created_at  TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_journal_date (created_at),
  FOREIGN KEY (admin_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE codes_secours (
  id          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id     INT UNSIGNED NOT NULL,
  code_hash   CHAR(64) NOT NULL,                       -- empreinte SHA-256 : le code lui-même n'est jamais stocké
  utilise     TINYINT(1) NOT NULL DEFAULT 0,
  created_at  TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_codes_user (user_id),
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

INSERT INTO zones_livraison (nom, region, frais, delai_jours) VALUES
('Touba — Centre / Grande Mosquée', 'Touba', 500, 1),
('Darou Marnane', 'Touba', 500, 1),
('Darou Khoudoss', 'Touba', 700, 1),
('Darou Miname', 'Touba', 700, 1),
('Touba Bogo', 'Touba', 700, 1),
('Gouye Mbind', 'Touba', 1000, 1),
('Ndamatou', 'Touba', 1000, 1),
('Khaïra', 'Touba', 1000, 2),
('Touba Ouadiour', 'Touba', 1500, 2);

INSERT INTO categories (nom, slug, icone, position) VALUES
('Mode & Wax',    'mode-wax',     'ph-t-shirt',          1),
('Électronique',  'electronique', 'ph-device-mobile',    2),
('Maison',        'maison',       'ph-armchair',         3),
('Beauté',        'beaute',       'ph-flower-lotus',     4),
('Alimentation',  'alimentation', 'ph-orange-slice',     5),
('Artisanat',     'artisanat',    'ph-paint-brush-broad',6),
('Enfants',       'enfants',      'ph-baby',             7),
('Auto & Moto',   'auto-moto',    'ph-car',              8),
('Services',      'services',     'ph-wrench',           9);

INSERT INTO categories (parent_id, nom, slug, position)
SELECT id, 'Tissus wax', 'tissus-wax', 1 FROM categories WHERE slug = 'mode-wax';

INSERT INTO categories (parent_id, nom, slug, position)
SELECT id, 'Boubous & tenues', 'boubous-tenues', 2 FROM categories WHERE slug = 'mode-wax';

INSERT INTO categories (parent_id, nom, slug, position)
SELECT id, 'Téléphones', 'telephones', 1 FROM categories WHERE slug = 'electronique';

INSERT INTO categories (parent_id, nom, slug, position)
SELECT id, 'Accessoires', 'accessoires-electronique', 2 FROM categories WHERE slug = 'electronique';

INSERT INTO users (nom, email, mot_de_passe, role) VALUES ('Cheikh Gueye', 'cheikhgueye1515@gmail.com', '$2y$10$N.l6AoGl../3w0CBua1i6.wQAY0bgTTtqbuLYzCh6A8pIp1UGDQsC', 'admin');
