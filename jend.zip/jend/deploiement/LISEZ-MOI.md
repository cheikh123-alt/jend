# Dossier « deploiement » — configurations de mise en ligne

Dossier **privé** : il n'est jamais accessible depuis Internet (`.htaccess` : accès refusé) et n'est jamais mis dans les archives du site.
Ton site local (XAMPP) ne l'utilise pas : il garde son propre `.env`.

| Fichier | Pour quoi |
|---|---|
| `infinityfree.env` | La configuration du site de démonstration **https://jend.free.je** (mode test, paiement simulé). |
| `production.env` | La configuration du **vrai site** (hébergement payant). Les clés secrètes sont déjà générées ; les lignes `A_REMPLIR` sont à compléter le moment venu. |

## Mettre en ligne (une seule commande)
Dans le Terminal :

```
cd /Applications/XAMPP/xamppfiles/htdocs/jend && sh scripts/preparer-mise-en-ligne.sh infinityfree
```

ou, pour le vrai site, une fois `production.env` rempli :

```
cd /Applications/XAMPP/xamppfiles/htdocs/jend && sh scripts/preparer-mise-en-ligne.sh production
```

Le script vérifie la configuration (il refuse s'il manque quelque chose et dit quoi), puis crée sur le Bureau, dans `salone/`,
**`jend-infinityfree-pret.zip`** ou **`jend-production-pret.zip`** : le site à jour + `config.env`, à décompresser directement dans le dossier
public de l'hébergeur (`htdocs/`, `public_html/`…).

## À retenir
- Ces fichiers contiennent tes mots de passe et clés : ne les envoie à personne, ne les colle pas dans une conversation.
- **Garde une copie de `production.env` ailleurs** (clé USB, gestionnaire de mots de passe) : sans son `APP_KEY`, les doubles authentifications ne fonctionneraient plus.
- Supprime l'archive `…-pret.zip` après chaque mise en ligne.
- Si tu ajoutes une table ou une colonne en local, la base en ligne devra recevoir la migration correspondante (phpMyAdmin → Importer).
