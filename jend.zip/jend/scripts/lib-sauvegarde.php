<?php
declare(strict_types=1);

/**
 * Chiffrement des fichiers de sauvegarde : AES-256-GCM par blocs de 4 Mo.
 *
 * Format : "JENDBK01" | sel (16 octets) | itérations (4 octets) | puis, pour chaque bloc :
 *          drapeau « dernier bloc » (1) | longueur (4) | IV (12) | étiquette d'authentification (16) | données chiffrées
 * Chaque bloc est authentifié avec son NUMÉRO et son drapeau : réordonner des blocs, en retirer ou tronquer la fin
 * est détecté au déchiffrement. La clé est dérivée de la phrase secrète (PBKDF2-SHA256, 200 000 itérations).
 */
const SAUV_MAGIE = 'JENDBK01';
const SAUV_BLOC = 4 * 1024 * 1024;
const SAUV_ITERATIONS = 200000;

function sauv_cle(string $phrase, string $sel, int $iterations): string
{
    return hash_pbkdf2('sha256', $phrase, $sel, $iterations, 32, true);
}

function sauv_lire_exactement($fp, int $n): string
{
    $tampon = '';
    while (strlen($tampon) < $n && !feof($fp)) {
        $morceau = fread($fp, $n - strlen($tampon));
        if ($morceau === false || $morceau === '') {
            break;
        }
        $tampon .= $morceau;
    }
    return $tampon;
}

function fichier_chiffrer(string $source, string $destination, string $phrase): void
{
    if (strlen($phrase) < 16) {
        throw new RuntimeException('La phrase secrète doit faire au moins 16 caractères.');
    }
    $in = fopen($source, 'rb');
    $out = fopen($destination, 'xb');
    if (!$in || !$out) {
        throw new RuntimeException('Impossible d\'ouvrir les fichiers.');
    }
    $sel = random_bytes(16);
    $cle = sauv_cle($phrase, $sel, SAUV_ITERATIONS);
    fwrite($out, SAUV_MAGIE . $sel . pack('N', SAUV_ITERATIONS));

    $index = 0;
    $courant = sauv_lire_exactement($in, SAUV_BLOC);
    while (true) {
        $suivant = strlen($courant) === SAUV_BLOC ? sauv_lire_exactement($in, SAUV_BLOC) : '';
        $dernier = $suivant === '' ? 1 : 0;                    // on sait si le bloc est le dernier en lisant le suivant
        $iv = random_bytes(12);
        $tag = '';
        $ct = openssl_encrypt($courant, 'aes-256-gcm', $cle, OPENSSL_RAW_DATA, $iv, $tag, SAUV_MAGIE . pack('J', $index) . chr($dernier), 16);
        if ($ct === false) {
            throw new RuntimeException('Chiffrement impossible.');
        }
        fwrite($out, chr($dernier) . pack('N', strlen($ct)) . $iv . $tag . $ct);
        if ($dernier) {
            break;
        }
        $courant = $suivant;
        $index++;
    }
    fclose($in);
    fclose($out);
}

/** @throws RuntimeException si la phrase est fausse OU si le fichier a été modifié, réordonné ou tronqué */
function fichier_dechiffrer(string $source, string $destination, string $phrase): void
{
    $in = fopen($source, 'rb');
    if (!$in) {
        throw new RuntimeException('Fichier illisible.');
    }
    $entete = sauv_lire_exactement($in, 8 + 16 + 4);
    if (strlen($entete) !== 28 || substr($entete, 0, 8) !== SAUV_MAGIE) {
        throw new RuntimeException('Ce fichier n\'est pas une sauvegarde chiffrée Jënd.');
    }
    $iterations = unpack('N', substr($entete, 24, 4))[1];
    if ($iterations < 100000 || $iterations > 5000000) {
        throw new RuntimeException('En-tête invalide.');
    }
    $cle = sauv_cle($phrase, substr($entete, 8, 16), $iterations);
    $out = fopen($destination, 'xb');
    if (!$out) {
        throw new RuntimeException('Le fichier de sortie existe déjà ou n\'est pas inscriptible.');
    }
    $index = 0;
    $termine = false;
    try {
        while (!$termine) {
            $h = sauv_lire_exactement($in, 1 + 4 + 12 + 16);
            if (strlen($h) !== 33) {
                throw new RuntimeException('Fichier tronqué (fin de sauvegarde manquante).');
            }
            $dernier = ord($h[0]);
            $longueur = unpack('N', substr($h, 1, 4))[1];
            if ($longueur > SAUV_BLOC + 16) {
                throw new RuntimeException('Bloc invalide.');
            }
            $ct = sauv_lire_exactement($in, $longueur);
            if (strlen($ct) !== $longueur) {
                throw new RuntimeException('Fichier tronqué.');
            }
            $clair = openssl_decrypt($ct, 'aes-256-gcm', $cle, OPENSSL_RAW_DATA, substr($h, 5, 12), substr($h, 17, 16), SAUV_MAGIE . pack('J', $index) . chr($dernier));
            if ($clair === false) {
                throw new RuntimeException('Phrase secrète incorrecte, ou fichier modifié/corrompu.');
            }
            fwrite($out, $clair);
            $termine = $dernier === 1;
            $index++;
        }
        $reste = fread($in, 1);
        if ($reste !== '' && $reste !== false) {
            throw new RuntimeException('Données inattendues après la fin de la sauvegarde.');
        }
    } catch (Throwable $e) {
        fclose($out);
        @unlink($destination);              // jamais de fichier partiel
        throw $e;
    } finally {
        fclose($in);
    }
    fclose($out);
}
