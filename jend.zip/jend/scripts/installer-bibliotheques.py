#!/usr/bin/env python3
"""
Télécharge UNE FOIS les bibliothèques JavaScript/CSS/polices du site et les range dans assets/vendor/,
pour que le site ne dépende plus d'aucun service externe (CDN) : on sert nos propres copies vérifiées.

    python3 scripts/installer-bibliotheques.py

Garanties :
  • seuls les domaines de la liste blanche ci-dessous sont contactés, en HTTPS ;
  • les versions sont ÉPINGLÉES (celles trouvées au moment de l'installation sont notées dans LICENCES.md) ;
  • quand c'est possible, chaque fichier est téléchargé depuis DEUX sources indépendantes (ex : cdnjs ET jsDelivr)
    et l'installation est annulée si leur contenu diffère ;
  • les empreintes SHA-256 de tous les fichiers sont écrites dans assets/vendor/SHA256SUMS : le vérificateur
    (scripts/verifier-production.php) détecte ainsi toute modification d'une bibliothèque sur le serveur.
Pour mettre une bibliothèque à jour : changez sa version ci-dessous, relancez, testez (python3 tests/run_all.py).
"""
import hashlib, re, sys, urllib.parse, urllib.request
from datetime import date
from pathlib import Path

RACINE = Path(__file__).resolve().parent.parent
VENDOR = RACINE / "assets" / "vendor"
DOMAINES = {"cdnjs.cloudflare.com", "unpkg.com", "cdn.jsdelivr.net", "api.fontshare.com", "cdn.fontshare.com"}
UA = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36"
TAILLE_MAX = 3 * 1024 * 1024

GSAP = "3.12.5"
PHOSPHOR = "2.1.2"
# Fontshare ne renvoie que la 1re famille quand on en demande plusieurs d'un coup : on les demande une par une.
# (Satoshi n'existe qu'en 300, 400, 500, 700 et 900 : la graisse 800 n'existe pas.)
FONTSHARE = [
    "https://api.fontshare.com/v2/css?f[]=clash-display@500,600,700&display=swap",
    "https://api.fontshare.com/v2/css?f[]=satoshi@400,500,700&display=swap",
]


def telecharger(url):
    p = urllib.parse.urlparse("https:" + url if url.startswith("//") else url)
    if p.scheme != "https" or p.hostname not in DOMAINES:
        sys.exit(f"REFUS : adresse hors liste blanche : {url}")
    req = urllib.request.Request(p.geturl(), headers={"User-Agent": UA, "Accept": "*/*"})
    with urllib.request.urlopen(req, timeout=40) as r:
        final = urllib.parse.urlparse(r.geturl())
        if final.hostname not in DOMAINES:
            sys.exit(f"REFUS : redirection vers un domaine non autorisé : {r.geturl()}")
        donnees = r.read(TAILLE_MAX + 1)
        if len(donnees) > TAILLE_MAX:
            sys.exit(f"REFUS : fichier trop gros : {url}")
        return donnees, r.geturl()


def sha(donnees):
    return hashlib.sha256(donnees).hexdigest()


ecrits = {}          # chemin relatif -> contenu
notes = []           # lignes de LICENCES.md


def poser(rel, donnees):
    ecrits[rel] = donnees


def recouper(nom, principal, miroir):
    """Télécharge depuis deux sources indépendantes et exige un contenu identique."""
    a, _ = telecharger(principal)
    b, _ = telecharger(miroir)
    if a != b:
        sys.exit(f"ÉCHEC DU RECOUPEMENT pour {nom} : {principal} et {miroir} ne renvoient pas le même fichier. Installation annulée.")
    print(f"  ✔ {nom} : identique sur 2 sources ({len(a)} octets)")
    return a


def version_npm(paquet, chemin):
    """Version exacte actuellement servie par unpkg pour un paquet non épinglé."""
    _, finale = telecharger(f"https://unpkg.com/{paquet}/{chemin}")
    m = re.search(r"/" + re.escape(paquet) + r"@([0-9][^/]*)/", finale)
    if not m:
        sys.exit(f"Version introuvable pour {paquet} ({finale})")
    return m.group(1)


print("== GSAP (animations) ==")
poser("js/gsap.min.js", recouper("gsap.min.js", f"https://cdnjs.cloudflare.com/ajax/libs/gsap/{GSAP}/gsap.min.js", f"https://cdn.jsdelivr.net/npm/gsap@{GSAP}/dist/gsap.min.js"))
poser("js/ScrollTrigger.min.js", recouper("ScrollTrigger.min.js", f"https://cdnjs.cloudflare.com/ajax/libs/gsap/{GSAP}/ScrollTrigger.min.js", f"https://cdn.jsdelivr.net/npm/gsap@{GSAP}/dist/ScrollTrigger.min.js"))
notes.append(f"| GSAP + ScrollTrigger | {GSAP} | Licence « GreenSock Standard (no charge) » — usage commercial permis ; lisez les conditions sur gsap.com/standard-license | cdnjs.cloudflare.com/ajax/libs/gsap/{GSAP}/ (recoupé avec jsDelivr npm gsap@{GSAP}) |")

print("== Lenis (défilement fluide) ==")
v = version_npm("lenis", "dist/lenis.min.js")
poser("js/lenis.min.js", recouper(f"lenis@{v}", f"https://unpkg.com/lenis@{v}/dist/lenis.min.js", f"https://cdn.jsdelivr.net/npm/lenis@{v}/dist/lenis.min.js"))
notes.append(f"| Lenis | {v} | MIT | unpkg.com/lenis@{v}/dist/lenis.min.js (recoupé avec jsDelivr) |")

print("== Splitting.js (texte animé) ==")
v = version_npm("splitting", "dist/splitting.min.js")
poser("js/splitting.min.js", recouper(f"splitting.min.js@{v}", f"https://unpkg.com/splitting@{v}/dist/splitting.min.js", f"https://cdn.jsdelivr.net/npm/splitting@{v}/dist/splitting.min.js"))
poser("css/splitting.css", recouper(f"splitting.css@{v}", f"https://unpkg.com/splitting@{v}/dist/splitting.css", f"https://cdn.jsdelivr.net/npm/splitting@{v}/dist/splitting.css"))
notes.append(f"| Splitting.js | {v} | MIT | unpkg.com/splitting@{v}/dist/ (recoupé avec jsDelivr) |")

print("== Icônes Phosphor (poids « regular » et « fill » : les seuls utilisés) ==")
for poids, famille in (("regular", "Phosphor"), ("fill", "Phosphor-Fill")):
    base = f"https://cdn.jsdelivr.net/npm/@phosphor-icons/web@{PHOSPHOR}/src/{poids}/"
    css_a, _ = telecharger(base + "style.css")
    css_b, _ = telecharger(f"https://unpkg.com/@phosphor-icons/web@{PHOSPHOR}/src/{poids}/style.css")
    if css_a != css_b:
        sys.exit(f"ÉCHEC DU RECOUPEMENT : style.css Phosphor {poids}")
    texte = css_a.decode("utf-8")
    m = re.search(r"url\((['\"]?)([^)'\"]+\.woff2)[^)]*\1\)\s*format\((['\"])woff2\3\)", texte)
    if not m:
        sys.exit(f"Police woff2 introuvable dans le CSS Phosphor {poids}")
    nom_woff2 = m.group(2).split("/")[-1].split("?")[0]
    police = recouper(nom_woff2, base + nom_woff2, f"https://unpkg.com/@phosphor-icons/web@{PHOSPHOR}/src/{poids}/{nom_woff2}")
    poser(f"fonts/{nom_woff2}", police)
    # on ne garde que le format woff2 (supporté par tous les navigateurs actuels) et on pointe vers notre copie
    texte = re.sub(r"src:\s*url\([^;]*\)\s*;", f'src: url("../fonts/{nom_woff2}") format("woff2");', texte, count=1) if re.search(r"src:\s*url\([^;]*\)\s*;", texte) else texte
    if "../fonts/" not in texte:
        sys.exit(f"Réécriture du CSS Phosphor {poids} impossible (format inattendu)")
    poser(f"css/phosphor-{poids}.css", texte.encode("utf-8"))
    print(f"  ✔ phosphor-{poids}.css réécrit → ../fonts/{nom_woff2}")
notes.append(f"| Phosphor Icons (web) | {PHOSPHOR} | MIT | jsdelivr.net/npm/@phosphor-icons/web@{PHOSPHOR}/src/{{regular,fill}}/ (recoupé avec unpkg) |")

print("== Polices Clash Display et Satoshi (Fontshare) ==")
blocs = []
for adresse in FONTSHARE:
    css, _ = telecharger(adresse)
    blocs += re.findall(r"@font-face\s*\{[^}]*\}", css.decode("utf-8"))
if len(blocs) != 6:
    sys.exit(f"Réponse Fontshare inattendue ({len(blocs)} polices trouvées, 6 attendues : Clash Display 500/600/700 et Satoshi 400/500/700)")
sortie = []
for bloc in blocs:
    fam = re.search(r"font-family:\s*['\"]?([^;'\"]+)", bloc).group(1).strip()
    poids = re.search(r"font-weight:\s*(\d+)", bloc).group(1)
    url = re.search(r"url\(['\"]?([^)'\"]+\.woff2[^)'\"]*)['\"]?\)", bloc)
    if not url:
        sys.exit(f"woff2 introuvable pour {fam} {poids}")
    police, _ = telecharger(url.group(1))
    nom = f"{re.sub('[^a-z0-9]+', '-', fam.lower()).strip('-')}-{poids}.woff2"
    poser(f"fonts/{nom}", police)
    nouveau = re.sub(r"src:\s*[^;]*;", f'src: url("../fonts/{nom}") format("woff2");', bloc, count=1)
    sortie.append(nouveau)
    print(f"  ✔ {fam} {poids} → fonts/{nom} ({len(police)} octets)")
poser("css/fontshare.css", ("\n".join(sortie) + "\n").encode("utf-8"))
notes.append("| Clash Display, Satoshi | (version Fontshare du jour) | Licence « ITF Free Font License » (Indian Type Foundry / Fontshare) — vérifiez les conditions sur fontshare.com | api.fontshare.com (CSS) et cdn.fontshare.com (fichiers woff2) |")

# ------------------------ écriture sur disque ------------------------
for rel, donnees in ecrits.items():
    f = VENDOR / rel
    f.parent.mkdir(parents=True, exist_ok=True)
    f.write_bytes(donnees)
sommes = "".join(f"{sha(d)}  {rel}\n" for rel, d in sorted(ecrits.items()))
(VENDOR / "SHA256SUMS").write_text(sommes)
(VENDOR / "LICENCES.md").write_text(
    "# Bibliothèques tierces hébergées sur ce site\n\n"
    f"Installées le {date.today().isoformat()} par `scripts/installer-bibliotheques.py`. "
    "Les empreintes SHA-256 de chaque fichier sont dans `SHA256SUMS` (contrôlées par `scripts/verifier-production.php`).\n\n"
    "| Bibliothèque | Version | Licence | Source |\n|---|---|---|---|\n" + "\n".join(notes) + "\n\n"
    "Respectez les conditions de chaque licence (mentions, usage). Ne modifiez jamais ces fichiers à la main : relancez le script.\n")
print(f"\n✔ {len(ecrits)} fichiers installés dans assets/vendor/ ({sum(len(d) for d in ecrits.values()) // 1024} Ko). Empreintes : assets/vendor/SHA256SUMS")
