<?php
declare(strict_types=1);

/**
 * Contrôle « prêt pour la production ».
 *     php scripts/verifier-production.php                          (vérifie le .env et la base)
 *     php scripts/verifier-production.php --url=https://site.sn    (vérifie aussi ce que voit un visiteur sur Internet)
 *     php scripts/verifier-production.php --env=/chemin/.env       (vérifie un autre fichier de configuration)
 *
 * ✘ = bloquant (ne PAS ouvrir au public) · ⚠ = à traiter · ✔ = bon.   Code de sortie 1 s'il y a au moins un ✘.
 */
if (PHP_SAPI !== 'cli') {
    http_response_code(403);
    exit('Interdit.');
}

$racine = dirname(__DIR__);
$url = null;
foreach (array_slice($argv, 1) as $a) {
    if (str_starts_with($a, '--env=')) {
        putenv('JEND_ENV_FILE=' . substr($a, 6));
    } elseif (str_starts_with($a, '--url=')) {
        $url = rtrim(substr($a, 6), '/');
    }
}
require $racine . '/includes/env.php';

$bloquants = 0;
$alertes = 0;
function ok(string $t): void { echo "  ✔ $t\n"; }
function ko(string $t, string $aide = ''): void { global $bloquants; $bloquants++; echo "  ✘ $t" . ($aide ? "\n      → $aide" : '') . "\n"; }
function warn(string $t, string $aide = ''): void { global $alertes; $alertes++; echo "  ⚠ $t" . ($aide ? "\n      → $aide" : '') . "\n"; }
function verifier(bool $cond, string $bon, string $mauvais, string $aide = '', bool $bloquant = true): void
{
    if ($cond) { ok($bon); } elseif ($bloquant) { ko($mauvais, $aide); } else { warn($mauvais, $aide); }
}

echo "\n== Configuration ==\n";
$modeTest = env('APP_ENV') === 'test';
if ($modeTest) {
    warn('APP_ENV = test : SITE DE TEST (paiements simulés, indexation interdite, bandeau « SITE DE TEST »)', 'Parfait pour essayer en ligne ; passez à APP_ENV=prod pour le lancement réel.');
} else {
    verifier(env('APP_ENV') === 'prod', 'APP_ENV = prod', 'APP_ENV doit valoir « prod » (actuellement : ' . (env('APP_ENV') ?? 'absent') . ')', 'En dev, les erreurs techniques sont affichées aux visiteurs.');
}
$appUrl = (string) env('APP_URL', '');
verifier(str_starts_with($appUrl, 'https://') && substr($appUrl, -1) !== '/' && filter_var($appUrl, FILTER_VALIDATE_URL) !== false, 'APP_URL en https', 'APP_URL doit être une adresse https:// valide, sans « / » final', 'Elle sert à forcer le HTTPS et aux liens des e-mails.');
if ($modeTest) {
    ok('Paiement simulé : normal sur un site de test');
} else {
    verifier(!in_array(env('PAIEMENT_FOURNISSEUR'), [null, '', 'simulation'], true), 'Fournisseur de paiement réel : ' . env('PAIEMENT_FOURNISSEUR'), 'PAIEMENT_FOURNISSEUR est vide ou « simulation »', 'Aucun paiement réel n\'est possible en simulation.');
}
$fournisseurs = array_map('trim', explode(',', strtolower((string) env('PAIEMENT_FOURNISSEUR', ''))));     // « paydunya », « paytech » ou les deux
if (in_array('paydunya', $fournisseurs, true)) {
    $cles = array_filter(['PAYDUNYA_MASTER_KEY', 'PAYDUNYA_PRIVATE_KEY', 'PAYDUNYA_TOKEN'], fn ($k) => trim((string) env($k, '')) === '');
    verifier(!$cles, 'PayDunya : les 3 clés sont renseignées', 'PayDunya : clé(s) manquante(s) : ' . implode(', ', $cles), 'Tableau de bord PayDunya → Intégrez notre API → votre application : copiez les clés (test OU live) dans .env.');
    verifier(in_array(strtolower(trim((string) env('PAYDUNYA_MODE', 'test'))), ['live', 'prod', 'production'], true) || $modeTest, 'PayDunya en mode LIVE (vrais paiements)', 'PAYDUNYA_MODE n\'est pas « live » : les paiements restent des TESTS', 'Mettez PAYDUNYA_MODE=live avec les clés « live » quand vous ouvrez le site au public.', false);
    verifier(env('PAYDUNYA_API_BASE', '') === '', 'PAYDUNYA_API_BASE absent (réservé aux tests locaux)', 'PAYDUNYA_API_BASE est défini : supprimez-le', 'Cette variable ne sert qu\'aux tests en local.');
}
if (in_array('paytech', $fournisseurs, true)) {
    $cles = array_filter(['PAYTECH_API_KEY', 'PAYTECH_API_SECRET'], fn ($k) => trim((string) env($k, '')) === '');
    verifier(!$cles, 'PayTech : les 2 clés sont renseignées', 'PayTech : clé(s) manquante(s) : ' . implode(', ', $cles), 'Espace marchand PayTech → paramètres API : copiez API_KEY et API_SECRET dans config.env.');
    verifier(in_array(strtolower(trim((string) env('PAYTECH_ENV', 'test'))), ['prod', 'production', 'live'], true) || $modeTest, 'PayTech en mode PROD (vrais paiements)', 'PAYTECH_ENV n\'est pas « prod » : les paiements restent des TESTS', 'Mettez PAYTECH_ENV=prod une fois votre compte activé par PayTech (contact@paytech.sn).', false);
    verifier(env('PAYTECH_API_BASE', '') === '', 'PAYTECH_API_BASE absent (réservé aux tests locaux)', 'PAYTECH_API_BASE est défini : supprimez-le', 'Cette variable ne sert qu\'aux tests en local.');
}
if (in_array('unitech', $fournisseurs, true)) {
    verifier(trim((string) env('UNITECH_API_KEY', '')) !== '', 'UnitechPay : clé API renseignée', 'UnitechPay : UNITECH_API_KEY manquant', 'Tableau de bord UnitechPay → Paramètres → API : copiez la clé dans config.env.');
    verifier(env('UNITECH_API_BASE', '') === '', 'UNITECH_API_BASE absent (réservé aux tests locaux)', 'UNITECH_API_BASE est défini : supprimez-le', 'Cette variable ne sert qu\'aux tests en local.');
}
$secret = (string) env('PAIEMENT_SECRET', '');
verifier(array_intersect(['paydunya', 'paytech', 'unitech'], $fournisseurs) !== [] || strlen($secret) >= 32, 'PAIEMENT_SECRET défini (' . strlen($secret) . ' caractères)', 'PAIEMENT_SECRET manquant ou trop court (32 caractères minimum)', 'php -r "echo bin2hex(random_bytes(32));"');
verifier(!in_array(env('DB_USER'), ['root', '', null], true), 'Utilisateur de base dédié (' . env('DB_USER') . ')', 'DB_USER est « root » ou vide', 'Créez un utilisateur MySQL réservé à Jënd, limité à cette base.', false);
verifier((string) env('DB_PASS', '') !== '', 'Mot de passe de base défini', 'DB_PASS est vide', 'Une base sans mot de passe est accessible à tous sur le serveur.');
$driver = (string) (env('MAIL_DRIVER') ?: 'mail');
verifier($driver !== 'log', "E-mails réels (MAIL_DRIVER = $driver)", 'MAIL_DRIVER = log : aucun e-mail ne sera envoyé', 'Sans e-mails, « mot de passe oublié » ne fonctionne pas.');
if ($driver === 'smtp') {
    verifier(env('SMTP_HOST') && env('SMTP_USER') && env('SMTP_PASS'), 'SMTP configuré (hôte, identifiant, mot de passe)', 'SMTP incomplet (SMTP_HOST / SMTP_USER / SMTP_PASS)');
    verifier(in_array(env('SMTP_SECURE') ?: 'tls', ['tls', 'ssl'], true), 'SMTP chiffré (' . (env('SMTP_SECURE') ?: 'tls') . ')', 'SMTP_SECURE doit être tls ou ssl');
}
$manquants = [];
foreach (['SOCIETE_NOM', 'SOCIETE_FORME', 'SOCIETE_ADRESSE', 'SOCIETE_NINEA', 'SOCIETE_RCCM', 'SOCIETE_TEL', 'CONTACT_EMAIL', 'SOCIETE_DIRECTEUR', 'HEBERGEUR'] as $v) {
    if (trim((string) env($v, '')) === '') {
        $manquants[] = $v;
    }
}
if ($manquants) {
    warn('Mentions légales incomplètes : ' . implode(', ', $manquants), 'Renseignez-les dans .env : elles s\'affichent dans « Mentions légales », « Contact » et les conditions (obligation légale).');
} else {
    ok('Mentions légales renseignées (exploitant, NINEA, RCCM, contact)');
}
verifier(strlen((string) env('APP_KEY', '')) >= 32, 'APP_KEY défini (chiffre les secrets 2FA)', 'APP_KEY manquant ou trop court (32 caractères minimum)', 'php -r "echo bin2hex(random_bytes(32));"   ⚠ Ne le perdez pas : sans lui, les 2FA enregistrées sont inutilisables.');
verifier((string) (env('ADMIN_2FA_OBLIGATOIRE') ?? '1') !== '0', '2FA obligatoire pour l\'administrateur', 'ADMIN_2FA_OBLIGATOIRE=0 : l\'admin peut se connecter sans double authentification', 'Retirez cette ligne (défaut : obligatoire en production).');
verifier(strlen((string) env('BACKUP_PASSPHRASE', '')) >= 16, 'Sauvegardes chiffrées (BACKUP_PASSPHRASE)', 'BACKUP_PASSPHRASE non défini : les sauvegardes ne sont pas chiffrées', 'Phrase de 16 caractères minimum, conservée AILLEURS que sur le serveur.', false);
verifier(trim((string) env('ADMIN_IPS', '')) !== '', 'Accès /admin restreint par IP (ADMIN_IPS)', 'Accès /admin ouvert à toutes les adresses IP', 'Si vous avez une adresse IP fixe, listez-la dans ADMIN_IPS (séparée par des virgules) : l\'admin devient invisible pour les autres.', false);
verifier((string) env('ALERT_EMAIL', env('ADMIN_EMAIL', '')) !== '', 'Alertes e-mail configurées', 'Aucune adresse pour les alertes (ALERT_EMAIL ou ADMIN_EMAIL)', 'Vous ne serez pas prévenu des erreurs 500 ni des paiements anormaux.');
verifier((string) env('ADMIN_EMAIL', 'admin@jend.local') !== 'admin@jend.local', 'E-mail administrateur personnalisé', 'ADMIN_EMAIL est encore « admin@jend.local »', 'Utilisez une vraie adresse que vous consultez.', false);
verifier((string) env('BACKUP_DIR', '') !== '', 'BACKUP_DIR défini', 'BACKUP_DIR non défini (sauvegardes dans storage/ par défaut)', 'Préférez un dossier privé hors du dossier public.', false);

echo "\n== Fichiers et serveur ==\n";
verifier(PHP_VERSION_ID >= 80000, 'PHP ' . PHP_VERSION, 'PHP 8.0 minimum requis (version : ' . PHP_VERSION . ')');
foreach (['pdo_mysql', 'gd', 'fileinfo', 'mbstring'] as $ext) {
    verifier(extension_loaded($ext), "Extension PHP $ext", "Extension PHP « $ext » manquante");
}
verifier(!is_file($racine . '/install.php'), 'install.php supprimé', 'install.php est encore présent', 'Supprimez-le après l\'installation (il refuse déjà le web, mais ne le laissez pas).', false);
verifier(!is_dir($racine . '/maquette'), 'Dossier maquette/ supprimé', 'Le dossier maquette/ est encore présent', 'Ce n\'est qu\'une ancienne maquette statique : supprimez-le.', false);
verifier(!is_file($racine . '/.env') || (fileperms($racine . '/.env') & 0007) === 0, '.env non lisible par « les autres » utilisateurs du serveur', '.env est lisible par tous les utilisateurs du serveur', 'chmod 600 .env', false);
verifier(is_writable($racine . '/storage'), 'storage/ accessible en écriture', 'storage/ n\'est pas accessible en écriture');
verifier(is_dir($racine . '/uploads/produits') ? is_writable($racine . '/uploads/produits') : is_writable($racine . '/uploads'), 'uploads/ accessible en écriture', 'uploads/ n\'est pas accessible en écriture');
$sommes = $racine . '/assets/vendor/SHA256SUMS';
if (!is_file($sommes)) {
    ko('assets/vendor/SHA256SUMS manquant : impossible de contrôler les bibliothèques', 'Relancez : python3 scripts/installer-bibliotheques.py');
} else {
    $ecarts = [];
    $nb = 0;
    foreach (file($sommes, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) as $l) {
        [$empreinte, $rel] = preg_split('/\s+/', trim($l), 2) + [1 => ''];
        $nb++;
        $f = $racine . '/assets/vendor/' . $rel;
        if (!is_file($f) || !hash_equals($empreinte, hash_file('sha256', $f))) {
            $ecarts[] = $rel;
        }
    }
    verifier(!$ecarts, "$nb bibliothèques hébergées intactes (empreintes SHA-256 conformes)", 'Bibliothèque(s) MODIFIÉE(S) ou manquante(s) : ' . implode(', ', array_slice($ecarts, 0, 5)), 'Un fichier a été altéré (piratage ?) : réinstallez le site depuis votre archive saine.');
}
verifier(is_file($racine . '/uploads/.htaccess'), 'uploads/.htaccess présent (interdit l\'exécution de scripts)', 'uploads/.htaccess manquant', 'Sans lui, un script déposé dans uploads/ pourrait s\'exécuter.');

echo "\n== Base de données ==\n";
try {
    $pdo = new PDO(sprintf('mysql:host=%s;port=%s;dbname=%s;charset=utf8mb4', env('DB_HOST', '127.0.0.1'), env('DB_PORT', '3306'), env('DB_NAME', 'jend')),
        (string) env('DB_USER', 'root'), (string) env('DB_PASS', ''), [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
    ok('Connexion à la base réussie');
    $n = (int) $pdo->query("SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = DATABASE()")->fetchColumn();
    verifier($n >= 20, "$n tables présentes", "Seulement $n tables (20 attendues)", 'Importez database/schema.sql puis database/seed.sql.');
    $demo = (int) $pdo->query("SELECT COUNT(*) FROM users WHERE email IN ('vendeur@jend.local')")->fetchColumn();
    verifier($demo === 0, 'Aucun compte de démonstration', 'Le compte « vendeur@jend.local » (démo) existe', 'Supprimez-le, ainsi que la boutique « Marché Démo » et ses produits.', false);
    $admins = (int) $pdo->query("SELECT COUNT(*) FROM users WHERE role = 'admin' AND actif = 1")->fetchColumn();
    verifier($admins >= 1, "$admins administrateur(s) actif(s)", 'Aucun administrateur actif');
    $sans2fa = (int) $pdo->query("SELECT COUNT(*) FROM users WHERE role = 'admin' AND actif = 1 AND totp_actif = 0")->fetchColumn();
    verifier($sans2fa === 0, 'Tous les administrateurs ont la double authentification', "$sans2fa administrateur(s) sans double authentification", 'Connectez-vous avec chaque compte admin → Compte → Sécurité → Activer la double authentification.');
    $local = (int) $pdo->query("SELECT COUNT(*) FROM users WHERE email LIKE '%@jend.local'")->fetchColumn();
    verifier($local === 0, 'Aucun compte en @jend.local', "$local compte(s) en @jend.local (adresses de test)", 'Remplacez-les par de vraies adresses ou supprimez-les.', false);
} catch (Throwable $e) {
    ko('Connexion à la base impossible : ' . $e->getMessage(), 'Vérifiez DB_HOST, DB_NAME, DB_USER, DB_PASS.');
}

if ($url !== null) {
    echo "\n== Ce que voit un visiteur sur $url ==\n";
    $ctx = stream_context_create(['http' => ['ignore_errors' => true, 'follow_location' => 0, 'timeout' => 10, 'method' => 'GET'], 'ssl' => ['verify_peer' => true, 'verify_peer_name' => true]]);
    $requete = function (string $adresse) use ($ctx): array {
        $corps = @file_get_contents($adresse, false, $ctx);
        $statut = 0;
        foreach (($http_response_header ?? []) as $h) {
            if (preg_match('#^HTTP/\S+\s+(\d{3})#', $h, $m)) { $statut = (int) $m[1]; }
        }
        return [$statut, $http_response_header ?? [], (string) $corps];
    };
    foreach (['.env', 'includes/db.php', 'pages/accueil.php', 'database/schema.sql', 'storage/', 'scripts/sauvegarde.php', 'tests/lib.py', 'install.php', 'CAHIER_DES_CHARGES.md', 'uploads/produits/'] as $chemin) {
        [$statut] = $requete("$url/$chemin");
        verifier(in_array($statut, [403, 404], true), "/$chemin inaccessible (HTTP $statut)", "/$chemin est ACCESSIBLE depuis Internet (HTTP $statut)", 'Fichier sensible exposé : vérifiez .htaccess / la configuration du serveur (voir DEPLOIEMENT.md).');
    }
    [$statut, $entetes, $corpsAccueil] = $requete("$url/");
    verifier($statut === 200, 'Page d\'accueil accessible (HTTP 200)', "La page d'accueil répond HTTP $statut");
    preg_match_all('#<(?:script|link|img)\b[^>]*\b(?:src|href)=["\'](https?://[^"\']+)#i', (string) $corpsAccueil, $externes);
    $siteHote = parse_url($url, PHP_URL_HOST);
    $etrangers = array_values(array_unique(array_filter(array_map(fn($u) => parse_url($u, PHP_URL_HOST), $externes[1] ?? []), fn($h) => $h && $h !== $siteHote)));
    verifier(!$etrangers, 'Aucune ressource externe (CDN) chargée par la page d\'accueil', 'La page d\'accueil charge des ressources externes : ' . implode(', ', $etrangers), 'Un CDN piraté pourrait injecter un script sur toutes vos pages : hébergez ces fichiers vous-même (assets/vendor/).');
    $liste = strtolower(implode("\n", $entetes));
    verifier(str_contains($liste, 'content-security-policy:'), 'En-tête Content-Security-Policy présent', 'En-tête Content-Security-Policy absent');
    verifier(str_contains($liste, 'x-frame-options:') && str_contains($liste, 'x-content-type-options:'), 'En-têtes anti-clickjacking et nosniff présents', 'En-têtes X-Frame-Options / X-Content-Type-Options absents');
    if (str_starts_with($url, 'https://')) {
        verifier(str_contains($liste, 'strict-transport-security:'), 'HSTS actif', 'En-tête Strict-Transport-Security absent', 'Vérifiez APP_ENV=prod et que PHP voit bien le HTTPS (TRUSTED_PROXY=1 derrière un proxy).');
        [$s, $e] = $requete('http://' . substr($url, 8) . '/');
        $loc = '';
        foreach ($e as $h) { if (stripos($h, 'location:') === 0) { $loc = trim(substr($h, 9)); } }
        verifier(in_array($s, [301, 302, 308], true) && str_starts_with($loc, 'https://'), 'http:// redirige vers https://', 'http:// ne redirige PAS vers https:// (HTTP ' . $s . ')');
    } else {
        warn('Adresse en http:// : impossible de contrôler le HTTPS et le HSTS', 'Relancez avec l\'adresse https:// du site en ligne.');
    }
}

echo "\n──────────────────────────────\n";
echo $bloquants === 0
    ? "✔ Aucun point bloquant" . ($alertes ? " ($alertes avertissement(s) à traiter)" : '') . ".\n"
    : "✘ $bloquants point(s) BLOQUANT(S) : ne pas ouvrir le site au public avant correction" . ($alertes ? " ($alertes avertissement(s) en plus)" : '') . ".\n";
exit($bloquants === 0 ? 0 : 1);
