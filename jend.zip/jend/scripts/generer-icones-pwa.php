<?php
declare(strict_types=1);

/** Génère les icônes de l'application livreur (PNG) avec GD : php scripts/generer-icones-pwa.php */
if (PHP_SAPI !== 'cli') {
    http_response_code(403);
    exit('Interdit.');
}
$dossier = dirname(__DIR__) . '/assets/img';
if (!is_dir($dossier)) {
    mkdir($dossier, 0755, true);
}

function icone(int $t): GdImage
{
    $im = imagecreatetruecolor($t, $t);
    imagealphablending($im, true);
    $terracotta = imagecolorallocate($im, 0xC2, 0x47, 0x1F);
    $creme = imagecolorallocate($im, 0xFA, 0xF3, 0xE7);
    $safran = imagecolorallocate($im, 0xF2, 0xB6, 0x32);
    imagefilledrectangle($im, 0, 0, $t, $t, $terracotta);          // plein cadre : l'icône reste valable en « maskable »
    $s = $t / 100;
    $ep = (int) round(13 * $s);                                    // épaisseur du trait du « J »
    $x = (int) round(56 * $s);                                     // barre verticale
    imagefilledrectangle($im, $x, (int) round(24 * $s), $x + $ep, (int) round(60 * $s), $creme);
    imagefilledrectangle($im, (int) round(40 * $s), (int) round(24 * $s), $x + $ep, (int) round(24 * $s) + $ep, $creme);   // barre du haut
    // crochet du bas : demi-anneau
    $rayon = (int) round(26 * $s);
    $cx = $x + $ep - $rayon;                                       // le crochet se raccorde exactement à la barre verticale
    $cy = (int) round(60 * $s);
    imagefilledarc($im, $cx, $cy, $rayon * 2, $rayon * 2, 0, 180, $creme, IMG_ARC_PIE);
    imagefilledarc($im, $cx, $cy, ($rayon - $ep) * 2, ($rayon - $ep) * 2, 0, 180, $terracotta, IMG_ARC_PIE);
    imagefilledellipse($im, (int) round(82 * $s), (int) round(80 * $s), (int) round(9 * $s), (int) round(9 * $s), $safran);   // point final du logo « Jënd. »
    return $im;
}
foreach (['pwa-192.png' => 192, 'pwa-512.png' => 512, 'apple-touch-icon.png' => 180] as $nom => $t) {
    $im = icone($t);
    imagepng($im, "$dossier/$nom", 9);
    echo "✔ assets/img/$nom ({$t}x{$t})\n";
}
