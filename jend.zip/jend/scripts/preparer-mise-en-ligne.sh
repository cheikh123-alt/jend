#!/bin/sh
# Prépare l'archive À DÉCOMPRESSER DIRECTEMENT dans le dossier public de l'hébergeur (htdocs/, public_html/…) :
# le site + sa configuration (config.env), sans install.php, sans données ni photos de test.
#
#   sh scripts/preparer-mise-en-ligne.sh infinityfree    → Bureau/salone/jend-infinityfree-pret.zip  (site de démonstration)
#   sh scripts/preparer-mise-en-ligne.sh production      → Bureau/salone/jend-production-pret.zip    (vrai site, après avoir rempli deploiement/production.env)
#
# Les configurations sont dans deploiement/ (dossier privé, jamais mis dans les archives ni accessible depuis Internet).
# ⚠ L'archive produite contient les mots de passe et les clés : ne l'envoyez à personne, supprimez-la après la mise en ligne.
set -e
cd "$(dirname "$0")/.."
CIBLE="${1:-}"
CONFIG="deploiement/$CIBLE.env"
if [ -z "$CIBLE" ] || [ ! -f "$CONFIG" ]; then
  echo "Usage : sh scripts/preparer-mise-en-ligne.sh infinityfree|production"
  echo "Configurations disponibles :"; ls deploiement/*.env 2>/dev/null | sed 's#deploiement/#  - #; s#\.env$##'
  exit 2
fi
PHP="${PHP:-/Applications/XAMPP/xamppfiles/bin/php}"
[ -x "$PHP" ] || PHP=php

# 1. Contrôle de la configuration (rien n'est affiché : ni mot de passe, ni clé)
JEND_ENV_FILE="$CONFIG" "$PHP" -r '
require "includes/env.php";
$err = [];
$texte = (string) file_get_contents(getenv("JEND_ENV_FILE"));
$manque = [];
foreach (preg_split("/\\R/", $texte) as $l) {
    if ($l !== "" && $l[0] !== "#" && preg_match("/^([A-Z0-9_]+)=.*(A_REMPLIR|A_REMPLACER)/", $l, $m)) { $manque[] = $m[1]; }
}
if ($manque) { $err[] = "à compléter : " . implode(", ", $manque); }
if (!preg_match("#^https://[^/]+$#", (string) env("APP_URL", ""))) { $err[] = "APP_URL doit être une adresse https sans « / » final"; }
foreach (["APP_KEY", "PAIEMENT_SECRET"] as $k) { if (strlen((string) env($k, "")) < 32) { $err[] = "$k manquant ou trop court"; } }
foreach (["DB_HOST", "DB_NAME", "DB_USER", "DB_PASS"] as $k) { if ((string) env($k, "") === "") { $err[] = "$k vide"; } }
if (!in_array(env("APP_ENV"), ["prod", "test"], true)) { $err[] = "APP_ENV doit valoir prod ou test (jamais dev en ligne)"; }
if (env("APP_ENV") === "prod") {
    if (env("PAIEMENT_FOURNISSEUR") !== "paydunya") { $err[] = "PAIEMENT_FOURNISSEUR doit valoir paydunya en production"; }
    if (env("MAIL_DRIVER") !== "smtp") { $err[] = "MAIL_DRIVER doit valoir smtp en production (sinon aucun e-mail ne part)"; }
}
if ($err) { fwrite(STDERR, "Configuration « " . basename(getenv("JEND_ENV_FILE")) . " » incomplète :\n  - " . implode("\n  - ", $err) . "\n"); exit(1); }
echo "Configuration vérifiée (" . env("APP_ENV") . ", " . env("APP_URL") . ")\n";
'

# 2. Archive du site (sans secrets), puis ajout de la configuration sous le nom config.env
sh scripts/archive-production.sh > /dev/null
zip -q ../jend-production.zip diagnostic.php
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
( cd "$TMP" && unzip -q "$OLDPWD/../jend-production.zip" && rm -f install.php )
cp "$CONFIG" "$TMP/config.env"
chmod 600 "$TMP/config.env"
# Hors du dossier servi par le serveur web local (htdocs) : sur le Bureau (dossier « salone » s'il existe)
DEST="$HOME/Desktop/salone"; [ -d "$DEST" ] || DEST="$HOME/Desktop"; [ -d "$DEST" ] || DEST="$HOME"
SORTIE="$DEST/jend-$CIBLE-pret.zip"
rm -f "$SORTIE"
( cd "$TMP" && zip -qr -X "$SORTIE" . -x "*.DS_Store" )
chmod 600 "$SORTIE"
echo "Archive prête : $SORTIE"
echo "→ À décompresser dans le dossier public de l'hébergeur (index.php et config.env directement dedans)."
echo "⚠ Elle contient tes mots de passe et clés : ne l'envoie à personne, supprime-la après la mise en ligne."
