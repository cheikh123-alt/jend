#!/bin/sh
# Prépare le DOSSIER à envoyer par FTP sur un hébergement sans terminal (ex : InfinityFree).
#   sh scripts/preparer-dossier-ftp.sh [dossier_de_sortie] [--avec-diagnostic]
# Par défaut : ~/Desktop/jend-ftp. Les ZIP ne sont pas décompressables sur ce type d'hébergement : on envoie les fichiers eux-mêmes.
# Le dossier ne contient PAS : .env (à créer sur le serveur), tests, scripts, base de données, maquette, documents, photos de démo.
set -e
cd "$(dirname "$0")/.."
SORTIE=""
DIAG=0
for a in "$@"; do
  case "$a" in
    --avec-diagnostic) DIAG=1 ;;
    *) SORTIE="$a" ;;
  esac
done
SORTIE="${SORTIE:-$HOME/Desktop/jend-ftp}"
if [ -e "$SORTIE" ]; then
  echo "Le dossier $SORTIE existe déjà : supprimez-le ou choisissez un autre nom."
  exit 1
fi
mkdir -p "$SORTIE"
rsync -a \
  --exclude='.env' --exclude='.env.*' --exclude='config.env' --exclude='deploiement/' --exclude='.git' --exclude='.gitignore' --exclude='.DS_Store' \
  --exclude='tests/' --exclude='scripts/' --exclude='database/' --exclude='maquette/' --exclude='install.php' \
  --exclude='*.md' --exclude='*.zip' --exclude='*.sql' --exclude='__pycache__' --exclude='*.pyc' \
  --exclude='diagnostic.php' --exclude='storage/*' --exclude='uploads/produits/*' --exclude='uploads/voix/*' --exclude='uploads/boutiques/*' --exclude='scripts/sources-icones' \
  ./ "$SORTIE/"
# dossiers vides mais nécessaires (le serveur y écrit : sessions, e-mails de test, photos)
mkdir -p "$SORTIE/storage" "$SORTIE/uploads/produits" "$SORTIE/uploads/voix" "$SORTIE/uploads/boutiques"
touch "$SORTIE/storage/.gitkeep" "$SORTIE/uploads/produits/.gitkeep" "$SORTIE/uploads/voix/.gitkeep" "$SORTIE/uploads/boutiques/.gitkeep"
cp storage/.htaccess "$SORTIE/storage/.htaccess"          # dossier interne : interdit depuis Internet (double protection)
if [ "$DIAG" = "1" ]; then
  cp diagnostic.php "$SORTIE/diagnostic.php"
fi
# contrôles
GROS=$(find "$SORTIE" -type f -size +10M | head -3)
if [ -n "$GROS" ]; then echo "⚠ Fichier de plus de 10 Mo (refusé par InfinityFree) : $GROS"; fi
SECRETS=$(find "$SORTIE" \( -name '.env' -o -name '*.env' -o -name 'app-key*' -o -name 'paiement-secret*' -o -name '*.sql' \) | head -3)
if [ -n "$SECRETS" ]; then echo "⛔ Fichier sensible dans le dossier, ne l'envoyez pas : $SECRETS"; exit 1; fi
NB=$(find "$SORTIE" -type f | wc -l | tr -d ' ')
TAILLE=$(du -sk "$SORTIE" | cut -f1)
echo "✔ Dossier prêt : $SORTIE"
echo "  $NB fichiers, $TAILLE Ko$( [ "$DIAG" = "1" ] && echo ', avec diagnostic.php' )"
echo
echo "À envoyer par FTP dans le dossier « htdocs » de votre hébergement (copier le CONTENU du dossier, pas le dossier lui-même)."
echo "Pensez à activer « afficher les fichiers cachés » dans votre logiciel FTP : .htaccess doit être envoyé."
echo "Puis créez le fichier .env (voir scripts/preparer-installation.php) et importez jend-installation.sql dans phpMyAdmin."
