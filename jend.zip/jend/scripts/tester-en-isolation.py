#!/usr/bin/env python3
"""
Lance les tests de bout en bout sur une COPIE JETABLE du site, avec sa propre base de données : vos vraies données
(comptes, boutiques, commandes, photos) ne sont jamais touchées.

    python3 scripts/tester-en-isolation.py                    # toute la batterie (tests/run_all.py)
    python3 scripts/tester-en-isolation.py test_etape9.py     # un seul fichier

Ce que fait le script :
  1. copie le projet dans un dossier temporaire (sans .env, sans photos ni journaux) ;
  2. crée la base jetable « jend_test_iso » avec le schéma, les zones de Touba, les catégories et 8 produits de démonstration ;
  3. démarre un serveur PHP temporaire qui reproduit les règles du .htaccess (dossiers internes interdits, uploads sans scripts) ;
  4. lance les tests, puis supprime la base, le serveur et la copie (même en cas d'erreur).
Ne nécessite que XAMPP (PHP + MariaDB) et Python 3.
"""
import os, re, shutil, signal, socket, subprocess, sys, tempfile, time
from pathlib import Path

RACINE = Path(__file__).resolve().parent.parent
PHP = os.environ.get("JEND_TEST_PHP", "/Applications/XAMPP/xamppfiles/bin/php")
MYSQL = os.environ.get("JEND_TEST_MYSQL", "/Applications/XAMPP/xamppfiles/bin/mysql")
NOM_BD = "jend_test_iso"          # nom réservé : jamais la vraie base

ROUTEUR = r'''<?php
// Reproduit pour « php -S » les règles du .htaccess : URL propres, dossiers internes interdits, uploads sans exécution.
$uri = urldecode((string) parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH));
if ($uri !== '/jend' && strpos($uri, '/jend/') !== 0) { http_response_code(404); exit; }
$rel = ltrim(substr($uri, 5), '/');
$racine = __DIR__ . '/jend';
if (preg_match('#^(includes|pages|database|storage|scripts|maquette|tests|deploiement)(/|$)#', $rel) || preg_match('#(^|/)\.(env|git)|\.(sql|md|lock|log|env)$#', $rel)) { http_response_code(403); exit('Forbidden'); }
$fichier = $racine . '/' . $rel;
if ($rel !== '' && is_dir($fichier)) { http_response_code(403); exit('Forbidden'); }
if ($rel !== '' && is_file($fichier)) {
    if (strpos($rel, 'uploads/') === 0 && !preg_match('#^uploads/(produits|boutiques)/[^/]+\.(jpe?g|png)$|^uploads/voix/[^/]+\.(webm|ogg|m4a|mp3)$#i', $rel)) { http_response_code(403); exit('Forbidden'); }
    if (substr($rel, -5) === '.html') { return false; }
    if (preg_match('#\.php$#', $rel) && strpos($rel, 'uploads/') !== 0) {
        $_SERVER['SCRIPT_NAME'] = '/jend/' . $rel; $_SERVER['SCRIPT_FILENAME'] = $fichier; chdir(dirname($fichier)); require $fichier; return true;
    }
    if (strpos($rel, 'assets/vendor/') === 0) {          // règles de assets/vendor/.htaccess : seuls js, css, woff2 ; cache d'un an
        if (!preg_match('#\.(js|css|woff2)$#', $rel)) { http_response_code(403); exit('Forbidden'); }
        $types = ['js' => 'text/javascript', 'css' => 'text/css', 'woff2' => 'font/woff2'];
        header('Content-Type: ' . $types[pathinfo($rel, PATHINFO_EXTENSION)]); header('Cache-Control: public, max-age=31536000, immutable'); header('X-Content-Type-Options: nosniff');
        readfile($fichier); return true;
    }
    if (substr($rel, -12) === '.webmanifest') { header('Content-Type: application/manifest+json'); header('X-Content-Type-Options: nosniff'); readfile($fichier); return true; }
    if (substr($rel, -5) === '.json') { return false; }
    header('X-Content-Type-Options: nosniff');
    if (basename($rel) === 'sw.js') { header('Cache-Control: no-cache'); }
    return false;
}
$_SERVER['SCRIPT_NAME'] = '/jend/index.php'; $_SERVER['SCRIPT_FILENAME'] = $racine . '/index.php';
chdir($racine); require $racine . '/index.php';
'''


def mysql(sql, base=None, entree=None):
    cmd = [MYSQL, "-h", "127.0.0.1", "-u", "root", "-N", "-B"] + ([base] if base else []) + (["-e", sql] if sql else [])
    r = subprocess.run(cmd, input=entree, capture_output=True, text=True)
    if r.returncode:
        sys.exit("Erreur MySQL : " + r.stderr[:300])
    return r.stdout


def port_libre():
    s = socket.socket(); s.bind(("127.0.0.1", 0)); p = s.getsockname()[1]; s.close(); return p


def main():
    if shutil.which("rsync") is None:
        sys.exit("rsync est introuvable.")
    racine_tmp = Path(tempfile.mkdtemp(prefix="jend-iso-"))
    copie = racine_tmp / "jend"
    serveur = None
    code = 1
    try:
        print(f"== Copie jetable : {copie}")
        subprocess.run(["rsync", "-a", "--exclude=.env", "--exclude=.git", "--exclude=__pycache__", "--exclude=*.zip", "--include=storage/.htaccess", "--exclude=storage/*", "--exclude=uploads/produits/*", "--exclude=uploads/voix/*", "--exclude=uploads/boutiques/*", "--exclude=deploiement/",
                        f"{RACINE}/", f"{copie}/"], check=True)
        (copie / "storage").mkdir(exist_ok=True); (copie / "uploads" / "produits").mkdir(parents=True, exist_ok=True); (copie / "uploads" / "voix").mkdir(parents=True, exist_ok=True); (copie / "uploads" / "boutiques").mkdir(parents=True, exist_ok=True)
        (racine_tmp / "routeur.php").write_text(ROUTEUR)
        for cle in ("paiement-secret.txt", "app-key.txt"):          # clés de développement créées d'avance (les tests lisent la clé de signature)
            (copie / "storage" / cle).write_text(os.urandom(32).hex())
        (copie / "storage" / "emails.log").write_text("")

        print(f"== Base jetable : {NOM_BD}")
        mysql(f"DROP DATABASE IF EXISTS {NOM_BD}; CREATE DATABASE {NOM_BD} CHARACTER SET utf8mb4")
        port = port_libre()
        (copie / ".env").write_text(
            f"APP_ENV=dev\nAPP_URL=http://127.0.0.1:{port}/jend\nDB_HOST=127.0.0.1\nDB_PORT=3306\nDB_NAME={NOM_BD}\nDB_USER=root\nDB_PASS=\n"
            "ADMIN_EMAIL=admin@jend.local\nADMIN_NOM=Administrateur\nMAIL_DRIVER=log\nPAIEMENT_FOURNISSEUR=simulation\n")
        r = subprocess.run([PHP, str(copie / "scripts" / "preparer-installation.php"), "--admin-email=admin@jend.local", "--demo",
                            f"--sortie={racine_tmp}/install.sql", f"--env={racine_tmp}/install.env"], capture_output=True, text=True)
        if r.returncode:
            sys.exit("Préparation de la base impossible : " + r.stderr + r.stdout)
        mysql("", NOM_BD, (racine_tmp / "install.sql").read_text())
        print("   tables :", mysql("SELECT COUNT(*) FROM information_schema.tables WHERE table_schema='" + NOM_BD + "'").strip(),
              "· produits de démonstration :", mysql("SELECT COUNT(*) FROM produits", NOM_BD).strip())

        print(f"== Serveur PHP temporaire : http://127.0.0.1:{port}/jend/")
        env = dict(os.environ, JEND_ENV_FILE=str(copie / ".env"))
        serveur = subprocess.Popen([PHP, "-S", f"127.0.0.1:{port}", "-t", str(racine_tmp), str(racine_tmp / "routeur.php")], env=env, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        for _ in range(60):
            try:
                socket.create_connection(("127.0.0.1", port), timeout=0.2).close(); break
            except OSError:
                time.sleep(0.1)
        if sys.argv[1:2] == ["--serveur"]:      # garde la copie en marche pour la regarder dans un navigateur (Ctrl-C ou kill pour arrêter et tout supprimer)
            signal.signal(signal.SIGTERM, lambda *a: (_ for _ in ()).throw(KeyboardInterrupt()))
            print(f"\n== Site de démonstration prêt : http://127.0.0.1:{port}/jend/  (comptes de démonstration : voir install.env)\n", flush=True)
            try:
                while True:
                    time.sleep(1)
            except KeyboardInterrupt:
                code = 0
                return
        cibles = sys.argv[1:] or ["run_all.py"]
        env_tests = {k: v for k, v in os.environ.items() if k != "JEND_ENV_FILE"}      # chaque test lit le .env de la copie (ou le sien)
        env_tests["JEND_TEST_URL"] = f"http://127.0.0.1:{port}/jend/"
        for cible in cibles:
            print(f"== Tests : {cible}\n")
            r = subprocess.run([sys.executable, str(copie / "tests" / cible)], env=env_tests)
            code = r.returncode if code in (0, 1) and (code == 1 or r.returncode) else code
            code = r.returncode if r.returncode else (code if code != 1 else 0)
    finally:
        if serveur:
            serveur.terminate()
            try:
                serveur.wait(timeout=10)
            except Exception:
                serveur.kill()
        mysql(f"DROP DATABASE IF EXISTS {NOM_BD}")
        shutil.rmtree(racine_tmp, ignore_errors=True)
        print("\n== Copie, serveur et base jetables supprimés. Vos vraies données n'ont pas été touchées.")
    sys.exit(code)


main()
