#!/usr/bin/env python3
"""Allège les icônes Phosphor : ne garde que celles réellement utilisées par le site.

  - assets/vendor/css/phosphor-site.css      (au lieu des feuilles complètes, ~165 Ko)
  - assets/vendor/fonts/Phosphor.woff2 et Phosphor-Fill.woff2  (au lieu des polices complètes, ~280 Ko)

Les fichiers complets restent pour pouvoir régénérer : feuilles dans assets/vendor/css/, polices dans scripts/sources-icones/.
À relancer après avoir ajouté une nouvelle icône dans le code :  python3 scripts/icones-site.py
(la réduction des polices demande fonttools et brotli :  python3 -m pip install --user fonttools brotli)
"""
import re, sys
from pathlib import Path

RACINE = Path(__file__).resolve().parent.parent
CSS = RACINE / "assets" / "vendor" / "css"
SOURCES = [RACINE / "index.php", RACINE / "database" / "seed.sql"] + [p for d in ("pages", "includes", "assets/js") for p in (RACINE / d).rglob("*") if p.suffix in (".php", ".js")]


def utilisees():
    noms = set()
    for f in SOURCES:
        if f.name.startswith("phosphor"):
            continue
        noms |= set(re.findall(r"\bph-[a-z0-9]+(?:-[a-z0-9]+)*", f.read_text(errors="ignore")))
    return noms - {"ph-fill", "ph-bold"}


def extraire(feuille, prefixe, noms):
    texte = (CSS / feuille).read_text()
    entete = texte[: texte.index(f"{prefixe}.ph-")]
    regles = {}
    for bloc, nom in re.findall(r"(" + re.escape(prefixe) + r"\.(ph-[a-z0-9-]+):before \{[^}]*\})", texte):
        regles[nom] = bloc
    return entete, regles


def reduire_police(nom, regles):
    """Garde dans la police uniquement les symboles des règles CSS données."""
    source = RACINE / "scripts" / "sources-icones" / nom
    cible = RACINE / "assets" / "vendor" / "fonts" / nom
    try:
        from fontTools import subset
    except ImportError:
        print(f"{nom} : non réduite (fonttools absent) — la police complète reste utilisée.")
        return
    points = sorted({int(c, 16) for r in regles for c in re.findall(r'content: "\\([0-9a-f]+)"', r)})
    options = subset.Options()
    options.flavor = "woff2"
    options.layout_features = []
    options.name_IDs = ["*"]
    options.notdef_outline = True
    police = subset.load_font(str(source), options)
    sub = subset.Subsetter(options)
    sub.populate(unicodes=points)
    sub.subset(police)
    subset.save_font(police, str(cible), options)
    print(f"{nom} : {len(points)} symboles, {source.stat().st_size // 1024} Ko → {cible.stat().st_size // 1024} Ko")


def main():
    noms = utilisees()
    e1, r1 = extraire("phosphor-regular.css", ".ph", noms)
    e2, r2 = extraire("phosphor-fill.css", ".ph-fill", noms)
    inconnues = sorted(n for n in noms if n not in r1 and n not in r2)
    sortie = ["/* Généré par scripts/icones-site.py — ne pas modifier à la main. " + str(len(noms)) + " icônes utilisées. */", e1.strip(), e2.strip()]
    sortie += [r1[n] for n in sorted(noms) if n in r1] + [r2[n] for n in sorted(noms) if n in r2]
    (CSS / "phosphor-site.css").write_text("\n".join(sortie) + "\n")
    taille = (CSS / "phosphor-site.css").stat().st_size
    print(f"phosphor-site.css : {len(noms)} icônes, {taille // 1024} Ko")
    reduire_police("Phosphor.woff2", [r1[n] for n in noms if n in r1])
    reduire_police("Phosphor-Fill.woff2", [r2[n] for n in noms if n in r2])
    # version (empreinte du contenu) dans l'adresse des polices : les navigateurs les gardent un an en cache,
    # une police modifiée doit donc changer d'adresse
    import hashlib
    feuille = (CSS / "phosphor-site.css").read_text()
    for nom in ("Phosphor.woff2", "Phosphor-Fill.woff2"):
        v = hashlib.sha256((RACINE / "assets" / "vendor" / "fonts" / nom).read_bytes()).hexdigest()[:10]
        feuille = re.sub(r'url\("\.\./fonts/' + re.escape(nom) + r'(\?v=[0-9a-f]+)?"\)', f'url("../fonts/{nom}?v={v}")', feuille)
    (CSS / "phosphor-site.css").write_text(feuille)
    # empreintes des fichiers produits ici : assets/vendor/SHA256SUMS sert au contrôle d'intégrité (diagnostic, tests)
    sommes = RACINE / "assets" / "vendor" / "SHA256SUMS"
    lignes = {l.split()[1]: l for l in sommes.read_text().strip().splitlines() if l.strip()}
    for rel in ("css/phosphor-site.css", "fonts/Phosphor.woff2", "fonts/Phosphor-Fill.woff2"):
        lignes[rel] = hashlib.sha256((RACINE / "assets" / "vendor" / rel).read_bytes()).hexdigest() + "  " + rel
    sommes.write_text("\n".join(lignes[k] for k in sorted(lignes)) + "\n")
    if inconnues:
        print("Classes « ph-… » sans icône Phosphor (texte, classes CSS du site) :", " ".join(inconnues))
    return 0


if __name__ == "__main__":
    sys.exit(main())
