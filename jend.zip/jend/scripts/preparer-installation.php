<?php
declare(strict_types=1);

/**
 * Prépare l'installation sur un hébergement SANS terminal (ex : InfinityFree). À lancer sur VOTRE ordinateur :
 *
 *   php scripts/preparer-installation.php --admin-email=vous@exemple.com [--admin-nom="Votre Nom"] [--demo]
 *        [--sortie=storage/jend-installation.sql] [--env=storage/hebergeur-test.env]
 *
 * Produit :
 *   • jend-installation.sql : tables + zones de livraison + catégories + votre compte administrateur
 *     (+ avec --demo : une boutique « Marché Démo » et 8 produits, pour avoir de quoi tester tout de suite).
 *     À importer dans phpMyAdmin, dans une base VIDE. Il ne contient ni CREATE DATABASE, ni USE, ni DROP :
 *     votre hébergeur n'autorise pas ces instructions, et un ré-import ne peut effacer aucune donnée
 *     (il échoue simplement si les tables existent déjà).
 *   • hebergeur-test.env : modèle de .env avec des clés secrètes ALÉATOIRES déjà générées ; il reste à compléter
 *     l'adresse du site, la base de données et l'e-mail.
 *
 * Les mots de passe générés ne sont affichés qu'ICI, une seule fois. Seules leurs empreintes (hachées) vont dans le SQL.
 */
if (PHP_SAPI !== 'cli') {
    http_response_code(403);
    exit('Interdit.');
}

$racine = dirname(__DIR__);
require $racine . '/includes/env.php';
require $racine . '/includes/helpers.php';

$opts = [];
foreach (array_slice($argv, 1) as $a) {
    if (preg_match('/^--([a-z-]+)(?:=(.*))?$/', $a, $m)) {
        $opts[$m[1]] = $m[2] ?? '1';
    }
}
$email = (string) ($opts['admin-email'] ?? '');
if (!filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($email) > 190) {
    fwrite(STDERR, "Indiquez votre adresse e-mail : --admin-email=vous@exemple.com\n");
    exit(2);
}
$nom = trim((string) ($opts['admin-nom'] ?? 'Administrateur'));
if ($nom === '' || mb_strlen($nom) > 120 || preg_match('/[\x00-\x1F\\\\\'"`;]/u', $nom)) {
    fwrite(STDERR, "Nom invalide (pas de guillemets, ni de ; ni de \\).\n");
    exit(2);
}
$sortie = (string) ($opts['sortie'] ?? $racine . '/storage/jend-installation.sql');
$sortieEnv = (string) ($opts['env'] ?? $racine . '/storage/hebergeur-test.env');
foreach ([$sortie, $sortieEnv] as $f) {
    if (file_exists($f)) {
        fwrite(STDERR, "Le fichier $f existe déjà : supprimez-le (ou choisissez un autre nom) pour ne pas l'écraser.\n");
        exit(2);
    }
}

/** Échappe une valeur texte pour un littéral SQL entre apostrophes. */
function sql_txt(string $v): string
{
    return "'" . str_replace(["\\", "'"], ["\\\\", "''"], $v) . "'";
}
function mot_de_passe_aleatoire(): string
{
    return rtrim(strtr(base64_encode(random_bytes(12)), '+/', '-_'), '=');
}

/** Nettoie un fichier SQL du projet : retire commentaires, CREATE DATABASE, USE, DROP, SET FOREIGN_KEY_CHECKS. */
function sql_hebergeur(string $fichier): string
{
    $sql = (string) file_get_contents($fichier);
    $sql = preg_replace('/^\s*--.*$/m', '', $sql);
    $instructions = [];
    foreach (preg_split('/;\s*(\r?\n|$)/', $sql) as $i) {
        $i = trim($i);
        if ($i === '' || preg_match('/^(CREATE\s+DATABASE|USE\s|DROP\s|SET\s+FOREIGN_KEY_CHECKS)/i', $i)) {
            continue;
        }
        $instructions[] = $i . ';';
    }
    return implode("\n\n", $instructions);
}

$schema = sql_hebergeur($racine . '/database/schema.sql');
$seed = sql_hebergeur($racine . '/database/seed.sql');
$nbTables = preg_match_all('/^CREATE TABLE\b/mi', $schema);
if ($nbTables < 40 || preg_match('/\b(CREATE DATABASE|DROP TABLE|USE\s+`?\w+`?;)/i', $schema . $seed)) {
    fwrite(STDERR, "Schéma inattendu ($nbTables tables) : arrêt.\n");
    exit(1);
}

$mdpAdmin = mot_de_passe_aleatoire();
$admin = "INSERT INTO users (nom, email, mot_de_passe, role) VALUES (" . sql_txt($nom) . ', ' . sql_txt($email) . ', ' . sql_txt(password_hash($mdpAdmin, PASSWORD_DEFAULT)) . ", 'admin');";

$demo = '';
$mdpVendeur = null;
if (isset($opts['demo'])) {
    $mdpVendeur = mot_de_passe_aleatoire();
    $demo = "INSERT INTO users (nom, email, mot_de_passe, role) VALUES ('Vendeur Démo', 'vendeur@jend.local', " . sql_txt(password_hash($mdpVendeur, PASSWORD_DEFAULT)) . ", 'vendeur');\n"
        . "INSERT INTO boutiques (user_id, nom, slug, description, statut) VALUES ((SELECT id FROM users WHERE email = 'vendeur@jend.local'), 'Marché Démo', 'marche-demo', 'Boutique de démonstration', 'active');\n";
    $exemples = [
        ['Pagne wax premium 6 yards', 'tissus-wax', 18500, 26000, 40, 4.8, 124], ['Smartphone 128 Go double SIM', 'telephones', 95000, null, 12, 4.5, 78],
        ['Sac en cuir tressé artisanal', 'artisanat', 22000, null, 15, 4.9, 56], ['Bissap séché bio 500 g', 'alimentation', 2500, null, 200, 4.7, 210],
        ['Écouteurs sans fil', 'accessoires-electronique', 12000, 18000, 60, 4.3, 342], ['Beurre de karité pur 250 ml', 'beaute', 4500, null, 80, 4.6, 98],
        ['Ensemble boubou brodé homme', 'boubous-tenues', 35000, null, 10, 4.8, 41], ['Lampe décorative en calebasse', 'maison', 14500, null, 18, 4.4, 33],
    ];
    foreach ($exemples as [$n, $cat, $prix, $barre, $stock, $note, $avis]) {
        $demo .= 'INSERT INTO produits (boutique_id, categorie_id, nom, slug, description, prix, prix_barre, stock, statut, note_moyenne, nb_avis) VALUES ('
            . "(SELECT id FROM boutiques WHERE slug = 'marche-demo'), (SELECT id FROM categories WHERE slug = " . sql_txt($cat) . '), '
            . sql_txt($n) . ', ' . sql_txt(slugify($n)) . ', ' . sql_txt("Produit de démonstration : $n.") . ", $prix, " . ($barre ?? 'NULL') . ", $stock, 'publie', $note, $avis);\n";
    }
}

$contenu = "-- Jënd : installation pour hébergement sans terminal — généré le " . date('Y-m-d H:i') . "\n"
    . "-- À importer dans une base VIDE (phpMyAdmin → Importer). Aucune instruction de création ou de suppression de base.\n\n"
    . "SET NAMES utf8mb4;\n\n" . $schema . "\n\n" . $seed . "\n\n" . $admin . "\n" . ($demo !== '' ? "\n" . $demo : '');
file_put_contents($sortie, $contenu);
chmod($sortie, 0600);

$appKey = bin2hex(random_bytes(32));
$secret = bin2hex(random_bytes(32));
$diag = bin2hex(random_bytes(10));
$env = <<<ENV
# Configuration d'un site de TEST sur hébergement gratuit (InfinityFree). Généré par scripts/preparer-installation.php.
# 1) Remplacez les valeurs « A_REMPLIR » par celles de votre panneau d'hébergement.
# 2) Enregistrez ce fichier sous le nom exact « .env » (avec le point) puis envoyez-le par FTP à côté de index.php.
# ⚠ Ce fichier contient des secrets : ne l'envoyez à personne, ne le publiez nulle part.

APP_ENV=test
# Adresse EXACTE du site, en https, SANS « www. » et SANS « / » final. Exemple : https://monsite.great-site.net
APP_URL=https://A_REMPLIR

# --- Base de données (panneau « MySQL Databases ») : l'hôte n'est PAS « localhost » ---
DB_HOST=A_REMPLIR
DB_PORT=3306
DB_NAME=A_REMPLIR
DB_USER=A_REMPLIR
DB_PASS=A_REMPLIR

ADMIN_EMAIL=$email
ADMIN_NOM=$nom

# --- Clés secrètes (déjà générées pour vous : ne les changez pas après avoir activé la 2FA) ---
APP_KEY=$appKey
PAIEMENT_SECRET=$secret
PAIEMENT_FOURNISSEUR=simulation
# Pour essayer PayDunya (clés TEST de votre application PayDunya), remplacez la ligne ci-dessus par PAIEMENT_FOURNISSEUR=paydunya et remplissez :
# PAYDUNYA_MODE=test
# PAYDUNYA_MASTER_KEY=
# PAYDUNYA_PRIVATE_KEY=
# PAYDUNYA_TOKEN=

# --- E-mails : mail() est très restreint sur InfinityFree, on passe par un compte Gmail (mot de passe d'application) ---
MAIL_DRIVER=smtp
MAIL_FROM=A_REMPLIR@gmail.com
MAIL_FROM_NAME=Jënd (test)
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_SECURE=tls
SMTP_USER=A_REMPLIR@gmail.com
SMTP_PASS=A_REMPLIR
ALERT_EMAIL=$email

# --- Redirection HTTPS ; mettre 0 SEULEMENT si le diagnostic montre que PHP ne voit pas le HTTPS ---
FORCE_HTTPS=1
TRUSTED_PROXY=0

# --- Commission des nouvelles boutiques, en % (0 = offre de lancement ; chaque boutique garde son taux, modifiable dans /admin/boutiques) ---
COMMISSION_DEFAUT=0

# --- Acompte pour les commandes payées à la livraison (en % du total ; 0 = aucun) et minimum en FCFA ---
ACOMPTE_POURCENT=20
ACOMPTE_MINIMUM=1000

# --- Mentions légales (pour un test, vous pouvez mettre des valeurs fictives ; pour un vrai lancement : les vraies) ---
SOCIETE_NOM=Jënd (site de test)
SOCIETE_FORME=A_REMPLIR
SOCIETE_CAPITAL=sans objet
SOCIETE_ADRESSE=A_REMPLIR
SOCIETE_NINEA=A_REMPLIR
SOCIETE_RCCM=A_REMPLIR
SOCIETE_TEL=A_REMPLIR
CONTACT_EMAIL=$email
SOCIETE_DIRECTEUR=$nom
HEBERGEUR=InfinityFree (iFastNet)

# --- Diagnostic (à SUPPRIMER après usage, avec le fichier diagnostic.php) ---
DIAGNOSTIC_CLE=$diag
ENV;
file_put_contents($sortieEnv, $env . "\n");
chmod($sortieEnv, 0600);

echo "✔ Fichier d'installation SQL : $sortie\n";
echo "  ($nbTables tables, zones de livraison, catégories, compte administrateur" . ($demo !== '' ? ', boutique et 8 produits de démonstration' : '') . ")\n";
echo "✔ Modèle de configuration    : $sortieEnv  (à compléter, puis à envoyer sous le nom « .env »)\n\n";
echo "Compte administrateur :\n  e-mail       : $email\n  mot de passe : $mdpAdmin\n";
if ($mdpVendeur !== null) {
    echo "Compte vendeur de démonstration :\n  e-mail       : vendeur@jend.local\n  mot de passe : $mdpVendeur\n";
}
echo "\nNotez ces mots de passe MAINTENANT : ils ne seront plus affichés. Ils ne sont pas enregistrés en clair.\n";
echo "Changez-les dès votre première connexion, et activez la double authentification de l'administrateur.\n";
