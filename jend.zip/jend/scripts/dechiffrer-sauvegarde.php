<?php
declare(strict_types=1);

/**
 * Déchiffre une sauvegarde créée par sauvegarde.php quand BACKUP_PASSPHRASE est défini.
 *     php scripts/dechiffrer-sauvegarde.php jend_db_20261007_020000.sql.gz.enc  base.sql.gz
 * La phrase secrète est lue dans .env (BACKUP_PASSPHRASE) ou dans la variable d'environnement JEND_BACKUP_PASSPHRASE.
 * Puis, pour restaurer la base : gunzip -c base.sql.gz | mysql -u utilisateur -p nom_de_la_base
 */
if (PHP_SAPI !== 'cli') {
    http_response_code(403);
    exit('Interdit.');
}
require dirname(__DIR__) . '/includes/env.php';
require __DIR__ . '/lib-sauvegarde.php';

if ($argc !== 3) {
    fwrite(STDERR, "Usage : php scripts/dechiffrer-sauvegarde.php <fichier.enc> <fichier_de_sortie>\n");
    exit(2);
}
$phrase = (string) (getenv('JEND_BACKUP_PASSPHRASE') ?: env('BACKUP_PASSPHRASE', ''));
if ($phrase === '') {
    fwrite(STDERR, "Phrase secrète introuvable : définissez BACKUP_PASSPHRASE dans .env ou JEND_BACKUP_PASSPHRASE.\n");
    exit(2);
}
try {
    fichier_dechiffrer($argv[1], $argv[2], $phrase);
    echo "✔ Sauvegarde déchiffrée : {$argv[2]}\n";
} catch (Throwable $e) {
    fwrite(STDERR, '✘ ' . $e->getMessage() . "\n");
    exit(1);
}
