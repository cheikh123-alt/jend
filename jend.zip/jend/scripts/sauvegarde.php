<?php
declare(strict_types=1);

/**
 * Sauvegarde de Jënd : base de données (compressée) + photos des produits.
 * À lancer en ligne de commande, idéalement chaque nuit (cron) :
 *     php scripts/sauvegarde.php
 *
 * Réglages (.env) : BACKUP_DIR (dossier de destination), BACKUP_KEEP (nombre de sauvegardes gardées, 14 par défaut),
 * MYSQLDUMP_BIN (chemin de mysqldump si le programme n'est pas trouvé tout seul),
 * BACKUP_PASSPHRASE (16 caractères minimum) : si défini, les sauvegardes sont CHIFFRÉES (AES-256-GCM, fichiers .enc).
 * Pour les lire : php scripts/dechiffrer-sauvegarde.php fichier.enc sortie. SANS cette phrase, elles sont irrécupérables : gardez-la ailleurs.
 *
 * Le fichier contient les mots de passe chiffrés des comptes et les données clients : gardez-le PRIVÉ,
 * dans un dossier inaccessible depuis Internet, et copiez-le régulièrement HORS du serveur.
 */
if (PHP_SAPI !== 'cli') {
    http_response_code(403);
    exit('Interdit.');
}

require dirname(__DIR__) . '/includes/env.php';
require __DIR__ . '/lib-sauvegarde.php';

$racine = dirname(__DIR__);
$dest   = (string) (env('BACKUP_DIR') ?: $racine . '/storage/sauvegardes');
$garder = max(1, (int) (env('BACKUP_KEEP') ?: 14));
$base   = (string) env('DB_NAME', 'jend');
if (!preg_match('/^[A-Za-z0-9_]+$/', $base)) {
    fwrite(STDERR, "DB_NAME invalide.\n");
    exit(1);
}

if (!is_dir($dest) && !mkdir($dest, 0700, true) && !is_dir($dest)) {
    fwrite(STDERR, "Impossible de créer $dest\n");
    exit(1);
}
chmod($dest, 0700);

/** Cherche mysqldump : réglage .env, emplacements usuels, puis PATH. */
function trouver_mysqldump(): ?string
{
    $candidats = array_filter([
        env('MYSQLDUMP_BIN'),
        '/Applications/XAMPP/xamppfiles/bin/mysqldump', '/Applications/MAMP/Library/bin/mysqldump',
        '/opt/homebrew/bin/mysqldump', '/usr/local/bin/mysqldump', '/usr/bin/mysqldump',
    ]);
    foreach (explode(PATH_SEPARATOR, (string) getenv('PATH')) as $dir) {
        $candidats[] = rtrim($dir, '/') . '/mysqldump';
    }
    foreach ($candidats as $c) {
        if (is_file($c) && is_executable($c)) {
            return $c;
        }
    }
    return null;
}

$dump = trouver_mysqldump();
if (!$dump) {
    fwrite(STDERR, "mysqldump introuvable : indiquez son chemin dans .env (MYSQLDUMP_BIN).\n");
    exit(1);
}

$horodatage = date('Ymd_His');
$fichierDb  = "$dest/jend_db_$horodatage.sql.gz";
$tmp        = $fichierDb . '.tmp';

// Pas de shell (commande en tableau) : aucune injection possible. Le mot de passe passe par l'environnement, pas par la ligne de commande.
$proc = proc_open(
    [$dump, '--single-transaction', '--quick', '--default-character-set=utf8mb4',
     '--host=' . env('DB_HOST', '127.0.0.1'), '--port=' . env('DB_PORT', '3306'), '--user=' . env('DB_USER', 'root'), $base],
    [1 => ['pipe', 'w'], 2 => ['pipe', 'w']],
    $pipes,
    null,
    ['PATH' => (string) getenv('PATH'), 'MYSQL_PWD' => (string) env('DB_PASS', '')]
);
if (!is_resource($proc)) {
    fwrite(STDERR, "Impossible de lancer mysqldump.\n");
    exit(1);
}
$gz = gzopen($tmp, 'wb9');
$fin = '';
while (!feof($pipes[1])) {
    $morceau = fread($pipes[1], 65536);
    if ($morceau === false || $morceau === '') {
        continue;
    }
    gzwrite($gz, $morceau);
    $fin = substr($fin . $morceau, -200);        // on garde la fin du fichier pour contrôler qu'il est complet
}
gzclose($gz);
$erreurs = stream_get_contents($pipes[2]);
$code = proc_close($proc);

if ($code !== 0 || strpos($fin, 'Dump completed') === false) {
    @unlink($tmp);
    fwrite(STDERR, "Échec de la sauvegarde de la base (code $code) : " . trim($erreurs) . "\n");
    exit(1);
}
rename($tmp, $fichierDb);
chmod($fichierDb, 0600);

$phrase = (string) env('BACKUP_PASSPHRASE', '');
if ($phrase !== '' && strlen($phrase) < 16) {
    @unlink($fichierDb);
    fwrite(STDERR, "BACKUP_PASSPHRASE trop courte (16 caractères minimum) : sauvegarde annulée.\n");
    exit(1);
}
/** Chiffre le fichier si une phrase secrète est définie, puis supprime la version en clair. */
$proteger = function (string $fichier) use ($phrase): string {
    if ($phrase === '') {
        return $fichier;
    }
    fichier_chiffrer($fichier, $fichier . '.enc', $phrase);
    chmod($fichier . '.enc', 0600);
    unlink($fichier);
    return $fichier . '.enc';
};
$fichierDb = $proteger($fichierDb);
printf("✔ Base sauvegardée%s : %s (%s Ko)\n", $phrase !== '' ? ' (chiffrée)' : '', $fichierDb, number_format(filesize($fichierDb) / 1024, 1, ',', ' '));

// Photos des produits et photos jointes aux signalements des clients
$dossiersPhotos = array_values(array_filter(['uploads/produits', 'storage/litiges'], fn ($d) => is_dir("$racine/$d") && count(glob("$racine/$d/*")) > 0));
if ($dossiersPhotos) {
    $fichierPhotos = "$dest/jend_photos_$horodatage.tar.gz";
    $p = proc_open(array_merge(['tar', '-czf', $fichierPhotos, '-C', $racine], $dossiersPhotos), [2 => ['pipe', 'w']], $pp);
    if (is_resource($p)) {
        $err = stream_get_contents($pp[2]);
        if (proc_close($p) === 0) {
            chmod($fichierPhotos, 0600);
            $fichierPhotos = $proteger($fichierPhotos);
            printf("✔ Photos sauvegardées%s : %s (%s Ko)\n", $phrase !== '' ? ' (chiffrées)' : '', $fichierPhotos, number_format(filesize($fichierPhotos) / 1024, 1, ',', ' '));
        } else {
            fwrite(STDERR, "⚠ Photos non sauvegardées : $err\n");
        }
    }
} else {
    echo "• Aucune photo à sauvegarder.\n";
}

// Rotation : on ne garde que les N dernières sauvegardes de chaque type
foreach (['jend_db_*.sql.gz*', 'jend_photos_*.tar.gz*'] as $motif) {
    $liste = glob("$dest/$motif");
    sort($liste);
    foreach (array_slice($liste, 0, max(0, count($liste) - $garder)) as $vieux) {
        unlink($vieux);
        echo "• Ancienne sauvegarde supprimée : " . basename($vieux) . "\n";
    }
}
echo "Terminé. Pensez à copier ces fichiers HORS du serveur.\n";
