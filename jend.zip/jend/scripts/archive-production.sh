#!/bin/sh
# Crée l'archive à envoyer sur le serveur de PRODUCTION (sans tests, maquette, secrets, photos de démo ni sauvegardes).
#   sh scripts/archive-production.sh        →  jend-production.zip (dans le dossier parent du projet)
set -e
cd "$(dirname "$0")/.."
SORTIE="../jend-production.zip"
rm -f "$SORTIE"
zip -qr "$SORTIE" . \
  -x ".env" "config.env" ".env.example" "storage/*" "!storage/.gitkeep" "uploads/produits/*" "uploads/voix/*" "uploads/boutiques/*" "scripts/sources-icones/*" "deploiement/*" \
  -x "tests/*" "maquette/*" "diagnostic.php" "*.DS_Store" "*.log" "*.bak" "CAHIER_DES_CHARGES.md" ".git/*" ".gitignore"
# les dossiers vides nécessaires au fonctionnement
mkdir -p /tmp/jend-vides/storage /tmp/jend-vides/uploads/produits /tmp/jend-vides/uploads/voix /tmp/jend-vides/uploads/boutiques
touch /tmp/jend-vides/storage/.gitkeep /tmp/jend-vides/uploads/produits/.gitkeep /tmp/jend-vides/uploads/voix/.gitkeep /tmp/jend-vides/uploads/boutiques/.gitkeep
cp storage/.htaccess /tmp/jend-vides/storage/.htaccess     # dossier interne : interdit depuis Internet (double protection)
( cd /tmp/jend-vides && zip -qr "$OLDPWD/$SORTIE" storage uploads ) 2>/dev/null || true
rm -rf /tmp/jend-vides
echo "Archive créée : $SORTIE"
unzip -l "$SORTIE" | tail -1
echo "Rappel : ne mettez JAMAIS le fichier .env dans une archive. Créez-le sur le serveur (voir .env.production.example)."
