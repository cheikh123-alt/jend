#!/bin/sh
# Jënd — test de charge sur une COPIE JETABLE (htdocs/jend-charge + base jend_charge), servie par l'Apache de XAMPP.
# Vos vraies données ne sont jamais touchées ; tout est supprimé à la fin. Usage : sh scripts/test-de-charge.sh [nombre de produits, 20000 par défaut]
# XAMPP (Apache + MySQL) doit être démarré.
set -e
X=/Applications/XAMPP/xamppfiles; H=$X/htdocs; C=$H/jend-charge; DB=jend_charge
MY="$X/bin/mysql -u root -N -B"
nettoyer() { printf "%s" "<?php array_map('unlink', glob(__DIR__ . '/storage/cache/*') ?: []); @rmdir(__DIR__ . '/storage/cache'); echo 1;" > "$C/vider.php"; curl -s -o /dev/null http://localhost/jend-charge/vider.php; rm -rf "$C"; $MY -e "DROP DATABASE IF EXISTS $DB"; }
trap nettoyer EXIT
rsync -a --exclude=.env --exclude=config.env --exclude=.git --exclude='*.zip' --exclude='storage/*' --exclude='uploads/produits/*' --exclude='uploads/voix/*' --exclude='uploads/boutiques/*' --exclude=deploiement/ --exclude=tests/ $H/jend/ $C/
mkdir -p $C/storage; chmod 777 $C/storage $C/uploads/produits
for k in paiement-secret.txt app-key.txt; do openssl rand -hex 32 > $C/storage/$k; done; : > $C/storage/emails.log; chmod 666 $C/storage/*
cat > $C/.env <<E
APP_ENV=dev
APP_URL=http://localhost/jend-charge
DB_HOST=127.0.0.1
DB_PORT=3306
DB_NAME=$DB
DB_USER=root
DB_PASS=
ADMIN_EMAIL=admin@jend.local
MAIL_DRIVER=log
PAIEMENT_FOURNISSEUR=simulation
E
$MY -e "DROP DATABASE IF EXISTS $DB; CREATE DATABASE $DB CHARACTER SET utf8mb4"
T=$(mktemp -d)
$X/bin/php $C/scripts/preparer-installation.php --admin-email=admin@jend.local --demo --sortie=$T/i.sql --env=$T/i.env >/dev/null
$MY $DB < $T/i.sql; rm -rf $T
N=${1:-20000}
# Catalogue réaliste : N produits répartis dans les catégories et les boutiques de démonstration
$MY $DB -e "CREATE TEMPORARY TABLE c (d INT); INSERT INTO c VALUES (0),(1),(2),(3),(4),(5),(6),(7),(8),(9);
CREATE TABLE nombres AS SELECT a.d + 10*b.d + 100*c2.d + 1000*d.d + 10000*e.d + 1 AS i FROM c a, c b, c c2, c d, c e;
SET @nb = (SELECT COUNT(*) FROM boutiques), @nc = (SELECT COUNT(*) FROM categories);
CREATE TEMPORARY TABLE lb AS SELECT id, ROW_NUMBER() OVER (ORDER BY id) - 1 AS r FROM boutiques;
CREATE TEMPORARY TABLE lc AS SELECT id, ROW_NUMBER() OVER (ORDER BY id) - 1 AS r FROM categories;
INSERT INTO produits (boutique_id, categorie_id, nom, slug, description, prix, stock, statut)
SELECT lb.id, lc.id, CONCAT(ELT(1 + n.i % 6, 'Boubou bazin', 'Pagne wax', 'Sac en cuir', 'Téléphone', 'Bissap', 'Sandales'), ' modèle ', n.i),
       CONCAT('produit-charge-', n.i), CONCAT('Description du produit ', n.i, ' : coton, fabriqué à Dakar, livraison rapide.'),
       1000 + (n.i * 37) % 90000, 1 + n.i % 40, 'publie'
  FROM nombres n JOIN lb ON lb.r = n.i % @nb JOIN lc ON lc.r = n.i % @nc WHERE n.i <= $N;
DROP TABLE nombres; UPDATE boutiques SET statut='active';"
echo "produits : $($MY $DB -e 'SELECT COUNT(*) FROM produits')"
B=http://localhost/jend-charge
SLUG=$($MY $DB -e "SELECT slug FROM produits WHERE slug='produit-charge-777'")
CAT=$($MY $DB -e "SELECT slug FROM categories WHERE parent_id IS NULL ORDER BY position LIMIT 1")
for u in "" "produits" "categorie/$CAT" "produit/$SLUG" "recherche?q=wax" "recherche?q=sandales+cuir"; do
  curl -s -o /dev/null -w "vérif /$u → %{http_code} (%{size_download} o)\n" "$B/$u"
done
for c in 1 10 50; do
  echo "== $c visiteur(s) en même temps"
  for u in "" "produits" "categorie/$CAT" "produit/$SLUG" "recherche?q=wax"; do
    R=$($X/bin/ab -q -n $((c*30 < 100 ? 100 : c*30)) -c $c "$B/$u" 2>&1)
    printf "  %-24s %8s pages/s · moyenne %6s ms · 95%% sous %5s ms · échecs %s · non-200 %s\n" "/$u" \
      "$(echo "$R" | awk '/Requests per second/{print $4}')" "$(echo "$R" | awk '/Time per request.*\(mean\)$/{print $4; exit}')" \
      "$(echo "$R" | awk '/^  95%/{print $2}')" "$(echo "$R" | awk '/Failed requests/{print $3}')" "$(echo "$R" | awk '/Non-2xx/{print $3}')"
  done
done
