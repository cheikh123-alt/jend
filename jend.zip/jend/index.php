<?php
declare(strict_types=1);

// Contrôleur frontal : toutes les URL passent ici (voir .htaccess).
require __DIR__ . '/includes/bootstrap.php';

$chemin = trim((string) parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH), '/');
$base   = trim(base_path(), '/');
if ($base !== '' && strpos($chemin, $base) === 0) {
    $chemin = trim(substr($chemin, strlen($base)), '/');
}

// Rappels mensuels de « la dépense du mois » (au plus une fois par heure, sans tâche planifiée sur l'hébergement)
try {
    depenses_rappels();
} catch (Throwable $e) {
    error_log('Jënd — rappels des dépenses : ' . $e->getMessage());
}

// URL fixes => [fichier du dossier pages/, variables transmises à la page]
$routes = [
    ''               => ['accueil'],
    'robots.txt'     => ['robots'],
    'cgu'                => ['info', ['doc' => 'cgu']],
    'cgv'                => ['info', ['doc' => 'cgv']],
    'conditions-vendeur' => ['info', ['doc' => 'conditions-vendeur']],
    'livraison-retours'  => ['info', ['doc' => 'livraison-retours']],
    'confidentialite'    => ['info', ['doc' => 'confidentialite']],
    'mentions-legales'   => ['info', ['doc' => 'mentions-legales']],
    'a-propos'           => ['info', ['doc' => 'a-propos']],
    'contact'            => ['contact'],
    'aide'               => ['aide'],
    'envoyer-au-pays'    => ['diaspora'],
    'depense'            => ['depenses'],
    'alertes'            => ['alertes'],
    'mode-leger'         => ['mode_leger'],
    'dev/emails'         => ['dev_emails'],
    'depense/nouvelle'   => ['depense_nouvelle'],
    'admin/messages'     => ['admin_messages'],
    'frais-commissions'  => ['info', ['doc' => 'frais-commissions']],
    'paiements-vendeurs' => ['info', ['doc' => 'paiements-vendeurs']],
    'produits'       => ['liste', ['mode' => 'tous']],
    'recherche'      => ['liste', ['mode' => 'recherche']],
    'categories'     => ['categories'],
    'panier'         => ['panier'],
    'panier/ajouter' => ['panier_ajouter'],
    'panier/modifier'=> ['panier_modifier'],
    'connexion'      => ['connexion'],
    'inscription'    => ['inscription'],
    'confirmer-email' => ['email_confirmer'],
    'deconnexion'    => ['deconnexion'],
    'compte'         => ['compte'],
    'commande'       => ['commande'],
    'commande/annuler' => ['commande_annuler'],
    'paiement/webhook' => ['paiement_webhook'],
    'compte/adresses'  => ['compte_adresses'],
    'compte/profil'    => ['compte_profil'],
    'vendeur/profil'   => ['vendeur_profil'],
    'vendeur/offres'   => ['vendeur_offres'],
    'offres'           => ['offres'],
    'sur-mesure'       => ['mesure_client'],
    'vendeur/sur-mesure' => ['vendeur_mesure'],
    'compte/securite'  => ['compte_securite'],
    'connexion/2fa'    => ['connexion_2fa'],
    'favoris'          => ['favoris'],
    'favoris/basculer' => ['favoris_basculer'],
    'avis/ajouter'     => ['avis_ajouter'],
    'mot-de-passe-oublie' => ['mdp_oublie'],
    'vendre'              => ['vendre'],
    'vendeur'             => ['vendeur_accueil'],
    'vendeur/statut'      => ['vendeur_statut'],
    'vendeur/fetes'       => ['vendeur_fetes'],
    'vendeur/releves'     => ['vendeur_releves'],
    'vendeur/kit'         => ['vendeur_kit'],
    'vendeur/affiche'     => ['vendeur_affiche'],
    'admin/fetes'         => ['admin_fetes'],
    'admin/croissance'    => ['admin_croissance'],
    'vendeur/boutique'    => ['vendeur_boutique'],
    'vendeur/produits'    => ['vendeur_produits'],
    'vendeur/produits/nouveau' => ['vendeur_produit_form', ['parametre' => null]],
    'vendeur/commandes'   => ['vendeur_commandes'],
    'vendeur/gains'       => ['vendeur_gains'],
    'simple'              => ['simple_accueil'],          // mode simple de l'espace vendeur (includes/simple.php)
    'simple/produit'      => ['simple_produit'],
    'simple/produits'     => ['simple_produits'],
    'simple/commandes'    => ['simple_commandes'],
    'simple/argent'       => ['simple_argent'],
    'simple/mode'         => ['simple_mode'],
    'notifications/push'  => ['notifications_push'],     // abonnement du téléphone aux notifications (includes/push.php)
    'admin/relances'      => ['admin_relances'],
    'vendeur/whatsapp'    => ['vendeur_whatsapp'],
    'admin/commissions'   => ['admin_commissions'],
    'admin'               => ['admin_accueil'],
    'admin/boutiques'     => ['admin_boutiques'],
    'admin/produits'      => ['admin_produits'],
    'admin/commandes'     => ['admin_commandes'],
    'admin/retraits'      => ['admin_retraits'],
    'admin/retraits/export' => ['admin_retraits_export'],
    'admin/categories'    => ['admin_categories'],
    'admin/zones'         => ['admin_zones'],
    'admin/litiges'       => ['admin_litiges'],
    'admin/parametres'    => ['admin_parametres'],
    'admin/tresorerie'    => ['admin_tresorerie'],
    'admin/caisse'        => ['admin_caisse'],
    'admin/offres'        => ['admin_offres'],
    'litiges'             => ['litiges'],
    'admin/courses'       => ['admin_courses'],
    'admin/livreurs'      => ['admin_livreurs'],
    'livreur'             => ['livreur_accueil'],
    'livreur/connexion'   => ['livreur_connexion'],
    'livreur/historique'  => ['livreur_historique'],
    'livreur/profil'      => ['livreur_profil'],
    'livreur/etat'        => ['livreur_etat'],
    'livreur/mot-de-passe' => ['livreur_mdp'],
    'admin/journal'       => ['admin_journal'],
];

// URL à paramètre (ex : produit/pagne-wax) => [fichier, variables] ; $parametre = valeur capturée
$motifs = [
    '#^categorie/([a-z0-9-]+)$#' => ['liste', ['mode' => 'categorie']],
    '#^produit/([a-z0-9-]+)$#'   => ['produit', []],
    '#^boutique/([a-z0-9-]+)$#'  => ['boutique_publique', []],
    '#^fete/([a-z0-9-]+)$#'      => ['fete', []],
    '#^position/([a-f0-9]{32})$#' => ['position', []],
    '#^depense/(\d+)$#'          => ['depense_voir', []],
    '#^payer/([a-z0-9-]+)$#'     => ['payer', []],
    '#^aide/suivi/([a-f0-9]{64})$#' => ['aide_fil', ['parSuivi' => true]],
    '#^aide/(AIDE-[0-9A-Fa-f]{8})$#' => ['aide_fil', []],
    '#^sur-mesure/([a-z0-9-]+)$#' => ['mesure_nouvelle', []],
    '#^livreur/course/(\d+)$#'   => ['livreur_course', []],
    '#^litige/photo/(\d+)$#'     => ['litige_photo', []],
    '#^litige/nouveau/(\d+)$#'   => ['litige_nouveau', []],
    '#^litige/(LIT-[A-Fa-f0-9]{8})$#' => ['litige_voir', []],
    '#^commande/([A-Za-z0-9-]+)$#' => ['commande_voir', []],
    '#^vendeur/produits/(\d+)/modifier$#' => ['vendeur_produit_form', []],
    '#^reinitialiser/([a-f0-9]{64})$#' => ['mdp_reinitialiser', []],
    '#^confirmer-email/([a-f0-9]{64})$#' => ['email_confirmer', []],
    '#^paiement/simulation/(SIM-[a-f0-9]{24})$#' => ['paiement_simulation', []],
    '#^paiement/retour/([A-Za-z0-9-]+)$#' => ['paiement_retour', []],
    '#^paiement/aller/([A-Za-z0-9-]+)$#' => ['paiement_aller', []],
    '#^paiement/([A-Za-z0-9-]+)$#' => ['paiement_demarrer', []],
];

$page = null;
$vars = [];
$parametre = null;

if (isset($routes[$chemin])) {
    [$page, $vars] = $routes[$chemin] + [1 => []];
} else {
    foreach ($motifs as $motif => [$fichier, $v]) {
        if (preg_match($motif, $chemin, $m)) {
            $page = $fichier;
            $vars = $v;
            $parametre = $m[1];
            break;
        }
    }
}

if ($page === null) {
    http_response_code(404);
    require __DIR__ . '/pages/404.php';
    exit;
}

extract($vars);
require __DIR__ . '/pages/' . $page . '.php';
