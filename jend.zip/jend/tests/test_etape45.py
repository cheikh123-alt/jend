"""Étape 45 : suivi professionnel d'un signalement (étapes, engagement de 48 h, chronologie, précisions du client)."""
import sys
from lib import *

S = Suite("Étape 45 — suivi des signalements", ["ad-t45@jend.local", "cl-t45@jend.local", "c2-t45@jend.local", "va-t45@jend.local"])
E = dict(zip(["ad", "cl", "c2", "va"], S.emails))
LOG = lambda: (JEND / "storage" / "emails.log").read_text() if (JEND / "storage" / "emails.log").exists() else ""
try:
    S.nettoyer()
    sql("DELETE FROM produits WHERE slug='produit-t45'"); sql("DELETE FROM boutiques WHERE slug='boutique-t45'"); sql("DELETE FROM zones_livraison WHERE nom='Zone T45'")
    sql("INSERT INTO zones_livraison (nom, region, frais, delai_jours) VALUES ('Zone T45', 'Touba', 1000, 1)")
    zone = int(sql("SELECT id FROM zones_livraison WHERE nom='Zone T45'"))
    pw = mot_de_passe()
    for k, nom, role in (("ad", "Admin T45", "admin"), ("cl", "Cliente T45", "client"), ("c2", "Autre T45", "client"), ("va", "Vendeur T45", "vendeur")):
        sql(f"INSERT INTO users (nom,email,mot_de_passe,role) VALUES ('{nom}','{E[k]}','{hash_mdp(pw)}','{role}')")
    sql(f"INSERT INTO boutiques (user_id,nom,slug,statut,commission_pct) SELECT id,'Boutique T45','boutique-t45','active',1 FROM users WHERE email='{E['va']}'")
    sql("INSERT INTO produits (boutique_id,categorie_id,nom,slug,description,prix,stock,statut) SELECT b.id,(SELECT MIN(id) FROM categories),'Produit T45','produit-t45','x',8000,20,'publie' FROM boutiques b WHERE b.slug='boutique-t45'")
    prod = sql("SELECT id FROM produits WHERE slug='produit-t45'")
    AD, C, C2 = Client(), Client(), Client()
    for cl, k in ((AD, "ad"), (C, "cl"), (C2, "c2")):
        cl.post("connexion", {"email": E[k], "mot_de_passe": pw})
    txt = lambda cl, u: cl.get(u)[1].replace("&#039;", "'").replace(" ", " ").replace("&nbsp;", " ").replace("\xa0", " ")
    C.req("panier/ajouter", {"csrf": C.token("produits"), "produit_id": prod, "quantite": 1, "retour": "/jend/produits"})
    _, _, hd = C.post("commande", {"nom": "Cliente T45", "telephone": "78 000 11 45", "zone_id": zone, "adresse": "Rue 45 Touba", "methode": "wave"})
    ref = hd["Location"].rsplit("/", 1)[-1]
    sql(f"UPDATE commande_boutiques cb JOIN commandes c ON c.id=cb.commande_id SET cb.statut='livree', cb.livre_le=NOW(), c.statut_paiement='paye', c.statut='terminee' WHERE c.reference='{ref}'")
    cb = sql(f"SELECT cb.id FROM commande_boutiques cb JOIN commandes c ON c.id=cb.commande_id WHERE c.reference='{ref}'")
    _, _, hd = C.post(f"litige/nouveau/{cb}", {"motif": "non_recu", "description": "Le livreur a marqué le colis livré mais je n'ai rien reçu."}, page_token=f"litige/nouveau/{cb}")
    lref = hd["Location"].rsplit("/", 1)[-1]
    lid = sql(f"SELECT id FROM litiges WHERE reference='{lref}'")
    ev = lambda: sql(f"SELECT GROUP_CONCAT(type ORDER BY id) FROM litige_evenements WHERE litige_id={lid}")

    S.titre("OUVERTURE DU DOSSIER")
    S.check("l'ouverture est inscrite dans la chronologie (auteur : client, texte du signalement)", ev() == "cree" and sql(f"SELECT auteur FROM litige_evenements WHERE litige_id={lid}") == "client")
    h = txt(C, f"litige/{lref}")
    S.check("la page montre les 4 étapes (ouvert, examen, décision, clôture) avec l'étape en cours", all(x in h for x in ("Dossier ouvert", "Examen par l'équipe", "Dossier clôturé", 'aria-current="step"')))
    S.check("engagement de 48 h : échéance et jauge du temps écoulé", "Engagement de réponse sous 48 h" in h and "au plus tard le" in h and "lit-jauge" in h)
    S.check("encart « Prochaine étape », résumé du dossier et garantie de l'argent bloqué", "Prochaine étape" in h and "Boutique T45" in h and "reste bloqué" in h)
    S.check("aucun style ni script en ligne (politique de sécurité)", " style=" not in h and "<script>" not in h and " onclick" not in h)

    S.titre("PRÉCISIONS DU CLIENT")
    avant = len(LOG())
    C.post(f"litige/{lref}", {"message": "Le vendeur m'a appelé, <b>il dit</b> que le colis est chez un voisin."}, page_token=f"litige/{lref}")
    h = txt(C, f"litige/{lref}")
    S.check("le client ajoute une précision : elle apparaît, échappée, signée « Vous »", "Précision ajoutée par le client" in h and "&lt;b&gt;il dit&lt;/b&gt;" in h and ">Vous<" in h)
    S.check("l'équipe est prévenue par e-mail", "Nouvelle précision sur le signalement " + lref in LOG()[avant:])
    C.post(f"litige/{lref}", {"message": "ok"}, page_token=f"litige/{lref}")
    S.check("message trop court refusé", sql(f"SELECT COUNT(*) FROM litige_evenements WHERE litige_id={lid} AND type='message_client'") == "1")
    C2.post(f"litige/{lref}", {"message": "Je m'immisce dans ce dossier."}, page_token="compte")
    S.check("un autre client ne peut ni voir ni écrire dans le dossier", C2.get(f"litige/{lref}")[0] == 404 and sql(f"SELECT COUNT(*) FROM litige_evenements WHERE litige_id={lid} AND type='message_client'") == "1")

    S.titre("TRAITEMENT PAR L'ÉQUIPE")
    adm = lambda d: AD.post("admin/litiges", {"id": lid, **d}, page_token=f"admin/litiges?id={lid}")
    h = txt(AD, f"admin/litiges?id={lid}")
    S.check("l'admin voit la même chronologie, avec le nom du client", "Historique du dossier" in h and "Cliente T45" in h and "colis est chez un voisin" in h)
    adm({"action": "repondre", "message": "Nous contactons le vendeur et le livreur."})
    adm({"action": "repondre", "message": "Le vendeur confirme un problème de livraison."})
    S.check("1re réponse = prise en charge, 2e = message de l'équipe", ev() == "cree,message_client,examen,message_equipe")
    h = txt(C, f"litige/{lref}")
    S.check("le client voit « Première réponse en … (engagement de 48 h respecté) »", "Première réponse en" in h and "respecté" in h and "lit-jauge" not in h)
    adm({"action": "rembourser", "message": "Nous vous remboursons intégralement.", "montant": 9000, "a_charge_vendeur": 1})
    S.check("la décision est inscrite avec son montant", ev().endswith("rembourse") and sql(f"SELECT montant FROM litige_evenements WHERE litige_id={lid} AND type='rembourse'") == "9000")
    h = txt(C, f"litige/{lref}")
    S.check("étapes : « Remboursement accepté » puis « Argent renvoyé » en cours", "Décision : remboursement accepté" in h and "Argent renvoyé" in h and "9 000" in h)
    C.post(f"litige/{lref}", {"message": "Merci, j'attends l'argent."}, page_token=f"litige/{lref}")
    S.check("dossier tranché : le client ne peut plus y écrire (formulaire absent)", sql(f"SELECT COUNT(*) FROM litige_evenements WHERE litige_id={lid} AND type='message_client'") == "1" and "Ajouter une précision" not in h)
    adm({"action": "confirmer_envoi", "message": ""})
    h = txt(C, f"litige/{lref}")
    S.check("« Remboursement envoyé » ajouté ; plus aucune étape en cours", ev().endswith("argent_envoye") and "Remboursement envoyé" in h and 'aria-current="step"' not in h)

    S.titre("RETARD ET MIGRATION")
    sql(f"UPDATE litiges SET repondu_le = created_at + INTERVAL 60 HOUR WHERE id={lid}")
    S.check("réponse tardive signalée honnêtement (« au-delà des 48 h promises »)", "au-delà des 48 h promises" in txt(C, f"litige/{lref}"))
    mig = (JEND / "database" / "migrations" / "024_litige_evenements.sql").read_text()
    S.check("la migration 024 crée la table et reprend les anciens signalements", "CREATE TABLE litige_evenements" in mig and mig.count("INSERT INTO litige_evenements") == 4)
finally:
    ok = S.fin()
    sql("DELETE FROM produits WHERE slug='produit-t45'"); sql("DELETE FROM boutiques WHERE slug='boutique-t45'"); sql("DELETE FROM zones_livraison WHERE nom='Zone T45'")
sys.exit(0 if ok else 1)
