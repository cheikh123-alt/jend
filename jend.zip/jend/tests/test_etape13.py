"""Étape 13 : pages juridiques et d'information, consentement à l'inscription et à l'ouverture de boutique, mentions légales."""
import os, re, subprocess, sys
from lib import *

S = Suite("Étape 13 — contenu juridique", ["a-t13@jend.local", "b-t13@jend.local"])
E = S.emails
DOCS = {"cgu": "Conditions générales d'utilisation", "cgv": "Conditions générales de vente", "conditions-vendeur": "Conditions générales des vendeurs",
        "livraison-retours": "Livraison, annulation et retours", "confidentialite": "Politique de confidentialité", "mentions-legales": "Mentions légales",
        "a-propos": "À propos de Jënd", "contact": "Aide et contact", "frais-commissions": "Frais et commissions", "paiements-vendeurs": "Paiements et reversements"}
try:
    S.nettoyer()
    S.titre("PAGES JURIDIQUES")
    A = Client(BASE)
    for url, titre in DOCS.items():
        s, corps, hd = A.get(url)
        S.check(f"/{url} s'affiche (200) avec son titre", s == 200 and titre.replace("'", "&#039;") in corps or (s == 200 and titre in corps))
        liens_morts = re.findall(r'href="[^"]*@@', corps)
        S.check(f"/{url} : aucun lien interne cassé", not liens_morts and "-lien\"" not in corps)
        S.check(f"/{url} : aucune ressource externe", not re.search(r'(src|href)="https?://(?!localhost|paydunya\.com/)', corps) or "mailto" in corps)
    s, corps, _ = A.get("livraison-retours")
    S.check("la page livraison liste les zones (Touba et régions) depuis la base", "Darou Marnane" in corps and "Touba" in corps and "Ziguinchor" in corps and "tout le Sénégal" in corps)
    S.check("la commission annoncée suit le .env (8 % par défaut)", "8 %" in A.get("frais-commissions")[1])
    S.check("mentions légales : champs non renseignés signalés « À COMPLÉTER »", "À COMPLÉTER" in A.get("mentions-legales")[1] or "NINEA" in A.get("mentions-legales")[1])
    S.check("pied de page : liens vers CGU, CGV, confidentialité, mentions légales", all(f'/{u}"' in A.get("")[1] for u in ("cgu", "cgv", "confidentialite", "mentions-legales")))
    S.check("plus aucun lien « # » vide dans le pied de page", 'href="#"' not in A.get("")[1])

    S.titre("CONSENTEMENT")
    pw = "Mdp-test-13579"
    s, corps, _ = A.get("inscription")
    S.check("le formulaire d'inscription contient la case d'acceptation", 'name="accepte"' in corps)
    s, corps, _ = A.post("inscription", {"nom": "Alice T13", "email": E[0], "mot_de_passe": pw, "mot_de_passe2": pw, "accepte": ""})
    S.check("inscription refusée sans accepter les conditions", s == 200 and "accepter les conditions" in corps)
    S.check("aucun compte créé dans ce cas", sql(f"SELECT COUNT(*) FROM users WHERE email='{E[0]}'") == "0")
    s, _, _ = A.post("inscription", {"nom": "Alice T13", "email": E[0], "mot_de_passe": pw, "mot_de_passe2": pw})
    S.check("inscription acceptée avec la case cochée", s == 302 and sql(f"SELECT COUNT(*) FROM users WHERE email='{E[0]}'") == "1")
    s, corps, _ = A.get("vendre")
    S.check("l'ouverture de boutique propose la case des conditions vendeur", 'name="accepte"' in corps and "conditions-vendeur" in corps)
    s, corps, _ = A.post("vendre", {"nom": "Boutique T13", "description": "", "telephone": "77 123 45 67", "accepte": ""})
    S.check("boutique refusée sans accepter les conditions vendeur", s == 200 and "conditions générales des vendeurs" in corps
            and sql("SELECT COUNT(*) FROM boutiques WHERE nom='Boutique T13'") == "0")
    s, _, _ = A.post("vendre", {"nom": "Boutique T13", "description": "", "telephone": "77 123 45 67"})
    S.check("boutique créée en acceptant", s == 302 and sql("SELECT COUNT(*) FROM boutiques WHERE nom='Boutique T13'") == "1")
    S.check("la nouvelle boutique reçoit la commission par défaut du .env (8)", sql("SELECT commission_pct FROM boutiques WHERE nom='Boutique T13'") in ("8.00", "8"))

    S.titre("OFFRE DE LANCEMENT (COMMISSION_DEFAUT=0)")
    import tempfile
    def rendu(valeur, doc):
        with tempfile.NamedTemporaryFile("w", suffix=".env", delete=False) as f:
            f.write(f"COMMISSION_DEFAUT={valeur}\n"); chemin = f.name
        code = f'putenv("JEND_ENV_FILE={chemin}"); require "{JEND}/includes/env.php"; require "{JEND}/includes/helpers.php"; require "{JEND}/includes/vendeur.php"; require "{JEND}/includes/legal.php"; echo commission_defaut(), "|", contenu_document("{doc}");'
        r = subprocess.run([PHP, "-r", code], capture_output=True, text=True, timeout=60)
        os.unlink(chemin)
        return r.stdout, r.stderr
    out, err = rendu("0", "frais-commissions")
    S.check("COMMISSION_DEFAUT=0 : la page annonce 0 % au lancement et un préavis de 30 jours", out.startswith("0|") and "0 % de commission" in out and "30 jours" in out, err)
    out, _ = rendu("0", "conditions-vendeur")
    S.check("COMMISSION_DEFAUT=0 : conditions vendeur cohérentes (0 %, préavis)", "commission est de 0 %" in out and "30 jours avant" in out)
    out, _ = rendu("5", "frais-commissions")
    S.check("COMMISSION_DEFAUT=5 : la page annonce 5 % et l'exemple (1 000 FCFA)", "5 %" in out and "1 000" in out.replace("\u202f", " ").replace("\xa0", " "))
    out, _ = rendu("abc", "frais-commissions")
    S.check("valeur invalide : retombe sur 8 %", out.startswith("8|"))
    out, _ = rendu("99", "frais-commissions")
    S.check("valeur hors limites (99) : retombe sur 8 %", out.startswith("8|"))

    S.titre("VÉRIFICATEUR DE PRODUCTION")
    r = subprocess.run([PHP, str(JEND / "scripts/verifier-production.php")], capture_output=True, text=True, timeout=120)
    S.check("le vérificateur signale les mentions légales incomplètes", "Mentions légales incomplètes" in r.stdout)
finally:
    ok = S.fin()
sys.exit(0 if ok else 1)
