"""Étape 38 : authentification (connexion, limites d'essais, sessions, temps de réponse)."""
import sys, time
from lib import *

S = Suite("Étape 38 — authentification", ["cl-t38@jend.local", "b2-t38@jend.local"])
E = dict(zip(["cl", "b2"], S.emails))
try:
    S.nettoyer()
    sql("DELETE FROM parametres WHERE cle='auth_faux_hash'"); sql("DELETE FROM limites WHERE cle LIKE 'login:%'")
    pw = mot_de_passe()
    sql(f"INSERT INTO users (nom,email,mot_de_passe,role) VALUES ('Cliente T38','{E['cl']}','{hash_mdp(pw)}','client')")
    sql(f"INSERT INTO users (nom,email,mot_de_passe,role,actif) VALUES ('Bloquee T38','{E['b2']}','{hash_mdp(pw)}','client',0)")

    S.titre("CONNEXION")
    A = Client()
    s, h, _ = A.post("connexion", {"email": E["cl"], "mot_de_passe": "mauvais-mot-de-passe"}, page_token="connexion")
    s2, h2, _ = A.post("connexion", {"email": "inconnu-t38@jend.local", "mot_de_passe": "mauvais-mot-de-passe"}, page_token="connexion")
    S.check("mauvais mot de passe et e-mail inconnu donnent exactement le même message", "E-mail ou mot de passe incorrect" in h and "E-mail ou mot de passe incorrect" in h2)
    S.check("une empreinte factice au réglage du serveur est créée pour les e-mails inconnus", len(sql("SELECT valeur FROM parametres WHERE cle='auth_faux_hash'")) == 60)
    def duree(email):
        c = Client(); tok = c.token("connexion"); t = time.time()
        c.req("connexion", {"csrf": tok, "email": email, "mot_de_passe": "essai-de-mot-de-passe"}); return time.time() - t
    sql("DELETE FROM limites WHERE cle LIKE 'login:%'")
    connu = sorted(duree(E["cl"]) for _ in range(3))[1]
    sql("DELETE FROM limites WHERE cle LIKE 'login:%'")
    inconnu = sorted(duree(f"inconnu{i}-t38@jend.local") for i in range(3))[1]
    S.check(f"le temps de réponse ne distingue pas un e-mail connu d'un inconnu ({connu*1000:.0f} ms / {inconnu*1000:.0f} ms)", abs(connu - inconnu) < 0.06, f"{connu:.3f} / {inconnu:.3f}")
    sql("DELETE FROM limites WHERE cle LIKE 'login:%'")
    s, h, hd = Client().post("connexion", {"email": E["b2"], "mot_de_passe": pw}, page_token="connexion")
    S.check("un compte désactivé ne peut pas se connecter, même avec le bon mot de passe", s == 200 and "incorrect" in h)
    c = Client(); tok = c.token("connexion")
    s, _, hd = c.req("connexion", {"csrf": "jeton-invente", "email": E["cl"], "mot_de_passe": pw})
    S.check("sans jeton CSRF valide, la connexion est refusée", "Location" not in hd or "/compte" not in hd.get("Location", ""))
    s, _, hd = c.req("connexion", {"csrf": tok, "email": E["cl"], "mot_de_passe": pw, "retour": "https://site-pirate.example/vol"})
    S.check("après connexion, une adresse de retour externe est ignorée (pas de redirection vers un autre site)", "site-pirate" not in hd.get("Location", "") and hd.get("Location", "").startswith("/"))
    S.check("la session est ouverte", "Cliente" in c.get("compte")[1] or c.get("compte")[0] == 200)

    S.titre("FORCE BRUTE")
    sql("DELETE FROM limites WHERE cle LIKE 'login:%'")
    B = Client()
    for _ in range(5):
        B.post("connexion", {"email": E["cl"], "mot_de_passe": "essai-faux"}, page_token="connexion")
    s, h, hd = B.post("connexion", {"email": E["cl"], "mot_de_passe": pw}, page_token="connexion")
    S.check("après 5 essais ratés sur un e-mail, même le bon mot de passe est refusé pendant 15 minutes", "Trop de tentatives" in h and "Location" not in hd)
    sql("DELETE FROM limites WHERE cle LIKE 'login:%'")

    S.titre("SESSION")
    c2 = Client(); c2.post("connexion", {"email": E["cl"], "mot_de_passe": pw}, page_token="connexion")
    S.check("connecté : la page « Mon compte » s'ouvre", c2.get("compte")[0] == 200)
    sql(f"UPDATE users SET session_version = session_version + 1 WHERE email='{E['cl']}'")
    S.check("après un changement de mot de passe ailleurs, les anciennes sessions sont coupées", c2.get("compte")[0] in (302, 303))
    c3 = Client(); c3.post("connexion", {"email": E["cl"], "mot_de_passe": pw}, page_token="connexion")
    c3.req("deconnexion", {"csrf": "faux"})
    S.check("une déconnexion forgée (sans jeton) est ignorée", c3.get("compte")[0] == 200)
    c3.post("deconnexion", {}, page_token="compte")
    S.check("la déconnexion ferme vraiment la session", c3.get("compte")[0] in (302, 303))
finally:
    ok = S.fin()
    sql("DELETE FROM limites WHERE cle LIKE 'login:%'"); sql("DELETE FROM parametres WHERE cle='auth_faux_hash'")
sys.exit(0 if ok else 1)
