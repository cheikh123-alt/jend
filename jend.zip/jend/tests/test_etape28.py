"""Étape 28 : paiement à la livraison désactivé par défaut (l'argent passe d'abord par Jënd) et activable par l'administrateur."""
import sys
from lib import *

S = Suite("Étape 28 — paiement à la livraison désactivé", ["cl-t28@jend.local", "va-t28@jend.local", "ad-t28@jend.local"])
E = dict(zip(["cl", "va", "ad"], S.emails))
try:
    S.nettoyer()
    sql("DELETE FROM parametres WHERE cle='paiement_livraison'")          # situation réelle : réglage jamais touché
    sql("DELETE FROM produits WHERE slug='produit-t28'"); sql("DELETE FROM boutiques WHERE slug='boutique-t28'")
    sql("DELETE FROM zones_livraison WHERE nom='Zone T28'")
    sql("INSERT INTO zones_livraison (nom, region, frais, delai_jours) VALUES ('Zone T28', 'Touba', 500, 1)")
    zone = int(sql("SELECT id FROM zones_livraison WHERE nom='Zone T28'"))
    pw = mot_de_passe()
    for k, nom, role in (("cl", "Cliente T28", "client"), ("va", "Vendeur T28", "vendeur"), ("ad", "Admin T28", "admin")):
        sql(f"INSERT INTO users (nom,email,mot_de_passe,role) VALUES ('{nom}','{E[k]}','{hash_mdp(pw)}','{role}')")
    sql(f"INSERT INTO boutiques (user_id,nom,slug,statut,commission_pct) SELECT id,'Boutique T28','boutique-t28','active',3 FROM users WHERE email='{E['va']}'")
    sql("INSERT INTO produits (boutique_id,categorie_id,nom,slug,description,prix,stock,statut) SELECT b.id,(SELECT MIN(id) FROM categories),'Produit T28','produit-t28','x',10000,50,'publie' FROM boutiques b WHERE b.slug='boutique-t28'")
    prod = int(sql("SELECT id FROM produits WHERE slug='produit-t28'"))
    C, AD = Client(), Client()
    C.post("connexion", {"email": E["cl"], "mot_de_passe": pw}); AD.post("connexion", {"email": E["ad"], "mot_de_passe": pw})
    nb = lambda: sql(f"SELECT COUNT(*) FROM commandes c JOIN users u ON u.id=c.client_id WHERE u.email='{E['cl']}'")
    def commander(methode):
        tok = C.token("produits"); C.req("panier/ajouter", {"csrf": tok, "produit_id": prod, "quantite": 1, "retour": "/jend/produits"})
        return C.post("commande", {"nom": "Cliente T28", "telephone": "78 000 11 28", "zone_id": zone, "adresse": "Rue 28 Touba", "methode": methode, "acompte_methode": "wave"})

    S.titre("PAR DÉFAUT : PAIEMENT EN LIGNE SEULEMENT")
    tok = C.token("produits"); C.req("panier/ajouter", {"csrf": tok, "produit_id": prod, "quantite": 1, "retour": "/jend/produits"})
    h = C.get("commande")[1]
    S.check("la page de commande ne propose plus « Paiement à la livraison » ni d'acompte", 'value="livraison"' not in h and "Paiement à la livraison" not in h and 'name="acompte_methode"' not in h)
    S.check("elle propose toujours Wave", 'value="wave"' in h)
    s, h, _ = commander("livraison")
    S.check("forcer le paiement à la livraison par une requête directe est refusé", s == 200 and nb() == "0")
    s, _, hd = commander("wave")
    S.check("un paiement en ligne passe normalement", s == 302 and nb() == "1")
    pub = Client()
    S.check("la page d'accueil et les conditions ne parlent plus d'espèces à la livraison", "Espèces à la livraison" not in pub.get("")[1] and "Paiement à la livraison disponible" not in pub.get("")[1] and "espèces à la réception" not in pub.get("cgv")[1] and "Paiement à la livraison (espèces)" not in pub.get("paiements-vendeurs")[1])

    S.titre("L'ADMINISTRATEUR PEUT LE RÉACTIVER")
    S.check("page Paramètres : carte « Paiement à la livraison » désactivée", "Proposer le paiement à la livraison" in AD.get("admin/parametres")[1])
    C.post("admin/parametres", {"action": "paiement_livraison", "actif": "1"}, page_token="compte")
    S.check("un client ne peut pas changer ce réglage", sql("SELECT COUNT(*) FROM parametres WHERE cle='paiement_livraison' AND valeur='1'") == "0")
    AD.post("admin/parametres", {"action": "paiement_livraison", "actif": "1"})
    S.check("l'admin l'active : réglage enregistré et journalisé", sql("SELECT valeur FROM parametres WHERE cle='paiement_livraison'") == "1" and int(sql("SELECT COUNT(*) FROM journal_admin WHERE action='paiement_livraison_active'")) == 1)
    tok = C.token("produits"); C.req("panier/ajouter", {"csrf": tok, "produit_id": prod, "quantite": 1, "retour": "/jend/produits"})
    h = C.get("commande")[1]
    S.check("activé : l'option réapparaît avec l'acompte", 'value="livraison"' in h and 'name="acompte_methode"' in h)
    AD.post("admin/parametres", {"action": "paiement_livraison"})
    S.check("l'admin le désactive de nouveau", sql("SELECT valeur FROM parametres WHERE cle='paiement_livraison'") == "0")
finally:
    sql("DELETE FROM parametres WHERE cle='paiement_livraison'")
    ok = S.fin()
    sql("DELETE FROM produits WHERE slug='produit-t28'"); sql("DELETE FROM boutiques WHERE slug='boutique-t28'")
    sql("DELETE FROM zones_livraison WHERE nom='Zone T28'")
    sql("DELETE FROM journal_admin WHERE action IN ('paiement_livraison_active','paiement_livraison_desactive')")
sys.exit(0 if ok else 1)
