"""Étape 14 : livraison dans tout le Sénégal (Touba + régions), zones gérées par l'administrateur."""
import sys
from lib import *

S = Suite("Étape 14 — zones de livraison (tout le Sénégal)", ["ad-t14@jend.local", "cl-t14@jend.local"])
E = S.emails
try:
    S.nettoyer()
    sql("DELETE FROM zones_livraison WHERE nom LIKE 'Zone T14%'")
    sql("DELETE FROM journal_admin WHERE detail LIKE 'Zone T14%'")
    S.titre("LIVRAISON DANS TOUT LE SÉNÉGAL")
    S.check("au moins 12 villes ou régions actives, dont Touba (9 quartiers)", int(sql("SELECT COUNT(DISTINCT region) FROM zones_livraison WHERE actif=1")) >= 12 and int(sql("SELECT COUNT(*) FROM zones_livraison WHERE actif=1 AND region='Touba'")) >= 5)
    C = Client(BASE)
    pw = mot_de_passe()
    C.post("inscription", {"nom": "Client T14", "email": E[1], "mot_de_passe": pw, "mot_de_passe2": pw})
    h = C.get("")[1]
    S.check("bandeau : « Livraison à tout le Sénégal »", "Livraison à <strong>tout le Sénégal</strong>" in h)
    adr = C.get("compte/adresses")[1]
    S.check("les zones sont groupées par ville (Touba, Dakar, Ziguinchor…)", '<optgroup label="Touba">' in adr and '<optgroup label="Dakar">' in adr and "Ziguinchor" in adr and "Dakar Plateau" in adr)
    sql("INSERT INTO zones_livraison (nom, region, frais, delai_jours, actif) VALUES ('Zone T14-inactive', 'Kaolack', 1000, 2, 0)")
    inactive = sql("SELECT id FROM zones_livraison WHERE nom='Zone T14-inactive'")
    s, h, _ = C.post("compte/adresses", {"action": "ajouter", "zone_id": inactive, "telephone": "771234567", "adresse": "Rue test zone inactive"})
    S.check("adresse dans une zone désactivée refusée", "Choisissez une zone" in h)

    S.titre("ADMINISTRATION DES ZONES")
    AD = Client(BASE)
    mdp = mot_de_passe()
    sql(f"INSERT INTO users (nom,email,mot_de_passe,role) VALUES ('Admin T14','{E[0]}','{hash_mdp(mdp)}','admin')")
    AD.post("connexion", {"email": E[0], "mot_de_passe": mdp})
    S.check("l'onglet Livraison s'affiche pour l'admin", AD.get("admin/zones")[0] == 200 and "Ajouter une zone" in AD.get("admin/zones")[1])
    S.check("client simple : /admin/zones → 404", C.get("admin/zones")[0] == 404)
    s, _, _ = C.post("admin/zones", {"action": "ajouter", "nom": "Zone T14 pirate", "frais": "0", "delai_jours": "1"}, page_token="compte")
    S.check("client simple ne peut pas ajouter de zone", sql("SELECT COUNT(*) FROM zones_livraison WHERE nom='Zone T14 pirate'") == "0")

    AD.post("admin/zones", {"action": "ajouter", "nom": "Zone T14 Nord", "region": "Touba", "frais": "1200", "delai_jours": "2"})
    S.check("l'admin ajoute une zone", sql("SELECT CONCAT(frais,'/',delai_jours,'/',actif) FROM zones_livraison WHERE nom='Zone T14 Nord'") == "1200/2/1")
    S.check("elle est aussitôt proposée aux clients", "Zone T14 Nord" in C.get("compte/adresses")[1])
    S.check("le journal admin garde la trace", int(sql("SELECT COUNT(*) FROM journal_admin WHERE action='zone_ajoutee' AND detail LIKE 'Zone T14 Nord%'")) == 1)
    zid = sql("SELECT id FROM zones_livraison WHERE nom='Zone T14 Nord'")
    AD.post("admin/zones", {"action": "ajouter", "nom": "Zone T14 Nord", "frais": "100", "delai_jours": "1"})
    S.check("un nom déjà pris est refusé", sql("SELECT COUNT(*) FROM zones_livraison WHERE nom='Zone T14 Nord'") == "1")
    for mauvais in ({"nom": "Zone T14 neg", "frais": "-5", "delai_jours": "1"}, {"nom": "Zone T14 abc", "frais": "abc", "delai_jours": "1"},
                    {"nom": "Zone T14 delai", "frais": "500", "delai_jours": "0"}, {"nom": "Z", "frais": "500", "delai_jours": "1"}):
        AD.post("admin/zones", {"action": "ajouter", **mauvais})
    S.check("frais négatifs, texte, délai nul, nom trop court : refusés", sql("SELECT COUNT(*) FROM zones_livraison WHERE nom LIKE 'Zone T14 %' AND nom<>'Zone T14 Nord'") == "0")
    AD.post("admin/zones", {"action": "ajouter", "nom": "Zone T14 <script>", "frais": "500", "delai_jours": "1"})
    S.check("le nom est échappé à l'affichage (pas de balise brute)", "<script>" not in AD.get("admin/zones")[1] or sql("SELECT COUNT(*) FROM zones_livraison WHERE nom LIKE '%<script>%'") == "0")
    sql("DELETE FROM zones_livraison WHERE nom LIKE '%<script>%'")

    AD.post("admin/zones", {"action": "modifier", "id": zid, "nom": "Zone T14 Nord", "region": "Touba", "frais": "1800", "delai_jours": "3"})
    S.check("l'admin modifie les frais et le délai", sql(f"SELECT CONCAT(frais,'/',delai_jours) FROM zones_livraison WHERE id={zid}") == "1800/3")
    # une commande dans cette zone utilise le nouveau tarif
    prod = sql("SELECT id FROM produits WHERE statut='publie' AND stock>5 LIMIT 1")
    if prod:
        ref = acheter(C, int(prod), 1, "livraison", zone=int(zid))
        S.check("la commande applique les frais de la zone (1 800 FCFA)", sql(f"SELECT frais_livraison FROM commandes WHERE reference='{ref}'") == "1800" if ref else False)
        AD.post("admin/zones", {"action": "modifier", "id": zid, "nom": "Zone T14 Nord", "region": "Touba", "frais": "900", "delai_jours": "1"})
        S.check("changer les frais ne touche pas aux commandes passées", sql(f"SELECT frais_livraison FROM commandes WHERE reference='{ref}'") == "1800")
    AD.post("admin/zones", {"action": "basculer", "id": zid})
    S.check("désactivation : la zone n'est plus proposée", sql(f"SELECT actif FROM zones_livraison WHERE id={zid}") == "0" and f'<option value="{zid}"' not in C.get("compte/adresses")[1] and f'<option value="{zid}"' not in C.get("commande")[1])
    s, h, _ = C.post("compte/adresses", {"action": "ajouter", "zone_id": zid, "telephone": "771234567", "adresse": "Rue test zone désactivée"})
    S.check("adresse dans une zone désactivée refusée", "Choisissez une zone" in h)
    AD.post("admin/zones", {"action": "basculer", "id": zid})
    C.post("compte/adresses", {"action": "ajouter", "zone_id": zid, "telephone": "771234567", "adresse": "Rue test Nord 5"})
    AD.post("admin/zones", {"action": "supprimer", "id": zid})
    S.check("zone utilisée par une adresse : suppression refusée", sql(f"SELECT COUNT(*) FROM zones_livraison WHERE id={zid}") == "1")
    AD.post("admin/zones", {"action": "ajouter", "nom": "Zone T14 sans ville", "frais": "300", "delai_jours": "1"})
    S.check("une zone sans ville est refusée", sql("SELECT COUNT(*) FROM zones_livraison WHERE nom='Zone T14 sans ville'") == "0")
    AD.post("admin/zones", {"action": "ajouter", "nom": "Zone T14 Vide", "region": "Kaolack", "frais": "300", "delai_jours": "1"})
    vid = sql("SELECT id FROM zones_livraison WHERE nom='Zone T14 Vide'")
    AD.post("admin/zones", {"action": "supprimer", "id": vid})
    S.check("zone sans adresse : supprimable", sql(f"SELECT COUNT(*) FROM zones_livraison WHERE id={vid}") == "0")

    S.titre("GARDE-FOU : AU MOINS UNE ZONE ACTIVE")
    sauve = sql("SELECT GROUP_CONCAT(id) FROM zones_livraison WHERE actif=1")
    sql("UPDATE zones_livraison SET actif=0 WHERE nom NOT LIKE 'Darou Marnane'")
    sql("UPDATE zones_livraison SET actif=1 WHERE nom='Darou Marnane'")
    dm = sql("SELECT id FROM zones_livraison WHERE nom='Darou Marnane'")
    AD.post("admin/zones", {"action": "basculer", "id": dm})
    S.check("impossible de désactiver la dernière zone active", sql(f"SELECT actif FROM zones_livraison WHERE id={dm}") == "1")
    sql("UPDATE zones_livraison SET actif=0 WHERE nom LIKE 'Zone T14%'")
    sql(f"UPDATE zones_livraison SET actif=1 WHERE id IN ({sauve})")
    sql(f"UPDATE zones_livraison SET actif=0 WHERE id NOT IN ({sauve})")

    S.titre("TEXTES")
    h = AD.get("livraison-retours")[1]
    S.check("page livraison : tout le Sénégal, avec la ville de chaque zone", "tout le Sénégal" in h and "Dakar" in h and "Touba" in h and "uniquement" not in h)
finally:
    sql("DELETE FROM zones_livraison WHERE nom LIKE 'Zone T14%' AND id NOT IN (SELECT zone_id FROM adresses)")
    ok = S.fin()
    sql("DELETE FROM zones_livraison WHERE nom LIKE 'Zone T14%'")
sys.exit(0 if ok else 1)
