"""
Bibliothèque commune des tests de bout en bout de Jënd (Python 3, aucune dépendance à installer).

⚠ Ces tests créent et SUPPRIMENT des données (comptes de test, commandes…). Ils refusent de s'exécuter
  si le site n'est pas en mode développement sur cette machine (APP_ENV=dev, base locale).

Lancer :  python3 tests/run_all.py            (tous)     ou     python3 tests/test_etape9.py
"""
import hashlib, hmac, http.cookiejar, json, os, re, secrets, subprocess, sys, tempfile, time, urllib.parse, urllib.request, uuid
from pathlib import Path

JEND = Path(__file__).resolve().parent.parent
ENV_FILE = JEND / ".env"
BASE = os.environ.get("JEND_TEST_URL", "http://localhost/jend/")
PHP = os.environ.get("JEND_TEST_PHP", "/Applications/XAMPP/xamppfiles/bin/php")
MYSQL_BIN = os.environ.get("JEND_TEST_MYSQL", "/Applications/XAMPP/xamppfiles/bin/mysql")


# Toute réponse du site est surveillée : un « Warning », « Notice », « Deprecated » ou « Fatal error » PHP affiché dans une page
# fait échouer la suite (c'est ce qui laissait passer l'erreur « Undefined variable $villes »).
ERREURS_PHP = []
MOTIF_ERREUR_PHP = re.compile(r"<b>(Warning|Notice|Deprecated|Fatal error|Parse error)</b>\s*:|(Warning|Notice|Deprecated|Fatal error|Parse error|Uncaught \w+)\s*:\s.{0,160}\bon line\b|Stack trace:")


def lire_env(chemin=ENV_FILE):
    valeurs = {}
    if Path(chemin).exists():
        for ligne in Path(chemin).read_text().splitlines():
            ligne = ligne.strip()
            if ligne and not ligne.startswith("#") and "=" in ligne:
                k, v = ligne.split("=", 1)
                valeurs[k.strip()] = re.sub(r"\s+#.*$", "", v).strip(" \t\"'")
    return valeurs


ENV = lire_env()
DB = {"host": ENV.get("DB_HOST", "127.0.0.1"), "port": ENV.get("DB_PORT", "3306"), "user": ENV.get("DB_USER", "root"),
      "pass": ENV.get("DB_PASS", ""), "name": ENV.get("DB_NAME", "jend")}


def garde_fou():
    if ENV.get("APP_ENV") != "dev" or DB["host"] not in ("127.0.0.1", "localhost") or "localhost" not in BASE and "127.0.0.1" not in BASE:
        sys.exit("REFUS : ces tests effacent des données. Ils ne tournent qu'avec APP_ENV=dev, une base locale et un site local.")
    if DB["name"] != "jend_test_iso" and os.environ.get("JEND_TEST_AUTORISER_BASE_REELLE") != "1":
        sys.exit("REFUS : ces tests créent et suppriment des données dans la base « " + DB["name"] + " ». Lancez-les sur une copie jetable :\n"
                 "    python3 scripts/tester-en-isolation.py            (toute la batterie)\n"
                 "    python3 scripts/tester-en-isolation.py test_etape9.py\n"
                 "(pour les lancer quand même sur la base courante : JEND_TEST_AUTORISER_BASE_REELLE=1, à vos risques)")


garde_fou()


def _cmd_mysql(base=True):
    c = [MYSQL_BIN, "-h", DB["host"], "-P", DB["port"], "-u", DB["user"], "-N", "-B"]
    if DB["pass"]:
        c.append("-p" + DB["pass"])
    if base:
        c.append(DB["name"])
    return c


def sql(q, base=True):
    r = subprocess.run(_cmd_mysql(base) + ["-e", q], capture_output=True, text=True)
    if r.returncode:
        raise RuntimeError(r.stderr)
    return r.stdout.strip()


def php(code, env_extra=None):
    e = dict(os.environ)
    e.update(env_extra or {})
    r = subprocess.run([PHP, "-r", code], capture_output=True, text=True, env=e)
    return r.stdout.strip(), r.stderr.strip()


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, *a, **k):
        return None


class Client:
    def __init__(self, base=None, cookies_secure_en_http=False, entetes=None):
        self.base = base
        self.entetes = dict(entetes or {})        # en-têtes envoyés avec CHAQUE requête (ex : simuler un proxy HTTPS)
        # Un vrai navigateur n'envoie un cookie « Secure » qu'en HTTPS. Pour simuler un site derrière HTTPS avec un serveur
        # local en http, on autorise explicitement l'envoi (cookies_secure_en_http=True).
        politique = http.cookiejar.DefaultCookiePolicy(secure_protocols=("https", "wss", "http")) if cookies_secure_en_http else None
        self.jar = http.cookiejar.CookieJar(policy=politique)
        self.op = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(self.jar), NoRedirect)

    def req(self, chemin, data=None, headers=None, raw=None, absolu=False):
        d = raw if raw is not None else (urllib.parse.urlencode(data, doseq=True).encode() if data is not None else None)
        rq = urllib.request.Request(chemin if absolu else (self.base or BASE) + chemin, data=d, headers={**self.entetes, **(headers or {})})
        try:
            r = self.op.open(rq, timeout=30)
            code, corps, entetes = r.status, r.read().decode(errors="replace"), r.headers
        except urllib.error.HTTPError as e:
            code, corps, entetes = e.code, e.read().decode(errors="replace"), e.headers
        m = MOTIF_ERREUR_PHP.search(corps)
        if m and "text/html" in (entetes.get("Content-Type") or ""):
            ERREURS_PHP.append(f"{chemin} → {corps[max(0, m.start() - 20):m.start() + 190]!r}")
        return code, corps, entetes

    def get(self, chemin, headers=None):
        return self.req(chemin, headers=headers)

    def token(self, chemin):
        m = re.search(r'name="csrf" value="([^"]+)"', self.get(chemin)[1])
        return m.group(1) if m else ""

    def post(self, chemin, data, page_token=None, headers=None):
        data = dict(data)
        if chemin in ("inscription", "vendre") and "accepte" not in data:
            data["accepte"] = "1"          # case « j'accepte les conditions » (passer accepte="" pour tester le refus)
        data["csrf"] = self.token(page_token or chemin)
        return self.req(chemin, data, headers=headers)

    def multipart(self, chemin, champs, fichiers, page_token=None):
        champs = dict(champs)
        champs["csrf"] = self.token(page_token or chemin)
        b = "----jend" + uuid.uuid4().hex
        corps = b""
        for k, v in champs.items():
            corps += f'--{b}\r\nContent-Disposition: form-data; name="{k}"\r\n\r\n{v}\r\n'.encode()
        for nom, fichier, contenu, mime in fichiers:
            corps += f'--{b}\r\nContent-Disposition: form-data; name="{nom}"; filename="{fichier}"\r\nContent-Type: {mime}\r\n\r\n'.encode() + contenu + b"\r\n"
        corps += f"--{b}--\r\n".encode()
        return self.req(chemin, raw=corps, headers={"Content-Type": f"multipart/form-data; boundary={b}"})


class Suite:
    """Compteur de vérifications + restauration de l'état d'origine (instantané des produits)."""

    def __init__(self, nom, emails=()):
        self.nom, self.emails = nom, list(emails)
        self.ok, self.echecs = 0, []
        lignes = sql("SELECT id, stock, note_moyenne, nb_avis, statut FROM produits").splitlines()
        self.snap = [l.split("\t") for l in lignes]
        self.env_original = ENV_FILE.read_text() if ENV_FILE.exists() else ""
        log = JEND / "storage" / "emails.log"
        self.log_original = log.read_text() if log.exists() else None      # le journal d'e-mails de l'utilisateur est restauré à la fin
        print(f"\n===== {nom} =====")

    def check(self, nom, cond, detail=""):
        if cond:
            self.ok += 1
            print(f"  OK   {nom}")
        else:
            self.echecs.append(nom)
            print(f"  ÉCHEC {nom} {detail}")

    def titre(self, t):
        print(t)

    def nettoyer(self):
        if DB["name"] == "jend_test_iso":
            sql("INSERT IGNORE INTO parametres (cle, valeur) VALUES ('verification_email', '0')")      # les tests existants commandent juste après l'inscription
            sql("INSERT IGNORE INTO parametres (cle, valeur) VALUES ('paiement_livraison', '1')")      # les tests existants utilisent le paiement à la livraison (désactivé par défaut sur le vrai site)
            sql("INSERT IGNORE INTO parametres (cle, valeur) VALUES ('delai_retrait_jours', '0')")      # les tests existants attendent un gain retirable tout de suite
        ids = ""
        if self.emails:
            ids = sql("SELECT GROUP_CONCAT(id) FROM users WHERE email IN ('%s')" % "','".join(self.emails))
        if ids and ids != "NULL":
            chemins = sql(f"SELECT GROUP_CONCAT(pi.chemin SEPARATOR '|') FROM produit_images pi JOIN produits p ON p.id=pi.produit_id JOIN boutiques b ON b.id=p.boutique_id WHERE b.user_id IN ({ids})")
            for c in (chemins.split("|") if chemins and chemins != "NULL" else []):
                f = JEND / c
                if re.match(r"^uploads/produits/[a-f0-9]{32}\.(jpg|png)$", c):
                    for g in (f, JEND / re.sub(r"\.(jpg|png)$", "-m.jpg", c)):         # la photo et sa miniature
                        if g.exists():
                            g.unlink()
            sql(f"DELETE FROM commandes WHERE client_id IN ({ids})")
            sql(f"DELETE r FROM retraits r JOIN boutiques b ON b.id=r.boutique_id WHERE b.user_id IN ({ids})")
            sql(f"DELETE FROM users WHERE id IN ({ids})")
        for i, st, nm, na, su in self.snap:
            sql(f"UPDATE produits SET stock={st}, note_moyenne={nm}, nb_avis={na}, statut='{su}' WHERE id={i}")
        sql("DELETE FROM limites")
        for f in (JEND / "storage").glob("alerte-*.txt"):          # limiteurs d'alertes créés pendant le test
            f.unlink()
        log = JEND / "storage" / "emails.log"
        if log.exists():
            log.unlink()
        if self.log_original is not None:
            log.write_text(self.log_original)

    def publier_demo(self):
        """Le temps du test, remet en vente les 8 produits de démonstration (restaurés ensuite par nettoyer())."""
        sql("UPDATE produits SET statut='publie' WHERE id BETWEEN 1 AND 8")

    def restaurer_env(self):
        if self.env_original:
            ENV_FILE.write_text(self.env_original)

    def modifier_env(self, **changements):
        """Modifie temporairement .env (restauré par restaurer_env)."""
        texte = self.env_original
        for k, v in changements.items():
            if re.search(rf"^{k}=.*$", texte, flags=re.M):
                texte = re.sub(rf"^{k}=.*$", f"{k}={v}", texte, flags=re.M)
            else:
                texte += f"\n{k}={v}\n"
        ENV_FILE.write_text(texte)

    def fin(self, extra=""):
        self.restaurer_env()
        self.nettoyer()
        print(f"\nnettoyage fait — {extra}comptes de test restants: "
              f"{sql('SELECT COUNT(*) FROM users WHERE email LIKE ' + chr(39) + '%-t%@jend.local' + chr(39))} | commandes: {sql('SELECT COUNT(*) FROM commandes')}")
        if ERREURS_PHP:
            self.echecs.append(f"{len(set(ERREURS_PHP))} message(s) d'erreur PHP affiché(s) dans des pages : " + " | ".join(sorted(set(ERREURS_PHP))[:3]))
        print(f"\n{self.nom} : {self.ok} vérifications réussies, {len(self.echecs)} échec(s)")
        for f in self.echecs:
            print(" -", f)
        return not self.echecs


def secret_paiement():
    f = JEND / "storage" / "paiement-secret.txt"
    return f.read_text().strip() if f.exists() else ""


def webhook(ref, statut, montant, t=None, signer=True, signature=None, headers=None):
    corps = json.dumps({"reference": ref, "statut": statut, "montant": montant, "t": int(time.time()) if t is None else t}).encode()
    sig = signature if signature is not None else (hmac.new(secret_paiement().encode(), corps, hashlib.sha256).hexdigest() if signer else "")
    h = {"Content-Type": "application/json", "X-Signature": sig}
    h.update(headers or {})
    return Client().req("paiement/webhook", raw=corps, headers=h)


def mot_de_passe():
    return "Pw-" + secrets.token_hex(5)


def fixtures_images():
    """Crée des images de test (saines et piégées) avec le PHP de XAMPP + GD. Retourne le dossier."""
    d = Path(tempfile.mkdtemp(prefix="jend-img-"))
    code = (
        '$d=%s;$im=imagecreatetruecolor(300,200);$c=imagecolorallocate($im,194,71,31);imagefill($im,0,0,$c);'
        'imagejpeg($im,"$d/ok.jpg",90);imagepng($im,"$d/ok.png");'
        'file_put_contents("$d/evil_appended.jpg",file_get_contents("$d/ok.jpg")."<?php system(\\"id\\"); ?>");'
        'file_put_contents("$d/shell.jpg","<?php echo shell_exec(\\$_GET[\\"c\\"]); ?>");'
        'file_put_contents("$d/shell.php",file_get_contents("$d/ok.jpg"));'
        'file_put_contents("$d/big.jpg",file_get_contents("$d/ok.jpg").str_repeat("0",3600000));'
        'file_put_contents("$d/fake.gif","GIF89a".str_repeat("x",200));'
    ) % json.dumps(str(d))
    out, err = php(code)
    assert not err, err
    return d


def hash_mdp(motdepasse):
    r = subprocess.run([PHP, "-r", "echo password_hash($argv[1], PASSWORD_DEFAULT);", "--", motdepasse], capture_output=True, text=True)
    return r.stdout.strip()


def zones_actives_ids():
    """Identifiants des zones de livraison actives (les numéros changent selon la base : on ne les écrit pas en dur)."""
    return [int(x) for x in sql("SELECT id FROM zones_livraison WHERE actif = 1 ORDER BY id").split()]


def acheter(client, produit_id, qte, methode, zone=None):
    zone = zone or zones_actives_ids()[0]
    tok = client.token("produits")
    client.req("panier/ajouter", {"csrf": tok, "produit_id": produit_id, "quantite": qte, "retour": "/jend/produits"})
    _, _, hd = client.post("commande", {"nom": "Client Test", "telephone": "78 000 11 22", "zone_id": zone, "adresse": "Rue 10 Médina", "methode": methode, "acompte_methode": "wave"})
    ref = hd.get("Location", "").rsplit("/", 1)[-1]
    if methode == "livraison" and ref and sql(f"SELECT acompte FROM commandes WHERE reference='{ref}'") not in ("0", ""):
        # paiement à la livraison : l'acompte est supposé déjà réglé (le circuit de paiement de l'acompte est testé dans test_etape18)
        sql(f"UPDATE commandes SET statut_paiement='acompte', statut='confirmee' WHERE reference='{ref}'")
    return ref


def etat(ref):
    return sql(f"SELECT CONCAT(statut,'|',statut_paiement) FROM commandes WHERE reference='{ref}'")
