"""Étape 17 : qui livre ? Le vendeur livre lui-même par défaut et touche le frais de livraison ; comptabilité des espèces."""
import json, re, sys
from lib import *

S = Suite("Étape 17 — le vendeur livre, les frais lui reviennent", ["ad-t17@jend.local", "cl-t17@jend.local", "va-t17@jend.local", "vb-t17@jend.local", "lv-t17@jend.local"])
E = dict(zip(["ad", "cl", "va", "vb", "lv"], S.emails))
INC = JEND / "includes"
cb_de = lambda ref: [int(x) for x in sql(f"SELECT cb.id FROM commande_boutiques cb JOIN commandes c ON c.id=cb.commande_id WHERE c.reference='{ref}' ORDER BY cb.id").split()]
col = lambda cb, c: sql(f"SELECT {c} FROM commande_boutiques WHERE id={cb}")
def gains(boutique_slug):
    bid = sql(f"SELECT id FROM boutiques WHERE slug='{boutique_slug}'")
    out, err = php(f'require "{INC}/env.php"; require "{INC}/db.php"; require "{INC}/parametres.php"; require "{INC}/vendeur.php"; echo json_encode(vendeur_gains({bid}));')
    assert not err, err
    return json.loads(out)
FRAIS = 1001            # impair, pour vérifier la répartition entre deux livraisons
try:
    S.nettoyer()
    sql("REPLACE INTO parametres (cle, valeur) VALUES ('livreurs_jend', '1')")      # fonction activée par l'admin pour ce test
    sql("DELETE FROM produits WHERE slug IN ('produit-a-t17','produit-b-t17')")
    sql("DELETE FROM boutiques WHERE slug IN ('boutique-a-t17','boutique-b-t17')")
    sql("DELETE FROM zones_livraison WHERE nom='Zone T17'")
    sql(f"INSERT INTO zones_livraison (nom, region, frais, delai_jours) VALUES ('Zone T17', 'Touba', {FRAIS}, 1)")
    zone = int(sql("SELECT id FROM zones_livraison WHERE nom='Zone T17'"))
    pw = mot_de_passe()
    for k, nom, role in (("ad", "Admin T17", "admin"), ("va", "Vendeur A", "vendeur"), ("vb", "Vendeur B", "vendeur")):
        sql(f"INSERT INTO users (nom,email,mot_de_passe,role) VALUES ('{nom}','{E[k]}','{hash_mdp(pw)}','{role}')")
    sql(f"INSERT INTO users (nom,email,telephone,mot_de_passe,role) VALUES ('Livreur T17','{E['lv']}','+221775556677','{hash_mdp(pw)}','livreur')")
    sql(f"INSERT INTO livreurs (user_id) SELECT id FROM users WHERE email='{E['lv']}'")
    for k, slug, mode in (("va", "boutique-a-t17", None), ("vb", "boutique-b-t17", "jend")):
        extra = f", livraison_par='{mode}'" if mode else ""
        sql(f"INSERT INTO boutiques (user_id,nom,slug,statut,commission_pct) SELECT id,'{slug}','{slug}','active',10 FROM users WHERE email='{E[k]}'")
        if mode:
            sql(f"UPDATE boutiques SET livraison_par='jend' WHERE slug='{slug}'")
        sql(f"INSERT INTO produits (boutique_id,categorie_id,nom,slug,description,prix,stock,statut) SELECT b.id,(SELECT MIN(id) FROM categories),'Produit {k}','produit-{k[1]}-t17','x',10000,80,'publie' FROM boutiques b WHERE b.slug='{slug}'")
    pa, pb = (int(sql(f"SELECT id FROM produits WHERE slug='produit-{x}-t17'")) for x in "ab")
    AD, C, VA, VB, L = Client(), Client(), Client(), Client(), Client()
    C.post("inscription", {"nom": "Cliente T17", "email": E["cl"], "mot_de_passe": pw, "mot_de_passe2": pw})
    for cl, k in ((AD, "ad"), (VA, "va"), (VB, "vb")):
        cl.post("connexion", {"email": E[k], "mot_de_passe": pw})
    L.post("livreur/connexion", {"email": E["lv"], "mot_de_passe": pw})

    S.titre("PAR DÉFAUT, LE VENDEUR LIVRE")
    S.check("une boutique créée sans réglage livre elle-même", sql("SELECT livraison_par FROM boutiques WHERE slug='boutique-a-t17'") == "vendeur")
    S.check("l'admin voit et peut changer le mode de livraison de chaque boutique", "Le vendeur livre" in AD.get("admin/boutiques")[1] and "Livreurs Jënd" in AD.get("admin/boutiques")[1])
    bid_a = sql("SELECT id FROM boutiques WHERE slug='boutique-a-t17'")
    VA.post("admin/boutiques", {"id": bid_a, "action": "livraison", "mode": "jend"}, page_token="vendeur")
    S.check("un vendeur ne peut pas s'attribuer des livreurs Jënd (admin seulement)", sql(f"SELECT livraison_par FROM boutiques WHERE id={bid_a}") == "vendeur")

    S.titre("CAS A : PAIEMENT EN LIGNE, LE VENDEUR LIVRE ET TOUCHE LA LIVRAISON")
    def acheter_zone(produits, methode):
        tok = C.token("produits")
        for p in produits:
            C.req("panier/ajouter", {"csrf": tok, "produit_id": p, "quantite": 1, "retour": "/jend/produits"})
        _, _, hd = C.post("commande", {"nom": "Client T17", "telephone": "78 000 11 22", "zone_id": zone, "adresse": "Rue test 17", "methode": methode, "acompte_methode": "wave"})
        r = hd.get("Location", "").rsplit("/", 1)[-1]
        if methode == "livraison":
            sql(f"UPDATE commandes SET statut_paiement='acompte', statut='confirmee' WHERE reference='{r}'")     # acompte supposé réglé
        return r
    ref = acheter_zone([pa], "wave"); (cb,) = cb_de(ref)
    S.check("la livraison garde la photographie « le vendeur livre » et la totalité du frais", col(cb, "livre_par") == "vendeur" and col(cb, "frais_part") == str(FRAIS))
    sql(f"UPDATE commandes SET statut_paiement='paye', statut='confirmee' WHERE reference='{ref}'")
    S.check("pas dans la liste des courses à affecter (pas de livreur nécessaire)", ref not in AD.get("admin/courses")[1])
    AD.post("admin/courses", {"id": cb, "livreur_id": sql(f"SELECT id FROM users WHERE email='{E['lv']}'")})
    S.check("affecter un livreur à une boutique qui livre elle-même est refusé", col(cb, "livreur_id") == "NULL")
    h = VA.get("vendeur/commandes")[1]
    S.check("le vendeur lit : « Vous livrez vous-même » et ce qu'il reçoit, livraison comprise", "Vous livrez cette commande vous-même" in h and "dont" in h and "1 001" in h.replace(" ", " ").replace("\xa0", " "))
    VA.post("vendeur/commandes", {"id": cb, "numero_suivi": ""})
    VA.post("vendeur/commandes", {"id": cb, "code_livraison": col(cb, "code_livraison")})
    S.check("il marque expédiée puis livrée avec le code du client", col(cb, "statut") == "livree")
    g = gains("boutique-a-t17")
    S.check(f"gains : 9 000 (10 000 − 10 %) + {FRAIS} de livraison = {9000 + FRAIS}", g["net"] == 9000 + FRAIS and g["frais_livraison"] == FRAIS and g["solde"] == 9000 + FRAIS and g["especes"] == 0, str(g))
    h = VA.get("vendeur/gains")[1]
    S.check("la page des gains affiche les frais de livraison gagnés", "Frais de livraison gagnés" in h)

    S.titre("CAS C : PAIEMENT À LA LIVRAISON, LE VENDEUR ENCAISSE LES ESPÈCES")
    ref2 = acheter_zone([pa], "livraison"); (cb2,) = cb_de(ref2)
    h = VA.get("vendeur/commandes")[1]
    S.check("le vendeur lit : « Vous encaissez … en espèces » et la commission à reverser", "en espèces" in h and "commission à reverser" in h)
    VA.post("vendeur/commandes", {"id": cb2, "numero_suivi": ""})
    VA.post("vendeur/commandes", {"id": cb2, "code_livraison": col(cb2, "code_livraison")})
    g = gains("boutique-a-t17")
    S.check("Jënd ne lui doit que l'acompte reçu en ligne (2 300) et il doit la commission de 1 000", g["credit"] == 9000 + FRAIS + 2300 and g["solde"] == 9000 + FRAIS + 2300 - 1000 and g["especes"] == 10000 + FRAIS - 2300 and g["a_reverser"] == 1000, str(g))
    S.check("le solde ne contient donc pas la vente en espèces : seulement l'acompte, moins la commission", g["especes"] == 8701)
    h = VA.get("vendeur/gains")[1]
    S.check("la page explique : espèces déjà encaissées + commission à reverser", "Espèces déjà encaissées" in h and "Commission à reverser" in h)

    S.titre("CAS B : PAIEMENT À LA LIVRAISON, LIVREUR JËND")
    ref3 = acheter_zone([pb], "livraison"); (cb3,) = cb_de(ref3)
    S.check("boutique en mode Jënd : livre_par = jend (la part de frais est enregistrée mais reste à Jënd : le vendeur n'y a pas droit)", col(cb3, "livre_par") == "jend" and col(cb3, "frais_part") == str(FRAIS))
    AD.post("admin/courses", {"id": cb3, "livreur_id": sql(f"SELECT id FROM users WHERE email='{E['lv']}'")})
    S.check("l'admin voit cette course et peut l'affecter", ref3 in AD.get("admin/courses")[1] and col(cb3, "livreur_id") != "NULL")
    for act in ("recuperer", "en_route"):
        L.post(f"livreur/course/{cb3}", {"action": act})
    VB.post("vendeur/commandes", {"id": cb3, "code_livraison": col(cb3, "code_livraison")})
    S.check("le vendeur de ce mode ne peut pas confirmer la livraison à la place du livreur", col(cb3, "statut") == "expediee")
    L.post(f"livreur/course/{cb3}", {"action": "livrer", "code": col(cb3, "code_livraison")})
    g = gains("boutique-b-t17")
    S.check("livré par Jënd : le vendeur est crédité de 9 000, sans frais de livraison", col(cb3, "statut") == "livree" and g["net"] == 9000 and g["solde"] == 9000 and g["frais_livraison"] == 0 and g["especes"] == 0, str(g))
    h = VB.get("vendeur/commandes?vue=terminees")[1]
    S.check("son écran dit : livraison assurée par un livreur Jënd", "Livraison assurée par un livreur Jënd" in h)

    S.titre("COMMANDE À DEUX BOUTIQUES : CHAQUE BOUTIQUE FACTURE SA LIVRAISON")
    ref4 = acheter_zone([pa, pb], "wave"); cbs = cb_de(ref4)
    parts = [int(col(c, "frais_part")) for c in cbs]
    modes = [col(c, "livre_par") for c in cbs]
    S.check("deux livraisons, deux colis : chaque livraison porte son propre frais (1 001 chacune, frais de référence)", len(cbs) == 2 and sorted(modes) == ["jend", "vendeur"] and parts == [FRAIS, FRAIS], f"{modes} {parts}")
    total_frais = int(sql(f"SELECT frais_livraison FROM commandes WHERE reference='{ref4}'"))
    S.check("le client paie les deux livraisons (produits + 2 × 1 001)", total_frais == 2 * FRAIS and int(sql(f"SELECT total FROM commandes WHERE reference='{ref4}'")) == 20000 + 2 * FRAIS)

    S.titre("SIGNALEMENT SUR DES ESPÈCES REMISES AU VENDEUR")
    sql(f"UPDATE commande_boutiques SET livre_le = NOW() WHERE id={cb2}")
    s, _, hd = C.multipart(f"litige/nouveau/{cb2}", {"motif": "autre", "description": "Un accessoire manquait dans le colis livré par le vendeur."}, [], page_token=f"litige/nouveau/{cb2}")
    ref_l = hd["Location"].rsplit("/", 1)[-1] if s == 302 else ""
    lid = sql(f"SELECT id FROM litiges WHERE reference='{ref_l}'") if ref_l else ""
    S.check("le client peut signaler le problème", s == 302 and bool(lid))
    sql(f"UPDATE commandes SET statut_paiement='paye' WHERE reference='{ref2}'")
    AD.post("admin/litiges", {"id": lid, "action": "rembourser", "message": "Remboursement accepté.", "montant": 5000, "a_charge_vendeur": 1}, page_token=f"admin/litiges?id={lid}")
    S.check("Jënd ne peut pas rembourser des espèces qu'elle n'a pas reçues (le vendeur rembourse en direct)", sql(f"SELECT statut FROM litiges WHERE id={lid}") == "ouvert")
    AD.post("admin/litiges", {"id": lid, "action": "rejeter", "message": "Le vendeur s'est engagé à vous remettre l'accessoire."}, page_token=f"admin/litiges?id={lid}")
    S.check("mais « refuser » ou « remplacer » restent possibles", sql(f"SELECT statut FROM litiges WHERE id={lid}") == "rejete")

    S.titre("RÉGLAGE PAR L'ADMINISTRATEUR")
    AD.post("admin/boutiques", {"id": bid_a, "action": "livraison", "mode": "jend"})
    S.check("l'admin confie la boutique aux livreurs Jënd (tracé dans le journal)", sql(f"SELECT livraison_par FROM boutiques WHERE id={bid_a}") == "jend" and int(sql("SELECT COUNT(*) FROM journal_admin WHERE action='livraison_modifiee'")) >= 1)
    ref5 = acheter_zone([pa], "wave"); (cb5,) = cb_de(ref5)
    S.check("les nouvelles commandes suivent le nouveau mode…", col(cb5, "livre_par") == "jend")
    S.check("…les anciennes gardent le leur (pas de changement en cours de route)", col(cb, "livre_par") == "vendeur")
    AD.post("admin/boutiques", {"id": bid_a, "action": "livraison", "mode": "vendeur"})
    S.check("retour au mode « le vendeur livre »", sql(f"SELECT livraison_par FROM boutiques WHERE id={bid_a}") == "vendeur")
finally:
    sql("DELETE FROM parametres WHERE cle = 'livreurs_jend'")
    sql("DELETE FROM produits WHERE slug IN ('produit-a-t17','produit-b-t17')")
    ok = S.fin()
    sql("DELETE FROM boutiques WHERE slug IN ('boutique-a-t17','boutique-b-t17')")
    sql("DELETE FROM zones_livraison WHERE nom='Zone T17'")
    sql("DELETE FROM journal_admin WHERE action='livraison_modifiee' AND detail LIKE '%t17%'")
sys.exit(0 if ok else 1)
