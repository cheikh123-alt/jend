"""Étape 57 : mode simple de l'espace vendeur (vendeurs qui lisent peu) — choix à l'ouverture, produit en photo/prix/voix, stock « − / + », commandes, argent, bascule."""
import sys, re
from lib import *

S = Suite("Étape 57 — mode simple du vendeur", ["vs-t57@jend.local", "vc-t57@jend.local", "cl-t57@jend.local"])
E = dict(zip(["vs", "vc", "cl"], S.emails))
IMG = fixtures_images()
aide = JEND / "assets" / "audio" / "aide" / "commandes.mp3"
try:
    S.nettoyer()
    sql("DELETE FROM zones_livraison WHERE nom='Zone T57'")
    sql("INSERT INTO zones_livraison (nom, region, frais, delai_jours) VALUES ('Zone T57', 'Thiès', 1000, 1)")
    zone = int(sql("SELECT id FROM zones_livraison WHERE nom='Zone T57'"))
    pw = mot_de_passe()
    for k, nom in (("vs", "Awa Simple"), ("vc", "Modou Complet")):
        sql(f"INSERT INTO users (nom,email,mot_de_passe,role,email_verifie) VALUES ('{nom}','{E[k]}','{hash_mdp(pw)}','client',1)")
    VS, VC = Client(), Client()
    VS.post("connexion", {"email": E["vs"], "mot_de_passe": pw}); VC.post("connexion", {"email": E["vc"], "mot_de_passe": pw})
    txt = lambda cl, u: cl.get(u)[1].replace("&#039;", "'").replace("&nbsp;", " ").replace("\xa0", " ").replace(" ", " ")

    S.titre("CHOIX DU MODE À L'OUVERTURE DE LA BOUTIQUE")
    h = txt(VS, "vendre")
    S.check("la page « Vendre » propose deux cartes : mode simple et mode complet (complet coché par défaut)",
            'name="mode" value="simple"' in h and re.search(r'value="complet"\s+checked', h) is not None and "Vous pourrez changer à tout moment" in h)
    st, _, hd = VS.post("vendre", {"nom": "Boutique T57 Simple", "description": "", "telephone": "77 123 45 57", "accepte": "1", "mode": "simple"})
    S.check("mode simple choisi : la boutique est créée en mode simple et le vendeur arrive sur l'écran à grands boutons",
            sql(f"SELECT b.mode_simple FROM boutiques b JOIN users u ON u.id=b.user_id WHERE u.email='{E['vs']}'") == "1" and hd.get("Location", "").endswith("/simple"))
    VC.post("vendre", {"nom": "Boutique T57 Complet", "description": "", "telephone": "77 123 45 58", "accepte": "1", "mode": "complet"})
    S.check("mode complet choisi : boutique en mode complet (comme avant)", sql(f"SELECT b.mode_simple FROM boutiques b JOIN users u ON u.id=b.user_id WHERE u.email='{E['vc']}'") == "0")
    bs = sql(f"SELECT b.id FROM boutiques b JOIN users u ON u.id=b.user_id WHERE u.email='{E['vs']}'")
    bc = sql(f"SELECT b.id FROM boutiques b JOIN users u ON u.id=b.user_id WHERE u.email='{E['vc']}'")
    sql(f"UPDATE boutiques SET statut='active', commission_pct=0 WHERE id IN ({bs},{bc})")
    sql(f"UPDATE boutiques SET commission_pct=10, commission_gratuite_jusqu=NULL WHERE id={bs}")      # 10 % : chiffres faciles à vérifier

    S.titre("ACCUEIL SIMPLE")
    st, _, hd = VS.get("vendeur")
    S.check("l'espace vendeur d'un vendeur en mode simple mène à l'accueil simple", st in (302, 303) and hd.get("Location", "").endswith("/simple"))
    h = txt(VS, "simple")
    S.check("quatre grands boutons : mettre un produit, commandes, argent (solde en chiffres), produits", all(t in h for t in ("Mettre un produit", "Mes commandes", "Mon argent", "Mes produits", "0 FCFA")) and h.count('class="simple-tuile ') == 4)
    S.check("pas de bouton d'aide audio tant que le message n'est pas enregistré", "data-aide" not in h)
    st, _, hd = VC.get("vendeur")
    S.check("le vendeur en mode complet garde son tableau de bord (avec la proposition du mode simple)", st == 200 and "Passer au mode simple" in txt(VC, "vendeur"))
    S.check("pages simples réservées aux vendeurs (visiteur → connexion, client sans boutique → « Vendre »)",
            Client().get("simple")[0] in (302, 303) and Client().get("simple/produit")[0] in (302, 303))

    S.titre("METTRE UN PRODUIT : PHOTO, IMAGE DE LA CATÉGORIE, PRIX, QUANTITÉ")
    cat = sql("SELECT id FROM categories WHERE parent_id IS NULL ORDER BY position, nom LIMIT 1")
    catnom = sql(f"SELECT nom FROM categories WHERE id={cat}")
    h = txt(VS, "simple/produit")
    S.check("formulaire : prendre une photo (appareil), choisir dans le téléphone, catégories en images, prix en chiffres, « − / + », micro",
            'capture="environment"' in h and 'name="categorie_id"' in h and 'inputmode="numeric"' in h and "simple-plus" in h and 'id="voix-demarrer"' in h)
    ok_jpg = (IMG / "ok.jpg").read_bytes()
    n0 = int(sql(f"SELECT COUNT(*) FROM produits WHERE boutique_id={bs}"))
    _, h, _ = VS.multipart("simple/produit", {"categorie_id": cat, "prix": "5 000", "stock": "3", "nom": ""}, [])
    S.check("sans photo : message clair, rien n'est créé", "Ajoutez au moins une photo" in h and int(sql(f"SELECT COUNT(*) FROM produits WHERE boutique_id={bs}")) == n0)
    _, h, _ = VS.multipart("simple/produit", {"categorie_id": cat, "prix": "cinq mille", "stock": "3", "nom": ""}, [("photos[]", "p.jpg", ok_jpg, "image/jpeg")])
    S.check("prix sans chiffres : refusé (« Écrivez le prix en chiffres »)", "Écrivez le prix en chiffres" in h.replace("&#039;", "'"))
    _, h, _ = VS.multipart("simple/produit", {"categorie_id": "", "prix": "5000", "stock": "3", "nom": ""}, [("photos[]", "p.jpg", ok_jpg, "image/jpeg")])
    S.check("catégorie non choisie : refusé", "touchez une image" in h)
    _, h, _ = VS.multipart("simple/produit", {"categorie_id": cat, "prix": "5000", "stock": "3", "nom": ""}, [("photos[]", "x.php", (IMG / "shell.jpg").read_bytes(), "image/jpeg")])
    S.check("faux fichier image (code caché) : refusé, mêmes contrôles que le mode complet", int(sql(f"SELECT COUNT(*) FROM produits WHERE boutique_id={bs}")) == n0)
    st, _, hd = VS.multipart("simple/produit", {"categorie_id": cat, "prix": "5 000", "stock": "3", "nom": ""},
                             [("photos[]", "", b"", "application/octet-stream"), ("photos[]", "p.jpg", ok_jpg, "image/jpeg")])
    p = sql(f"SELECT id, nom, prix, stock, statut FROM produits WHERE boutique_id={bs} ORDER BY id DESC LIMIT 1").split("\t")
    S.check("produit créé : prix « 5 000 » lu comme 5000, quantité 3, en vente, retour à « Mes produits »",
            st in (302, 303) and hd.get("Location", "").endswith("/simple/produits") and p[2:] == ["5000", "3", "publie"])
    S.check("sans nom tapé : le produit prend le nom de sa catégorie et de la boutique", p[1] == f"{catnom} — Boutique T57 Simple")
    chemin = sql(f"SELECT chemin FROM produit_images WHERE produit_id={p[0]}")
    S.check("la photo est enregistrée (et sa miniature), le champ vide de l'appareil photo est ignoré",
            int(sql(f"SELECT COUNT(*) FROM produit_images WHERE produit_id={p[0]}")) == 1 and (JEND / chemin).exists() and (JEND / re.sub(r"\.(jpg|png)$", "-m.jpg", chemin)).exists())
    S.check("le produit apparaît aussi dans l'espace complet et sur le site", sql(f"SELECT COUNT(*) FROM produits WHERE id={p[0]} AND boutique_id={bs}") == "1"
            and Client().get("produit/" + sql(f"SELECT slug FROM produits WHERE id={p[0]}"))[0] == 200)
    _, h, _ = VS.multipart("simple/produit", {"categorie_id": cat, "prix": "12000", "stock": "1", "nom": "Boubou bazin T57"}, [("photos[]", "p.png", (IMG / "ok.png").read_bytes(), "image/png")])
    S.check("nom facultatif écrit par quelqu'un d'autre : gardé", sql(f"SELECT COUNT(*) FROM produits WHERE boutique_id={bs} AND nom='Boubou bazin T57' AND prix=12000") == "1")

    S.titre("MES PRODUITS : « − / + », RETIRER, REMETTRE")
    pid = p[0]
    autre_id_bidon = 999999999
    h = txt(VS, "simple/produits")
    S.check("liste en images : photo, prix en gros, quantité", "5 000 FCFA" in h and f'id="produit-{pid}"' in h and "En vente" in h and f'data-produit="{pid}"' in h)
    act = lambda a, i=pid: VS.post("simple/produits", {"id": i, "action": a}, page_token="simple/produits")
    act("plus"); act("plus")
    S.check("« + » deux fois : 3 → 5", sql(f"SELECT stock FROM produits WHERE id={pid}") == "5")
    act("moins")
    S.check("« − » : 5 → 4", sql(f"SELECT stock FROM produits WHERE id={pid}") == "4")
    import json as _json
    st, corps, _ = VS.req("simple/produits", {"csrf": VS.token("simple/produits"), "id": pid, "action": "plus"}, headers={"X-Requested-With": "fetch"})
    j = _json.loads(corps)
    S.check("« + » depuis la page (sans rechargement) : réponse JSON avec le nouveau chiffre", st == 200 and j["ok"] and j["stock"] == 5 and j["en_vente"] is True)
    st, corps, _ = VS.req("simple/produits", {"csrf": VS.token("simple/produits"), "id": autre_id_bidon, "action": "plus"}, headers={"X-Requested-With": "fetch"})
    S.check("… erreur renvoyée en JSON (produit introuvable)", st == 422 and _json.loads(corps)["ok"] is False)
    act("moins")
    sql(f"UPDATE produits SET stock=0 WHERE id={pid}"); act("moins")
    S.check("jamais en dessous de 0", sql(f"SELECT stock FROM produits WHERE id={pid}") == "0")
    sql(f"UPDATE produits SET stock=2 WHERE id={pid}")
    act("retirer")
    S.check("« Retirer » : le produit n'est plus en vente", sql(f"SELECT statut FROM produits WHERE id={pid}") == "archive" and "Pas en vente" in txt(VS, "simple/produits"))
    act("vendre")
    S.check("« Remettre en vente »", sql(f"SELECT statut FROM produits WHERE id={pid}") == "publie")
    sql(f"INSERT INTO produits (boutique_id,categorie_id,nom,slug,prix,stock,statut) VALUES ({bc},{cat},'Autre T57','autre-t57',1000,7,'publie')")
    autre = sql("SELECT id FROM produits WHERE slug='autre-t57'")
    act("plus", autre); act("retirer", autre)
    S.check("impossible de toucher au produit d'un autre vendeur", sql(f"SELECT stock, statut FROM produits WHERE id={autre}") == "7\tpublie")
    VS.req("simple/produits", {"id": pid, "action": "plus"})
    S.check("sans jeton de sécurité (CSRF) : rien ne change", sql(f"SELECT stock FROM produits WHERE id={pid}") == "2")

    S.titre("MES COMMANDES : UN SEUL GROS BOUTON À LA FOIS")
    sql(f"UPDATE produits SET stock=10 WHERE id={pid}")
    C = Client()
    C.post("inscription", {"nom": "Cliente T57", "email": E["cl"], "telephone": "", "mot_de_passe": "Wax-Thies-2026!", "mot_de_passe2": "Wax-Thies-2026!", "accepte": "1"})
    C.req("panier/ajouter", {"csrf": C.token("produits"), "produit_id": pid, "quantite": 2, "retour": "/jend/produits"})
    _, _, hd = C.post("commande", {"nom": "Cliente T57", "telephone": "77 123 45 59", "zone_id": zone, "adresse": "Rue 57 Thiès", "methode": "wave"})
    ref = hd.get("Location", "").rsplit("/", 1)[-1]
    cb = sql(f"SELECT cb.id FROM commande_boutiques cb JOIN commandes c ON c.id=cb.commande_id WHERE c.reference='{ref}' AND cb.boutique_id={bs}")
    h = txt(VS, "simple/commandes")
    S.check("commande non payée : « Attendez, n'envoyez rien », pas de bouton d'envoi", "Attendez" in h and "J'ai envoyé le colis" not in h)
    VS.post("simple/commandes", {"id": cb}, page_token="simple/commandes")
    S.check("et l'envoi est refusé par le serveur (mêmes règles que le mode complet)", sql(f"SELECT statut FROM commande_boutiques WHERE id={cb}") == "a_preparer")
    sql(f"UPDATE commandes SET statut_paiement='paye', statut='confirmee' WHERE reference='{ref}'")
    h = txt(VS, "simple/commandes")
    S.check("commande payée : photo du produit, « × 2 », client, Appeler / WhatsApp, montant reçu, bouton « J'ai envoyé le colis »",
            "× 2" in h and "Cliente T57" in h and 'href="tel:' in h and "wa.me/221771234559" in h and "Vous recevez" in h and "J'ai envoyé le colis" in h and "simple-commande-photo" in h)
    S.check("l'accueil simple affiche une pastille « 1 » sur Mes commandes", 'aria-label="1 à traiter"' in txt(VS, "simple"))
    VS.post("simple/commandes", {"id": cb}, page_token="simple/commandes")
    S.check("« J'ai envoyé le colis » : commande expédiée", sql(f"SELECT statut FROM commande_boutiques WHERE id={cb}") == "expediee")
    h = txt(VS, "simple/commandes")
    code = sql(f"SELECT code_livraison FROM commande_boutiques WHERE id={cb}")
    S.check("ensuite : grand champ « Code du client » et bouton « Le client a reçu »", "Code du client" in h and "Le client a reçu" in h)
    if code and code != "NULL":
        mauvais = "0000" if code != "0000" else "1111"
        _, h2, _ = VS.req("simple/commandes", {"csrf": VS.token("simple/commandes"), "id": cb, "code_livraison": mauvais})
        S.check("mauvais code : refusé, la commande reste expédiée", sql(f"SELECT statut FROM commande_boutiques WHERE id={cb}") == "expediee")
        VS.post("simple/commandes", {"id": cb, "code_livraison": code}, page_token="simple/commandes")
    else:
        S.check("(commande sans code : confirmation directe)", True)
        VS.post("simple/commandes", {"id": cb}, page_token="simple/commandes")
    S.check("bon code : commande livrée, elle disparaît de la liste", sql(f"SELECT statut FROM commande_boutiques WHERE id={cb}") == "livree" and "Pas de commande en ce moment" in txt(VS, "simple/commandes"))
    VC.post("simple/commandes", {"id": cb}, page_token="simple/commandes")
    S.check("un autre vendeur ne peut pas agir sur cette commande", sql(f"SELECT statut FROM commande_boutiques WHERE id={cb}") == "livree")

    S.titre("MON ARGENT : APERÇU COMPLET")
    h = txt(VS, "simple/argent")
    m = re.search(r'class="simple-solde">.*?<b>([^<]*)</b>', h, re.S)
    S.check("solde en gros : 2 × 5 000 − 10 % (1 000) + 1 000 de livraison par le vendeur = 10 000 FCFA", "Jënd garde pour vous" in h and m and m.group(1) == "10 000 FCFA", m and m.group(1))
    S.check("taux de commission en gros (10 %) et exemple : 10 000 vendus → Jënd 1 000 → pour vous 9 000",
            "10 %" in h and "Vous vendez" in h and re.search(r"Jënd prend</small><b>1 000 FCFA", h) and re.search(r"Pour vous</small><b>9 000 FCFA", h))
    S.check("règles à connaître : rien à payer pour ouvrir, rien si pas livré, livraison pour le vendeur, préavis de 30 jours",
            "Rien à payer pour ouvrir" in h and "ne prend rien si la vente est annulée" in h and "frais de livraison sont pour vous" in h and "30 jours avant" in h)
    lignes = re.findall(r'<li class="simple-calcul-ligne[^"]*">.*?<b>([^<]+)</b>.*?<strong>([^<]+)</strong>', h, re.S)
    S.check("calcul ligne par ligne : ventes + livraison − commission = gagné, puis = gardé pour moi",
            lignes == [("Mes ventes livrées", "+ 10 000 FCFA"), ("Livraisons faites par moi", "+ 1 000 FCFA"), ("Commission de Jënd", "− 1 000 FCFA"), ("Ce que j'ai gagné", "10 000 FCFA"), ("Jënd garde pour moi", "10 000 FCFA")], lignes)
    S.check("dernière vente détaillée : photo, × 2, vente, part de Jënd, livraison, montant pour le vendeur",
            "Mes dernières ventes" in h and "× 2" in h and "− 1 000 FCFA" in h and "+ 1 000 FCFA" in h and "simple-ventes" in h)
    S.check("délai avant disponibilité et lien vers le relevé du mois", ("dès la livraison" in h or "après la livraison" in h) and "vendeur/releves" in h)
    S.check("numéro de paiement masqué s'il est affiché (jamais en entier)", "77 123 45 57" not in h)
    sql(f"UPDATE boutiques SET commission_gratuite_jusqu=DATE_ADD(CURDATE(), INTERVAL 10 DAY) WHERE id={bs}")
    sql("INSERT INTO parametres (cle, valeur) VALUES ('commission_annonce_pct','12'),('commission_annonce_le',DATE_FORMAT(DATE_ADD(CURDATE(), INTERVAL 30 DAY),'%Y-%m-%d')) ON DUPLICATE KEY UPDATE valeur=VALUES(valeur)")
    h = txt(VS, "simple/argent")
    S.check("parrainage : 0 % jusqu'à la date, et l'exemple suit (Jënd prend 0)", "Parrainage : 0 % jusqu'au" in h and re.search(r"Jënd prend</small><b>0 FCFA", h))
    S.check("changement de taux annoncé : prévenu avec la date et le nouveau taux", "Attention" in h and "12 %" in h)
    sql("DELETE FROM parametres WHERE cle IN ('commission_annonce_pct','commission_annonce_le')")
    sql(f"UPDATE boutiques SET commission_gratuite_jusqu=NULL WHERE id={bs}")
    h = txt(VC, "simple/argent")
    S.check("vendeur sans vente : le calcul attend la première livraison (pas de tableau vide)", "Pas encore de vente livrée" in h and "simple-calcul-ligne" not in h)

    S.titre("AIDE AUDIO")
    aide.parent.mkdir(parents=True, exist_ok=True)
    aide.write_bytes(b"ID3" + b"\0" * 200)
    h = txt(VS, "simple/commandes")
    S.check("message enregistré déposé dans assets/audio/aide/ : le bouton « Écouter » apparaît sur sa page", 'data-aide="aide-commandes"' in h and "assets/audio/aide/commandes.mp3" in h)
    S.check("… et seulement sur sa page", "data-aide" not in txt(VS, "simple/argent"))
    aide.unlink()

    S.titre("PASSER D'UN MODE À L'AUTRE")
    VS.req("simple/mode", {"mode": "complet"})
    S.check("sans jeton de sécurité : le mode ne change pas", sql(f"SELECT mode_simple FROM boutiques WHERE id={bs}") == "1")
    VS.post("simple/mode", {"mode": "complet"}, page_token="simple")
    S.check("« Passer au mode complet » : tableau de bord complet, mêmes produits", sql(f"SELECT mode_simple FROM boutiques WHERE id={bs}") == "0"
            and VS.get("vendeur")[0] == 200 and "Boubou bazin T57" in txt(VS, "vendeur/produits"))
    VS.post("simple/mode", {"mode": "simple"}, page_token="vendeur")
    S.check("« Passer au mode simple » depuis le tableau de bord : retour au mode simple", sql(f"SELECT mode_simple FROM boutiques WHERE id={bs}") == "1")
    S.check("le mode complet reste accessible page par page (Gains, Boutique…) même en mode simple", VS.get("vendeur/gains")[0] == 200 and VS.get("vendeur/produits")[0] == 200)
finally:
    if aide.exists():
        aide.unlink()
    sql("DELETE FROM produits WHERE slug='autre-t57'")
    S.nettoyer()
    sql("DELETE FROM zones_livraison WHERE nom='Zone T57'")
    ok = S.fin()
sys.exit(0 if ok else 1)
