"""Étape 29 : après la connexion, le vendeur et l'administrateur arrivent directement sur leur espace."""
import sys
from lib import *

S = Suite("Étape 29 — arrivée directe sur son espace", ["cl-t29@jend.local", "va-t29@jend.local", "ad-t29@jend.local"])
E = dict(zip(["cl", "va", "ad"], S.emails))
try:
    S.nettoyer()
    sql("DELETE FROM boutiques WHERE slug='boutique-t29'")
    pw = mot_de_passe()
    for k, nom, role in (("cl", "Cliente T29", "client"), ("va", "Vendeur T29", "vendeur"), ("ad", "Admin T29", "admin")):
        sql(f"INSERT INTO users (nom,email,mot_de_passe,role) VALUES ('{nom}','{E[k]}','{hash_mdp(pw)}','{role}')")
    sql(f"INSERT INTO boutiques (user_id,nom,slug,statut,commission_pct) SELECT id,'Boutique T29','boutique-t29','active',3 FROM users WHERE email='{E['va']}'")
    dest = lambda cl, email, extra={}: cl.post("connexion", {"email": email, "mot_de_passe": pw, **extra}, page_token="connexion")[2].get("Location", "")

    S.check("un client arrive sur « Mon compte »", dest(Client(), E["cl"]).endswith("/compte"))
    S.check("un vendeur arrive directement sur son tableau de bord", dest(Client(), E["va"]).endswith("/vendeur"))
    S.check("un administrateur arrive directement sur l'administration", dest(Client(), E["ad"]).endswith("/admin"))
    S.check("une page demandée explicitement est respectée (retour=…)", dest(Client(), E["va"], {"retour": "/jend/panier"}).endswith("/panier"))
    V = Client(); V.post("connexion", {"email": E["va"], "mot_de_passe": pw}, page_token="connexion")
    S.check("déjà connecté, la page de connexion renvoie vers son espace", V.get("connexion")[2].get("Location", "").endswith("/vendeur") or "Espace vendeur" in V.get("connexion")[1])
    S.check("le lien du compte, en haut du site, mène à son espace", 'href="/jend/vendeur"' in V.get("produits")[1])
    S.check("le bouton « Quitter » est dans l'en-tête de toutes les pages pour un compte connecté", 'action="/jend/deconnexion"' in V.get("vendeur")[1] and 'action="/jend/deconnexion"' in V.get("produits")[1])
    S.check("et n'apparaît pas pour un visiteur", 'action="/jend/deconnexion"' not in Client().get("produits")[1])
    V.post("deconnexion", {}, page_token="vendeur")
    S.check("il déconnecte vraiment", "/connexion" in V.get("vendeur")[2].get("Location", ""))
    css = Client().get("assets/css/identite.css")[1]
    S.check("panneaux « récap » (commande, signalement) : plus de décalage de 130 px vers le bas, sous le pied de page", ".recap-pleine { position: relative; top: auto;" in css)
finally:
    ok = S.fin()
    sql("DELETE FROM boutiques WHERE slug='boutique-t29'")
sys.exit(0 if ok else 1)
