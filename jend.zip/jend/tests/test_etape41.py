"""Étape 41 : notifications (pastilles sur les onglets des tableaux de bord, cloche dans l'en-tête)."""
import re, sys
from lib import *

S = Suite("Étape 41 — notifications", ["ad-t41@jend.local", "cl-t41@jend.local", "va-t41@jend.local"])
E = dict(zip(["ad", "cl", "va"], S.emails))
def pastille(h, chemin):
    nav = re.search(r'<nav class="onglets".*?</nav>', h, flags=re.S)
    h = nav.group(0) if nav else ""
    m = re.search(r'href="/jend/' + re.escape(chemin) + r'"[^>]*>.*?</a>', h, flags=re.S)
    p = re.search(r'pastille-onglet[^"]*"[^>]*>(\d+)', m.group(0)) if m else None
    return int(p.group(1)) if p else 0
def cloche(h):
    m = re.search(r'class="cloche[^"]*".*?</a>', h, flags=re.S)
    p = re.search(r'class="pastille">(\d+)', m.group(0)) if m else None
    return int(p.group(1)) if p else 0
try:
    S.nettoyer()
    sql("DELETE FROM produits WHERE slug='produit-t41'"); sql("DELETE FROM boutiques WHERE slug IN ('boutique-t41','attente-t41')")
    sql("DELETE FROM zones_livraison WHERE nom='Zone T41'"); sql("DELETE FROM messages_support")
    sql("INSERT INTO zones_livraison (nom, region, frais, delai_jours) VALUES ('Zone T41', 'Touba', 500, 1)")
    zone = int(sql("SELECT id FROM zones_livraison WHERE nom='Zone T41'"))
    pw = mot_de_passe()
    for k, nom, role in (("ad", "Admin T41", "admin"), ("cl", "Cliente T41", "client"), ("va", "Vendeur T41", "vendeur")):
        sql(f"INSERT INTO users (nom,email,mot_de_passe,role) VALUES ('{nom}','{E[k]}','{hash_mdp(pw)}','{role}')")
    sql(f"INSERT INTO boutiques (user_id,nom,slug,statut,commission_pct,sur_mesure,telephone_paiement) SELECT id,'Boutique T41','boutique-t41','active',1,1,'+221771112233' FROM users WHERE email='{E['va']}'")
    sql("INSERT INTO produits (boutique_id,categorie_id,nom,slug,description,prix,stock,statut) SELECT b.id,(SELECT MIN(id) FROM categories),'Produit T41','produit-t41','x',10000,3,'publie' FROM boutiques b WHERE b.slug='boutique-t41'")
    AD, C, VA = Client(), Client(), Client()
    for cl, k in ((AD, "ad"), (C, "cl"), (VA, "va")):
        cl.post("connexion", {"email": E[k], "mot_de_passe": pw})

    S.titre("RIEN À FAIRE")
    h = C.get("compte")[1]
    S.check("client sans action en attente : aucune pastille, cloche sans chiffre", pastille(h, "compte") == 0 and cloche(h) == 0 and "Rien à faire" in h)

    S.titre("LE CLIENT")
    C.req("panier/ajouter", {"csrf": C.token("produits"), "produit_id": sql("SELECT id FROM produits WHERE slug='produit-t41'"), "quantite": 1, "retour": "/jend/produits"})
    _, _, hd = C.post("commande", {"nom": "Cliente T41", "telephone": "78 000 11 41", "zone_id": zone, "adresse": "Rue 41 Touba", "methode": "wave"})
    ref = hd["Location"].rsplit("/", 1)[-1]
    C.post("produit/produit-t41", {"action": "offre", "prix": "8000", "quantite": "1"}, page_token="produit/produit-t41")
    VA.post("vendeur/offres", {"id": sql("SELECT MAX(id) FROM offres"), "action": "contre", "contre": "9000"})
    C.post("contact", {"telephone": "", "sujet": "paiement", "commande": "", "message": "Une question sur mon paiement Wave"}, page_token="contact")
    AD.post("admin/messages", {"id": sql("SELECT MAX(id) FROM messages_support"), "action": "repondre", "texte": "Bonjour, que se passe-t-il ?"})
    h = C.get("compte")[1]
    S.check("pastilles client : 1 commande à payer, 1 contre-proposition, 1 réponse de l'aide", pastille(h, "compte") == 1 and pastille(h, "offres") == 1 and pastille(h, "aide") == 1, f"{pastille(h, 'compte')}/{pastille(h, 'offres')}/{pastille(h, 'aide')}")
    S.check("la cloche de l'en-tête additionne tout (3) et mène à « Mon compte »", cloche(h) == 3 and 'class="cloche cloche-active"' in h)
    S.check("la cloche est visible sur toutes les pages, même hors du compte", cloche(C.get("produits")[1]) == 3)

    S.titre("LE VENDEUR")
    sql(f"UPDATE commandes SET statut_paiement='paye', statut='confirmee' WHERE reference='{ref}'")
    C.post("produit/produit-t41", {"action": "offre", "prix": "8500", "quantite": "1"}, page_token="produit/produit-t41")    # (déjà une offre en cours : refusée)
    sql("DELETE FROM limites WHERE cle LIKE 'mesure:%'")
    C.post("sur-mesure/boutique-t41", {"description": "Un boubou brodé bleu nuit en bazin riche", "mesures": "", "budget": "", "date": ""}, page_token="sur-mesure/boutique-t41")
    h = VA.get("vendeur")[1]
    S.check("pastilles vendeur : 1 commande à préparer, 1 demande sur mesure, 1 produit en stock bas", pastille(h, "vendeur/commandes") == 1 and pastille(h, "vendeur/sur-mesure") == 1 and pastille(h, "vendeur/produits") == 1,
            f"{pastille(h, 'vendeur/commandes')}/{pastille(h, 'vendeur/sur-mesure')}/{pastille(h, 'vendeur/produits')}")
    S.check("la cloche du vendeur mène à son tableau de bord", cloche(h) >= 3 and re.search(r'href="/jend/vendeur" class="cloche', h) is not None)

    S.titre("L'ADMINISTRATEUR")
    sql(f"INSERT INTO boutiques (user_id,nom,slug,statut) SELECT id,'Attente T41','attente-t41','en_attente' FROM users WHERE email='{E['cl']}'")
    C.post(f"aide/{sql('SELECT reference FROM messages_support ORDER BY id DESC LIMIT 1')}", {"texte": "Le débit a eu lieu hier soir."}, page_token="compte")
    h = AD.get("admin")[1]
    S.check("pastilles admin : 1 boutique à valider, 1 message (le client a répondu)", pastille(h, "admin/boutiques") == 1 and pastille(h, "admin/messages") == 1)
    S.check("la cloche de l'admin mène à l'administration", re.search(r'href="/jend/admin" class="cloche', h) is not None and cloche(h) >= 2)
    AD.post("admin/boutiques", {"action": "activer", "id": sql("SELECT id FROM boutiques WHERE slug='attente-t41'")})
    S.check("une fois la boutique validée, la pastille disparaît", pastille(AD.get("admin")[1], "admin/boutiques") == 0)
finally:
    ok = S.fin()
    sql("DELETE FROM produits WHERE slug='produit-t41'"); sql("DELETE FROM boutiques WHERE slug IN ('boutique-t41','attente-t41')")
    sql("DELETE FROM zones_livraison WHERE nom='Zone T41'"); sql("DELETE FROM messages_support"); sql("DELETE FROM limites WHERE cle LIKE 'offre:%' OR cle LIKE 'mesure:%' OR cle LIKE 'support%'")
sys.exit(0 if ok else 1)
