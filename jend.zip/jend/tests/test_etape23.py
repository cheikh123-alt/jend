"""Étape 23 : page « Paiements et reversements » (information des vendeurs sur les frais PayDunya, les délais et les retraits)."""
import re, sys
from lib import *

S = Suite("Étape 23 — informations de paiement pour les vendeurs", ["ad-t23@jend.local", "cl-t23@jend.local"])
E = S.emails
texte = lambda h: re.sub(r"\s+", " ", re.sub(r"<[^>]+>", " ", h)).replace("&#039;", "'")
try:
    S.nettoyer()
    sql("DELETE FROM parametres WHERE cle IN ('jour_reversement','paydunya_taux_indicatif','delai_retrait_jours')")
    pw = mot_de_passe()
    sql(f"INSERT INTO users (nom,email,mot_de_passe,role) VALUES ('Admin T23','{E[0]}','{hash_mdp(pw)}','admin')")
    AD, C = Client(), Client(); AD.post("connexion", {"email": E[0], "mot_de_passe": pw})
    C.post("inscription", {"nom": "Cliente T23", "email": E[1], "mot_de_passe": pw, "mot_de_passe2": pw})

    S.titre("LA PAGE POUR LES VENDEURS")
    s, h, _ = Client().get("paiements-vendeurs")
    t = texte(h)
    S.check("page publique « Paiements et reversements » (200) liée depuis le pied de page et depuis « Frais et commissions »", s == 200 and "paiements-vendeurs" in Client().get("")[1] and "paiements-vendeurs" in Client().get("frais-commissions")[1])
    S.check("elle explique le trajet de l'argent : PayDunya → compte de Jënd → « Mes gains » → retrait", all(x in t for x in ("PayDunya", "compte de Jënd", "Mes gains", "retrait", "code que le client vous donne")))
    S.check("elle dit clairement qui paie les frais PayDunya aujourd'hui (Jënd) et que cela peut changer avec 30 jours de préavis", "frais de PayDunya sont aujourd'hui à la charge de Jënd" in t and "30 jours à l'avance" in t)
    S.check("délai avant retrait (3 jours par défaut) et retrait minimum annoncés", "retirable 3 jours après la livraison" in t and "5 000 FCFA" in t.replace(" ", " ").replace("\xa0", " "))
    S.check("paiement à la livraison : seul l'acompte transite, le vendeur qui livre encaisse le reste", re.search(r"Seul l' ?acompte réglé en ligne passe par Jënd", t) is not None)
    S.check("limites de PayDunya reconnues (retenue de fonds possible, délais), avec liens vers leurs documents officiels en nouvel onglet sécurisé", "retenir ou bloquer des fonds" in t and 'href="https://paydunya.com/service-fees" target="_blank" rel="noopener noreferrer"' in h and 'href="https://paydunya.com/terms-of-service" target="_blank" rel="noopener noreferrer"' in h)
    S.check("aucun taux de frais inventé : sans réglage de l'admin, la page renvoie vers la grille officielle", "Leurs taux exacts et à jour sont publiés" in t and not re.search(r"\d+(,\d+)?\s?%\s+(par|de frais)", t))
    S.check("aucun jour de reversement annoncé tant que l'admin n'en choisit pas", "dans les meilleurs délais" in t)

    S.titre("RÉGLAGES DE L'ADMINISTRATEUR")
    S.check("section « Informations de paiement montrées aux vendeurs » dans Paramètres, réservée à l'admin", "Informations de paiement montrées aux vendeurs" in AD.get("admin/parametres")[1] and C.get("admin/parametres")[0] == 404)
    AD.post("admin/parametres", {"action": "infos_paiement", "jour": "lundi", "taux": "3 % par paiement mobile money (à vérifier)"})
    t = texte(Client().get("paiements-vendeurs")[1])
    S.check("jour de reversement et taux indicatif apparaissent aussitôt, présentés comme indicatifs", "chaque lundi" in t.lower() and "3 % par paiement mobile money (à vérifier)" in t and "à titre indicatif" in t)
    AD.post("admin/parametres", {"action": "infos_paiement", "jour": "dimanche", "taux": "ok"})
    AD.post("admin/parametres", {"action": "infos_paiement", "jour": "mardi", "taux": '<script>alert(1)</script>'})
    AD.post("admin/parametres", {"action": "infos_paiement", "jour": "mardi", "taux": "x" * 200})
    S.check("jour inconnu, balises ou texte trop long : refusés (réglage inchangé)", sql("SELECT valeur FROM parametres WHERE cle='jour_reversement'") == "lundi" and "<script>" not in Client().get("paiements-vendeurs")[1])
    C.post("admin/parametres", {"action": "infos_paiement", "jour": "vendredi", "taux": "1 %"}, page_token="compte")
    S.check("un client ne peut pas modifier ces informations", sql("SELECT valeur FROM parametres WHERE cle='jour_reversement'") == "lundi")
    AD.post("admin/parametres", {"action": "retraits", "jours": "5"})
    S.check("le délai annoncé suit le réglage de l'admin (5 jours)", "retirable 5 jours après la livraison" in texte(Client().get("paiements-vendeurs")[1]))
    S.check("les changements sont dans le journal", int(sql("SELECT COUNT(*) FROM journal_admin WHERE action='infos_paiement_modifiees'")) == 1)
finally:
    sql("DELETE FROM parametres WHERE cle IN ('jour_reversement','paydunya_taux_indicatif','delai_retrait_jours')")
    ok = S.fin()
    sql("DELETE FROM journal_admin WHERE action IN ('infos_paiement_modifiees','delai_retrait_modifie')")
sys.exit(0 if ok else 1)
