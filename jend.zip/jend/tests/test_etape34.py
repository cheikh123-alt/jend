"""Étape 34 : vidéo du produit (lien) et parrainage entre vendeurs."""
import sys
from lib import *

S = Suite("Étape 34 — vidéo produit et parrainage", ["ad-t34@jend.local", "cl-t34@jend.local", "va-t34@jend.local", "vb-t34@jend.local"])
E = dict(zip(["ad", "cl", "va", "vb"], S.emails))
try:
    S.nettoyer()
    sql("DELETE FROM produits WHERE slug LIKE 'produit-video-t34%'"); sql("DELETE FROM boutiques WHERE slug IN ('boutique-t34','filleul-t34')")
    sql("DELETE FROM zones_livraison WHERE nom='Zone T34'"); sql("DELETE FROM parametres WHERE cle='parrainage_jours'")
    sql("INSERT INTO zones_livraison (nom, region, frais, delai_jours) VALUES ('Zone T34', 'Touba', 500, 1)")
    zone = int(sql("SELECT id FROM zones_livraison WHERE nom='Zone T34'"))
    pw = mot_de_passe()
    for k, nom, role in (("ad", "Admin T34", "admin"), ("cl", "Cliente T34", "client"), ("va", "Vendeur T34", "vendeur"), ("vb", "Filleul T34", "client")):
        sql(f"INSERT INTO users (nom,email,mot_de_passe,role) VALUES ('{nom}','{E[k]}','{hash_mdp(pw)}','{role}')")
    sql(f"INSERT INTO boutiques (user_id,nom,slug,statut,commission_pct,code_parrain,telephone_paiement) SELECT id,'Boutique T34','boutique-t34','active',10,'PARRT34A','+221771112233' FROM users WHERE email='{E['va']}'")
    bid = sql("SELECT id FROM boutiques WHERE slug='boutique-t34'")
    cat = sql("SELECT MIN(id) FROM categories")
    AD, C, VA, VB, P = Client(), Client(), Client(), Client(), Client()
    for cl, k in ((AD, "ad"), (C, "cl"), (VA, "va"), (VB, "vb")):
        cl.post("connexion", {"email": E[k], "mot_de_passe": pw})
    txt = lambda cl, u: cl.get(u)[1].replace("&#039;", "'")
    def creer(nom, video):
        return VA.post("vendeur/produits/nouveau", {"nom": nom, "categorie_id": cat, "description": "x", "prix": "8000", "prix_barre": "", "stock": "5", "statut": "publie", "video_url": video}, page_token="vendeur/produits/nouveau")

    S.titre("VIDÉO DU PRODUIT")
    for mauvais in ("http://www.tiktok.com/@a/video/1", "https://site-inconnu.com/video", "javascript:alert(1)", "https://tiktok.com.pirate.net/x", "pas un lien"):
        creer("Produit video T34 refus", mauvais)
    S.check("liens refusés : http, site inconnu, javascript:, faux domaine, texte libre", sql("SELECT COUNT(*) FROM produits WHERE nom='Produit video T34 refus'") == "0")
    creer("Produit video T34", "https://www.tiktok.com/@jend/video/123456")
    slug = sql("SELECT slug FROM produits WHERE nom='Produit video T34'")
    S.check("lien TikTok en https accepté et enregistré", sql("SELECT video_url FROM produits WHERE nom='Produit video T34'") == "https://www.tiktok.com/@jend/video/123456")
    h = txt(P, f"produit/{slug}")
    S.check("la fiche produit affiche « Voir la vidéo du produit » (nouvel onglet, sans référent)", "Voir la vidéo du produit" in h and 'href="https://www.tiktok.com/@jend/video/123456"' in h and 'rel="noopener noreferrer nofollow"' in h)
    S.check("la carte du produit porte la pastille vidéo, et la page du lien de paiement propose la vidéo", "pastille-video" in txt(P, "produits") and "Voir la vidéo" in txt(P, f"payer/{slug}"))
    creer("Produit video T34 sans", "")
    S.check("la vidéo reste facultative", sql("SELECT COUNT(*) FROM produits WHERE nom='Produit video T34 sans' AND video_url IS NULL") == "1")

    S.titre("PARRAINAGE ENTRE VENDEURS")
    h = txt(VA, "vendeur")
    S.check("le tableau de bord du vendeur propose son lien de parrainage (30 jours par défaut)", "Parrainer un vendeur" in h and "vendre?parrain=PARRT34A" in h and "30 jours sans commission" in h)
    h = txt(VB, "vendre?parrain=PARRT34A")
    S.check("le filleul qui ouvre le lien voit qui l'invite", "Vous êtes invité par" in h and "Boutique T34" in h)
    VB.post("vendre", {"nom": "Filleul T34", "description": "", "telephone": "77 222 33 44", "accepte": "1"}, page_token="vendre")
    fid = sql("SELECT id FROM boutiques WHERE slug='filleul-t34'")
    S.check("sa boutique est rattachée au parrain et reçoit son propre code", sql(f"SELECT parrain_boutique_id FROM boutiques WHERE id={fid}") == bid and len(sql(f"SELECT code_parrain FROM boutiques WHERE id={fid}")) == 8)
    S.check("pas de récompense tant que la boutique n'est pas validée", sql(f"SELECT COALESCE(commission_gratuite_jusqu,'') FROM boutiques WHERE id={bid}") == "")
    VA.post("admin/boutiques", {"action": "activer", "id": fid}, page_token="vendeur")
    S.check("un vendeur ne peut pas valider lui-même la boutique de son filleul", sql(f"SELECT statut FROM boutiques WHERE id={fid}") == "en_attente")
    AD.post("admin/boutiques", {"action": "activer", "id": fid})
    S.check("l'admin valide : parrain ET filleul gagnent 30 jours sans commission", sql(f"SELECT DATEDIFF(commission_gratuite_jusqu, CURDATE()) FROM boutiques WHERE id={bid}") == "30" and sql(f"SELECT DATEDIFF(commission_gratuite_jusqu, CURDATE()) FROM boutiques WHERE id={fid}") == "30")
    AD.post("admin/boutiques", {"action": "suspendre", "id": fid}); AD.post("admin/boutiques", {"action": "activer", "id": fid})
    S.check("réactiver la boutique ne redonne pas la récompense", sql(f"SELECT DATEDIFF(commission_gratuite_jusqu, CURDATE()) FROM boutiques WHERE id={bid}") == "30")
    S.check("le vendeur voit « aucune commission jusqu'au … » dans son espace", "aucune commission jusqu'au" in txt(VA, "vendeur"))
    C.req("panier/ajouter", {"csrf": C.token("produits"), "produit_id": sql("SELECT id FROM produits WHERE nom='Produit video T34'"), "quantite": 1, "retour": "/jend/produits"})
    _, _, hd = C.post("commande", {"nom": "Cliente T34", "telephone": "78 000 11 34", "zone_id": zone, "adresse": "Rue 34 Touba", "methode": "wave"})
    ref = hd["Location"].rsplit("/", 1)[-1]
    S.check("pendant la période offerte, la commande ne porte aucune commission (boutique à 10 %)", sql(f"SELECT cb.commission FROM commande_boutiques cb JOIN commandes c ON c.id=cb.commande_id WHERE c.reference='{ref}'") == "0")
    sql(f"UPDATE boutiques SET commission_gratuite_jusqu = CURDATE() - INTERVAL 1 DAY WHERE id={bid}")
    C.req("panier/ajouter", {"csrf": C.token("produits"), "produit_id": sql("SELECT id FROM produits WHERE nom='Produit video T34'"), "quantite": 1, "retour": "/jend/produits"})
    _, _, hd = C.post("commande", {"nom": "Cliente T34", "telephone": "78 000 11 34", "zone_id": zone, "adresse": "Rue 34 Touba", "methode": "wave"})
    ref2 = hd["Location"].rsplit("/", 1)[-1]
    S.check("après la période, la commission normale revient (10 % de 8 000 = 800)", sql(f"SELECT cb.commission FROM commande_boutiques cb JOIN commandes c ON c.id=cb.commande_id WHERE c.reference='{ref2}'") == "800")
    AD.post("admin/parametres", {"action": "parrainage", "jours": "0"})
    S.check("l'admin peut désactiver le parrainage : le bloc disparaît du tableau de bord", sql("SELECT valeur FROM parametres WHERE cle='parrainage_jours'") == "0" and "Parrainer un vendeur" not in txt(VA, "vendeur"))
    for mauvais in ("-3", "abc", "400"):
        AD.post("admin/parametres", {"action": "parrainage", "jours": mauvais})
    S.check("valeurs invalides refusées", sql("SELECT valeur FROM parametres WHERE cle='parrainage_jours'") == "0")
finally:
    sql("DELETE FROM parametres WHERE cle='parrainage_jours'")
    ok = S.fin()
    sql("DELETE FROM produits WHERE slug LIKE 'produit-video-t34%'"); sql("DELETE FROM boutiques WHERE slug IN ('boutique-t34','filleul-t34')")
    sql("DELETE FROM zones_livraison WHERE nom='Zone T34'")
    sql("DELETE FROM journal_admin WHERE action IN ('parrainage_recompense','parrainage_modifie')")
sys.exit(0 if ok else 1)
