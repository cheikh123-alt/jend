"""Étape 8 : paiement en ligne (simulation) — parcours normal, attaques sur le webhook, production."""
import json, re, sys, time, hmac, hashlib
from lib import *

S = Suite("Étape 8 — paiement", ["alice-t8@jend.local", "bob-t8@jend.local"])
E = S.emails
try:
    S.nettoyer()
    S.publier_demo()
    pa = mot_de_passe()
    A, B = Client(), Client()
    A.post("inscription", {"nom": "Alice Test", "email": E[0], "mot_de_passe": pa, "mot_de_passe2": pa})
    B.post("inscription", {"nom": "Bob Test", "email": E[1], "mot_de_passe": pa, "mot_de_passe2": pa})
    F = int(sql(f"SELECT frais FROM zones_livraison WHERE id={zones_actives_ids()[0]}"))      # frais de la première zone de livraison active
    T1, T2, T4 = 95000 + F, 5000 + F, 14500 + F                                        # totaux des commandes testées (produits + livraison)
    cnt = lambda ref: sql(f"SELECT COUNT(*) FROM paiements p JOIN commandes c ON c.id=p.commande_id WHERE c.reference='{ref}'")

    S.titre("PARCOURS NORMAL (Wave)")
    ref = acheter(A, 2, 1, "wave")                       # 95 000 + frais
    S.check("commande Wave créée, en attente de paiement", ref.startswith("JND-") and etat(ref) == "en_attente|en_attente", ref)
    S.check("page commande propose « Payer maintenant »", "Payer maintenant" in A.get("commande/" + ref)[1])
    s, _, hd = A.post("paiement/" + ref, {}, page_token="commande/" + ref)
    sim = hd.get("Location", "")
    S.check("démarrage du paiement → page du fournisseur", s == 302 and "/paiement/simulation/SIM-" in sim, sim)
    pref = sim.rsplit("/", 1)[-1]
    h = A.get(sim.replace("http://localhost/jend/", "").replace("/jend/", ""))[1]
    S.check("page de simulation affiche le bon montant", (f"{T1:,}".replace(",", " ") + " FCFA") in h.replace("\u202f", " ") and "MODE SIMULATION" in h)
    A.get("paiement/" + ref)
    S.check("démarrer en GET (lien piégé) est refusé", cnt(ref) == "1")

    S.titre("RETOUR DU NAVIGATEUR ≠ PREUVE DE PAIEMENT")
    h = A.get("paiement/retour/" + ref)[1]
    S.check("retour sans webhook : « en cours de vérification », pas payé", "en cours de vérification" in h and etat(ref) == "en_attente|en_attente")

    S.titre("WEBHOOK : ATTAQUES")
    S.check("sans signature → 401", webhook(pref, "reussi", T1, signer=False)[0] == 401 and etat(ref) == "en_attente|en_attente")
    S.check("fausse signature → 401", webhook(pref, "reussi", T1, signature="0" * 64)[0] == 401 and etat(ref) == "en_attente|en_attente")
    S.check("montant truqué (signé) → 400, commande non payée", webhook(pref, "reussi", F)[0] == 400 and etat(ref) == "en_attente|en_attente")
    S.check("notification périmée (1 h) → 400", webhook(pref, "reussi", T1, t=int(time.time()) - 3600)[0] == 400 and etat(ref) == "en_attente|en_attente")
    S.check("référence inconnue → 404", webhook("SIM-" + "a" * 24, "reussi", T1)[0] == 404)
    s = Client().req("paiement/webhook", raw=b"pas du json", headers={"X-Signature": hmac.new(secret_paiement().encode(), b"pas du json", hashlib.sha256).hexdigest()})[0]
    S.check("corps mal formé (signé) → 400", s == 400)
    S.check("GET sur le webhook → 405", Client().get("paiement/webhook")[0] == 405)

    S.titre("WEBHOOK : SUCCÈS")
    S.check("notification valide → commande payée et confirmée", webhook(pref, "reussi", T1)[0] == 200 and etat(ref) == "confirmee|paye", etat(ref))
    S.check("paiement enregistré « reussi » avec preuve brute", sql(f"SELECT CONCAT(statut,'|',IF(reponse_brute IS NULL,'sans','avec')) FROM paiements WHERE reference_externe='{pref}'") == "reussi|avec")
    s, h, _ = webhook(pref, "reussi", T1)
    S.check("même notification rejouée → ignorée (200 « Déjà traité »)", s == 200 and json.loads(h)["message"] == "Déjà traité")
    webhook(pref, "echoue", T1)
    S.check("un « échec » tardif ne casse pas une commande payée", etat(ref) == "confirmee|paye")
    S.check("une seule ligne de paiement réussie", sql(f"SELECT COUNT(*) FROM paiements p JOIN commandes c ON c.id=p.commande_id WHERE c.reference='{ref}' AND p.statut='reussi'") == "1")
    S.check("page retour : « Paiement reçu »", "Paiement reçu" in A.get("paiement/retour/" + ref)[1])
    h = A.get("commande/" + ref)[1]
    S.check("commande payée : plus de bouton payer, plus d'annulation", "Payer maintenant" not in h and "Annuler cette commande" not in h and "reçu via" in h)
    A.post("commande/annuler", {"reference": ref}, page_token="compte")
    S.check("annulation d'une commande payée refusée", etat(ref) == "confirmee|paye")

    S.titre("ÉCHEC PUIS NOUVELLE TENTATIVE (Orange Money)")
    ref2 = acheter(A, 4, 2, "orange_money")              # 2 x 2 500 + frais
    p1 = A.post("paiement/" + ref2, {}, page_token="commande/" + ref2)[2]["Location"].rsplit("/", 1)[-1]
    webhook(p1, "echoue", T2)
    S.check("paiement refusé → statut « echoue »", etat(ref2) == "en_attente|echoue", etat(ref2))
    h = A.get("commande/" + ref2)[1]
    S.check("la commande propose de réessayer", "Payer maintenant" in h and "a échoué" in h)
    p2 = A.post("paiement/" + ref2, {}, page_token="commande/" + ref2)[2]["Location"].rsplit("/", 1)[-1]
    S.check("nouvelle tentative = nouvelle référence", p2 != p1)
    webhook(p2, "reussi", T2)
    S.check("2e tentative réussie → commande payée", etat(ref2) == "confirmee|paye")

    S.titre("SIMULATION : ENCHAÎNEMENT RÉEL VIA LA PAGE")
    ref3 = acheter(A, 6, 1, "carte")                     # 4 500 + frais
    simpath = A.post("paiement/" + ref3, {}, page_token="commande/" + ref3)[2]["Location"].replace("http://localhost/jend/", "").replace("/jend/", "")
    s, _, hd = A.post(simpath, {"resultat": "abandon"})
    S.check("abandon sans payer : commande reste en attente", etat(ref3) == "en_attente|en_attente" and "paiement/retour" in hd.get("Location", ""))
    A.post(simpath, {"resultat": "reussi"})
    S.check("bouton « paiement réussi » → webhook signé → payée", etat(ref3) == "confirmee|paye")
    h = A.get(simpath)[1]
    S.check("page de simulation déjà traitée : plus de boutons", "déjà été traité" in h and "Simuler un paiement réussi" not in h)

    S.titre("ACCÈS D'UN AUTRE CLIENT")
    ref4 = acheter(A, 8, 1, "wave")
    S.check("B ne peut pas démarrer le paiement de A (404)", B.post("paiement/" + ref4, {}, page_token="produits")[0] == 404)
    S.check("B ne voit pas la page retour de A (404)", B.get("paiement/retour/" + ref4)[0] == 404)

    S.titre("ANNULATION PUIS PAIEMENT TARDIF")
    p4 = A.post("paiement/" + ref4, {}, page_token="commande/" + ref4)[2]["Location"].rsplit("/", 1)[-1]
    A.post("commande/annuler", {"reference": ref4}, page_token="compte")
    S.check("commande en attente annulée", etat(ref4) == "annulee|en_attente")
    S.check("commande annulée : pas de bouton payer", "Payer maintenant" not in A.get("commande/" + ref4)[1])
    A.post("paiement/" + ref4, {}, page_token="commande/" + ref4)
    S.check("impossible de relancer le paiement d'une commande annulée", cnt(ref4) == "1")
    webhook(p4, "reussi", T4)
    S.check("paiement tardif : commande annulée mais argent tracé (à rembourser)", etat(ref4) == "annulee|paye", etat(ref4))

    S.titre("PRODUCTION : LA SIMULATION DOIT DISPARAÎTRE")
    S.modifier_env(APP_ENV="prod", MAIL_DRIVER="log", APP_URL="https://jend.example.test", TRUSTED_PROXY="1")
    xf = {"X-Forwarded-Proto": "https"}                  # on simule un proxy HTTPS pour ne pas être redirigé
    S.check("page de simulation introuvable en production (404)", A.get(simpath, headers=xf)[0] == 404)
    s, h, _ = Client().req("paiement/webhook", raw=b"{}", headers={"X-Signature": "x", **xf})
    S.restaurer_env()
    S.check("webhook sans clé secrète en production : échoue (500) sans rien accepter ni rien révéler", s == 500 and "PAIEMENT_SECRET" not in h and "/Applications/" not in h, f"{s} {h[:80]}")
finally:
    ok = S.fin()
sys.exit(0 if ok else 1)
