"""Étape 61 : interrupteur « paiement en ligne » — tant qu'aucun prestataire n'a validé le compte, le site fonctionne
en paiement à la livraison uniquement (sans acompte), et ne promet nulle part un paiement en ligne."""
import sys, re
from lib import *

S = Suite("Étape 61 — paiement à la livraison uniquement", ["ad-t61@jend.local", "ve-t61@jend.local", "cl-t61@jend.local"])
E = dict(zip(["ad", "ve", "cl"], S.emails))
AVANT = {}
try:
    for k in ("paiement_en_ligne", "paiement_livraison"):
        v = sql(f"SELECT valeur FROM parametres WHERE cle='{k}'")
        AVANT[k] = v if v != "" else None
    S.nettoyer()
    sql("DELETE FROM zones_livraison WHERE nom='Zone T61'")
    sql("INSERT INTO zones_livraison (nom, region, frais, delai_jours) VALUES ('Zone T61', 'Matam', 1000, 1)")
    zone = sql("SELECT id FROM zones_livraison WHERE nom='Zone T61'")
    pw = mot_de_passe()
    for k, nom, role in (("ad", "Admin T61", "admin"), ("ve", "Vendeur T61", "vendeur")):
        sql(f"INSERT INTO users (nom,email,mot_de_passe,role,email_verifie) VALUES ('{nom}','{E[k]}','{hash_mdp(pw)}','{role}',1)")
    sql(f"INSERT INTO boutiques (user_id,nom,slug,statut,commission_pct) SELECT id,'Boutique T61','boutique-t61','active',1 FROM users WHERE email='{E['ve']}'")
    sql("INSERT INTO produits (boutique_id,categorie_id,nom,slug,prix,stock,statut) SELECT b.id,(SELECT MIN(id) FROM categories),'Sac T61','sac-t61',10000,50,'publie' FROM boutiques b WHERE b.slug='boutique-t61'")
    pid = sql("SELECT id FROM produits WHERE slug='sac-t61'")
    AD, C = Client(), Client()
    AD.post("connexion", {"email": E["ad"], "mot_de_passe": pw})
    C.post("inscription", {"nom": "Client T61", "email": E["cl"], "telephone": "", "mot_de_passe": "Wax-Matam-2026!", "mot_de_passe2": "Wax-Matam-2026!", "accepte": "1"})
    regler = lambda actif: AD.post("admin/parametres", {"action": "paiement_en_ligne", **({"actif": "1"} if actif else {})}, page_token="admin/parametres")
    cod = lambda actif: AD.post("admin/parametres", {"action": "paiement_livraison", **({"actif": "1"} if actif else {})}, page_token="admin/parametres")

    def panier():
        C.req("panier/ajouter", {"csrf": C.token("produits"), "produit_id": pid, "quantite": 1, "retour": "/jend/produits"})

    def commander(methode):
        panier()
        st, corps, hd = C.post("commande", {"nom": "Client T61", "telephone": "77 123 45 61", "zone_id": zone, "adresse": "Rue 61 Matam", "methode": methode, "acompte_methode": "wave"})
        return hd.get("Location", "").rsplit("/", 1)[-1] if st in (302, 303) else None, corps

    S.titre("PAR DÉFAUT : PAIEMENT EN LIGNE PROPOSÉ")
    panier()
    h = C.get("commande")[1]
    S.check("Wave, Orange Money, carte proposés", 'value="wave"' in h and 'value="carte"' in h)
    ref_en_ligne, _ = commander("wave")
    S.check("commande Wave possible", ref_en_ligne is not None and len(ref_en_ligne) > 5)

    S.titre("GARDE-FOU")
    cod(False)
    regler(False)
    S.check("impossible de couper le paiement en ligne si le paiement à la livraison est aussi coupé (plus personne ne pourrait commander)",
            sql("SELECT valeur FROM parametres WHERE cle='paiement_en_ligne'") in ("", "1"))
    cod(True)

    S.titre("PAIEMENT EN LIGNE COUPÉ")
    regler(False)
    S.check("l'admin coupe le paiement en ligne (journalisé)", sql("SELECT valeur FROM parametres WHERE cle='paiement_en_ligne'") == "0" and sql("SELECT COUNT(*) FROM journal_admin WHERE action='paiement_en_ligne_desactive'") == "1")
    h = AD.get("admin/parametres")[1]
    S.check("l'administration l'affiche « Coupé »", "Paiement en ligne (Wave, Orange Money, carte)" in h and ">Coupé<" in h)
    cod(False)
    S.check("et refuse alors de couper aussi le paiement à la livraison", sql("SELECT valeur FROM parametres WHERE cle='paiement_livraison'") == "1")
    panier()
    h = C.get("commande")[1]
    S.check("page de commande : seulement « à la livraison », message clair, aucun acompte demandé",
            'value="wave"' not in h and 'value="carte"' not in h and 'value="livraison"' in h and "momentanément indisponible" in h and 'name="acompte_methode"' not in h)
    ref_bad, corps = commander("wave")
    S.check("commande Wave forcée (formulaire trafiqué) : refusée par le serveur", ref_bad is None)
    ref, _ = commander("livraison")
    S.check("commande à la livraison : enregistrée, sans acompte", ref is not None and sql(f"SELECT acompte FROM commandes WHERE reference='{ref}'") == "0")
    h = C.get("commande/" + ref)[1]
    S.check("pas de bouton de paiement ni de redirection : « Vous paierez … en espèces à la livraison »", "data-envoi-auto" not in h and "Payer maintenant" not in h and "en espèces à la livraison" in h)
    S.check("le vendeur doit préparer tout de suite (commande confirmée sans paiement en ligne)", sql(f"SELECT vendeur_prevenu_le IS NOT NULL FROM commande_boutiques cb JOIN commandes c ON c.id=cb.commande_id WHERE c.reference='{ref}'") == "1")
    h = C.get("commande/" + ref_en_ligne)[1]
    S.check("ancienne commande Wave non payée : message « momentanément indisponible », pas de bouton Payer", "momentanément indisponible" in h and "Payer maintenant" not in h)
    st, _, hd = C.post("paiement/" + ref_en_ligne, {}, page_token="commande/" + ref_en_ligne)
    S.check("et le démarrage du paiement est refusé (aucun envoi vers un prestataire)", hd.get("Location", "").endswith("/commande/" + ref_en_ligne))

    S.titre("AUCUNE PROMESSE DE PAIEMENT EN LIGNE")
    acc = Client().get("")[1]
    S.check("bandeau : « Paiement en espèces à la livraison », plus « Wave & Orange Money acceptés »", "Paiement en espèces à la livraison" in acc and "Orange Money acceptés" not in acc)
    S.check("accueil : pas de pastilles Wave / carte, « En espèces, à la livraison »", '<span class="chip">Wave</span>' not in acc and "En espèces, à la livraison" in acc)
    S.check("fiche produit : « Paiement en espèces à la livraison »", "Paiement en espèces à la livraison" in Client().get("produit/sac-t61")[1])
    v = Client().get("vendre")[1].replace("&#039;", "'")
    S.check("page « Vendre » : plus de « le client a payé avant » ni « Zéro impayé »", "Le client paie à la livraison" in v and "Zéro impayé" not in v and "Le client paie avant ?" not in v)

    S.titre("RALLUMER")
    regler(True)
    panier()
    h = C.get("commande")[1]
    S.check("paiement en ligne réactivé : Wave et carte de nouveau proposés", 'value="wave"' in h and 'value="carte"' in h)
    S.check("l'ancienne commande Wave peut de nouveau être payée", "Payer maintenant" in C.get("commande/" + ref_en_ligne)[1])
finally:
    for k, v in AVANT.items():
        sql(f"DELETE FROM parametres WHERE cle='{k}'")
        if v is not None:
            sql(f"INSERT INTO parametres (cle, valeur) VALUES ('{k}', '{v}')")
    sql("DELETE FROM produits WHERE slug='sac-t61'")
    S.nettoyer()
    sql("DELETE FROM zones_livraison WHERE nom='Zone T61'")
    ok = S.fin()
sys.exit(0 if ok else 1)
