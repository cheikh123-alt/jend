"""Étape 52 : boîte de réception de test (mode développement uniquement)."""
import sys
from lib import *

S = Suite("Étape 52 — boîte de réception de test")
LOG = JEND / "storage" / "emails.log"
try:
    S.titre("BOÎTE DE TEST")
    avant = LOG.read_text() if LOG.exists() else ""
    LOG.write_text(avant + "[2026-10-17 10:00:00] À : client-t52@jend.local\nSujet : Confirmez votre adresse e-mail\nOuvrez ce lien : http://127.0.0.1/jend/email/confirmer/abc <b>\n" + "-" * 60 + "\n")
    s, h, _ = Client().get("dev/emails")
    S.check("mode dev : la page liste l'e-mail (sujet, destinataire)", s == 200 and "Confirmez votre adresse e-mail" in h and "client-t52@jend.local" in h)
    S.check("les liens sont cliquables et le reste du texte est échappé", 'href="http://127.0.0.1/jend/email/confirmer/abc"' in h and "&lt;b&gt;" in h)
    S.check("le sujet ne contient pas le début du message", "<b>Confirmez votre adresse e-mail</b><small>" in h)
    S.check("filtre par recherche", "Confirmez votre adresse" not in Client().get("dev/emails?q=introuvable-xyz")[1])
    for mode in ("test", "prod"):
        S.modifier_env(APP_ENV=mode, APP_KEY="ab" * 32, PAIEMENT_SECRET="cd" * 32, FORCE_HTTPS="0")
        S.check(f"mode {mode} : page introuvable (404)", Client().get("dev/emails")[0] == 404)
    S.restaurer_env()
    LOG.write_text(avant)
finally:
    ok = S.fin()
sys.exit(0 if ok else 1)
