"""Étape 49 : vitesse (icônes allégées, animations sur l'accueil seulement, miniatures, cache), achat rapide et réassurance."""
import sys, re
from lib import *

S = Suite("Étape 49 — vitesse et conversion", ["cl-t49@jend.local", "va-t49@jend.local"])
E = dict(zip(["cl", "va"], S.emails))
IMG = fixtures_images()
try:
    S.nettoyer()
    sql("DELETE FROM produits WHERE slug='produit-t49'"); sql("DELETE FROM boutiques WHERE slug='boutique-t49'")
    pw = mot_de_passe()
    for k, nom, role in (("cl", "Cliente T49", "client"), ("va", "Vendeur T49", "vendeur")):
        sql(f"INSERT INTO users (nom,email,mot_de_passe,role) VALUES ('{nom}','{E[k]}','{hash_mdp(pw)}','{role}')")
    sql(f"INSERT INTO boutiques (user_id,nom,slug,statut,commission_pct) SELECT id,'Boutique T49','boutique-t49','active',1 FROM users WHERE email='{E['va']}'")
    cat = sql("SELECT MIN(id) FROM categories")
    sql(f"INSERT INTO produits (boutique_id,categorie_id,nom,slug,description,prix,stock,statut) SELECT b.id,{cat},'Bazin T49','produit-t49','x',15000,20,'publie' FROM boutiques b WHERE b.slug='boutique-t49'")
    prod = sql("SELECT id FROM produits WHERE slug='produit-t49'")
    C, VA = Client(), Client()
    for cl, k in ((C, "cl"), (VA, "va")):
        cl.post("connexion", {"email": E[k], "mot_de_passe": pw})
    txt = lambda cl, u: cl.get(u)[1].replace("&#039;", "'").replace(" ", " ").replace("&nbsp;", " ").replace("\xa0", " ")

    S.titre("VITESSE")
    accueil, fiche = txt(Client(), ""), txt(Client(), "produit/produit-t49")
    S.check("une seule feuille d'icônes allégée (plus les ~165 Ko complets)", "phosphor-site.css" in fiche and "phosphor-regular.css" not in fiche and "phosphor-fill.css" not in fiche)
    css = (JEND / "assets" / "vendor" / "css" / "phosphor-site.css")
    S.check("feuille d'icônes de moins de 25 Ko", css.stat().st_size < 25 * 1024)
    complet = (JEND / "assets" / "vendor" / "css" / "phosphor-regular.css").read_text() + (JEND / "assets" / "vendor" / "css" / "phosphor-fill.css").read_text()
    existantes = set(re.findall(r"\.(ph-[a-z0-9-]+):before", complet))
    utilisees = set()
    for f in [JEND / "index.php"] + list((JEND / "pages").rglob("*.php")) + list((JEND / "includes").rglob("*.php")) + list((JEND / "assets" / "js").glob("*.js")):
        utilisees |= set(re.findall(r"\bph-[a-z0-9]+(?:-[a-z0-9]+)*", f.read_text(errors="ignore")))
    manquantes = sorted(n for n in (utilisees & existantes) if f".{n}:before" not in css.read_text())
    S.check("chaque icône utilisée par le site est dans la feuille allégée" + (f" (manque : {' '.join(manquantes[:8])})" if manquantes else ""), not manquantes)
    polices = JEND / "assets" / "vendor" / "fonts"
    S.check("polices d'icônes réduites (moins de 40 Ko chacune) et sources complètes gardées pour régénérer",
            (polices / "Phosphor.woff2").stat().st_size < 40 * 1024 and (polices / "Phosphor-Fill.woff2").stat().st_size < 40 * 1024
            and (JEND / "scripts" / "sources-icones" / "Phosphor.woff2").stat().st_size > 100 * 1024)
    try:
        from fontTools.ttLib import TTFont
        cmap = set(TTFont(str(polices / "Phosphor.woff2")).getBestCmap()) | set(TTFont(str(polices / "Phosphor-Fill.woff2")).getBestCmap())
        points = {int(c, 16) for c in re.findall(r'content: "\\([0-9a-f]+)"', css.read_text())}
        S.check("chaque icône de la feuille a bien son symbole dans les polices réduites", points <= cmap)
    except ImportError:
        pass
    S.check("adresse des polices d'icônes versionnée (cache d'un an sans risque)", re.search(r'Phosphor\.woff2\?v=[0-9a-f]{10}', css.read_text()) is not None)
    S.check("animations seulement sur l'accueil ; ailleurs ni GSAP ni défilement « lissé »", "gsap.min.js" in accueil and "gsap.min.js" not in fiche and "lenis" not in accueil and "lenis" not in fiche)
    S.check("scripts chargés sans bloquer l'affichage (defer)", all("defer" in t for t in re.findall(r"<script [^>]*src=[^>]*>", accueil)))
    S.check("polices principales préchargées", 'rel="preload"' in fiche and "satoshi-400.woff2" in fiche)
    ht = (JEND / ".htaccess").read_text()
    S.check(".htaccess : compression (DEFLATE) et cache d'un an pour CSS, JS et polices", "DEFLATE" in ht and "max-age=31536000" in ht)

    S.titre("MINIATURES")
    base = {"nom": "Bazin T49", "categorie_id": cat, "description": "x", "prix": "15000", "prix_barre": "", "stock": "20", "statut": "publie", "video_url": ""}
    VA.multipart(f"vendeur/produits/{prod}/modifier", base, [("photos[]", "ok.jpg", (IMG / "ok.jpg").read_bytes(), "image/jpeg")])
    chemin = sql(f"SELECT chemin FROM produit_images WHERE produit_id={prod}")
    mini = chemin.replace(".jpg", "-m.jpg")
    S.check("une miniature légère est créée avec la photo", (JEND / mini).exists())
    h = txt(Client(), "boutique/boutique-t49")
    S.check("les cartes produits affichent la miniature (pas la grande photo)", mini in h and f'src="/jend/{chemin}"' not in h)
    S.check("la fiche produit garde la grande photo", chemin in txt(Client(), "produit/produit-t49"))
    (JEND / mini).unlink()
    S.check("photo ancienne sans miniature : elle est créée au premier affichage", mini in txt(Client(), "boutique/boutique-t49") and (JEND / mini).exists())

    S.titre("ACHAT RAPIDE ET RÉASSURANCE")
    h = txt(C, "produit/produit-t49")
    S.check("fiche produit : « Acheter maintenant », barre d'achat mobile, garanties près du bouton", "Acheter maintenant" in h and "barre-achat" in h and "Argent protégé" in h and "Code de réception" in h)
    S.check("bouton « Besoin d'aide ? » sur la fiche produit", "aide-flottante" in h)
    _, _, hd = C.post("panier/ajouter", {"produit_id": prod, "quantite": 1, "acheter": "1", "retour": "/jend/produits"}, page_token="produit/produit-t49")
    S.check("« Acheter maintenant » mène directement à la commande", hd.get("Location", "").endswith("/commande"))
    C.post("panier/ajouter", {"produit_id": prod, "quantite": 1, "retour": "/jend/produit/produit-t49"}, page_token="produit/produit-t49")
    h = txt(C, "produit/produit-t49")
    S.check("après « Ajouter au panier » : bouton « Voir le panier et commander »", "Voir le panier et commander" in h and 'class="flash-lien"' in h)
    h = txt(C, "commande")
    S.check("commande : étapes visibles, « Confirmer et payer », garanties dans le récapitulatif", 'class="etapes-achat"' in h and "Confirmer et payer" in h and "gardé par Jënd" in h)
    S.check("connexion depuis la commande : « Votre panier est gardé »", "Votre panier est gardé" in txt(Client(), "connexion?retour=%2Fjend%2Fcommande"))
    S.check("accueil : bande de confiance sous l'affiche", "bande-confiance" in accueil and "Argent protégé" in accueil)
finally:
    ok = S.fin()
    sql("DELETE FROM produits WHERE slug='produit-t49'"); sql("DELETE FROM boutiques WHERE slug='boutique-t49'")
sys.exit(0 if ok else 1)
