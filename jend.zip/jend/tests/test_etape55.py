"""Étape 55 : vitrine professionnelle de la boutique (logo, bannière, accroche, réseaux, WhatsApp, recherche et catégories, livraison, avis)."""
import sys, re
from lib import *

S = Suite("Étape 55 — vitrine de boutique", ["va-t55@jend.local", "vb-t55@jend.local"])
E = dict(zip(["va", "vb"], S.emails))
IMG = fixtures_images()
try:
    S.nettoyer()
    sql("DELETE FROM produits WHERE slug LIKE 'produit-t55%'"); sql("DELETE FROM boutiques WHERE slug IN ('boutique-t55','boutique-t55b')")
    pw = mot_de_passe()
    for k, nom in (("va", "Vendeur T55"), ("vb", "Autre T55")):
        sql(f"INSERT INTO users (nom,email,mot_de_passe,role) VALUES ('{nom}','{E[k]}','{hash_mdp(pw)}','vendeur')")
    sql(f"INSERT INTO boutiques (user_id,nom,slug,statut,commission_pct,telephone_paiement) SELECT id,'Boutique T55','boutique-t55','active',1,'+221771115555' FROM users WHERE email='{E['va']}'")
    sql(f"INSERT INTO boutiques (user_id,nom,slug,statut,commission_pct) SELECT id,'Boutique T55b','boutique-t55b','active',1 FROM users WHERE email='{E['vb']}'")
    cats = sql("SELECT id FROM categories ORDER BY id LIMIT 2").split("\n")
    for i, (nom, cat) in enumerate((("Wax bleu T55", cats[0]), ("Bazin T55", cats[0]), ("Encens T55", cats[1]))):
        sql(f"INSERT INTO produits (boutique_id,categorie_id,nom,slug,description,prix,stock,statut) SELECT id,{cat},'{nom}','produit-t55-{i}','x',5000,10,'publie' FROM boutiques WHERE slug='boutique-t55'")
    bid = sql("SELECT id FROM boutiques WHERE slug='boutique-t55'")
    VA, VB = Client(), Client()
    VA.post("connexion", {"email": E["va"], "mot_de_passe": pw}); VB.post("connexion", {"email": E["vb"], "mot_de_passe": pw})
    txt = lambda cl, u: cl.get(u)[1].replace("&#039;", "'").replace(" ", " ").replace("&nbsp;", " ").replace("\xa0", " ")
    base = {"action": "vitrine", "slogan": "Le wax de Touba <b>depuis 2015</b>", "ville": "Touba", "couleur": "vert", "contact_whatsapp": "77 111 55 55",
            "reseau_tiktok": "https://www.tiktok.com/@boutiquet55", "reseau_instagram": "", "reseau_facebook": ""}

    S.titre("RÉGLAGES DE LA VITRINE")
    S.check("section « Ma vitrine » dans l'onglet Boutique", "Ma vitrine" in txt(VA, "vendeur/boutique"))
    VA.multipart("vendeur/boutique", {**base, "reseau_instagram": "https://site-pirate.example/instagram.com"}, [], page_token="vendeur/boutique")
    S.check("lien Instagram piégé (autre site) refusé : rien n'est enregistré", sql(f"SELECT slogan IS NULL FROM boutiques WHERE id={bid}") == "1")
    VA.multipart("vendeur/boutique", {**base, "reseau_facebook": "https://facebook.com@site-pirate.example/"}, [], page_token="vendeur/boutique")
    S.check("lien avec identifiant caché (« …@site-pirate ») refusé", sql(f"SELECT slogan IS NULL FROM boutiques WHERE id={bid}") == "1")
    VA.multipart("vendeur/boutique", {**base, "contact_whatsapp": "12345"}, [], page_token="vendeur/boutique")
    S.check("numéro WhatsApp invalide refusé", sql(f"SELECT slogan IS NULL FROM boutiques WHERE id={bid}") == "1")
    VA.multipart("vendeur/boutique", base, [("logo", "logo.png", (IMG / "ok.png").read_bytes(), "image/png"), ("banniere", "b.jpg", (IMG / "ok.jpg").read_bytes(), "image/jpeg")], page_token="vendeur/boutique")
    logo, ban = sql(f"SELECT logo_chemin FROM boutiques WHERE id={bid}"), sql(f"SELECT banniere_chemin FROM boutiques WHERE id={bid}")
    S.check("logo et bannière enregistrés dans uploads/boutiques/ sous un nom aléatoire",
            re.fullmatch(r"uploads/boutiques/[a-f0-9]{32}\.png", logo) is not None and re.fullmatch(r"uploads/boutiques/[a-f0-9]{32}\.jpg", ban) is not None and (JEND / logo).exists())
    S.check("accroche, ville, couleur, WhatsApp et TikTok enregistrés", sql(f"SELECT CONCAT(ville,'|',couleur,'|',contact_whatsapp,'|',reseau_tiktok) FROM boutiques WHERE id={bid}") == "Touba|vert|+221771115555|https://www.tiktok.com/@boutiquet55")
    VA.multipart("vendeur/boutique", base, [("logo", "shell.jpg", (IMG / "shell.jpg").read_bytes(), "image/jpeg")], page_token="vendeur/boutique")
    S.check("faux logo (script déguisé) refusé, l'ancien est gardé", sql(f"SELECT logo_chemin FROM boutiques WHERE id={bid}") == logo)
    S.check("boutique sans vitrine : initiales et couleur par défaut, pas de bouton WhatsApp", "couleur-terre" in txt(Client(), "boutique/boutique-t55b") and "wa.me/221" not in txt(Client(), "boutique/boutique-t55b"))
    VB.multipart("vendeur/boutique", {**base, "slogan": "piratage"}, [], page_token="vendeur/boutique")
    S.check("un autre vendeur ne modifie que SA boutique", "piratage" != sql(f"SELECT slogan FROM boutiques WHERE id={bid}") and sql("SELECT slogan FROM boutiques WHERE slug='boutique-t55b'") == "piratage")

    S.titre("VITRINE PUBLIQUE")
    h = txt(Client(), "boutique/boutique-t55")
    S.check("bannière, logo, accroche (échappée), ville, couleur", ban in h and "vitrine-logo" in h and "&lt;b&gt;depuis 2015" in h and "Touba" in h and "couleur-vert" in h)
    S.check("bouton « Écrire » vers le WhatsApp de la boutique et lien TikTok", "wa.me/221771115555" in h and "tiktok.com/@boutiquet55" in h and 'rel="noopener noreferrer nofollow"' in h)
    S.check("chiffres de la boutique, sections Produits / À propos / Livraison", "vitrine-chiffres" in h and "3</b><span>produits en vente" in h and 'id="a-propos"' in h and 'id="livraison"' in h and "Votre argent est gardé par Jënd" in h)
    S.check("catégories propres à la boutique (Tout 3, puis 2 et 1)", re.search(r"Tout <small>3</small>", h) is not None and "<small>2</small>" in h and "<small>1</small>" in h)
    S.check("recherche dans la boutique : « bazin » → 1 produit", "Bazin T55" in txt(Client(), "boutique/boutique-t55?q=bazin") and "Wax bleu T55" not in txt(Client(), "boutique/boutique-t55?q=bazin"))
    S.check("filtre par catégorie", "Encens T55" in txt(Client(), f"boutique/boutique-t55?cat={cats[1]}") and "Bazin T55" not in txt(Client(), f"boutique/boutique-t55?cat={cats[1]}"))
    S.check("catégorie inventée ignorée (tous les produits)", "Bazin T55" in txt(Client(), "boutique/boutique-t55?cat=99999"))
    S.check("livraison : frais par région affichés", "region-livraison" in h and "FCFA" in h)
    VA.multipart("vendeur/boutique", {**base, "retirer_logo": "1"}, [], page_token="vendeur/boutique")
    S.check("retirer le logo l'efface du disque", sql(f"SELECT logo_chemin IS NULL FROM boutiques WHERE id={bid}") == "1" and not (JEND / logo).exists())
finally:
    ok = S.fin()
    for col in ("logo_chemin", "banniere_chemin"):
        for c in sql(f"SELECT {col} FROM boutiques WHERE slug IN ('boutique-t55','boutique-t55b') AND {col} IS NOT NULL").split("\n"):
            if c and c != "NULL":
                for f in (JEND / c, JEND / c.replace(".png", "-m.jpg").replace(".jpg", "-m.jpg")):
                    f.unlink(missing_ok=True)
    sql("DELETE FROM produits WHERE slug LIKE 'produit-t55%'"); sql("DELETE FROM boutiques WHERE slug IN ('boutique-t55','boutique-t55b')")
sys.exit(0 if ok else 1)
