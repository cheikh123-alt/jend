"""Étape 51 : choix du fichier de configuration (config.env prioritaire, .env sinon), protection contre un .env de développement mis en ligne."""
import sys, os, shutil, subprocess, tempfile
from lib import *

S = Suite("Étape 51 — fichier de configuration")
tmp = Path(tempfile.mkdtemp(prefix="jend-env-"))
try:
    (tmp / "includes").mkdir()
    shutil.copy(JEND / "includes" / "env.php", tmp / "includes" / "env.php")
    def lire(cle):          # lit la configuration comme le site, dans un dossier jetable (aucune base n'est contactée)
        e = {k: v for k, v in os.environ.items() if k != "JEND_ENV_FILE"}
        r = subprocess.run([PHP, "-r", f"require '{tmp}/includes/env.php'; echo env('{cle}', '(rien)');"], capture_output=True, text=True, env=e)
        return r.stdout.strip()

    S.titre("QUEL FICHIER EST LU")
    def choix(hote, ip):    # nom du fichier retenu pour une visite (adresse tapée, IP du visiteur)
        r = subprocess.run([PHP, "-r", f"require '{tmp}/includes/env.php'; echo basename(env_choisir_fichier('{tmp}', '{hote}', '{ip}'));"], capture_output=True, text=True)
        return r.stdout.strip()
    (tmp / ".env").write_text("APP_ENV=dev\nDB_HOST=127.0.0.1\n")
    S.check("seulement .env (l'ordinateur) : .env est lu", lire("DB_HOST") == "127.0.0.1" and choix("jend.free.je", "41.82.10.5") == ".env")
    (tmp / "config.env").write_text("APP_ENV=test\nAPP_URL=https://jend.free.je\nDB_HOST=sql105.exemple.test\n")
    S.check("les deux fichiers, XAMPP (localhost) : le .env de l'ordinateur reste utilisé", choix("localhost", "127.0.0.1") == ".env" and choix("localhost:80", "::1") == ".env")
    S.check("les deux fichiers, téléphone sur le Wi-Fi local : .env", choix("192.168.1.10", "192.168.1.20") == ".env")
    S.check("les deux fichiers, terminal (scripts) : .env", lire("DB_HOST") == "127.0.0.1")
    S.check("les deux fichiers, site ouvert à son adresse en ligne : config.env", choix("jend.free.je", "10.0.0.5") == "config.env" and choix("www.jend.free.je", "") == "config.env")
    S.check("les deux fichiers, visiteur venant d'Internet (autre adresse de l'hébergeur) : config.env", choix("if0-43194544.infinityfreeapp.com", "41.82.10.5") == "config.env")
    (tmp / ".env").unlink()
    S.check("seulement config.env : config.env est lu", lire("DB_HOST") == "sql105.exemple.test" and choix("localhost", "127.0.0.1") == "config.env")

    S.titre("SÉCURITÉ DU MODE DÉVELOPPEMENT")
    r = php(f"require '{JEND}/includes/env.php'; $d = ['APP_ENV' => 'dev']; echo env_securiser($d, '41.82.10.5')['APP_ENV'], '|', env_securiser($d, '127.0.0.1')['APP_ENV'], '|', env_securiser($d, '192.168.1.20')['APP_ENV'], '|', env_securiser($d, '::1')['APP_ENV'], '|', env_securiser(['APP_ENV' => 'test'], '41.82.10.5')['APP_ENV'];")[0]
    S.check("un .env « dev » vu depuis Internet passe en production (pas d'erreurs techniques affichées)", r.split("|")[0] == "prod")
    S.check("depuis l'ordinateur ou le Wi-Fi local, le mode dev reste actif", r.split("|")[1:4] == ["dev", "dev", "dev"])
    S.check("un fichier « test » n'est pas modifié", r.split("|")[4] == "test")

    S.titre("PROTECTION")
    S.check("config.env n'est pas téléchargeable", Client().get("config.env")[0] in (403, 404))
    (JEND / "deploiement").mkdir(exist_ok=True)
    secret = JEND / "deploiement" / "essai-t51.env"
    secret.write_text("DB_PASS=secret\n")
    S.check("le dossier privé deploiement/ n'est pas accessible depuis Internet", Client().get("deploiement/essai-t51.env")[0] in (403, 404))
    secret.unlink()
    up = "\n".join(l for l in (JEND / "uploads" / ".htaccess").read_text().splitlines() if not l.lstrip().startswith("#"))
    S.check("uploads/.htaccess sans directive refusée par InfinityFree (sinon erreur 500 : photos invisibles)", "Options" not in up and "RemoveHandler" not in up and "php_" not in up)
    S.check("un fichier .php déposé dans uploads/ reste refusé", Client().get("uploads/essai.php")[0] in (403, 404))
    arch = (JEND / "scripts" / "archive-production.sh").read_text()
    S.check("deploiement/ et config.env sont exclus de l'archive de production", '"deploiement/*"' in arch and '"config.env"' in arch)
finally:
    shutil.rmtree(tmp, ignore_errors=True)
    ok = S.fin()
sys.exit(0 if ok else 1)
