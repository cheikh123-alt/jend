"""Étape 40 : aide et contact (formulaire, boîte de réception de l'admin, réponses)."""
import re, sys
from lib import *

S = Suite("Étape 40 — aide et contact", ["ad-t40@jend.local", "cl-t40@jend.local", "va-t40@jend.local", "c2-t40@jend.local"])
E = dict(zip(["ad", "cl", "va", "c2"], S.emails))
LOG = lambda: (JEND / "storage" / "emails.log").read_text() if (JEND / "storage" / "emails.log").exists() else ""
try:
    S.nettoyer()
    sql("DELETE FROM messages_support"); sql("DELETE FROM limites WHERE cle LIKE 'support:%'")
    pw = mot_de_passe()
    for k, nom, role in (("ad", "Admin T40", "admin"), ("cl", "Cliente T40", "client"), ("va", "Vendeur T40", "vendeur"), ("c2", "Autre T40", "client")):
        sql(f"INSERT INTO users (nom,email,mot_de_passe,role) VALUES ('{nom}','{E[k]}','{hash_mdp(pw)}','{role}')")
    AD, C, VA, C2, P = Client(), Client(), Client(), Client(), Client()
    for cl, k in ((AD, "ad"), (C, "cl"), (VA, "va"), (C2, "c2")):
        cl.post("connexion", {"email": E[k], "mot_de_passe": pw})
    txt = lambda cl, u: cl.get(u)[1].replace("&#039;", "'")

    S.titre("OÙ TROUVER L'AIDE")
    h = txt(P, "contact")
    S.check("la page « Aide et contact » affiche les coordonnées et un formulaire", "Aide et contact" in h and 'name="message"' in h and 'name="sujet"' in h)
    S.check("le pied de page y mène pour tout le monde", "Aide et contact" in txt(P, ""))
    S.check("onglet « Aide » dans le compte du client", 'href="/jend/aide"' in txt(C, "compte"))
    S.check("raccourci « Contacter Jënd » dans le tableau de bord vendeur (sujet « boutique » présélectionné)", "contact?sujet=boutique" in txt(VA, "vendeur") if sql(f"SELECT COUNT(*) FROM boutiques b JOIN users u ON u.id=b.user_id WHERE u.email='{E['va']}'") != "0" else True)

    S.titre("ENVOI")
    avant = len(LOG())
    s, _, hd = P.post("contact", {"nom": "Visiteur", "email": "visiteur-t40@example.test", "telephone": "", "sujet": "technique", "commande": "", "message": "Le bouton de paiement ne répond pas sur mon téléphone."}, page_token="contact")
    S.check("un visiteur non connecté peut écrire", sql("SELECT COUNT(*) FROM messages_support WHERE email='visiteur-t40@example.test'") == "1")
    S.check("il reçoit un accusé de réception avec une référence AIDE-…", re.search(r"AIDE-[0-9A-F]{8}", LOG()[avant:]) is not None)
    P.post("contact", {"nom": "Robot", "email": "robot@example.test", "telephone": "", "sujet": "autre", "commande": "", "message": "Achetez mes pilules miracles maintenant", "site_web": "http://spam.example"}, page_token="contact")
    S.check("un robot qui remplit le champ caché est ignoré", sql("SELECT COUNT(*) FROM messages_support WHERE email='robot@example.test'") == "0")
    for donnees in ({"sujet": "inconnu"}, {"message": "court"}, {"email": "pas-un-email"}, {"commande": "<script>"}):
        P.post("contact", {"nom": "Visiteur", "email": "v2-t40@example.test", "telephone": "", "sujet": "autre", "commande": "", "message": "Un message assez long pour passer", **donnees}, page_token="contact")
    S.check("sujet inconnu, message trop court, e-mail invalide, numéro de commande piégé : refusés", sql("SELECT COUNT(*) FROM messages_support WHERE email='v2-t40@example.test'") == "0")
    for i in range(4):
        P.post("contact", {"nom": "Visiteur", "email": f"v{i}-flood@example.test", "telephone": "", "sujet": "autre", "commande": "", "message": "Message répété pour tester la limite"}, page_token="contact")
    S.check("un visiteur est limité (3 messages par heure)", int(sql("SELECT COUNT(*) FROM messages_support WHERE email LIKE '%flood@example.test'")) <= 2)
    C.post("contact", {"nom": "Faux nom", "email": "autre@example.test", "telephone": "77 123 45 67", "sujet": "paiement", "commande": "JND-261012-A4F2", "message": "Mon paiement Wave a été débité mais la commande est en attente. <b>Merci</b>"}, page_token="contact")
    S.check("un client connecté écrit avec SON nom et SON e-mail (pas ceux saisis)", sql(f"SELECT CONCAT(nom,'|',email,'|',commande_ref) FROM messages_support WHERE user_id=(SELECT id FROM users WHERE email='{E['cl']}')") == f"Cliente T40|{E['cl']}|JND-261012-A4F2")
    mid = sql(f"SELECT id FROM messages_support WHERE email='{E['cl']}'")

    S.titre("BOÎTE DE RÉCEPTION DE L'ADMIN")
    h = txt(AD, "admin/messages")
    S.check("l'admin voit les messages, avec pastille sur l'onglet et dans « À faire »", "Mon paiement Wave" in h and "pastille-onglet" in h and "message(s) d'aide à traiter" in txt(AD, "admin"))
    S.check("le message est affiché échappé (pas de balise active)", "<b>Merci</b>" not in h and "&lt;b&gt;Merci&lt;/b&gt;" in h)
    S.check("réservé à l'administrateur", C.get("admin/messages")[0] == 404 and VA.get("admin/messages")[0] == 404)
    C.post("admin/messages", {"id": mid, "action": "repondre", "reponse": "Piratage", "resolu": "1"}, page_token="compte")
    S.check("un client ne peut pas répondre à la place de l'admin", sql(f"SELECT COALESCE(reponse,'') FROM messages_support WHERE id={mid}") == "")
    C.post("admin/messages", {"id": mid, "action": "repondre", "texte": "Piratage"}, page_token="compte")
    S.check("un client ne peut pas répondre au nom de l'équipe", sql(f"SELECT COUNT(*) FROM messages_support_reponses WHERE message_id={mid}") == "0")
    ref = sql(f"SELECT reference FROM messages_support WHERE id={mid}")

    S.titre("CONVERSATION")
    avant = len(LOG())
    AD.post("admin/messages", {"id": mid, "action": "repondre", "texte": "Bonjour, pouvez-vous nous donner l'heure du paiement ?"})
    S.check("l'admin répond dans la conversation : statut « en attente du client », e-mail avec le lien de la conversation",
            sql(f"SELECT statut FROM messages_support WHERE id={mid}") == "en_cours" and f"aide/{ref}" in LOG()[avant:])
    h = txt(C, f"aide/{ref}")
    S.check("le client voit tout le fil (son message puis la réponse) et peut répondre au même endroit", "Mon paiement Wave" in h and "heure du paiement" in h and 'name="texte"' in h)
    C.post(f"aide/{ref}", {"texte": "Le paiement a été fait à 14 h 05 avec Wave."}, page_token=f"aide/{ref}")
    S.check("la réponse du client s'ajoute au MÊME message (pas de nouveau message) et repasse « à répondre »",
            sql("SELECT COUNT(*) FROM messages_support WHERE user_id IS NOT NULL") == "1" and sql(f"SELECT statut FROM messages_support WHERE id={mid}") == "nouveau"
            and sql(f"SELECT COUNT(*) FROM messages_support_reponses WHERE message_id={mid}") == "2")
    S.check("l'admin voit la réponse du client dans la même conversation", "14 h 05" in txt(AD, "admin/messages"))
    C2.post(f"aide/{ref}", {"texte": "Intrusion"}, page_token="compte")
    S.check("un autre client ne peut ni lire ni écrire dans cette conversation", C2.get(f"aide/{ref}")[0] == 404 and sql(f"SELECT COUNT(*) FROM messages_support_reponses WHERE message_id={mid}") == "2")
    AD.post("admin/messages", {"id": mid, "action": "repondre", "texte": "Merci, c'est confirmé : votre commande est payée."})
    AD.post("admin/messages", {"id": mid, "action": "clore"})
    S.check("l'admin clôt la conversation une fois tout réglé", sql(f"SELECT statut FROM messages_support WHERE id={mid}") == "resolu" and "Closes" in txt(AD, "admin/messages"))
    C.post(f"aide/{ref}", {"texte": "Encore une question"}, page_token=f"aide/{ref}")
    S.check("conversation close : le client ne peut plus y écrire, il est invité à faire une nouvelle demande", sql(f"SELECT COUNT(*) FROM messages_support_reponses WHERE message_id={mid}") == "3" and "nouveau message" in txt(C, f"aide/{ref}"))
    AD.post("admin/messages", {"id": mid, "action": "rouvrir"})
    S.check("l'admin peut la rouvrir si besoin", sql(f"SELECT statut FROM messages_support WHERE id={mid}") == "en_cours")

    S.titre("VISITEUR SANS COMPTE")
    vid = sql("SELECT id FROM messages_support WHERE email='visiteur-t40@example.test'")
    avant = len(LOG())
    AD.post("admin/messages", {"id": vid, "action": "repondre", "texte": "Quel téléphone utilisez-vous ?"})
    lien = re.findall(r"aide/suivi/([a-f0-9]{64})", LOG()[avant:])
    S.check("le visiteur reçoit un lien secret vers la conversation", len(lien) == 1)
    V = Client()
    S.check("ce lien ouvre la conversation sans compte", "Quel téléphone" in txt(V, f"aide/suivi/{lien[0]}"))
    V.post(f"aide/suivi/{lien[0]}", {"texte": "Un Samsung A14."}, page_token=f"aide/suivi/{lien[0]}")
    S.check("et permet de répondre dans le même fil", "Samsung A14" in txt(AD, "admin/messages"))
    S.check("un lien inventé ne mène à rien", V.get("aide/suivi/" + "a" * 64)[0] == 404)
finally:
    ok = S.fin()
    sql("DELETE FROM messages_support"); sql("DELETE FROM limites WHERE cle LIKE 'support:%'")
    sql("DELETE FROM journal_admin WHERE action='support_reponse'")
sys.exit(0 if ok else 1)
