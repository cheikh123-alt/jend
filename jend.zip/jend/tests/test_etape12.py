"""Étape 11 : préparation d'un hébergement gratuit sans terminal (InfinityFree) : mode TEST, diagnostic, installation SQL, dossier FTP."""
import glob, os, re, shutil, socket, subprocess, sys, tempfile, time
from pathlib import Path
from lib import *

S = Suite("Étape 11 — hébergement de test (sans terminal)", ["a-t12@jend.local", "b-t12@jend.local"])
E = S.emails
INC = JEND / "includes"
xf = {"X-Forwarded-Proto": "https"}
TESTENV = dict(APP_ENV="test", APP_URL="https://test.example.test", TRUSTED_PROXY="1", MAIL_DRIVER="log", APP_KEY="ab" * 32, PAIEMENT_SECRET="cd" * 32)


def php_run(code, args=()):
    r = subprocess.run([PHP, "-r", code, "--", *args], capture_output=True, text=True, timeout=120)
    return r.stdout.strip(), r.stderr.strip()


def port_libre():
    s = socket.socket(); s.bind(("127.0.0.1", 0)); p = s.getsockname()[1]; s.close(); return p


try:
    S.nettoyer()
    S.publier_demo()

    S.titre("ADRESSES DES PRODUITS (indépendantes du serveur)")
    cas = {"Beurre de karité pur 250 ml": "beurre-de-karite-pur-250-ml", "Ensemble boubou brodé homme": "ensemble-boubou-brode-homme", "Écouteurs sans fil": "ecouteurs-sans-fil",
           "Lampe décorative en calebasse": "lampe-decorative-en-calebasse", "ÉLÉGANT Pagne N°5 — « wax »": "elegant-pagne-n-5-wax", "L’été à Ñaaye œuvre": "lete-a-naaye-oeuvre",
           "   ": "article", "Cœur d’Afrique & Çà": "coeur-dafrique-ca"}
    ok_all = True
    for texte, attendu in cas.items():
        out, err = php_run(f'require "{INC}/env.php"; require "{INC}/helpers.php"; echo slugify($argv[1]);', [texte])
        ok_all &= (out == attendu)
        if out != attendu:
            print("     écart :", texte, "→", out, "(attendu", attendu + ")")
    S.check("8 cas d'accents, ligatures, apostrophes et symboles", ok_all)
    out, _ = php_run(f'echo preg_match("/iconv\\s*\\(\\s*[\'\\"]/", file_get_contents("{INC}/helpers.php")) ? "iconv" : "sans-iconv";')
    S.check("le code n'utilise plus iconv (dont le résultat varie d'un serveur à l'autre)", out == "sans-iconv")

    S.titre("MODE TEST (APP_ENV=test)")
    pw = mot_de_passe()
    S.modifier_env(**TESTENV)
    s, h, hd = Client().req("", headers=xf)
    S.check("accueil accessible derrière HTTPS", s == 200)
    S.check("bandeau « SITE DE TEST » visible sur la page", "SITE DE TEST" in h and "aucun paiement réel" in h)
    S.check("indexation interdite : balise robots + en-tête X-Robots-Tag", 'name="robots" content="noindex, nofollow"' in h and "noindex" in (hd.get("X-Robots-Tag") or ""))
    s, h, hd = Client().req("robots.txt", headers=xf)
    S.check("robots.txt : tout interdit aux moteurs de recherche", h.strip().splitlines() == ["User-agent: *", "Disallow: /"] and "text/plain" in hd.get("Content-Type", ""))
    s, h, hd = Client().req("produits?x=1")
    S.check("sécurisé comme la production : HTTP → HTTPS (301) sur l'adresse officielle", s == 301 and hd.get("Location") == "https://test.example.test/jend/produits?x=1", hd.get("Location", ""))
    S.check("HSTS actif derrière HTTPS", "max-age" in (Client().req("", headers=xf)[2].get("Strict-Transport-Security") or ""))
    s, h, hd = Client().req("paiement/webhook", raw=b"{}", headers={"X-Signature": "x", **xf})
    S.check("signature invalide refusée (webhook protégé en mode test)", s == 401)
    S.modifier_env(**TESTENV, FORCE_HTTPS="0")
    s, _, _ = Client().req("produits")
    S.check("FORCE_HTTPS=0 : plus de redirection (garde-fou contre les boucles si l'hébergeur ne signale pas le HTTPS)", s == 200)
    S.modifier_env(**{**TESTENV, "DB_PASS": "mauvais-mot-de-passe"})
    s, h, _ = Client().req("", headers=xf)
    S.check("base inaccessible (site de test) : la cause est expliquée, sans aucun identifiant ni message technique",
            s == 500 and "Cause probable : utilisateur ou mot de passe refusé" in h and "Access denied" not in h and "mauvais-mot-de-passe" not in h
            and (not TESTENV.get("DB_USER") or TESTENV["DB_USER"] not in h) and (not TESTENV.get("DB_HOST") or TESTENV["DB_HOST"] not in h))

    S.titre("PAIEMENT SIMULÉ EN MODE TEST (indispensable pour essayer en ligne)")
    S.modifier_env(**TESTENV)
    A = Client(cookies_secure_en_http=True, entetes=xf)
    A.post("inscription", {"nom": "Alice T12", "email": E[0], "mot_de_passe": pw, "mot_de_passe2": pw}, headers=xf)
    sql(f"UPDATE users SET email_verifie = 1 WHERE email='{E[0]}'")          # (la confirmation de l'e-mail est testée à l'étape 39)
    tok = A.token("produits")
    A.req("panier/ajouter", {"csrf": tok, "produit_id": 2, "quantite": 1, "retour": "/jend/produits"}, headers=xf)
    s, _, hd = A.post("commande", {"nom": "Alice", "telephone": "78 000 11 22", "zone_id": 1, "adresse": "Rue 10 Médina", "methode": "wave"}, headers=xf)
    ref = hd.get("Location", "").rsplit("/", 1)[-1]
    S.check("commande Wave créée en mode test", ref.startswith("JND-"), ref)
    s, _, hd = A.post("paiement/" + ref, {}, page_token="commande/" + ref, headers=xf)
    sim = hd.get("Location", "").replace("http://localhost/jend/", "").replace("/jend/", "")
    S.check("la page de paiement simulé existe en mode test", s == 302 and "paiement/simulation/SIM-" in sim, sim)
    h = A.req(sim, headers=xf)[1]
    S.check("elle indique clairement qu'aucun argent n'est débité", "MODE SIMULATION" in h)
    A.post(sim, {"resultat": "reussi"}, headers=xf)
    S.check("paiement réussi → commande payée et confirmée", etat(ref) == "confirmee|paye")
    S.modifier_env(**{**TESTENV, "APP_ENV": "prod"})
    S.check("en PRODUCTION, la même page est introuvable (404) : jamais de faux paiement en vrai lancement", Client().req(sim, headers=xf)[0] == 404)
    s, h, hd = Client().req("", headers=xf)
    S.check("en production : pas de bandeau de test, pas de X-Robots-Tag", "SITE DE TEST" not in h and not hd.get("X-Robots-Tag"))
    h = Client().req("robots.txt", headers=xf)[1]
    S.check("en production : robots.txt protège les zones privées mais autorise le reste", "Disallow: /admin" in h and "Allow: /" in h and "Disallow: /\n" not in h)
    S.restaurer_env()

    S.titre("PAGE DE DIAGNOSTIC (diagnostic.php)")
    S.check("sans DIAGNOSTIC_CLE configuré : page introuvable (404)", Client().get("diagnostic.php?cle=nimportequoi")[0] == 404 and Client().get("diagnostic.php")[0] == 404)
    cle = "cle-de-test-" + secrets.token_hex(8)
    S.modifier_env(DIAGNOSTIC_CLE=cle)
    S.check("clé absente, fausse ou trop courte : 404 (aucune information)", all(Client().get(u)[0] == 404 for u in ("diagnostic.php", "diagnostic.php?cle=faux", "diagnostic.php?cle=" + cle[:-1], "diagnostic.php?cle=")))
    s, h, hd = Client().get("diagnostic.php?cle=" + cle)
    S.check("bonne clé : rapport affiché (non indexable, non mis en cache)", s == 200 and "Diagnostic du serveur" in h and "noindex" in (hd.get("X-Robots-Tag") or "") and "no-store" in (hd.get("Cache-Control") or ""))
    S.check("sections : serveur, HTTPS, fichiers, configuration, base, e-mails, sécurité extérieure", all(t in h for t in ("1. Serveur et PHP", "2. HTTPS", "3. Fichiers du site", "4. Configuration", "5. Base de données", "6. Connexions sortantes", "7. Sécurité vue de l")))
    S.check("contrôles réels : PHP, extensions, base de données, tables", "PHP 8" in h and "Extension gd" in h and "Connexion à la base réussie" in h and "tables présentes" in h)
    secrets_env = [v for k, v in lire_env().items() if k in ("DB_PASS", "APP_KEY", "PAIEMENT_SECRET", "SMTP_PASS") and len(v) >= 6]
    S.check("le rapport n'affiche AUCUN mot de passe ni clé secrète", not any(v in h for v in secrets_env) and "<script>" in h)
    S.check("avertit que le fichier doit être supprimé après usage", "supprimez" in h.lower() and "DIAGNOSTIC_CLE" in h)
    piege = UP = JEND / "uploads" / "produits" / "diag-exec-test.php"
    S.check("action « créer » refusée avec une mauvaise clé (aucun fichier créé)", Client().get("diagnostic.php?cle=faux&action=creer")[0] == 404 and not piege.exists())
    S.check("action « créer » avec la bonne clé : fichier piège écrit", Client().get(f"diagnostic.php?cle={cle}&action=creer")[1] == "ok" and piege.exists())
    s, h, _ = Client().get("uploads/produits/diag-exec-test.php")
    S.check("… et ce script n'est JAMAIS exécuté (403)", s == 403 and "SCRIPT-EXECUTE" not in h)
    S.check("action « supprimer » : fichier piège effacé", Client().get(f"diagnostic.php?cle={cle}&action=supprimer")[1] == "ok" and not piege.exists())
    S.restaurer_env()

    S.titre("INSTALLATION SQL SANS TERMINAL (scripts/preparer-installation.php)")
    d = Path(tempfile.mkdtemp(prefix="jend-t12-"))
    prep = JEND / "scripts" / "preparer-installation.php"
    def preparer(*args):
        return subprocess.run([PHP, str(prep), *args], capture_output=True, text=True, timeout=60)
    r = preparer(f"--sortie={d}/x.sql", f"--env={d}/x.env")
    S.check("refus sans adresse e-mail", r.returncode == 2 and not (d / "x.sql").exists())
    r = preparer("--admin-email=pas-un-email", f"--sortie={d}/x.sql", f"--env={d}/x.env")
    S.check("refus d'une adresse e-mail invalide", r.returncode == 2)
    r = preparer("--admin-email=a@b.co", "--admin-nom=O'Brien; DROP TABLE users", f"--sortie={d}/x.sql", f"--env={d}/x.env")
    S.check("refus d'un nom contenant des caractères dangereux (injection)", r.returncode == 2 and not (d / "x.sql").exists())
    r = preparer("--admin-email=moi@example.test", "--admin-nom=Awa Diop", "--demo", f"--sortie={d}/inst.sql", f"--env={d}/inst.env")
    S.check("génération réussie (avec données de démonstration)", r.returncode == 0 and (d / "inst.sql").exists() and (d / "inst.env").exists(), r.stdout + r.stderr)
    mdp_admin = re.search(r"Compte administrateur :\n\s+e-mail\s+: \S+\n\s+mot de passe : (\S+)", r.stdout).group(1)
    mdp_vendeur = re.search(r"vendeur de démonstration :\n\s+e-mail\s+: \S+\n\s+mot de passe : (\S+)", r.stdout).group(1)
    contenu = (d / "inst.sql").read_text()
    S.check("le SQL ne contient ni CREATE DATABASE, ni USE, ni DROP, ni SET FOREIGN_KEY_CHECKS", not re.search(r"CREATE\s+DATABASE|^\s*USE\s|DROP\s+TABLE|FOREIGN_KEY_CHECKS", contenu, flags=re.I | re.M))
    S.check("40 tables créées dans le fichier", len(re.findall(r"^CREATE TABLE\b", contenu, flags=re.M)) == 40)
    S.check("aucun mot de passe en clair dans le SQL (empreintes seulement)", mdp_admin not in contenu and mdp_vendeur not in contenu and "$2y$" in contenu)
    S.check("fichiers de sortie lisibles par le propriétaire seulement (600)", oct((d / "inst.sql").stat().st_mode & 0o777) == "0o600" and oct((d / "inst.env").stat().st_mode & 0o777) == "0o600")
    r2 = preparer("--admin-email=moi@example.test", f"--sortie={d}/inst.sql", f"--env={d}/autre.env")
    S.check("refuse d'écraser un fichier existant", r2.returncode == 2 and "existe déjà" in r2.stderr)
    envtxt = (d / "inst.env").read_text()
    S.check("modèle .env : APP_ENV=test, clés de 64 caractères aléatoires, champs à remplir signalés", "APP_ENV=test" in envtxt and re.search(r"^APP_KEY=[0-9a-f]{64}$", envtxt, flags=re.M) and re.search(r"^PAIEMENT_SECRET=[0-9a-f]{64}$", envtxt, flags=re.M) and "A_REMPLIR" in envtxt and re.search(r"^DIAGNOSTIC_CLE=[0-9a-f]{20}$", envtxt, flags=re.M))
    r3 = preparer("--admin-email=moi@example.test", f"--sortie={d}/i2.sql", f"--env={d}/i2.env")
    S.check("chaque génération produit de NOUVELLES clés", re.search(r"^APP_KEY=(\w+)", (d / "i2.env").read_text(), flags=re.M).group(1) != re.search(r"^APP_KEY=(\w+)", envtxt, flags=re.M).group(1))
    nom_bd = "jend_inst_t12"; assert nom_bd != DB["name"]
    sql(f"DROP DATABASE IF EXISTS {nom_bd}; CREATE DATABASE {nom_bd} CHARACTER SET utf8mb4", base=False)
    mysql = lambda fichier: subprocess.run(f"'{MYSQL_BIN}' -h {DB['host']} -P {DB['port']} -u {DB['user']} {'-p' + DB['pass'] if DB['pass'] else ''} {nom_bd} < '{fichier}'", shell=True, capture_output=True, text=True)
    cnt = lambda q: sql(q.replace("§", nom_bd), base=False)
    try:
        imp = mysql(d / "inst.sql")
        S.check("import dans une base VIDE réussi (comme dans phpMyAdmin)", imp.returncode == 0, imp.stderr[:200])
        S.check("40 tables, 28 zones de livraison (Touba + régions), 13 catégories", cnt("SELECT COUNT(*) FROM information_schema.tables WHERE table_schema='§'") == "40" and cnt("SELECT COUNT(*) FROM §.zones_livraison") == "28" and cnt("SELECT COUNT(*) FROM §.categories") == "13")
        S.check("compte admin créé avec l'e-mail et le nom demandés", cnt("SELECT CONCAT(role,'|',nom,'|',email) FROM §.users WHERE role='admin'") == "admin|Awa Diop|moi@example.test")
        hash_admin = cnt("SELECT mot_de_passe FROM §.users WHERE role='admin'")
        out, _ = php_run('echo json_encode([password_verify($argv[1], $argv[2]), password_verify("faux", $argv[2])]);', [mdp_admin, hash_admin])
        S.check("le mot de passe affiché dans le terminal ouvre bien le compte admin (et un faux, non)", out == "[true,false]", out)
        S.check("démo : boutique active + 8 produits publiés avec adresses propres", cnt("SELECT COUNT(*) FROM §.produits WHERE statut='publie'") == "8" and cnt("SELECT statut FROM §.boutiques") == "active" and cnt("SELECT COUNT(*) FROM §.produits WHERE slug IN ('beurre-de-karite-pur-250-ml','ecouteurs-sans-fil')") == "2")
        S.check("chaque produit a une catégorie valide", cnt("SELECT COUNT(*) FROM §.produits p JOIN §.categories c ON c.id=p.categorie_id") == "8")
        avant = cnt("SELECT COUNT(*) FROM §.users")
        imp2 = mysql(d / "inst.sql")
        S.check("un 2e import est REFUSÉ (tables déjà là) et n'efface rien", imp2.returncode != 0 and cnt("SELECT COUNT(*) FROM §.users") == avant and cnt("SELECT COUNT(*) FROM §.produits") == "8")
        sql(f"DROP DATABASE {nom_bd}; CREATE DATABASE {nom_bd} CHARACTER SET utf8mb4", base=False)
        r4 = preparer("--admin-email=sans-demo@example.test", f"--sortie={d}/s.sql", f"--env={d}/s.env")
        imp3 = mysql(d / "s.sql")
        S.check("sans --demo : aucun produit, aucun compte de démonstration", imp3.returncode == 0 and cnt("SELECT COUNT(*) FROM §.produits") == "0" and cnt("SELECT COUNT(*) FROM §.users") == "1" and "vendeur de démonstration" not in r4.stdout)
    finally:
        sql(f"DROP DATABASE IF EXISTS {nom_bd}", base=False)

    S.titre("DOSSIER FTP (scripts/preparer-dossier-ftp.sh)")
    ftp = d / "jend-ftp"
    sh = lambda *a: subprocess.run(["sh", str(JEND / "scripts" / "preparer-dossier-ftp.sh"), *a], capture_output=True, text=True, cwd=str(JEND), timeout=120)
    r = sh(str(ftp))
    present = lambda rel: (ftp / rel).exists()
    S.check("dossier créé sans erreur", r.returncode == 0 and ftp.is_dir(), r.stdout + r.stderr)
    S.check("fichiers indispensables présents (index, .htaccess, includes, pages, assets, uploads/.htaccess)", all(present(x) for x in ("index.php", ".htaccess", "includes/bootstrap.php", "pages/accueil.php", "assets/css/style.css", "assets/js/main.js", "assets/vendor/js/gsap.min.js", "assets/vendor/SHA256SUMS", "uploads/.htaccess", "assets/vendor/.htaccess")))
    S.check("dossiers d'écriture présents : storage/ et uploads/produits/", present("storage/.gitkeep") and present("uploads/produits/.gitkeep"))
    interdits = [".env", "tests", "scripts", "database", "maquette", "install.php", "diagnostic.php", "CAHIER_DES_CHARGES.md", "DEPLOIEMENT.md", "AUDIT_SECURITE.md", ".gitignore"]
    S.check("exclus : .env, tests, scripts, base de données, maquette, install.php, documents, diagnostic", not any(present(x) for x in interdits), str([x for x in interdits if present(x)]))
    tous = [p for p in ftp.rglob("*") if p.is_file()]
    S.check("aucun secret ni fichier sensible (.env, .sql, .zip, clés, journaux) ; storage/ ne contient que sa protection", not [p for p in tous if p.suffix in (".env", ".sql", ".zip", ".log", ".pyc") or p.name in (".env", "app-key.txt", "paiement-secret.txt", "emails.log")] and sorted(p.name for p in (ftp / "storage").iterdir()) == [".gitkeep", ".htaccess"])
    S.check("aucun fichier de plus de 10 Mo (limite de l'hébergeur)", max(p.stat().st_size for p in tous) < 10 * 1024 * 1024)
    S.check("aucune photo de vendeur embarquée", [p.name for p in (ftp / "uploads" / "produits").iterdir()] == [".gitkeep"])
    S.check("refuse d'écraser un dossier existant", sh(str(ftp)).returncode == 1)
    ftp2 = d / "avec-diag"
    sh(str(ftp2), "--avec-diagnostic")
    S.check("--avec-diagnostic : ajoute diagnostic.php", (ftp2 / "diagnostic.php").exists())
    S.check("le .htaccess envoyé est identique à celui du site", (ftp / ".htaccess").read_bytes() == (JEND / ".htaccess").read_bytes())

    S.titre("LE DOSSIER FTP FONCTIONNE SEUL (serveur PHP temporaire + base jetable, comme sur l'hébergeur)")
    nom_bd = "jend_ftp_t12"; assert nom_bd != DB["name"]
    sql(f"DROP DATABASE IF EXISTS {nom_bd}; CREATE DATABASE {nom_bd} CHARACTER SET utf8mb4", base=False)
    port = port_libre()
    serveur = None
    try:
        r = preparer("--admin-email=hote@example.test", "--admin-nom=Hôte Test", "--demo", f"--sortie={d}/ftp.sql", f"--env={d}/ftp.env")
        mdp_a = re.search(r"Compte administrateur :\n\s+e-mail\s+: \S+\n\s+mot de passe : (\S+)", r.stdout).group(1)
        mdp_v = re.search(r"vendeur de démonstration :\n\s+e-mail\s+: \S+\n\s+mot de passe : (\S+)", r.stdout).group(1)
        imp = subprocess.run(f"'{MYSQL_BIN}' -h {DB['host']} -P {DB['port']} -u {DB['user']} {'-p' + DB['pass'] if DB['pass'] else ''} {nom_bd} < '{d}/ftp.sql'", shell=True, capture_output=True, text=True)
        S.check("installation de la base à partir du SQL généré", imp.returncode == 0, imp.stderr[:200])
        modele = (d / "ftp.env").read_text()
        for cle, val in {"APP_URL": f"http://127.0.0.1:{port}", "DB_HOST": DB["host"], "DB_NAME": nom_bd, "DB_USER": DB["user"], "DB_PASS": DB["pass"],
                         "MAIL_DRIVER": "log", "FORCE_HTTPS": "0", "MAIL_FROM": "a@exemple.test", "SMTP_USER": "a@exemple.test", "SMTP_PASS": "x"}.items():
            modele = re.sub(rf"^{cle}=.*$", f"{cle}={val}", modele, flags=re.M)
        (ftp / ".env").write_text(modele)         # ce que l'utilisateur fait avec son FTP
        serveur = subprocess.Popen([PHP, "-S", f"127.0.0.1:{port}", "-t", str(ftp)], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        for _ in range(50):
            try:
                socket.create_connection(("127.0.0.1", port), timeout=0.2).close(); break
            except OSError:
                time.sleep(0.1)
        base = f"http://127.0.0.1:{port}/"
        c = Client(base)
        s, h, _ = c.get("")
        S.check("accueil du dossier FTP : 200, bandeau de test, produits de démonstration", s == 200 and "SITE DE TEST" in h and h.count('class="carte"') == 8, str(s) + " cartes=" + str(h.count('class="carte"')))
        S.check("polices et bibliothèques servies depuis le dossier", all(Client(base).get(f"assets/vendor/{f}")[0] == 200 for f in ("js/gsap.min.js", "css/phosphor-regular.css", "fonts/satoshi-400.woff2")))
        S.check("pages catalogue : produits, catégorie, recherche, 404", all(c.get(u)[0] == 200 for u in ("produits", "categorie/mode-wax", "recherche?q=wax", "connexion", "inscription", "vendre")) and c.get("nimportequoi")[0] == 404)
        slug = sql(f"SELECT slug FROM {nom_bd}.produits WHERE nom LIKE 'Beurre%'", base=False)
        S.check("fiche produit (adresse propre)", slug == "beurre-de-karite-pur-250-ml" and c.get("produit/" + slug)[0] == 200)
        cl = Client(base)
        cl.post("inscription", {"nom": "Client FTP", "email": "client-ftp@example.test", "mot_de_passe": "Mdp-test-12345", "mot_de_passe2": "Mdp-test-12345"})
        S.check("inscription d'un client", cl.get("compte")[0] == 200)
        S.check("sur une installation neuve, la confirmation de l'e-mail est exigée", sql(f"SELECT email_verifie FROM {nom_bd}.users WHERE email='client-ftp@example.test'", base=False) == "0")
        sql(f"UPDATE {nom_bd}.users SET email_verifie = 1 WHERE email='client-ftp@example.test'", base=False)      # (le lien de confirmation est testé à l'étape 39)
        tok = cl.token("produits"); cl.req("panier/ajouter", {"csrf": tok, "produit_id": 1, "quantite": 2, "retour": "/produits"})
        s, _, hd = cl.post("commande", {"nom": "Client FTP", "telephone": "77 123 45 67", "zone_id": 1, "adresse": "Rue 1 Dakar", "methode": "wave"})
        refc = hd.get("Location", "").rsplit("/", 1)[-1]
        S.check("commande Wave créée", refc.startswith("JND-"), refc)
        s, _, hd = cl.post("paiement/" + refc, {}, page_token="commande/" + refc)
        simu = hd.get("Location", "").replace(base, "").lstrip("/")
        cl.post(simu, {"resultat": "reussi"})
        statut = sql(f"SELECT CONCAT(statut,'|',statut_paiement) FROM {nom_bd}.commandes WHERE reference='{refc}'", base=False)
        S.check("paiement simulé de bout en bout : commande confirmée et payée", statut == "confirmee|paye", statut)
        adm = Client(base)
        s, _, hd = adm.post("connexion", {"email": "hote@example.test", "mot_de_passe": mdp_a})
        S.check("l'administrateur se connecte avec le mot de passe affiché", s == 302 and adm.get("compte")[0] == 200)
        s, _, hd = adm.get("admin")
        S.check("2FA obligatoire pour l'admin sur ce site (redirigé vers Sécurité)", s == 302 and hd["Location"].endswith("/compte/securite"))
        v = Client(base)
        v.post("connexion", {"email": "vendeur@jend.local", "mot_de_passe": mdp_v})
        S.check("le vendeur de démonstration voit la commande à préparer", refc in v.get("vendeur/commandes")[1])
    finally:
        if serveur:
            serveur.terminate(); serveur.wait(timeout=10)
        sql(f"DROP DATABASE IF EXISTS {nom_bd}", base=False)
        shutil.rmtree(d, ignore_errors=True)
finally:
    ok = S.fin()
sys.exit(0 if ok else 1)
