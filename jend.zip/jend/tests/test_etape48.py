"""Étape 48 : position GPS de livraison, « dépense du mois », description vocale, alertes « prévenez-moi », mode économie de données."""
import sys, re, datetime, urllib.parse
from lib import *

S = Suite("Étape 48 — position, dépense, voix, alertes, mode léger", ["ad-t48@jend.local", "cl-t48@jend.local", "c2-t48@jend.local", "va-t48@jend.local"])
E = dict(zip(["ad", "cl", "c2", "va"], S.emails))
LOG = lambda: (JEND / "storage" / "emails.log").read_text() if (JEND / "storage" / "emails.log").exists() else ""
try:
    S.nettoyer()
    sql("DELETE FROM produits WHERE slug IN ('produit-t48','riz-t48')"); sql("DELETE FROM boutiques WHERE slug='boutique-t48'"); sql("DELETE FROM zones_livraison WHERE nom='Zone T48'")
    sql("INSERT INTO zones_livraison (nom, region, frais, delai_jours) VALUES ('Zone T48', 'Touba', 1000, 1)")
    zone = int(sql("SELECT id FROM zones_livraison WHERE nom='Zone T48'"))
    pw = mot_de_passe()
    for k, nom, role in (("ad", "Admin T48", "admin"), ("cl", "Cliente T48", "client"), ("c2", "Autre T48", "client"), ("va", "Vendeur T48", "vendeur")):
        sql(f"INSERT INTO users (nom,email,mot_de_passe,role) VALUES ('{nom}','{E[k]}','{hash_mdp(pw)}','{role}')")
    sql(f"INSERT INTO boutiques (user_id,nom,slug,statut,commission_pct,livraison_par) SELECT id,'Boutique T48','boutique-t48','active',1,'vendeur' FROM users WHERE email='{E['va']}'")
    cat = sql("SELECT MIN(id) FROM categories")
    for slug, nom in (("produit-t48", "Thiouraye T48"), ("riz-t48", "Riz T48 25 kg")):
        sql(f"INSERT INTO produits (boutique_id,categorie_id,nom,slug,description,prix,stock,statut) SELECT b.id,{cat},'{nom}','{slug}','x',10000,50,'publie' FROM boutiques b WHERE b.slug='boutique-t48'")
    prod, riz = sql("SELECT id FROM produits WHERE slug='produit-t48'"), sql("SELECT id FROM produits WHERE slug='riz-t48'")
    AD, C, C2, VA = Client(), Client(), Client(), Client()
    for cl, k in ((AD, "ad"), (C, "cl"), (C2, "c2"), (VA, "va")):
        cl.post("connexion", {"email": E[k], "mot_de_passe": pw})
    txt = lambda cl, u, h=None: cl.req(u, headers=h)[1].replace("&#039;", "'").replace(" ", " ").replace("&nbsp;", " ").replace("\xa0", " ")
    def ajouter(pid, q=1, cl=None):
        cl = cl or C
        cl.req("panier/ajouter", {"csrf": cl.token("produits"), "produit_id": pid, "quantite": q, "retour": "/jend/produits"})
    def commander(extra=None):
        ajouter(prod)
        _, _, hd = C.post("commande", {"nom": "Awa Ndiaye", "telephone": "77 123 45 48", "zone_id": zone, "adresse": "Darou Marnane, maison bleue", "methode": "wave", **(extra or {})})
        return hd["Location"].rsplit("/", 1)[-1]
    def produit_form(champs, fichiers=()):
        base = {"nom": "Thiouraye T48", "categorie_id": cat, "description": "x", "prix": "10000", "prix_barre": "", "stock": "50", "statut": "publie", "video_url": ""}
        return VA.multipart(f"vendeur/produits/{prod}/modifier", {**base, **champs}, list(fichiers))

    S.titre("MA POSITION")
    _, _, hd = C.get("")
    S.check("le site autorise la localisation et le micro pour lui seul", "geolocation=(self)" in hd.get("Permissions-Policy", "") and "microphone=(self)" in hd.get("Permissions-Policy", ""))
    ajouter(prod)
    S.check("la commande propose « Utiliser ma position actuelle »", "Utiliser ma position actuelle" in txt(C, "commande") and "commande.js" in txt(C, "commande"))
    ref = commander({"lat": "14.861234", "lng": "-15.875678"})
    S.check("position enregistrée avec la commande et l'adresse", sql(f"SELECT CONCAT(livraison_lat,',',livraison_lng) FROM commandes WHERE reference='{ref}'") == "14.861234,-15.875678"
            and sql(f"SELECT CONCAT(lat,',',lng) FROM adresses a JOIN users u ON u.id=a.user_id WHERE u.email='{E['cl']}' LIMIT 1") == "14.861234,-15.875678")
    ref0 = commander({"lat": "48.85", "lng": "2.35"})
    S.check("position hors du Sénégal (Paris) ignorée", sql(f"SELECT livraison_lat IS NULL FROM commandes WHERE reference='{ref0}'") == "1")
    sql(f"UPDATE commandes SET statut_paiement='paye', statut='confirmee' WHERE reference='{ref}'")
    h = VA.get("vendeur/commandes")[1]
    S.check("le vendeur a le bouton « Itinéraire GPS » vers le point exact", "google.com/maps/dir/?api=1&amp;destination=14.861234%2C-15.875678" in h)
    ref2 = commander({"cadeau": "1"})
    sql(f"UPDATE commandes SET statut_paiement='paye', statut='confirmee' WHERE reference='{ref2}'")
    h = C.get(f"commande/{ref2}")[1]
    m = re.search(r"position%2F([a-f0-9]{32})", h) or re.search(r"position/([a-f0-9]{32})", urllib.parse.unquote(h))
    S.check("cadeau sans position : bouton « Demander sa position » avec un lien secret", "Demander sa position" in h and m is not None)
    jeton = m.group(1)
    V = Client()
    s, h, _ = V.get(f"position/{jeton}")
    S.check("le proche ouvre le lien sans compte ; ni produit ni prix affichés", s == 200 and "Envoyer ma position" in h and "Thiouraye" not in h and "FCFA" not in h)
    V.post(f"position/{jeton}", {"lat": "0", "lng": "0"})
    S.check("position fantaisiste (0,0) refusée", sql(f"SELECT livraison_lat IS NULL FROM commandes WHERE reference='{ref2}'") == "1")
    V.post(f"position/{jeton}", {"lat": "14.7167", "lng": "-17.4677"})
    S.check("position du proche enregistrée sur la commande", sql(f"SELECT CONCAT(livraison_lat,',',livraison_lng) FROM commandes WHERE reference='{ref2}'") == "14.716700,-17.467700")
    S.check("lien inventé : introuvable", V.get("position/" + "0" * 32)[0] == 404)
    sql(f"UPDATE commande_boutiques cb JOIN commandes c ON c.id=cb.commande_id SET cb.statut='livree', cb.livre_le=NOW() WHERE c.reference='{ref2}'")
    S.check("après la livraison, le lien ne sert plus", V.get(f"position/{jeton}")[0] == 404)
    sql(f"UPDATE commandes SET statut='annulee' WHERE reference IN ('{ref}','{ref0}')")

    S.titre("LA DÉPENSE DU MOIS")
    ajouter(riz, 2)
    S.check("le panier propose « Enregistrer comme dépense du mois »", "Enregistrer comme dépense du mois" in txt(C, "panier"))
    C.post("depense/nouvelle", {"nom": "Dépense de Maman", "jour": "5", "livraison_nom": "Maman T48", "livraison_telephone": "77 555 44 48", "zone_id": zone, "adresse": "Touba Darou Khoudoss", "cadeau": "1"})
    did = sql(f"SELECT d.id FROM depenses d JOIN users u ON u.id=d.client_id WHERE u.email='{E['cl']}'")
    attendu = (datetime.date.today().replace(day=5) if datetime.date.today().day < 5 else (datetime.date.today().replace(day=1) + datetime.timedelta(days=32)).replace(day=5)).isoformat()
    S.check("dépense enregistrée : 2 riz, cadeau, prochain rappel le 5", did != "" and sql(f"SELECT CONCAT(quantite) FROM depense_lignes WHERE depense_id={did}") == "2"
            and sql(f"SELECT CONCAT(cadeau,'|',prochain_rappel) FROM depenses WHERE id={did}") == f"1|{attendu}")
    S.check("un autre client ne la voit pas", C2.get(f"depense/{did}")[0] == 404)
    h = txt(C, f"depense/{did}")
    S.check("la page montre le total au prix du jour (20 000 FCFA)", "Environ 20 000 FCFA" in h and "Riz T48" in h)
    C.post(f"depense/{did}", {"action": "commander"})
    h = txt(C, "commande")
    S.check("« Commander maintenant » : panier rempli et adresse du destinataire pré-remplie", 'value="Maman T48"' in h and "Touba Darou Khoudoss" in h and "Dépense de Maman" in h)
    sql(f"UPDATE depenses SET prochain_rappel = CURDATE() WHERE id={did}")
    (JEND / "storage" / "depenses-rappel.txt").unlink(missing_ok=True)
    avant = len(LOG())
    Client().get("")
    S.check("le jour venu : e-mail « Votre dépense … est prête » avec le lien", "Votre dépense « Dépense de Maman » est prête" in LOG()[avant:] and f"depense/{did}" in LOG()[avant:])
    S.check("et le rappel suivant est programmé le mois prochain", sql(f"SELECT prochain_rappel > CURDATE() AND dernier_rappel = CURDATE() FROM depenses WHERE id={did}") == "1")
    avant = len(LOG()); Client().get("")
    S.check("pas de rappel en double", "est prête" not in LOG()[avant:])
    C.post(f"depense/{did}", {"action": "pause"})
    S.check("mise en pause", sql(f"SELECT actif FROM depenses WHERE id={did}") == "0")
    C2.post(f"depense/{did}", {"action": "supprimer"}, page_token="compte")
    S.check("un autre client ne peut pas la supprimer", sql(f"SELECT COUNT(*) FROM depenses WHERE id={did}") == "1")

    S.titre("DESCRIPTION VOCALE")
    ogg = b"OggS" + b"\x00" * 3000
    produit_form({}, [("voix", "vocal.ogg", ogg, "audio/ogg")])
    voix = sql(f"SELECT voix_chemin FROM produits WHERE id={prod}")
    S.check("message vocal enregistré sous un nom aléatoire dans uploads/voix/", re.fullmatch(r"uploads/voix/[a-f0-9]{32}\.ogg", voix) is not None)
    h = C.get("produit/produit-t48")[1]
    S.check("la fiche produit propose d'écouter le vendeur", "Le vendeur vous parle de son produit" in h and voix in h and 'type="audio/ogg"' in h)
    S.check("le fichier audio est servi", Client().get(voix)[0] == 200)
    produit_form({}, [("voix", "piege.ogg", b"<?php system('id'); ?>" + b" " * 2000, "audio/ogg")])
    S.check("faux fichier audio (script PHP) refusé, l'ancien est conservé", sql(f"SELECT voix_chemin FROM produits WHERE id={prod}") == voix)
    S.check("un script dans uploads/voix ne peut pas être appelé", Client().get("uploads/voix/test.php")[0] in (403, 404))
    produit_form({"supprimer_voix": "1"})
    S.check("le vendeur peut supprimer l'enregistrement (fichier effacé)", sql(f"SELECT voix_chemin IS NULL FROM produits WHERE id={prod}") == "1" and not (JEND / voix).exists())

    S.titre("PRÉVENEZ-MOI")
    C.post("produit/produit-t48", {"action": "alerte"})
    S.check("alerte activée au prix vu (10 000)", sql(f"SELECT prix_vu FROM alertes_produit WHERE produit_id={prod}") == "10000")
    S.check("la page « Alertes prix » la liste", "Thiouraye T48" in txt(C, "alertes"))
    avant = len(LOG())
    produit_form({"prix": "8500"})
    S.check("baisse de prix : e-mail « Baisse de prix » (10 000 → 8 500) et alerte consommée", "Baisse de prix" in LOG()[avant:] and "8 500" in LOG()[avant:].replace(" ", " ").replace("\xa0", " ")
            and sql(f"SELECT COUNT(*) FROM alertes_produit WHERE produit_id={prod}") == "0")
    sql(f"UPDATE produits SET stock=0 WHERE id={prod}")
    C.post("produit/produit-t48", {"action": "alerte"})
    S.check("produit épuisé : l'alerte attend son retour", sql(f"SELECT epuise FROM alertes_produit WHERE produit_id={prod}") == "1")
    avant = len(LOG())
    produit_form({"prix": "8500", "stock": "4"})
    S.check("retour en stock : e-mail « est de retour »", "est de retour" in LOG()[avant:] and sql(f"SELECT COUNT(*) FROM alertes_produit WHERE produit_id={prod}") == "0")

    S.titre("ÉCONOMIE DE DONNÉES")
    h = txt(Client(), "")
    S.check("par défaut : animations chargées", "gsap.min.js" in h and 'class="leger"' not in h)
    h = txt(Client(), "", {"Save-Data": "on"})
    S.check("téléphone en économie de données : pages sans bibliothèques d'animation", "gsap.min.js" not in h and 'class="leger"' in h)
    L2 = Client()
    _, _, hd = L2.post("mode-leger", {"retour": "/jend/produits"}, page_token="produits")
    S.check("bouton du pied de page : activé, retour à la page d'origine", hd.get("Location", "") == "/jend/produits" and "gsap.min.js" not in txt(L2, ""))
    _, _, hd = L2.post("mode-leger", {"retour": "//site-pirate.example/"}, page_token="produits")
    S.check("retour vers un autre site refusé (redirection vers l'accueil)", hd.get("Location", "") == "/jend/" and "gsap.min.js" in txt(L2, ""))
finally:
    ok = S.fin()
    for f in (JEND / "uploads" / "voix").glob("*.ogg"):
        f.unlink()
    sql("DELETE FROM produits WHERE slug IN ('produit-t48','riz-t48')"); sql("DELETE FROM boutiques WHERE slug='boutique-t48'"); sql("DELETE FROM zones_livraison WHERE nom='Zone T48'")
sys.exit(0 if ok else 1)
