"""Étape 54 : versements à date fixe, référence du transfert, relevés mensuels (comme les grandes marketplaces)."""
import sys, re
from lib import *

S = Suite("Étape 54 — versements et relevés", ["ad-t54@jend.local", "cl-t54@jend.local", "va-t54@jend.local", "vb-t54@jend.local"])
E = dict(zip(["ad", "cl", "va", "vb"], S.emails))
LOG = lambda: (JEND / "storage" / "emails.log").read_text() if (JEND / "storage" / "emails.log").exists() else ""
try:
    S.nettoyer()
    sql("DELETE FROM parametres WHERE cle IN ('jour_reversement','versements_prepares_le')")
    sql("DELETE FROM produits WHERE slug IN ('produit-t54','produit-t54b')"); sql("DELETE FROM boutiques WHERE slug IN ('boutique-t54','boutique-t54b')"); sql("DELETE FROM zones_livraison WHERE nom='Zone T54'")
    sql("INSERT INTO zones_livraison (nom, region, frais, delai_jours) VALUES ('Zone T54', 'Touba', 1000, 1)")
    zone = int(sql("SELECT id FROM zones_livraison WHERE nom='Zone T54'"))
    pw = mot_de_passe()
    for k, nom, role in (("ad", "Admin T54", "admin"), ("cl", "Cliente T54", "client"), ("va", "Vendeur T54", "vendeur"), ("vb", "Vendeuse B T54", "vendeur")):
        sql(f"INSERT INTO users (nom,email,mot_de_passe,role) VALUES ('{nom}','{E[k]}','{hash_mdp(pw)}','{role}')")
    for k, slug, prod, nomp in (("va", "boutique-t54", "produit-t54", "=HYPERLINK(1) Pagne T54"), ("vb", "boutique-t54b", "produit-t54b", "Pagne B T54")):
        sql(f"INSERT INTO boutiques (user_id,nom,slug,statut,commission_pct,telephone_paiement,livraison_par) SELECT id,'Boutique {slug}','{slug}','active',1,'+221771115454','vendeur' FROM users WHERE email='{E[k]}'")
        sql(f"INSERT INTO produits (boutique_id,categorie_id,nom,slug,description,prix,stock,statut) SELECT b.id,(SELECT MIN(id) FROM categories),'{nomp}','{prod}','x',20000,20,'publie' FROM boutiques b WHERE b.slug='{slug}'")
    bid, bidb = sql("SELECT id FROM boutiques WHERE slug='boutique-t54'"), sql("SELECT id FROM boutiques WHERE slug='boutique-t54b'")
    AD, C, VA, VB = Client(), Client(), Client(), Client()
    for cl, k in ((AD, "ad"), (C, "cl"), (VA, "va"), (VB, "vb")):
        cl.post("connexion", {"email": E[k], "mot_de_passe": pw})
    txt = lambda cl, u: cl.get(u)[1].replace("&#039;", "'").replace(" ", " ").replace("&nbsp;", " ").replace("\xa0", " ")
    for slugp in ("produit-t54", "produit-t54b"):
        pid = sql(f"SELECT id FROM produits WHERE slug='{slugp}'")
        C.req("panier/ajouter", {"csrf": C.token("produits"), "produit_id": pid, "quantite": 1, "retour": "/jend/produits"})
        _, _, hd = C.post("commande", {"nom": "Cliente T54", "telephone": "77 123 45 54", "zone_id": zone, "adresse": "Rue 54 Touba", "methode": "wave"})
        ref = hd["Location"].rsplit("/", 1)[-1]
        sql(f"UPDATE commande_boutiques cb JOIN commandes c ON c.id=cb.commande_id SET cb.statut='livree', cb.livre_le=NOW()-INTERVAL 5 DAY, c.statut_paiement='paye', c.statut='terminee' WHERE c.reference='{ref}'")

    S.titre("RÉGLAGE ET AFFICHAGE")
    S.check("sans jour fixé : le vendeur voit « Versements sur demande »", "Versements sur demande" in txt(VA, "vendeur/gains"))
    AD.post("admin/parametres", {"action": "infos_paiement", "jour": "lundi", "taux": ""})
    h = txt(VA, "vendeur/gains")
    S.check("jour fixé (lundi) : « Prochain versement : lundi … » avec le solde (20 800 FCFA)", re.search(r"Prochain versement : <b>lundi \d+", h) is not None and "20 800 FCFA" in h)
    S.check("la page publique s'engage : « Chaque lundi, votre solde disponible vous est versé automatiquement »", "Chaque lundi, votre solde disponible vous est versé automatiquement" in txt(Client(), "paiements-vendeurs"))
    VB.post("vendeur/gains", {"action": "versement", "methode_versement": "orange_money"}, page_token="vendeur/gains")
    S.check("la vendeuse B désactive le versement automatique (et choisit Orange Money)", sql(f"SELECT CONCAT(versement_auto,'|',methode_versement) FROM boutiques WHERE id={bidb}") == "0|orange_money")

    S.titre("PRÉPARATION DES VERSEMENTS")
    avant = len(LOG())
    AD.post("admin/retraits", {"action": "preparer"})
    S.check("un versement automatique de tout le solde est préparé pour A", sql(f"SELECT CONCAT(montant,'|',automatique,'|',statut,'|',methode) FROM retraits WHERE boutique_id={bid}") == "20800|1|demande|wave")
    S.check("rien pour B, qui a désactivé le versement automatique", sql(f"SELECT COUNT(*) FROM retraits WHERE boutique_id={bidb}") == "0")
    S.check("e-mail au vendeur « versement … en préparation » et récapitulatif à l'admin", "Votre versement de 20 800 FCFA est en préparation".replace(" ", "") in LOG()[avant:].replace(" ", "").replace("\xa0", "").replace(" ", "") and "versement(s) à envoyer" in LOG()[avant:])
    AD.post("admin/retraits", {"action": "preparer"})
    S.check("relancer ne crée pas de doublon (le solde est déjà réservé)", sql(f"SELECT COUNT(*) FROM retraits WHERE boutique_id={bid}") == "1")
    S.check("la page admin montre « Auto » et le prochain lundi", "Auto</span>" in txt(AD, "admin/retraits") and "Versements automatiques chaque lundi" in txt(AD, "admin/retraits"))

    S.titre("ENVOI AVEC RÉFÉRENCE")
    rid = sql(f"SELECT id FROM retraits WHERE boutique_id={bid}")
    avant = len(LOG())
    AD.post("admin/retraits", {"action": "payer", "id": rid, "reference": "WV-2026-ABC123"})
    S.check("versé : date et référence enregistrées", sql(f"SELECT CONCAT(statut,'|',paye_le IS NOT NULL,'|',reference_transfert) FROM retraits WHERE id={rid}") == "paye|1|WV-2026-ABC123")
    S.check("e-mail « Versement envoyé » au vendeur, avec la référence", "Versement envoyé" in LOG()[avant:] and "WV-2026-ABC123" in LOG()[avant:])
    S.check("le vendeur voit la référence dans « Mes retraits »", "WV-2026-ABC123" in txt(VA, "vendeur/gains"))

    S.titre("RELEVÉ MENSUEL")
    h = txt(VA, "vendeur/releves")
    S.check("relevé : vente livrée, commission, versement et référence", "Ventes livrées" in h and "20 000 FCFA" in h and "200 FCFA" in h and "WV-2026-ABC123" in h and "Envoyé" in h)
    s, corps, hd = VA.get("vendeur/releves?format=csv")
    S.check("export Excel (CSV) téléchargeable", s == 200 and "text/csv" in hd.get("Content-Type", "") and "attachment" in hd.get("Content-Disposition", ""))
    import csv, io
    cellules = [c for ligne in csv.reader(io.StringIO(corps.lstrip("\ufeff")), delimiter=";") for c in ligne]
    S.check("CSV : aucune cellule ne commence par = + - @ (pas de formule exécutée par Excel), le nom piégé est bien présent",
            not any(c[:1] in "=+-@" and c[:1] != "" and not re.fullmatch(r"-?\d+", c) for c in cellules) and "-20800" in cellules and any("=HYPERLINK" in c for c in cellules))
    S.check("le relevé de B ne montre pas les ventes de A", "WV-2026-ABC123" not in txt(VB, "vendeur/releves") and "=HYPERLINK" not in txt(VB, "vendeur/releves"))
    S.check("un client n'a pas accès aux relevés", C.get("vendeur/releves")[0] in (302, 303))
    S.check("mois invalide ignoré (pas d'erreur)", VA.get("vendeur/releves?mois=2026-13")[0] == 200 and VA.get("vendeur/releves?mois=abc")[0] == 200)
finally:
    sql("DELETE FROM parametres WHERE cle IN ('jour_reversement','versements_prepares_le')")
    sql("DELETE FROM journal_admin WHERE admin_id IN (SELECT id FROM users WHERE email LIKE '%-t54@jend.local')")
    ok = S.fin()
    sql("DELETE FROM retraits WHERE boutique_id IN (SELECT id FROM boutiques WHERE slug IN ('boutique-t54','boutique-t54b'))")
    sql("DELETE FROM produits WHERE slug IN ('produit-t54','produit-t54b')"); sql("DELETE FROM boutiques WHERE slug IN ('boutique-t54','boutique-t54b')"); sql("DELETE FROM zones_livraison WHERE nom='Zone T54'")
sys.exit(0 if ok else 1)
