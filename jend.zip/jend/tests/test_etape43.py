"""Étape 43 : chaque vendeur fixe ses frais de livraison par zone."""
import re, sys
from lib import *

S = Suite("Étape 43 — frais de livraison des vendeurs", ["cl-t43@jend.local", "va-t43@jend.local", "vb-t43@jend.local"])
E = dict(zip(["cl", "va", "vb"], S.emails))
try:
    S.nettoyer()
    sql("DELETE FROM produits WHERE slug IN ('produit-a-t43','produit-b-t43')"); sql("DELETE FROM boutiques WHERE slug IN ('boutique-a-t43','boutique-b-t43')")
    sql("DELETE FROM zones_livraison WHERE nom IN ('Zone A T43','Zone B T43')")
    sql("INSERT INTO zones_livraison (nom, region, frais, delai_jours) VALUES ('Zone A T43','Touba',1000,1),('Zone B T43','Touba',2000,2)")
    za = sql("SELECT id FROM zones_livraison WHERE nom='Zone A T43'"); zb = sql("SELECT id FROM zones_livraison WHERE nom='Zone B T43'")
    pw = mot_de_passe()
    for k, nom, role in (("cl", "Cliente T43", "client"), ("va", "Vendeur A T43", "vendeur"), ("vb", "Vendeur B T43", "vendeur")):
        sql(f"INSERT INTO users (nom,email,mot_de_passe,role) VALUES ('{nom}','{E[k]}','{hash_mdp(pw)}','{role}')")
    for k, slug in (("va", "boutique-a-t43"), ("vb", "boutique-b-t43")):
        sql(f"INSERT INTO boutiques (user_id,nom,slug,statut,commission_pct,telephone_paiement) SELECT id,'{slug}','{slug}','active',1,'+221771112233' FROM users WHERE email='{E[k]}'")
        sql(f"INSERT INTO produits (boutique_id,categorie_id,nom,slug,description,prix,stock,statut) SELECT b.id,(SELECT MIN(id) FROM categories),'Produit {k}','produit-{k[1]}-t43','x',10000,20,'publie' FROM boutiques b WHERE b.slug='{slug}'")
    pa, pb = sql("SELECT id FROM produits WHERE slug='produit-a-t43'"), sql("SELECT id FROM produits WHERE slug='produit-b-t43'")
    C, VA, VB = Client(), Client(), Client()
    for cl, k in ((C, "cl"), (VA, "va"), (VB, "vb")):
        cl.post("connexion", {"email": E[k], "mot_de_passe": pw})
    txt = lambda cl, u: cl.get(u)[1].replace("&#039;", "'").replace(" ", " ").replace("&nbsp;", " ")

    S.titre("LE VENDEUR FIXE SES FRAIS")
    h = txt(VA, "vendeur/boutique")
    S.check("l'onglet « Boutique » propose « Mes frais de livraison », zone par zone, avec les frais de référence en indication", "Mes frais de livraison" in h and f'name="frais[{za}]"' in h and 'placeholder="1000"' in h)
    for mauvais in ({f"frais[{za}]": "-5"}, {f"frais[{za}]": "abc"}, {f"frais[{za}]": "999999"}, {f"delai[{za}]": "0"}):
        VA.post("vendeur/boutique", {"action": "frais", **mauvais}, page_token="vendeur/boutique")
    S.check("frais négatifs, texte, montant énorme ou délai nul : refusés", sql("SELECT COUNT(*) FROM boutique_frais") == "0")
    VA.post("vendeur/boutique", {"action": "frais", f"frais[{za}]": "500", f"delai[{za}]": "", f"frais[{zb}]": "3000", f"delai[{zb}]": "3"}, page_token="vendeur/boutique")
    S.check("le vendeur A fixe 500 FCFA pour la zone A et 3 000 FCFA (3 jours) pour la zone B", sql(f"SELECT GROUP_CONCAT(CONCAT(zone_id,':',frais,':',COALESCE(delai_jours,'-')) ORDER BY zone_id) FROM boutique_frais") == f"{za}:500:-,{zb}:3000:3")
    C.post("vendeur/boutique", {"action": "frais", f"frais[{za}]": "1"}, page_token="compte")
    S.check("un client ne peut pas modifier les frais d'une boutique", sql(f"SELECT frais FROM boutique_frais WHERE zone_id={za}") == "500")

    S.titre("CE QUE PAIE LE CLIENT")
    S.check("la fiche produit annonce la livraison à partir des frais de la boutique (500)", "Livraison à partir de 500 FCFA" in txt(C, "produit/produit-a-t43"))
    C.req("panier/ajouter", {"csrf": C.token("produits"), "produit_id": pa, "quantite": 1, "retour": "/jend/produits"})
    h = txt(C, "commande")
    S.check("à la commande, chaque zone affiche les frais de CETTE boutique (500 et 3 000, 3 j)", f'value="{za}" data-frais="500"' in h and f'value="{zb}" data-frais="3000"' in h and "(3 j)" in h)
    _, _, hd = C.post("commande", {"nom": "Cliente T43", "telephone": "78 000 11 43", "zone_id": za, "adresse": "Rue 43 Touba", "methode": "wave"})
    ref = hd["Location"].rsplit("/", 1)[-1]
    S.check("la commande facture 500 FCFA de livraison, qui reviennent au vendeur", sql(f"SELECT frais_livraison FROM commandes WHERE reference='{ref}'") == "500" and sql(f"SELECT cb.frais_part FROM commande_boutiques cb JOIN commandes c ON c.id=cb.commande_id WHERE c.reference='{ref}'") == "500")
    C.req("panier/ajouter", {"csrf": C.token("produits"), "produit_id": pa, "quantite": 1, "retour": "/jend/produits"})
    C.req("panier/ajouter", {"csrf": C.token("produits"), "produit_id": pb, "quantite": 1, "retour": "/jend/produits"})
    h = txt(C, "commande")
    S.check("panier de deux boutiques : zone A = 500 (A) + 1 000 (B, frais de référence) = 1 500, et « 2 boutiques, 2 colis »", f'value="{za}" data-frais="1500"' in h and "2 boutiques, 2 colis" in h)
    _, _, hd = C.post("commande", {"nom": "Cliente T43", "telephone": "78 000 11 43", "zone_id": za, "adresse": "Rue 43 Touba", "methode": "wave"})
    ref2 = hd["Location"].rsplit("/", 1)[-1]
    parts = sql(f"SELECT GROUP_CONCAT(cb.frais_part ORDER BY b.slug) FROM commande_boutiques cb JOIN commandes c ON c.id=cb.commande_id JOIN boutiques b ON b.id=cb.boutique_id WHERE c.reference='{ref2}'")
    S.check("chaque boutique reçoit SES frais (A : 500, B : 1 000) et le total est 1 500", parts == "500,1000" and sql(f"SELECT frais_livraison FROM commandes WHERE reference='{ref2}'") == "1500", parts)
    h = txt(C, "livraison-retours")
    S.check("la page « Livraison et retours » indique les frais de chaque boutique dans la ville", "boutique-a-t43" in h and "500 FCFA à 3 000 FCFA" in h)
    VA.post("vendeur/boutique", {"action": "frais"}, page_token="vendeur/boutique")
    S.check("tout vider remet les frais de référence", sql("SELECT COUNT(*) FROM boutique_frais") == "0")
finally:
    ok = S.fin()
    sql("DELETE FROM produits WHERE slug IN ('produit-a-t43','produit-b-t43')"); sql("DELETE FROM boutiques WHERE slug IN ('boutique-a-t43','boutique-b-t43')")
    sql("DELETE FROM zones_livraison WHERE nom IN ('Zone A T43','Zone B T43')")
sys.exit(0 if ok else 1)
