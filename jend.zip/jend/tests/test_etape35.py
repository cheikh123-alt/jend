"""Étape 35 : commande sur mesure (demande, devis, acceptation, paiement par le circuit habituel)."""
import sys
from lib import *

S = Suite("Étape 35 — commande sur mesure", ["cl-t35@jend.local", "c2-t35@jend.local", "va-t35@jend.local", "vb-t35@jend.local"])
E = dict(zip(["cl", "c2", "va", "vb"], S.emails))
try:
    S.nettoyer()
    sql("DELETE FROM produits WHERE nom LIKE 'Commande sur mesure SM-%' OR slug='pagne-t35'"); sql("DELETE FROM boutiques WHERE slug IN ('tailleur-t35','autre-t35')")
    sql("DELETE FROM zones_livraison WHERE nom='Zone T35'")
    sql("INSERT INTO zones_livraison (nom, region, frais, delai_jours) VALUES ('Zone T35', 'Touba', 500, 1)")
    zone = int(sql("SELECT id FROM zones_livraison WHERE nom='Zone T35'"))
    pw = mot_de_passe()
    for k, nom, role in (("cl", "Cliente T35", "client"), ("c2", "Autre T35", "client"), ("va", "Tailleur T35", "vendeur"), ("vb", "Autre vendeur T35", "vendeur")):
        sql(f"INSERT INTO users (nom,email,mot_de_passe,role) VALUES ('{nom}','{E[k]}','{hash_mdp(pw)}','{role}')")
    for k, slug in (("va", "tailleur-t35"), ("vb", "autre-t35")):
        sql(f"INSERT INTO boutiques (user_id,nom,slug,statut,commission_pct,telephone_paiement) SELECT id,'{slug}','{slug}','active',1,'+221771112233' FROM users WHERE email='{E[k]}'")
    bid = sql("SELECT id FROM boutiques WHERE slug='tailleur-t35'")
    C, C2, VA, VB, P = Client(), Client(), Client(), Client(), Client()
    for cl, k in ((C, "cl"), (C2, "c2"), (VA, "va"), (VB, "vb")):
        cl.post("connexion", {"email": E[k], "mot_de_passe": pw})
    txt = lambda cl, u: cl.get(u)[1].replace("&#039;", "'")
    dm = lambda c: sql(f"SELECT {c} FROM demandes_mesure ORDER BY id DESC LIMIT 1")
    demande = {"description": "Un boubou brodé pour homme, bazin bleu nuit, broderie dorée", "mesures": "poitrine 104, longueur 140", "budget": "30000", "date": ""}

    S.titre("ACTIVATION PAR LE VENDEUR")
    S.check("boutique sans sur-mesure : pas de bouton, et la page de demande n'existe pas (404)", "sur-mesure" not in txt(P, "boutique/tailleur-t35") and C.get("sur-mesure/tailleur-t35")[0] == 404)
    VA.post("vendeur/boutique", {"nom": "tailleur-t35", "description": "", "telephone": "77 111 22 33", "offres_actives": "1", "sur_mesure": "1"}, page_token="vendeur/boutique")
    S.check("le vendeur active le sur-mesure : bouton sur sa page publique et onglet dans son espace", sql(f"SELECT sur_mesure FROM boutiques WHERE id={bid}") == "1"
            and "Commander du sur-mesure" in txt(P, "boutique/tailleur-t35") and "vendeur/sur-mesure" in txt(VA, "vendeur"))

    sql("INSERT INTO produits (boutique_id,categorie_id,nom,slug,description,prix,stock,statut) SELECT b.id,(SELECT MIN(id) FROM categories),'Pagne T35','pagne-t35','x',5000,5,'publie' FROM boutiques b WHERE b.slug='tailleur-t35'")
    h = txt(P, "produit/pagne-t35")
    S.check("la fiche d'un produit de la boutique propose « Demander un devis » (sur-mesure)", "Demander un devis" in h and "sur-mesure/tailleur-t35" in h)
    S.check("le vendeur ne voit pas cet encart sur son propre produit", "Demander un devis" not in txt(VA, "produit/pagne-t35"))

    S.titre("DEMANDE DU CLIENT")
    S.check("un visiteur non connecté est envoyé à la connexion", "/connexion" in P.get("sur-mesure/tailleur-t35")[2].get("Location", ""))
    C.post("sur-mesure/tailleur-t35", {**demande, "description": "trop court"}, page_token="sur-mesure/tailleur-t35")
    VA.post("sur-mesure/tailleur-t35", demande, page_token="sur-mesure/tailleur-t35")
    S.check("description trop courte, ou vendeur qui commande chez lui : refusés", sql("SELECT COUNT(*) FROM demandes_mesure") == "0")
    s, _, hd = C.post("sur-mesure/tailleur-t35", demande, page_token="sur-mesure/tailleur-t35")
    did = dm("id")
    S.check("demande enregistrée avec une référence SM-…, statut « envoyée »", dm("statut") == "envoyee" and dm("reference").startswith("SM-") and hd["Location"].endswith("/sur-mesure"))
    S.check("le vendeur la voit dans « À faire » et dans son onglet, avec les mesures", "devis à envoyer" in txt(VA, "vendeur") and "poitrine 104" in txt(VA, "vendeur/sur-mesure"))

    S.titre("DEVIS DU VENDEUR")
    VB.post("vendeur/sur-mesure", {"id": did, "action": "devis", "prix": "25000", "delai": "7", "message": ""})
    S.check("un autre vendeur ne peut pas répondre", dm("statut") == "envoyee")
    for prix, delai in (("100", "7"), ("25000", "0"), ("abc", "7"), ("25000", "400")):
        VA.post("vendeur/sur-mesure", {"id": did, "action": "devis", "prix": prix, "delai": delai, "message": ""})
    S.check("prix ou délai invalides refusés", dm("statut") == "envoyee")
    VA.post("vendeur/sur-mesure", {"id": did, "action": "devis", "prix": "25000", "delai": "7", "message": "Bazin riche inclus"})
    S.check("devis envoyé : 25 000 FCFA, 7 jours", dm("CONCAT(statut,'|',prix,'|',delai_jours)") == "devis|25000|7")
    S.check("le client le voit dans « À faire » et dans « Sur mesure »", "devis sur mesure reçu" in txt(C, "compte") and "Bazin riche inclus" in txt(C, "sur-mesure"))

    S.titre("ACCEPTATION ET PAIEMENT")
    C2.post("sur-mesure", {"id": did, "action": "accepter", "prix": "25000"})
    S.check("un autre client ne peut pas accepter ce devis", dm("statut") == "devis")
    s, _, hd = C.post("sur-mesure", {"id": did, "action": "accepter", "prix": "25000"})       # le formulaire renvoie le prix affiché au client
    pid = dm("produit_id")
    S.check("le client accepte : un produit réservé est créé au prix du devis, et il part à la commande", dm("statut") == "acceptee" and hd["Location"].endswith("/commande")
            and sql(f"SELECT CONCAT(prix,'|',stock,'|',reserve_client_id IS NOT NULL) FROM produits WHERE id={pid}") == "25000|1|1")
    slug = sql(f"SELECT slug FROM produits WHERE id={pid}")
    S.check("ce produit n'apparaît ni dans le catalogue, ni sur la page de la boutique, ni dans les produits du vendeur", "Commande sur mesure" not in txt(P, "produits") and "Commande sur mesure" not in txt(P, "boutique/tailleur-t35") and "Commande sur mesure" not in txt(VA, "vendeur/produits"))
    S.check("un autre client ne peut ni le voir ni le mettre dans son panier", C2.get(f"produit/{slug}")[0] == 404 and P.get(f"payer/{slug}")[0] == 404)
    C2.req("panier/ajouter", {"csrf": C2.token("produits"), "produit_id": pid, "quantite": 1, "retour": "/jend/produits"})
    S.check("même en forçant l'ajout au panier", "Commande sur mesure" not in txt(C2, "panier"))
    s, _, hd = C.post("commande", {"nom": "Cliente T35", "telephone": "78 000 11 35", "zone_id": zone, "adresse": "Rue 35 Touba", "methode": "wave"})
    ref = hd["Location"].rsplit("/", 1)[-1]
    S.check("la commande est créée au prix du devis (25 000), commission de 1 % (250)", sql(f"SELECT sous_total FROM commandes WHERE reference='{ref}'") == "25000"
            and sql(f"SELECT cb.commission FROM commande_boutiques cb JOIN commandes c ON c.id=cb.commande_id WHERE c.reference='{ref}'") == "250")
    S.check("la demande passe à « Commandée » et ne peut pas être payée deux fois", "Commandée" in txt(C, "sur-mesure") and sql(f"SELECT stock FROM produits WHERE id={pid}") == "0")
    C.post("sur-mesure", {"id": did, "action": "accepter"})
    S.check("un second clic sur « payer » ne recrée rien", sql("SELECT COUNT(*) FROM produits WHERE nom LIKE 'Commande sur mesure SM-%'") == "1")

    S.titre("REFUS")
    sql("DELETE FROM limites WHERE cle LIKE 'mesure:%'")
    C.post("sur-mesure/tailleur-t35", demande, page_token="sur-mesure/tailleur-t35"); d2 = dm("id")
    VA.post("vendeur/sur-mesure", {"id": d2, "action": "refuser", "message": "Planning complet"})
    S.check("le vendeur peut décliner, avec un message visible par le client", dm("statut") == "refusee" and "Planning complet" in txt(C, "sur-mesure"))
    C.post("sur-mesure", {"id": d2, "action": "accepter"})
    S.check("une demande refusée ne peut pas être acceptée", dm("statut") == "refusee")
finally:
    ok = S.fin()
    sql("DELETE FROM produits WHERE nom LIKE 'Commande sur mesure SM-%' OR slug='pagne-t35'"); sql("DELETE FROM boutiques WHERE slug IN ('tailleur-t35','autre-t35')")
    sql("DELETE FROM zones_livraison WHERE nom='Zone T35'"); sql("DELETE FROM limites WHERE cle LIKE 'mesure:%'")
sys.exit(0 if ok else 1)
