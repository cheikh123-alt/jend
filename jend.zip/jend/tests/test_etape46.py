"""Étape 46 : fiche de confiance des boutiques, images pour le statut, « Spécial fêtes », « Envoyer à ma famille »."""
import sys, re
from lib import *

S = Suite("Étape 46 — confiance, statut, fêtes, cadeau", ["ad-t46@jend.local", "cl-t46@jend.local", "va-t46@jend.local", "vb-t46@jend.local"])
E = dict(zip(["ad", "cl", "va", "vb"], S.emails))
LOG = lambda: (JEND / "storage" / "emails.log").read_text() if (JEND / "storage" / "emails.log").exists() else ""
try:
    S.nettoyer()
    sql("DELETE FROM fetes WHERE nom LIKE 'Fête T46%'")
    sql("DELETE FROM produits WHERE slug IN ('produit-t46','produit-t46b')"); sql("DELETE FROM boutiques WHERE slug IN ('boutique-t46','boutique-t46b')"); sql("DELETE FROM zones_livraison WHERE nom='Zone T46'")
    sql("INSERT INTO zones_livraison (nom, region, frais, delai_jours) VALUES ('Zone T46', 'Touba', 1000, 1)")
    zone = int(sql("SELECT id FROM zones_livraison WHERE nom='Zone T46'"))
    pw = mot_de_passe()
    for k, nom, role in (("ad", "Admin T46", "admin"), ("cl", "Cliente T46", "client"), ("va", "Vendeur T46", "vendeur"), ("vb", "Autre Vendeur T46", "vendeur")):
        sql(f"INSERT INTO users (nom,email,mot_de_passe,role) VALUES ('{nom}','{E[k]}','{hash_mdp(pw)}','{role}')")
    for k, slug in (("va", "boutique-t46"), ("vb", "boutique-t46b")):
        sql(f"INSERT INTO boutiques (user_id,nom,slug,statut,commission_pct,livraison_par) SELECT id,'Boutique {slug}','{slug}','active',1,'vendeur' FROM users WHERE email='{E[k]}'")
    for slug, bs in (("produit-t46", "boutique-t46"), ("produit-t46b", "boutique-t46b")):
        sql(f"INSERT INTO produits (boutique_id,categorie_id,nom,slug,description,prix,stock,statut) SELECT b.id,(SELECT MIN(id) FROM categories),'Boubou {slug}','{slug}','x',10000,50,'publie' FROM boutiques b WHERE b.slug='{bs}'")
    prod, prodb = sql("SELECT id FROM produits WHERE slug='produit-t46'"), sql("SELECT id FROM produits WHERE slug='produit-t46b'")
    bid = sql("SELECT id FROM boutiques WHERE slug='boutique-t46'")
    AD, C, VA, VB = Client(), Client(), Client(), Client()
    for cl, k in ((AD, "ad"), (C, "cl"), (VA, "va"), (VB, "vb")):
        cl.post("connexion", {"email": E[k], "mot_de_passe": pw})
    txt = lambda cl, u: cl.get(u)[1].replace("&#039;", "'").replace(" ", " ").replace("&nbsp;", " ").replace("\xa0", " ")
    def commander(extra=None):
        C.req("panier/ajouter", {"csrf": C.token("produits"), "produit_id": prod, "quantite": 1, "retour": "/jend/produits"})
        _, _, hd = C.post("commande", {"nom": "Awa Ndiaye", "telephone": "77 123 45 46", "zone_id": zone, "adresse": "Rue 46 Touba", "methode": "wave", **(extra or {})})
        return hd["Location"].rsplit("/", 1)[-1]

    S.titre("FICHE DE CONFIANCE")
    h = txt(C, "boutique/boutique-t46")
    S.check("boutique sans vente : pas de faux chiffres, message « moins de 3 ventes livrées »", "Fiche de confiance" in h and "moins de 3 ventes livrées" in h)
    refs = [commander() for _ in range(4)]
    for r in refs:
        sql(f"UPDATE commande_boutiques cb JOIN commandes c ON c.id=cb.commande_id SET cb.statut='livree', cb.livre_le=c.created_at + INTERVAL 48 HOUR, c.statut_paiement='paye', c.statut='terminee' WHERE c.reference='{r}'")
    cb0 = sql(f"SELECT cb.id FROM commande_boutiques cb JOIN commandes c ON c.id=cb.commande_id WHERE c.reference='{refs[0]}'")
    cl_id = sql(f"SELECT id FROM users WHERE email='{E['cl']}'")
    sql(f"INSERT INTO litiges (reference, commande_boutique_id, client_id, motif, description, statut) VALUES ('LIT-T46AAAAA', {cb0}, {cl_id}, 'defectueux', 'Produit défectueux pour le test 46.', 'rembourse')")
    h = txt(C, "boutique/boutique-t46")
    S.check("4 ventes livrées, délai moyen 2 jours, 75 % sans problème (1 remboursement accordé sur 4)", "4</dd>" in h and "2 jours" in h and "75 %" in h)
    S.check("la fiche produit affiche la ligne de confiance", "ventes livrées" in txt(C, "produit/produit-t46") and "75 %" in txt(C, "produit/produit-t46"))
    S.check("le vendeur voit sa fiche dans son tableau de bord", "Ma fiche de confiance" in txt(VA, "vendeur") and "75 %" in txt(VA, "vendeur"))

    S.titre("IMAGES POUR LE STATUT")
    s, h, hd = VA.get("vendeur/statut")
    S.check("page vendeur : produits prêts à transformer en image, script dédié chargé", s == 200 and 'data-nom="Boubou produit-t46"' in h and "statut.js" in h and "produit/produit-t46" in h)
    S.check("un client n'y a pas accès", C.get("vendeur/statut")[0] == 302)
    S.check("politique de sécurité : seul blob: est ajouté pour l'aperçu (aucun script en ligne)", "img-src 'self' blob:" in hd.get("Content-Security-Policy", "") and "script-src 'self'" in hd.get("Content-Security-Policy", ""))
    js = (JEND / "assets" / "js" / "statut.js").read_text()
    S.check("l'image est dessinée dans le navigateur (canvas 1080 × 1920), rien n'est envoyé", "1080" in js and "1920" in js and "fetch(" not in js and "XMLHttpRequest" not in js)

    S.titre("SPÉCIAL FÊTES")
    S.check("pas de fête programmée : pas d'onglet « Spécial fêtes » pour le vendeur", "vendeur/fetes" not in VA.get("vendeur")[1])
    adm = lambda d: AD.post("admin/fetes", d, page_token="admin/fetes")
    adm({"nom": "Fête T46", "date_fete": "2026-02-30", "actif": "1"})
    adm({"nom": "Fête T46", "date_fete": "2099-01-10", "date_limite": "2099-02-01", "actif": "1"})
    S.check("dates invalides refusées (30 février, date limite après la fête)", sql("SELECT COUNT(*) FROM fetes WHERE nom LIKE 'Fête T46%'") == "0")
    C.post("admin/fetes", {"nom": "Fête T46 pirate", "date_fete": "2099-01-10"}, page_token="compte")
    S.check("un client ne peut pas programmer de fête", sql("SELECT COUNT(*) FROM fetes WHERE nom LIKE 'Fête T46%'") == "0")
    import datetime
    jour = (datetime.date.today() + datetime.timedelta(days=10)).isoformat(); lim = (datetime.date.today() + datetime.timedelta(days=6)).isoformat()
    adm({"nom": "Fête T46", "date_fete": jour, "date_limite": lim, "texte": "Préparez la fête <b>T46</b>", "actif": "1"})
    fid, fslug = sql("SELECT id FROM fetes WHERE nom='Fête T46'"), sql("SELECT slug FROM fetes WHERE nom='Fête T46'")
    S.check("fête programmée ; vitrine ouverte 3 semaines avant par défaut", fid != "" and sql(f"SELECT DATEDIFF(date_fete, vitrine_des) FROM fetes WHERE id={fid}") == "21")
    S.check("l'onglet « Spécial fêtes » apparaît pour le vendeur", "vendeur/fetes" in VA.get("vendeur")[1])
    VA.post("vendeur/fetes", {"fete_id": fid, "produits[]": [prod, prodb]}, page_token="vendeur/fetes")
    S.check("le vendeur ne rattache que SES produits (celui d'une autre boutique est ignoré)", sql(f"SELECT GROUP_CONCAT(produit_id) FROM produit_fetes WHERE fete_id={fid}") == prod)
    h = txt(C, f"fete/{fslug}")
    S.check("vitrine publique : compte à rebours, date limite, produit, texte échappé", "Dans 10 jours" in h and "commandez au plus tard le" in h and "Boubou produit-t46" in h and "&lt;b&gt;T46" in h and "Boubou produit-t46b" not in h)
    S.check("bandeau sur l'accueil et badge sur la fiche produit", f"fete/{fslug}" in txt(C, "") and "Spécial Fête T46" in txt(C, "produit/produit-t46"))
    VA.post("vendeur/fetes", {"fete_id": fid}, page_token="vendeur/fetes")
    S.check("tout décocher retire les produits de la vitrine", sql(f"SELECT COUNT(*) FROM produit_fetes WHERE fete_id={fid}") == "0")
    sql(f"UPDATE fetes SET date_fete = CURDATE() - INTERVAL 1 DAY, vitrine_des = CURDATE() - INTERVAL 20 DAY, date_limite = NULL WHERE id={fid}")
    S.check("fête passée : vitrine introuvable et bandeau retiré", C.get(f"fete/{fslug}")[0] == 404 and f"fete/{fslug}" not in txt(C, ""))

    S.titre("ENVOYER À MA FAMILLE")
    S.check("page de présentation et lien dans le pied de page", "Offrez directement le produit" in txt(C, "envoyer-au-pays") and "envoyer-au-pays" in txt(C, ""))
    S.check("la commande propose « C'est pour un proche ? »", (C.req("panier/ajouter", {"csrf": C.token("produits"), "produit_id": prod, "quantite": 1, "retour": "/jend/produits"}) or True) and "C'est pour un proche" in txt(C, "commande"))
    ref = commander({"cadeau": "1", "message_cadeau": "Pour maman <3, bonne fête !"})
    S.check("commande cadeau enregistrée avec le petit mot", sql(f"SELECT CONCAT(cadeau,'|',message_cadeau) FROM commandes WHERE reference='{ref}'") == "1|Pour maman <3, bonne fête !")
    h = txt(C, f"commande/{ref}")
    S.check("avant paiement : pas de bouton pour envoyer le code", "Cadeau pour Awa Ndiaye" in h and "wa.me/221771234546" not in h)
    sql(f"UPDATE commandes SET statut_paiement='paye', statut='confirmee' WHERE reference='{ref}'")
    code = sql(f"SELECT cb.code_livraison FROM commande_boutiques cb JOIN commandes c ON c.id=cb.commande_id WHERE c.reference='{ref}'")
    h = C.get(f"commande/{ref}")[1]
    S.check("après paiement : bouton WhatsApp vers le numéro du proche, avec le code", "https://wa.me/221771234546?text=" in h and any(code in t for t in re.findall(r'wa\.me/221771234546\?text=([^"]+)', h)))
    h = txt(VA, "vendeur/commandes")
    S.check("le vendeur est prévenu : ni prix ni facture, et le mot à joindre (échappé)", "ni prix ni facture" in h and "Pour maman &lt;3" in h)
    sql(f"UPDATE commande_boutiques cb JOIN commandes c ON c.id=cb.commande_id SET cb.statut='expediee' WHERE c.reference='{ref}'")
    cb = sql(f"SELECT cb.id FROM commande_boutiques cb JOIN commandes c ON c.id=cb.commande_id WHERE c.reference='{ref}'")
    avant = len(LOG())
    C.post(f"commande/{ref}", {"id": cb}, page_token=f"commande/{ref}")
    S.check("remise confirmée : e-mail « Votre cadeau a été remis à Awa Ndiaye »", "Votre cadeau a été remis à Awa Ndiaye" in LOG()[avant:])
finally:
    sql("DELETE FROM fetes WHERE nom LIKE 'Fête T46%'")
    ok = S.fin()
    sql("DELETE FROM produits WHERE slug IN ('produit-t46','produit-t46b')"); sql("DELETE FROM boutiques WHERE slug IN ('boutique-t46','boutique-t46b')"); sql("DELETE FROM zones_livraison WHERE nom='Zone T46'")
sys.exit(0 if ok else 1)
