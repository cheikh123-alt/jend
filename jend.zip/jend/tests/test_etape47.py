"""Étape 47 : promotion de fête (facultative, choisie par le vendeur, appliquée et retirée automatiquement, relue en base)."""
import sys, datetime
from lib import *

S = Suite("Étape 47 — promotion de fête", ["ad-t47@jend.local", "cl-t47@jend.local", "va-t47@jend.local"])
E = dict(zip(["ad", "cl", "va"], S.emails))
try:
    S.nettoyer()
    sql("DELETE FROM fetes WHERE nom LIKE 'Fête T47%'")
    sql("DELETE FROM produits WHERE slug='produit-t47'"); sql("DELETE FROM boutiques WHERE slug='boutique-t47'"); sql("DELETE FROM zones_livraison WHERE nom='Zone T47'")
    sql("INSERT INTO zones_livraison (nom, region, frais, delai_jours) VALUES ('Zone T47', 'Touba', 1000, 1)")
    zone = int(sql("SELECT id FROM zones_livraison WHERE nom='Zone T47'"))
    pw = mot_de_passe()
    for k, nom, role in (("ad", "Admin T47", "admin"), ("cl", "Cliente T47", "client"), ("va", "Vendeur T47", "vendeur")):
        sql(f"INSERT INTO users (nom,email,mot_de_passe,role) VALUES ('{nom}','{E[k]}','{hash_mdp(pw)}','{role}')")
    sql(f"INSERT INTO boutiques (user_id,nom,slug,statut,commission_pct,offres_actives) SELECT id,'Boutique T47','boutique-t47','active',1,1 FROM users WHERE email='{E['va']}'")
    sql("INSERT INTO produits (boutique_id,categorie_id,nom,slug,description,prix,stock,statut) SELECT b.id,(SELECT MIN(id) FROM categories),'Encens T47','produit-t47','x',10000,50,'publie' FROM boutiques b WHERE b.slug='boutique-t47'")
    prod = sql("SELECT id FROM produits WHERE slug='produit-t47'")
    AD, C, VA = Client(), Client(), Client()
    for cl, k in ((AD, "ad"), (C, "cl"), (VA, "va")):
        cl.post("connexion", {"email": E[k], "mot_de_passe": pw})
    txt = lambda cl, u: cl.get(u)[1].replace("&#039;", "'").replace(" ", " ").replace("&nbsp;", " ").replace("\xa0", " ")
    jour = (datetime.date.today() + datetime.timedelta(days=5)).isoformat()
    AD.post("admin/fetes", {"nom": "Fête T47", "date_fete": jour, "actif": "1"}, page_token="admin/fetes")
    fid = sql("SELECT id FROM fetes WHERE nom='Fête T47'")
    def commander():
        C.req("panier/ajouter", {"csrf": C.token("produits"), "produit_id": prod, "quantite": 2, "retour": "/jend/produits"})
        _, _, hd = C.post("commande", {"nom": "Cliente T47", "telephone": "77 123 45 47", "zone_id": zone, "adresse": "Rue 47 Touba", "methode": "wave"})
        return hd["Location"].rsplit("/", 1)[-1]

    S.titre("CHOIX DE LA PROMOTION PAR LE VENDEUR")
    VA.post("vendeur/fetes", {"fete_id": fid, "produits[]": [prod], f"remise[{prod}]": "33"}, page_token="vendeur/fetes")
    S.check("pourcentage hors liste (33 %) refusé", sql(f"SELECT COUNT(*) FROM produit_fetes WHERE fete_id={fid}") == "0")
    VA.post("vendeur/fetes", {"fete_id": fid, "produits[]": [prod], f"remise[{prod}]": "90"}, page_token="vendeur/fetes")
    S.check("promotion au-delà de 50 % refusée", sql(f"SELECT COUNT(*) FROM produit_fetes WHERE fete_id={fid}") == "0")
    VA.post("vendeur/fetes", {"fete_id": fid, "produits[]": [prod], f"remise[{prod}]": "10"}, page_token="vendeur/fetes")
    S.check("promotion de 10 % enregistrée", sql(f"SELECT remise_pct FROM produit_fetes WHERE fete_id={fid} AND produit_id={prod}") == "10")
    S.check("le vendeur voit le prix promo dans la liste (9 000 FCFA)", "Promo −10 % → 9 000 FCFA" in txt(VA, "vendeur/fetes"))

    S.titre("PRIX APPLIQUÉ PARTOUT (ET RELU EN BASE)")
    h = txt(C, "boutique/boutique-t47")
    S.check("carte : 9 000 FCFA, ancien prix barré 10 000, badge « Promo fête -10% »", "9 000 FCFA" in h and "<s>10 000 FCFA</s>" in h and "Promo fête -10%" in h)
    h = txt(C, "produit/produit-t47")
    S.check("fiche produit : prix promo et badge « Promo Fête T47 −10 % »", "9 000 FCFA" in h and "Promo Fête T47 −10 %" in h)
    S.check("pendant la promotion, pas de « Proposer mon prix »", "Proposer mon prix" not in h)
    C.post(f"produit/produit-t47", {"action": "offre", "prix": "8000", "quantite": "1"}, page_token="produit/produit-t47")
    S.check("une offre forcée est refusée par le serveur", sql(f"SELECT COUNT(*) FROM offres WHERE produit_id={prod}") == "0")
    C.req("panier/ajouter", {"csrf": C.token("produits"), "produit_id": prod, "quantite": 2, "retour": "/jend/produits"})
    h = txt(C, "panier")
    S.check("panier : 9 000 l'unité, « promo fête −10 % », 18 000 au total", "9 000 FCFA l'unité" in h and "promo fête −10 %" in h and "18 000 FCFA" in h)
    _, _, hd = C.post("commande", {"nom": "Cliente T47", "telephone": "77 123 45 47", "zone_id": zone, "adresse": "Rue 47 Touba", "methode": "wave"})
    ref = hd["Location"].rsplit("/", 1)[-1]
    S.check("commande : 2 × 9 000 enregistrés, commission de 1 % sur 18 000 (180)",
            sql(f"SELECT CONCAT(cl.prix_unitaire,'|',cb.sous_total,'|',cb.commission) FROM commande_lignes cl JOIN commande_boutiques cb ON cb.id=cl.commande_boutique_id JOIN commandes c ON c.id=cb.commande_id WHERE c.reference='{ref}'") == "9000|18000|180")

    S.titre("FIN AUTOMATIQUE")
    sql(f"UPDATE fetes SET date_fete = CURDATE() - INTERVAL 1 DAY, vitrine_des = CURDATE() - INTERVAL 22 DAY WHERE id={fid}")
    S.check("le lendemain de la fête, le prix normal revient (fiche produit)", "10 000 FCFA" in txt(C, "produit/produit-t47") and "Promo Fête T47" not in txt(C, "produit/produit-t47"))
    sql(f"UPDATE commandes SET statut='annulee' WHERE reference='{ref}'")
    ref2 = commander()
    S.check("et une nouvelle commande est au prix normal (10 000 l'unité)", sql(f"SELECT cl.prix_unitaire FROM commande_lignes cl JOIN commande_boutiques cb ON cb.id=cl.commande_boutique_id JOIN commandes c ON c.id=cb.commande_id WHERE c.reference='{ref2}'") == "10000")
    sql(f"UPDATE fetes SET actif = 0, date_fete = CURDATE() + INTERVAL 3 DAY, vitrine_des = CURDATE() - INTERVAL 2 DAY WHERE id={fid}")
    S.check("fête masquée par l'admin : promotion suspendue", "10 000 FCFA" in txt(C, "produit/produit-t47") and "9 000 FCFA" not in txt(C, "produit/produit-t47"))
finally:
    sql("DELETE FROM fetes WHERE nom LIKE 'Fête T47%'")
    ok = S.fin()
    sql("DELETE FROM produits WHERE slug='produit-t47'"); sql("DELETE FROM boutiques WHERE slug='boutique-t47'"); sql("DELETE FROM zones_livraison WHERE nom='Zone T47'")
sys.exit(0 if ok else 1)
