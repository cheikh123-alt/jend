"""Étape 63 : paiement UnitechPay (faux serveur local suivant leur documentation v1.2.0) — création Wave / Orange Max It,
page relais vers l'application, webhook signé HMAC (en-tête ou corps), contrôles, adresse de notification, moyens non couverts."""
import http.server, json, re, socket, sys, threading, urllib.parse, hmac, hashlib, time
from lib import *

S = Suite("Étape 63 — UnitechPay", ["ad-t63@jend.local", "ve-t63@jend.local", "cl-t63@jend.local"])
E = dict(zip(["ad", "ve", "cl"], S.emails))
CLE = "ut_cle_API_0123456789abcdef"
APPELS, NUM = [], [0]


class Faux(http.server.BaseHTTPRequestHandler):
    def log_message(self, *a): pass

    def _rep(self, obj, code=200):
        c = json.dumps(obj).encode(); self.send_response(code); self.send_header("Content-Type", "application/json"); self.send_header("Content-Length", str(len(c))); self.end_headers(); self.wfile.write(c)

    def do_POST(self):
        action = urllib.parse.parse_qs(urllib.parse.urlparse(self.path).query).get("action", [""])[0]
        corps = json.loads(self.rfile.read(int(self.headers.get("Content-Length") or 0)) or b"{}")
        APPELS.append((action, dict(self.headers), corps))
        if self.headers.get("Authorization") != "Bearer " + CLE:
            return self._rep({"success": False, "message": "Clé API invalide", "code": 401}, 401)
        if action == "configure_webhook":
            return self._rep({"success": True, "message": "Webhook configuré"})
        if action in ("create_wave_payment", "create_orange_maxit", "create_orange_om"):
            NUM[0] += 1; ref = f"UTP-{NUM[0]:05d}-XYZ"
            url = f"https://pay.wave.com/c/{ref}" if action == "create_wave_payment" else f"maxit://pay?ref={ref}"
            return self._rep({"success": True, "data": {"transaction_id": NUM[0], "reference": ref, "payment_url": url, "amount": corps.get("amount"), "status": "pending"}})
        self._rep({"success": False, "message": "Action inconnue", "code": 404}, 404)


s = socket.socket(); s.bind(("127.0.0.1", 0)); PORT = s.getsockname()[1]; s.close()
serveur = http.server.ThreadingHTTPServer(("127.0.0.1", PORT), Faux)
threading.Thread(target=serveur.serve_forever, daemon=True).start()


def webhook_ut(reference, montant, event="payment_completed", status="completed", cle=CLE, mode="corps"):
    d = {"event": event, "transaction_id": 1, "reference": reference, "amount": montant, "status": status, "method": "wave",
         "commission": int(montant * 0.015), "net_amount": montant - int(montant * 0.015), "timestamp": int(time.time()), "signed_at": int(time.time())}
    if mode == "corps":
        d["signature"] = hmac.new(cle.encode(), f"{event}|{reference}|{montant}|{status}|{d['signed_at']}".encode(), hashlib.sha256).hexdigest()
        return Client().req("paiement/webhook", raw=json.dumps(d).encode(), headers={"Content-Type": "application/json"})
    brut = json.dumps(d).encode()
    sig = hmac.new(cle.encode(), brut, hashlib.sha256).hexdigest()
    return Client().req("paiement/webhook", raw=brut, headers={"Content-Type": "application/json", "X-UnitechPay-Signature": sig})


try:
    S.nettoyer()
    sql("DELETE FROM zones_livraison WHERE nom='Zone T63'")
    sql("INSERT INTO zones_livraison (nom, region, frais, delai_jours) VALUES ('Zone T63', 'Fatick', 1000, 1)")
    zone = sql("SELECT id FROM zones_livraison WHERE nom='Zone T63'")
    pw = mot_de_passe()
    for k, nom, role in (("ad", "Admin T63", "admin"), ("ve", "Vendeur T63", "vendeur")):
        sql(f"INSERT INTO users (nom,email,mot_de_passe,role,email_verifie) VALUES ('{nom}','{E[k]}','{hash_mdp(pw)}','{role}',1)")
    sql(f"INSERT INTO boutiques (user_id,nom,slug,statut,commission_pct) SELECT id,'Boutique T63','boutique-t63','active',1 FROM users WHERE email='{E['ve']}'")
    sql("INSERT INTO produits (boutique_id,categorie_id,nom,slug,prix,stock,statut) SELECT b.id,(SELECT MIN(id) FROM categories),'Bazin T63','bazin-t63',10000,50,'publie' FROM boutiques b WHERE b.slug='boutique-t63'")
    pid = sql("SELECT id FROM produits WHERE slug='bazin-t63'")
    AD, C = Client(), Client()
    AD.post("connexion", {"email": E["ad"], "mot_de_passe": pw})
    C.post("inscription", {"nom": "Client T63", "email": E["cl"], "telephone": "", "mot_de_passe": "Wax-Fatick-2026!", "mot_de_passe2": "Wax-Fatick-2026!", "accepte": "1"})
    S.modifier_env(PAIEMENT_FOURNISSEUR="unitech", UNITECH_API_KEY=CLE, UNITECH_API_BASE=f"http://127.0.0.1:{PORT}/api.php", APP_URL=BASE.rstrip("/"))
    etat = lambda ref: sql(f"SELECT CONCAT(statut,'|',statut_paiement) FROM commandes WHERE reference='{ref}'")

    def commander(methode="wave", cadeau=False):
        C.req("panier/ajouter", {"csrf": C.token("produits"), "produit_id": pid, "quantite": 1, "retour": "/jend/produits"})
        champs = {"nom": "Client T63", "telephone": "77 123 45 63", "zone_id": zone, "adresse": "Rue 63 Fatick", "methode": methode, "acompte_methode": "wave"}
        if cadeau:
            champs.update(cadeau="1", message_cadeau="")
        _, _, hd = C.post("commande", champs)
        return hd.get("Location", "").rsplit("/", 1)[-1]

    def payer(ref):
        APPELS.clear()
        _, _, hd = C.post("paiement/" + ref, {}, page_token="commande/" + ref)
        return hd.get("Location", "")

    S.titre("ADMINISTRATION")
    h = AD.get("admin/parametres")[1]
    S.check("UnitechPay listé, clé présente, mode RÉEL (pas de bac à sable chez eux)", "UnitechPay" in h and "mode <b>RÉEL</b>" in h)
    APPELS.clear()
    AD.post("admin/parametres", {"action": "unitech_webhook"}, page_token="admin/parametres")
    a = APPELS[0] if APPELS else ("", {}, {})
    S.check("bouton : l'adresse de notification du site est enregistrée chez UnitechPay (Bearer, HTTPS du site)",
            a[0] == "configure_webhook" and a[1].get("Authorization") == "Bearer " + CLE and a[2].get("webhook_url", "").endswith("/paiement/webhook") and "payment_completed" in a[2].get("events", []))

    S.titre("PAIEMENT WAVE")
    ref = commander(); total = int(sql(f"SELECT total FROM commandes WHERE reference='{ref}'"))
    loc = payer(ref)
    a = APPELS[0] if APPELS else ("", {}, {})
    S.check("demande « create_wave_payment » : montant exact, numéro du client sur 9 chiffres, retour vers la commande",
            a[0] == "create_wave_payment" and a[2].get("amount") == total and a[2].get("customer_number") == "771234563" and a[2].get("callback_success", "").endswith("/paiement/retour/" + ref), a[2])
    S.check("la clé ne part qu'en en-tête, jamais dans la page", CLE not in C.get("commande/" + ref)[1])
    S.check("le client passe par la page relais du site (lien Wave hors politique de sécurité)", loc.endswith("/paiement/aller/" + ref), loc)
    h = C.get("paiement/aller/" + ref)[1].replace("&amp;", "&")
    reference = re.search(r"UTP-\d{5}-XYZ", h).group(0) if re.search(r"UTP-\d{5}-XYZ", h) else ""
    S.check("page relais : bouton vers le lien Wave reçu de UnitechPay, script d'ouverture automatique", 'href="https://pay.wave.com/c/' + reference + '"' in h and "paiement-aller.js" in h)
    S.check("page relais réservée au client de la commande", Client().get("paiement/aller/" + ref)[0] in (302, 303) and AD.get("paiement/aller/" + ref)[0] in (302, 303))
    S.check("paiement enregistré « unitech » avec la référence UnitechPay", sql(f"SELECT fournisseur FROM paiements WHERE reference_externe='{reference}'") == "unitech")

    S.titre("WEBHOOK SIGNÉ")
    st, _, _ = webhook_ut(reference, total, cle="mauvaise-cle")
    S.check("signature fausse : refusé (401)", st == 401 and etat(ref).endswith("|en_attente"))
    st, _, _ = Client().req("paiement/webhook", raw=json.dumps({"event": "payment_completed", "reference": reference, "amount": total, "status": "completed"}).encode(), headers={"Content-Type": "application/json"})
    S.check("sans signature : refusé", st == 401 and etat(ref).endswith("|en_attente"))
    st, _, _ = webhook_ut(reference, total - 500)
    S.check("montant différent (signé) : refusé", st == 400 and etat(ref).endswith("|en_attente"))
    st, _, _ = webhook_ut("UTP-99999-XYZ", total)
    S.check("référence inconnue : refusée", st == 404)
    st, corps, _ = webhook_ut(reference, total)
    S.check("signature dans le corps (event|reference|amount|status|signed_at) : commande payée", st == 200 and etat(ref) == "confirmee|paye", corps)
    st, corps, _ = webhook_ut(reference, total)
    S.check("notification rejouée : ignorée, pas de double paiement", st == 200 and json.loads(corps)["message"] == "Déjà traité")
    ref2 = commander(); total2 = int(sql(f"SELECT total FROM commandes WHERE reference='{ref2}'")); payer(ref2)
    reference2 = sql(f"SELECT p.reference_externe FROM paiements p JOIN commandes c ON c.id=p.commande_id WHERE c.reference='{ref2}' AND p.statut='initie'")
    st, _, _ = webhook_ut(reference2, total2, mode="entete")
    S.check("signature en en-tête X-UnitechPay-Signature (corps brut) : acceptée aussi", st == 200 and etat(ref2) == "confirmee|paye")
    ref3 = commander(); payer(ref3)
    reference3 = sql(f"SELECT p.reference_externe FROM paiements p JOIN commandes c ON c.id=p.commande_id WHERE c.reference='{ref3}' AND p.statut='initie'")
    webhook_ut(reference3, int(sql(f"SELECT total FROM commandes WHERE reference='{ref3}'")), event="payment_expired", status="expired")
    S.check("paiement expiré : commande « échoué », le client peut réessayer", etat(ref3).endswith("|echoue"))
    st, corps, _ = webhook_ut("UTP-00001-XYZ", 1000, event="withdrawal_processed", status="processed")
    S.check("événement de retrait (signé) : accepté et ignoré", st == 200 and json.loads(corps)["message"] == "Ignoré")

    S.titre("ORANGE MONEY, MOYENS NON COUVERTS, CADEAU")
    ref4 = commander("orange_money"); loc4 = payer(ref4)
    S.check("Orange Money : « create_orange_maxit », puis page relais vers l'application Max It", APPELS and APPELS[0][0] == "create_orange_maxit" and loc4.endswith("/paiement/aller/" + ref4) and 'href="maxit://pay?ref=' in C.get("paiement/aller/" + ref4)[1].replace("&amp;", "&"))
    sql(f"UPDATE commandes SET statut='annulee' WHERE reference IN ('{ref3}','{ref4}')")
    ref5 = commander("carte"); loc5 = payer(ref5)
    S.check("carte bancaire : non proposée par UnitechPay → paiement impossible, raison claire pour l'admin",
            "/paiement/aller/" not in loc5 and "non proposé par UnitechPay" in AD.get("admin/parametres")[1])
    sql(f"UPDATE commandes SET statut='annulee' WHERE reference='{ref5}'")
    ref6 = commander(cadeau=True); payer(ref6)
    S.check("cadeau sans téléphone sur le compte : on n'envoie PAS le numéro du proche, raison claire", not APPELS and "numéro Wave / Orange Money du client inconnu" in AD.get("admin/parametres")[1])
    sql(f"UPDATE users SET telephone='+221781112233' WHERE email='{E['cl']}'")
    payer(ref6)
    S.check("avec le téléphone du compte : c'est lui qui paie (781112233)", APPELS and APPELS[0][2].get("customer_number") == "781112233")
    S.check("conditions vendeurs : UnitechPay nommé, lien vers leur site", "UnitechPay" in Client().get("paiements-vendeurs")[1] and "pay.unitech.sn" in Client().get("paiements-vendeurs")[1])
finally:
    serveur.shutdown()
    (JEND / "storage" / "paiement-derniere-erreur.txt").unlink(missing_ok=True)
    sql("DELETE FROM produits WHERE slug='bazin-t63'")
    S.restaurer_env()
    S.nettoyer()
    sql("DELETE FROM zones_livraison WHERE nom='Zone T63'")
    ok = S.fin()
sys.exit(0 if ok else 1)
