"""Étape 32 : le taux de commission est présenté comme une offre de lancement (réglable par l'administrateur)."""
import sys
from lib import *

S = Suite("Étape 32 — offre de lancement", ["ad-t32@jend.local", "va-t32@jend.local"])
E = dict(zip(["ad", "va"], S.emails))
try:
    S.nettoyer()
    sql("DELETE FROM boutiques WHERE slug='boutique-t32'")
    sql("DELETE FROM parametres WHERE cle IN ('commission_defaut','commission_offre_lancement')")
    sql("INSERT INTO parametres (cle, valeur) VALUES ('commission_defaut', '1')")
    pw = mot_de_passe()
    for k, nom, role in (("ad", "Admin T32", "admin"), ("va", "Vendeur T32", "vendeur")):
        sql(f"INSERT INTO users (nom,email,mot_de_passe,role) VALUES ('{nom}','{E[k]}','{hash_mdp(pw)}','{role}')")
    sql(f"INSERT INTO boutiques (user_id,nom,slug,statut,commission_pct) SELECT id,'Boutique T32','boutique-t32','active',1 FROM users WHERE email='{E['va']}'")
    AD, VA, P = Client(), Client(), Client()
    AD.post("connexion", {"email": E["ad"], "mot_de_passe": pw}); VA.post("connexion", {"email": E["va"], "mot_de_passe": pw})
    txt = lambda cl, u: cl.get(u)[1].replace("&#039;", "'")

    S.check("accueil : « seulement 1 % · offre de lancement »", "seulement 1 % · offre de lancement" in txt(P, ""))
    S.check("page « Ouvrir une boutique » : offre de lancement à 1 %", "Offre de lancement : seulement 1 % de commission" in txt(P, "vendre"))
    h = txt(P, "frais-commissions")
    S.check("« Frais et commissions » : offre de lancement, taux qui pourra évoluer avec 30 jours de préavis", "Offre de lancement : 1 % de commission" in h and "30 jours avant" in h)
    S.check("espace vendeur : le bandeau rappelle l'offre de lancement", "Offre de lancement" in txt(VA, "vendeur") and "1 %" in txt(VA, "vendeur"))
    AD.post("admin/parametres", {"action": "commission", "commission": "1"})          # case « offre de lancement » décochée
    S.check("l'admin retire la mention : le taux reste 1 %, sans « offre de lancement »", sql("SELECT valeur FROM parametres WHERE cle='commission_offre_lancement'") == "0"
            and "offre de lancement" not in txt(P, "").lower() and "1 % sur les ventes livrées" in txt(P, ""))
    AD.post("admin/parametres", {"action": "commission", "commission": "1", "lancement": "1"})
    S.check("l'admin la remet", "offre de lancement" in txt(P, ""))
finally:
    sql("DELETE FROM parametres WHERE cle IN ('commission_defaut','commission_offre_lancement')")
    ok = S.fin()
    sql("DELETE FROM boutiques WHERE slug='boutique-t32'")
    sql("DELETE FROM journal_admin WHERE action='commission_defaut_modifiee'")
sys.exit(0 if ok else 1)
