"""Étape 18 : acompte pour les commandes payées à la livraison (calcul, paiement, annulation, client absent, comptabilité)."""
import json, re, sys
from lib import *

S = Suite("Étape 18 — acompte", ["ad-t18@jend.local", "cl-t18@jend.local", "va-t18@jend.local", "vb-t18@jend.local", "lv-t18@jend.local"])
E = dict(zip(["ad", "cl", "va", "vb", "lv"], S.emails))
INC = JEND / "includes"
LOG = lambda: (JEND / "storage" / "emails.log").read_text()
col = lambda cb, c: sql(f"SELECT {c} FROM commande_boutiques WHERE id={cb}")
cmd = lambda ref, c: sql(f"SELECT {c} FROM commandes WHERE reference='{ref}'")
PRIX, FRAIS = 10000, 1001

def calcul(total, pct=None, minimum=None):
    import tempfile, os
    f = tempfile.NamedTemporaryFile("w", suffix=".env", delete=False)
    f.write((f"ACOMPTE_POURCENT={pct}\n" if pct is not None else "") + (f"ACOMPTE_MINIMUM={minimum}\n" if minimum is not None else "")); f.close()
    out, err = php(f'require "{INC}/env.php"; require "{INC}/helpers.php"; require "{INC}/paiement.php"; echo acompte_calculer({total});', {"JEND_ENV_FILE": f.name})
    os.unlink(f.name)
    return out
def gains(slug):
    bid = sql(f"SELECT id FROM boutiques WHERE slug='{slug}'")
    out, err = php(f'require "{INC}/env.php"; require "{INC}/db.php"; require "{INC}/parametres.php"; require "{INC}/vendeur.php"; echo json_encode(vendeur_gains({bid}));')
    return json.loads(out)
try:
    S.titre("CALCUL DE L'ACOMPTE")
    S.check("20 % par défaut, arrondi à la centaine supérieure : 11 001 → 2 300", calcul(11001) == "2300")
    S.check("minimum de 1 000 FCFA : 3 000 → 1 000 (et non 600)", calcul(3000) == "1000")
    S.check("jamais plus que le total : 500 → 500", calcul(500) == "500")
    S.check("ACOMPTE_POURCENT=0 : aucun acompte", calcul(11001, pct=0) == "0")
    S.check("pourcentage et minimum réglables (30 %, minimum 2 000) : 11 001 → 3 400", calcul(11001, pct=30, minimum=2000) == "3400")
    S.check("valeur absurde (150 %) bornée à 100 % ; texte invalide → 20 % par défaut", calcul(11001, pct=150) == "11001" and calcul(11001, pct="abc") == "2300")

    S.nettoyer()
    sql("REPLACE INTO parametres (cle, valeur) VALUES ('livreurs_jend', '1')")      # fonction activée par l'admin pour ce test
    sql("DELETE FROM produits WHERE slug IN ('produit-a-t18','produit-b-t18')")
    sql("DELETE FROM boutiques WHERE slug IN ('boutique-a-t18','boutique-b-t18')")
    sql("DELETE FROM zones_livraison WHERE nom='Zone T18'")
    sql(f"INSERT INTO zones_livraison (nom, region, frais, delai_jours) VALUES ('Zone T18', 'Touba', {FRAIS}, 1)")
    zone = int(sql("SELECT id FROM zones_livraison WHERE nom='Zone T18'"))
    pw = mot_de_passe()
    for k, nom, role in (("ad", "Admin T18", "admin"), ("va", "Vendeur A", "vendeur"), ("vb", "Vendeur B", "vendeur")):
        sql(f"INSERT INTO users (nom,email,mot_de_passe,role) VALUES ('{nom}','{E[k]}','{hash_mdp(pw)}','{role}')")
    sql(f"INSERT INTO users (nom,email,telephone,mot_de_passe,role) VALUES ('Livreur T18','{E['lv']}','+221775556677','{hash_mdp(pw)}','livreur')")
    sql(f"INSERT INTO livreurs (user_id) SELECT id FROM users WHERE email='{E['lv']}'")
    for k, slug, mode in (("va", "boutique-a-t18", "vendeur"), ("vb", "boutique-b-t18", "jend")):
        sql(f"INSERT INTO boutiques (user_id,nom,slug,statut,commission_pct,livraison_par) SELECT id,'{slug}','{slug}','active',10,'{mode}' FROM users WHERE email='{E[k]}'")
        sql(f"INSERT INTO produits (boutique_id,categorie_id,nom,slug,description,prix,stock,statut) SELECT b.id,(SELECT MIN(id) FROM categories),'Produit {k}','produit-{k[1]}-t18','x',{PRIX},80,'publie' FROM boutiques b WHERE b.slug='{slug}'")
    pa, pb = (int(sql(f"SELECT id FROM produits WHERE slug='produit-{x}-t18'")) for x in "ab")
    AD, C, VA, VB, L = Client(), Client(), Client(), Client(), Client()
    C.post("inscription", {"nom": "Cliente T18", "email": E["cl"], "mot_de_passe": pw, "mot_de_passe2": pw})
    for cl, k in ((AD, "ad"), (VA, "va"), (VB, "vb")):
        cl.post("connexion", {"email": E[k], "mot_de_passe": pw})
    L.post("livreur/connexion", {"email": E["lv"], "mot_de_passe": pw})

    cbs = lambda ref: [int(x) for x in sql(f"SELECT cb.id FROM commande_boutiques cb JOIN commandes c ON c.id=cb.commande_id WHERE c.reference='{ref}' ORDER BY cb.id").split()]

    S.titre("COMMANDE À PAYER À LA LIVRAISON : L'ACOMPTE")
    tok = C.token("produits"); C.req("panier/ajouter", {"csrf": tok, "produit_id": pa, "quantite": 1, "retour": "/jend/produits"})
    h = C.get("commande")[1]
    S.check("la page de commande explique l'acompte (pourcentage, minimum, reste en espèces) et demande le moyen de paiement", "Acompte de 20" in h and "reste en espèces" in h and 'name="acompte_methode"' in h and "n'est pas remboursé" in h.replace("&#039;", "'"))
    s, h, hd = C.post("commande", {"nom": "Client T18", "telephone": "78 000 11 22", "zone_id": zone, "adresse": "Rue test 18", "methode": "livraison", "acompte_methode": ""})
    S.check("sans moyen de paiement pour l'acompte : refusé", s == 200 and "acompte" in h and sql(f"SELECT COUNT(*) FROM commandes c JOIN users u ON u.id=c.client_id WHERE u.email='{E['cl']}'") == "0")
    s, _, hd = C.post("commande", {"nom": "Client T18", "telephone": "78 000 11 22", "zone_id": zone, "adresse": "Rue test 18", "methode": "livraison", "acompte_methode": "wave"})
    ref = hd["Location"].rsplit("/", 1)[-1]; (cb,) = cbs(ref)
    S.check("commande créée « en attente » : acompte de 2 300 (20 % de 11 001, arrondi), moyen Wave", cmd(ref, "acompte") == "2300" and cmd(ref, "acompte_methode") == "wave" and cmd(ref, "statut") == "en_attente" and cmd(ref, "statut_paiement") == "en_attente")
    S.check("part d'acompte de la livraison = 2 300 ; paiement enregistré pour le seul acompte", col(cb, "acompte_part") == "2300" and sql(f"SELECT CONCAT(p.montant,'|',p.methode) FROM paiements p JOIN commandes c ON c.id=p.commande_id WHERE c.reference='{ref}'") == "2300|wave")
    h = C.get(f"commande/{ref}")[1]
    S.check("la page de commande propose « Payer l'acompte (2 300 FCFA) » et annonce le reste à payer en espèces (8 701)", ("Payer l'acompte" in h or "Payer l&#039;acompte" in h) and "2 300" in h.replace(" ", " ") and "8 701" in h.replace(" ", " "))
    VA.post("vendeur/commandes", {"id": cb, "numero_suivi": ""})
    S.check("tant que l'acompte n'est pas payé, le vendeur ne peut pas préparer la commande", col(cb, "statut") == "a_preparer" and "paiement de l'acompte" in VA.get("vendeur/commandes")[1].replace("&#039;", "'"))

    S.titre("PAIEMENT DE L'ACOMPTE (notification signée du fournisseur)")
    _, _, hd = C.post(f"paiement/{ref}", {}, page_token=f"commande/{ref}")
    sim = hd["Location"].rsplit("/", 1)[-1]
    s = webhook(sim, "reussi", 11001)[0]
    S.check("notification avec le montant TOTAL au lieu de l'acompte : refusée, rien ne change", s == 400 and cmd(ref, "statut_paiement") == "en_attente")
    s = webhook(sim, "reussi", 2300)[0]
    S.check("notification signée avec le bon montant : statut « acompte payé », commande confirmée", s == 200 and cmd(ref, "statut_paiement") == "acompte" and cmd(ref, "statut") == "confirmee")
    S.check("une même notification rejouée est ignorée", webhook(sim, "reussi", 2300)[0] == 200 and cmd(ref, "statut_paiement") == "acompte")
    h = C.get(f"commande/{ref}")[1]
    S.check("le client lit « Acompte reçu » et le reste à payer en espèces", "Acompte de" in h and "Reste à payer en espèces" in h and "Payer l'acompte" not in h and "Payer l&#039;acompte" not in h)
    S.check("le vendeur peut maintenant préparer la commande", "Marquer comme expédiée" in VA.get("vendeur/commandes")[1])
    S.check("le client ne peut plus payer deux fois", C.post(f"paiement/{ref}", {}, page_token=f"commande/{ref}")[0] == 302 and "Payer l'acompte" not in C.get(f"commande/{ref}")[1] and "Payer l&#039;acompte" not in C.get(f"commande/{ref}")[1])

    S.titre("LIVRAISON PAR LE VENDEUR : ESPÈCES = RESTE, ACOMPTE POUR JËND")
    h = VA.get("vendeur/commandes")[1]
    S.check("le vendeur lit combien il encaisse en espèces (8 701) et l'acompte déjà payé (2 300)", "8 701" in h.replace(" ", " ") and "acompte déjà payé" in h)
    VA.post("vendeur/commandes", {"id": cb, "numero_suivi": ""})
    VA.post("vendeur/commandes", {"id": cb, "code_livraison": col(cb, "code_livraison")})
    g = gains("boutique-a-t18")
    S.check("livré : le vendeur est crédité de l'acompte (2 300), doit 1 000 de commission, a encaissé 8 701", col(cb, "statut") == "livree" and g["credit"] == 2300 and g["a_reverser"] == 1000 and g["especes"] == 8701 and g["solde"] == 1300, str(g))
    S.check("commande terminée et entièrement payée", cmd(ref, "statut_paiement") == "paye" and cmd(ref, "statut") == "terminee")

    S.titre("LIVRAISON PAR UN LIVREUR JËND : LE LIVREUR ENCAISSE LE RESTE")
    sql("UPDATE boutiques SET livraison_par='jend' WHERE slug='boutique-b-t18'")
    tok = C.token("produits"); C.req("panier/ajouter", {"csrf": tok, "produit_id": pb, "quantite": 1, "retour": "/jend/produits"})
    s, _, hd = C.post("commande", {"nom": "Client T18", "telephone": "78 000 11 22", "zone_id": zone, "adresse": "Rue test 18", "methode": "livraison", "acompte_methode": "orange_money"})
    ref2 = hd["Location"].rsplit("/", 1)[-1]; (cb2,) = cbs(ref2)
    sql(f"UPDATE commandes SET statut_paiement='acompte', statut='confirmee' WHERE reference='{ref2}'")
    S.check("acompte réglé avec Orange Money (moyen choisi par le client)", cmd(ref2, "acompte_methode") == "orange_money")
    AD.post("admin/courses", {"id": cb2, "livreur_id": sql(f"SELECT id FROM users WHERE email='{E['lv']}'")})
    h = L.get(f"livreur/course/{cb2}")[1]
    S.check("le livreur voit à encaisser le RESTE seulement (8 701), pas le total", "8 701" in h.replace(" ", " ") and "11 001" not in h.replace(" ", " "))
    for act in ("recuperer", "en_route"):
        L.post(f"livreur/course/{cb2}", {"action": act})
    L.post(f"livreur/course/{cb2}", {"action": "livrer", "code": col(cb2, "code_livraison")})
    g = gains("boutique-b-t18")
    S.check("livreur Jënd : le vendeur est crédité du prix − commission (9 000), sans frais de livraison", col(cb2, "statut") == "livree" and g["solde"] == 9000 and g["frais_livraison"] == 0, str(g))

    S.titre("ANNULATION AVANT PRÉPARATION : L'ACOMPTE EST REMBOURSÉ")
    tok = C.token("produits"); C.req("panier/ajouter", {"csrf": tok, "produit_id": pa, "quantite": 1, "retour": "/jend/produits"})
    s, _, hd = C.post("commande", {"nom": "Client T18", "telephone": "78 000 11 22", "zone_id": zone, "adresse": "Rue test 18", "methode": "livraison", "acompte_methode": "wave"})
    ref3 = hd["Location"].rsplit("/", 1)[-1]
    sql(f"UPDATE commandes SET statut_paiement='acompte', statut='confirmee' WHERE reference='{ref3}'")
    stock0 = sql(f"SELECT stock FROM produits WHERE id={pa}")
    h = C.get(f"commande/{ref3}")[1]
    S.check("le client peut annuler tant que la commande n'est pas préparée", "Annuler cette commande" in h)
    C.post("commande/annuler", {"reference": ref3}, page_token=f"commande/{ref3}")
    S.check("commande annulée, produits remis en stock", cmd(ref3, "statut") == "annulee" and int(sql(f"SELECT stock FROM produits WHERE id={pa}")) == int(stock0) + 1)
    S.check("elle apparaît dans « À rembourser » (acompte payé)", ref3 in AD.get("admin/commandes?vue=rembourser")[1])
    AD.post("admin/commandes", {"id": sql(f"SELECT id FROM commandes WHERE reference='{ref3}'"), "action": "rembourser"}, page_token="admin/commandes?vue=rembourser")
    S.check("l'admin marque l'acompte remboursé", cmd(ref3, "statut_paiement") == "rembourse")

    S.titre("CLIENT ABSENT OU REFUS : L'ACOMPTE EST CONSERVÉ")
    tok = C.token("produits"); C.req("panier/ajouter", {"csrf": tok, "produit_id": pa, "quantite": 1, "retour": "/jend/produits"})
    s, _, hd = C.post("commande", {"nom": "Client T18", "telephone": "78 000 11 22", "zone_id": zone, "adresse": "Rue test 18", "methode": "livraison", "acompte_methode": "wave"})
    ref4 = hd["Location"].rsplit("/", 1)[-1]; (cb4,) = cbs(ref4)
    sql(f"UPDATE commandes SET statut_paiement='acompte', statut='confirmee' WHERE reference='{ref4}'")
    VA.post("vendeur/commandes", {"id": cb4, "numero_suivi": ""})
    stock1 = int(sql(f"SELECT stock FROM produits WHERE id={pa}"))
    id4 = sql(f"SELECT id FROM commandes WHERE reference='{ref4}'")
    S.check("l'admin voit le bouton « Client absent / refus »", "Client absent / refus" in AD.get("admin/commandes")[1])
    S.check("un client ou un vendeur ne peut pas déclencher cette action", (C.post("admin/commandes", {"id": id4, "cb": cb4, "action": "refus"}, page_token="compte")[0] in (302, 404)) and col(cb4, "statut") == "expediee")
    log0 = LOG()
    AD.post("admin/commandes", {"id": id4, "cb": cb4, "action": "refus"}, page_token="admin/commandes")
    S.check("livraison « retournée », acompte acquis, produits remis en stock, commande terminée", col(cb4, "statut") == "retournee" and col(cb4, "acompte_acquis") == "1" and int(sql(f"SELECT stock FROM produits WHERE id={pa}")) == stock1 + 1 and cmd(ref4, "statut") == "terminee")
    S.check("le client est prévenu par e-mail que l'acompte est conservé", "Livraison non aboutie" in LOG()[len(log0):])
    g = gains("boutique-a-t18")
    S.check("vendeur qui devait livrer : l'acompte de 2 300 lui est acquis (indemnisation)", g["acompte_acquis"] == 2300 and g["solde"] == 1300 + 2300, str(g))
    AD.post("admin/commandes", {"id": id4, "cb": cb4, "action": "refus"}, page_token="admin/commandes")
    S.check("l'action ne peut pas être répétée", int(sql(f"SELECT COUNT(*) FROM journal_admin WHERE action='acompte_conserve' AND detail LIKE '{ref4}%'")) == 1)
    S.check("l'action est tracée dans le journal", int(sql("SELECT COUNT(*) FROM journal_admin WHERE action='acompte_conserve'")) >= 1)

    S.titre("ACOMPTE DÉSACTIVÉ ET COMMANDES EN LIGNE")
    tok = C.token("produits"); C.req("panier/ajouter", {"csrf": tok, "produit_id": pa, "quantite": 1, "retour": "/jend/produits"})
    s, _, hd = C.post("commande", {"nom": "Client T18", "telephone": "78 000 11 22", "zone_id": zone, "adresse": "Rue test 18", "methode": "wave"})
    ref5 = hd["Location"].rsplit("/", 1)[-1]
    S.check("un paiement en ligne n'a pas d'acompte : le total est payé d'un coup", cmd(ref5, "acompte") == "0" and sql(f"SELECT p.montant FROM paiements p JOIN commandes c ON c.id=p.commande_id WHERE c.reference='{ref5}'") == "11001")
finally:
    sql("DELETE FROM parametres WHERE cle = 'livreurs_jend'")
    sql("DELETE FROM produits WHERE slug IN ('produit-a-t18','produit-b-t18')")
    ok = S.fin()
    sql("DELETE FROM boutiques WHERE slug IN ('boutique-a-t18','boutique-b-t18')")
    sql("DELETE FROM zones_livraison WHERE nom='Zone T18'")
    sql("DELETE FROM journal_admin WHERE action IN ('acompte_conserve','livraison_modifiee')")
sys.exit(0 if ok else 1)
