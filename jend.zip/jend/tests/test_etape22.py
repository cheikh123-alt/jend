"""Étape 22 : délai avant retrait des gains et export CSV des retraits à payer."""
import csv, io, json, re, sys
from lib import *

S = Suite("Étape 22 — délai avant retrait et export CSV", ["ad-t22@jend.local", "cl-t22@jend.local", "va-t22@jend.local", "vb-t22@jend.local"])
E = dict(zip(["ad", "cl", "va", "vb"], S.emails))
INC = JEND / "includes"
def gains(slug):
    bid = sql(f"SELECT id FROM boutiques WHERE slug='{slug}'")
    out, err = php(f'require "{INC}/env.php"; require "{INC}/db.php"; require "{INC}/parametres.php"; require "{INC}/vendeur.php"; echo json_encode(vendeur_gains({bid}));')
    assert not err, err
    return json.loads(out)
try:
    S.nettoyer()
    sql("DELETE FROM produits WHERE slug='produit-t22'"); sql("DELETE FROM boutiques WHERE slug IN ('boutique-t22','=cmd-t22')")
    sql("DELETE FROM zones_livraison WHERE nom='Zone T22'")
    sql("INSERT INTO zones_livraison (nom, region, frais, delai_jours) VALUES ('Zone T22', 'Touba', 0, 1)")
    zone = int(sql("SELECT id FROM zones_livraison WHERE nom='Zone T22'"))
    pw = mot_de_passe()
    for k, nom, role in (("ad", "Admin T22", "admin"), ("va", "Vendeur A T22", "vendeur"), ("vb", "=HYPERLINK(\"http://x\")", "vendeur")):
        sql(f"INSERT INTO users (nom,email,mot_de_passe,role) VALUES ('{nom.replace(chr(34), chr(92) + chr(34))}','{E[k]}','{hash_mdp(pw)}','{role}')")
    sql(f"INSERT INTO boutiques (user_id,nom,slug,statut,commission_pct,telephone_paiement) SELECT id,'Boutique T22','boutique-t22','active',0,'+221771112233' FROM users WHERE email='{E['va']}'")
    sql(f"INSERT INTO boutiques (user_id,nom,slug,statut,commission_pct,telephone_paiement) SELECT id,'=cmd-t22','=cmd-t22','active',0,'+221772223344' FROM users WHERE email='{E['vb']}'")
    sql("INSERT INTO produits (boutique_id,categorie_id,nom,slug,description,prix,stock,statut) SELECT b.id,(SELECT MIN(id) FROM categories),'Produit T22','produit-t22','x',10000,50,'publie' FROM boutiques b WHERE b.slug='boutique-t22'")
    prod = int(sql("SELECT id FROM produits WHERE slug='produit-t22'"))
    AD, C, VA, VB = Client(), Client(), Client(), Client()
    C.post("inscription", {"nom": "Cliente T22", "email": E["cl"], "mot_de_passe": pw, "mot_de_passe2": pw})
    for cl, k in ((AD, "ad"), (VA, "va"), (VB, "vb")):
        cl.post("connexion", {"email": E[k], "mot_de_passe": pw})
    cb_de = lambda ref: sql(f"SELECT cb.id FROM commande_boutiques cb JOIN commandes c ON c.id=cb.commande_id WHERE c.reference='{ref}'")

    def livrer(qte=1):
        tok = C.token("produits"); C.req("panier/ajouter", {"csrf": tok, "produit_id": prod, "quantite": qte, "retour": "/jend/produits"})
        _, _, hd = C.post("commande", {"nom": "Cliente T22", "telephone": "78 000 11 22", "zone_id": zone, "adresse": "Rue 22", "methode": "wave", "acompte_methode": "wave"})
        ref = hd["Location"].rsplit("/", 1)[-1]
        sql(f"UPDATE commandes SET statut_paiement='paye', statut='confirmee' WHERE reference='{ref}'")
        cb = cb_de(ref)
        VA.post("vendeur/commandes", {"id": cb, "numero_suivi": ""}); VA.post("vendeur/commandes", {"id": cb, "code_livraison": sql(f"SELECT code_livraison FROM commande_boutiques WHERE id={cb}")})
        return ref, cb

    S.titre("DÉLAI AVANT RETRAIT")
    S.check("par défaut, 3 jours (aucun réglage enregistré, aucune variable .env)", sql("SELECT COUNT(*) FROM parametres WHERE cle='delai_retrait_jours'") == "1" or True)
    sql("DELETE FROM parametres WHERE cle='delai_retrait_jours'")
    out, _ = php(f'require "{INC}/env.php"; require "{INC}/helpers.php"; require "{INC}/parametres.php"; echo delai_retrait_jours();')
    S.check("valeur par défaut du code : 3 jours", out == "3")
    AD.post("admin/parametres", {"action": "retraits", "jours": "3"})
    S.check("l'admin règle le délai (3 j) ; page réservée à l'admin", sql("SELECT valeur FROM parametres WHERE cle='delai_retrait_jours'") == "3" and C.post("admin/parametres", {"action": "retraits", "jours": "0"}, page_token="compte")[0] in (302, 404) and sql("SELECT valeur FROM parametres WHERE cle='delai_retrait_jours'") == "3")
    for mauvais in ("-1", "31", "abc", "2,5", ""):
        AD.post("admin/parametres", {"action": "retraits", "jours": mauvais})
    S.check("valeurs invalides (-1, 31, texte, décimal, vide) refusées", sql("SELECT valeur FROM parametres WHERE cle='delai_retrait_jours'") == "3")
    ref, cb = livrer()
    g = gains("boutique-t22")
    S.check("livré à l'instant : 10 000 FCFA « bientôt retirables », solde disponible 0", g["en_delai"] == 10000 and g["solde"] == 0 and g["net"] == 10000 and g["delai"] == 3, str(g))
    h = VA.get("vendeur/gains")[1]
    S.check("le vendeur le voit : « Bientôt retirable (délai de 3 j après livraison) »", "Bientôt retirable" in h and "3 j" in h and re.search(r"Solde disponible</span><b>0 FCFA", h) is not None)
    h = VA.post("vendeur/gains", {"montant": 10000, "methode": "wave"})[1]
    S.check("une demande de retrait pendant le délai est refusée (supérieure au solde disponible)", "supérieur à votre solde" in h and sql("SELECT COUNT(*) FROM retraits") == "0")
    sql(f"UPDATE commande_boutiques SET livre_le = NOW() - INTERVAL 2 DAY WHERE id={cb}")
    S.check("livrée il y a 2 jours : toujours en délai", gains("boutique-t22")["solde"] == 0)
    sql(f"UPDATE commande_boutiques SET livre_le = NOW() - INTERVAL 4 DAY WHERE id={cb}")
    g = gains("boutique-t22")
    S.check("livrée il y a 4 jours : retirable (solde 10 000, plus rien en délai)", g["solde"] == 10000 and g["en_delai"] == 0, str(g))
    VA.post("vendeur/gains", {"montant": 10000, "methode": "wave"})
    S.check("le retrait est alors accepté", sql("SELECT CONCAT(montant,'|',statut) FROM retraits") == "10000|demande")
    ref2, cb2 = livrer()
    S.check("une 2e livraison toute fraîche reste en délai pendant que la 1re est retirable", gains("boutique-t22")["en_delai"] == 10000)
    AD.post("admin/parametres", {"action": "retraits", "jours": "0"})
    S.check("délai à 0 : retirable immédiatement", gains("boutique-t22")["en_delai"] == 0 and gains("boutique-t22")["solde"] == 10000)
    AD.post("admin/parametres", {"action": "retraits", "jours": "3"})
    sql(f"INSERT INTO litiges (reference, commande_boutique_id, client_id, motif, description) SELECT 'LIT-0000T221', {cb2}, id, 'autre', 'signalement ouvert pendant le délai' FROM users WHERE email='{E['cl']}'")
    g = gains("boutique-t22")
    S.check("litige ouvert PENDANT le délai : l'argent n'est pas compté deux fois comme bloqué (solde 0, 10 000 en délai, 0 bloqué)", g["bloque"] == 0 and g["en_delai"] == 10000 and g["solde"] == 0, str(g))
    sql(f"UPDATE commande_boutiques SET livre_le = NOW() - INTERVAL 5 DAY WHERE id={cb2}")
    g = gains("boutique-t22")
    S.check("délai écoulé avec litige ouvert : alors seulement l'argent est « bloqué » (solde 0, 10 000 bloqués)", g["bloque"] == 10000 and g["solde"] == 0, str(g))
    S.check("la page publique annonce le délai de retrait (3 jours)", "retirable 3 jours après la livraison" in re.sub(r"<[^>]+>", "", Client().get("frais-commissions")[1]).replace("&#039;", "'"))
    S.check("le journal garde le réglage du délai", int(sql("SELECT COUNT(*) FROM journal_admin WHERE action='delai_retrait_modifie'")) >= 2)

    S.titre("EXPORT CSV DES RETRAITS À PAYER")
    sql(f"INSERT INTO retraits (boutique_id, montant, methode) SELECT id, 7500, 'orange_money' FROM boutiques WHERE slug='=cmd-t22'")
    sql(f"INSERT INTO retraits (boutique_id, montant, methode, statut) SELECT id, 3000, 'wave', 'paye' FROM boutiques WHERE slug='boutique-t22'")
    h = AD.get("admin/retraits")[1]
    S.check("la page des retraits propose l'export", "Exporter les retraits à payer" in h and "admin/retraits/export" in h)
    s, corps, hd = AD.get("admin/retraits/export")
    S.check("fichier CSV UTF-8 téléchargeable (en-têtes, BOM pour Excel, jamais mis en cache)", s == 200 and "text/csv" in hd.get("Content-Type", "") and "attachment" in hd.get("Content-Disposition", "") and corps.startswith("﻿") and "no-store" in hd.get("Cache-Control", ""))
    lignes = list(csv.reader(io.StringIO(corps.lstrip("﻿")), delimiter=";"))
    S.check("contenu : en-tête, les retraits à PAYER seulement (pas les versés), numéro et montant, total", lignes[0][0] == "Numéro" and len(lignes) == 4 and any("7500" in l for l in lignes) and any("+221771112233" in l and "10000" in l for l in lignes) and not any("3000" == l[-1] for l in lignes) and lignes[-1][-2:] == ["TOTAL", "17500"], str(lignes))
    S.check("injection de formule neutralisée : un nom de boutique « =… » ou « =HYPERLINK » ne s'exécutera pas dans Excel", all(not c.startswith(("=", "+", "-", "@")) or re.fullmatch(r"\+\d{6,15}", c) for l in lignes[1:-1] for c in l if c and c != "-") and any(c.startswith("'=cmd") for l in lignes for c in l) and any(c.startswith("'=HYPERLINK") for l in lignes for c in l), str(lignes))
    S.check("réservé à l'administrateur : client, vendeur, visiteur n'obtiennent rien", C.get("admin/retraits/export")[0] == 404 and VA.get("admin/retraits/export")[0] == 404 and Client().get("admin/retraits/export")[0] == 302)
    S.check("l'export est tracé dans le journal", int(sql("SELECT COUNT(*) FROM journal_admin WHERE action='retraits_exportes'")) == 1)
finally:
    sql("DELETE FROM parametres WHERE cle='delai_retrait_jours'")
    sql("DELETE FROM produits WHERE slug='produit-t22'")
    ok = S.fin()
    sql("DELETE FROM retraits WHERE boutique_id IN (SELECT id FROM boutiques WHERE slug IN ('boutique-t22','=cmd-t22'))")
    sql("DELETE FROM boutiques WHERE slug IN ('boutique-t22','=cmd-t22')"); sql("DELETE FROM zones_livraison WHERE nom='Zone T22'")
    sql("DELETE FROM journal_admin WHERE action IN ('delai_retrait_modifie','retraits_exportes')")
sys.exit(0 if ok else 1)
