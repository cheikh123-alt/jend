"""Étape 20 : identité visuelle propre à Jënd (motifs, étiquettes de prix, entrées wolof) et textes d'accueil honnêtes."""
import re, sys
from lib import *

S = Suite("Étape 20 — identité visuelle", [])
MOTIFS = JEND / "assets" / "img" / "motifs"
try:
    h = Client().get("")[1]
    S.titre("FICHIERS D'IDENTITÉ")
    S.check("feuille de style d'identité chargée après celle du site", h.find("css/style.css") != -1 and h.find("css/identite.css") > h.find("css/style.css"))
    S.check("20 motifs SVG tissés (losanges, chevrons, tresse, points) en 5 couleurs de la palette", len(list(MOTIFS.glob("*.svg"))) == 20)
    css = (JEND / "assets" / "css" / "identite.css").read_text(encoding="utf-8")
    refs = set(re.findall(r'url\("\.\./img/motifs/([a-z-]+\.svg)"\)', css))
    S.check("tous les motifs cités par le CSS existent", refs and all((MOTIFS / r).is_file() for r in refs), str(sorted(refs)))
    S.check("la feuille d'identité est servie (200, text/css) et n'appelle aucun domaine externe ni données en ligne", Client().get("assets/css/identite.css")[0] == 200 and not re.search(r"url\((?!\"\.\./img/motifs/)", css) and "http" not in css)
    S.titre("ACCUEIL : COMPOSITION PROPRE À JËND")
    S.check("entrée de dictionnaire wolof (jënd = acheter, jaay = vendre)", "verbe wolof" in h and "acheter" in h and "jaay" in h and "vendre" in h)
    S.check("« plan du marché » : les univers sont des tuiles de tailles différentes (6 tuiles, la première double)", h.count('class="tuile tuile-') == 6 and "tuile-0" in h)
    S.check("banderole tissée, titres numérotés, registre des vendeurs, « notre parole »", all(x in h for x in ("banderole", "num-section", "registre", 'class="parole"', "pied-geant")))
    S.check("cartes produit : étiquette de prix suspendue et mention « chez <boutique> »", 'class="prix"' in h and "chez <a" in h and "/boutique/" in h)
    S.titre("PAGES INTÉRIEURES")
    s404, h404, _ = Client().get("page-qui-nexiste-pas")
    S.check("page 404 dans l'identité (grand 404 contouré, entrée de dictionnaire) et toujours en 404", s404 == 404 and "perdu-chiffre" in h404 and "entree-dico" in h404)
    S.check("le CSS couvre ticket de caisse, formulaires à coins taillés, onglets-rubans, tuiles de tableau de bord, badges-tampons", all(x in css for x in (".recap-ligne::before", ".wrap-etroit .formulaire", ".onglets a.actif", ".stat-fort::before", ".badge {")))
    S.check("pages publiques inchangées côté sécurité : connexion et inscription chargent la feuille d'identité", all("css/identite.css" in Client().get(u)[1] for u in ("connexion", "inscription", "produits", "livraison-retours")))
    S.titre("TEXTES HONNÊTES (aucune promesse que le site ne tient pas)")
    S.check("plus de faux rabais « -30 % sur le wax » ni de « vendeurs vérifiés partout au Sénégal »", "-30%" not in h and "Vendeurs vérifiés" not in h)
    S.check("plus de « retours faciles / 7 jours pour changer d'avis » : on parle de signalement", "changer d'avis" not in h and "Signalement" in Client().get("produit/" + sql("SELECT slug FROM produits WHERE statut='publie' LIMIT 1"))[1])
    S.check("la livraison annoncée correspond aux zones réelles (frais minimum lu en base)", f"{int(sql('SELECT MIN(frais) FROM zones_livraison WHERE actif=1')):,}".replace(",", " ") in h.replace(" ", " "))
    S.titre("AUCUNE ERREUR PHP AFFICHÉE (Warning, Notice, Deprecated, Fatal error)")
    pages = ["", "produits", "categories", "recherche?q=wax", "connexion", "inscription", "vendre", "panier", "mot-de-passe-oublie", "page-inconnue", "robots.txt",
             "cgu", "cgv", "conditions-vendeur", "livraison-retours", "confidentialite", "mentions-legales", "a-propos", "contact", "frais-commissions"]
    pages += ["produit/" + x for x in sql("SELECT slug FROM produits WHERE statut='publie' LIMIT 2").split()] + ["categorie/" + x for x in sql("SELECT slug FROM categories LIMIT 3").split()]
    motif = re.compile(r"(Warning|Notice|Deprecated|Fatal error|Parse error|Uncaught)\s*:|Stack trace")
    sales = {u: motif.search(Client().get(u)[1]).group(0) for u in pages if motif.search(Client().get(u)[1])}
    S.check(f"{len(pages)} pages publiques sans aucun message d'erreur PHP", not sales, str(sales))
    S.check("curseur d'origine conservé : plus de rond qui suit la souris (ni élément, ni style, ni script)", 'class="curseur"' not in h and ".curseur {" not in (JEND / "assets/css/style.css").read_text(encoding="utf-8") and "mousemove" not in (JEND / "assets/js/main.js").read_text(encoding="utf-8"))
    S.titre("SÉCURITÉ INCHANGÉE")
    ent = Client().get("")[2]
    csp = ent.get("Content-Security-Policy", "")
    S.check("CSP toujours stricte : tout vient du site lui-même", "default-src 'self'" in csp and "http" not in re.sub(r"'self'", "", csp))
    S.check("aucun script ni style en ligne ajouté sur l'accueil", "<style" not in h and not re.search(r"\sstyle=", h) and not re.search(r"<script(?![^>]*src=)", h))
finally:
    ok = S.fin()
sys.exit(0 if ok else 1)
