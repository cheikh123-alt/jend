"""Étape 60 : PayTech à côté de PayDunya (prestataire principal + secours automatique, IPN signée HMAC-SHA256),
et durée des taux contrôlée par l'administrateur (nouveau taux appliqué tout seul à sa date, frais client avec date de fin)."""
import http.server, json, re, socket, sys, threading, urllib.parse, hmac, hashlib, os, time
from lib import *

S = Suite("Étape 60 — PayTech + durée des taux", ["ad-t60@jend.local", "ve-t60@jend.local", "cl-t60@jend.local"])
E = dict(zip(["ad", "ve", "cl"], S.emails))
PT = {"key": "pt_test_KEY_0123456789", "secret": "pt_test_SECRET_0123456789"}
PD = {"master": "pd_master_0123456789", "private": "pd_private_0123456789", "token": "pd_token_0123456789"}
APPELS, PANNE, NUM = [], {"paytech": False, "paydunya": False}, [0]


class Faux(http.server.BaseHTTPRequestHandler):
    """Faux PayTech (/api/…) et faux PayDunya (/v1/…) sur le même port."""
    def log_message(self, *a): pass

    def _rep(self, obj, code=200):
        c = json.dumps(obj).encode(); self.send_response(code); self.send_header("Content-Type", "application/json"); self.send_header("Content-Length", str(len(c))); self.end_headers(); self.wfile.write(c)

    def do_POST(self):
        brut = self.rfile.read(int(self.headers.get("Content-Length") or 0))
        if self.path.startswith("/api/payment/request-payment"):
            champs = {k: v[0] for k, v in urllib.parse.parse_qs(brut.decode()).items()}
            APPELS.append(("paytech", dict(self.headers), champs))
            if PANNE["paytech"]:
                return self._rep({"success": 0, "errors": ["indisponible"]}, 500)
            if (self.headers.get("API_KEY"), self.headers.get("API_SECRET")) != (PT["key"], PT["secret"]):
                return self._rep({"success": -1, "errors": ["Clés invalides"]}, 401)
            NUM[0] += 1; tok = "pt" + str(NUM[0]).zfill(6) + "tokXYZ"
            return self._rep({"success": 1, "token": tok, "redirect_url": f"http://127.0.0.1:{PORT}/payment/checkout/{tok}", "redirectUrl": f"http://127.0.0.1:{PORT}/payment/checkout/{tok}"})
        if self.path.startswith("/v1/checkout-invoice/create"):
            corps = json.loads(brut or b"{}")
            APPELS.append(("paydunya", dict(self.headers), corps))
            if PANNE["paydunya"]:
                return self._rep({"response_code": "9999", "response_text": "panne"}, 500)
            NUM[0] += 1; tok = "pd" + str(NUM[0]).zfill(6) + "tokXYZ"
            return self._rep({"response_code": "00", "response_text": f"http://127.0.0.1:{PORT}/checkout/{tok}", "token": tok})
        self._rep({}, 404)


s = socket.socket(); s.bind(("127.0.0.1", 0)); PORT = s.getsockname()[1]; s.close()
serveur = http.server.ThreadingHTTPServer(("127.0.0.1", PORT), Faux)
threading.Thread(target=serveur.serve_forever, daemon=True).start()


def ipn_paytech(token, ref_tentative, montant, evenement="sale_complete", secret=None, json_corps=False, sans_hmac=False):
    m = hmac.new((secret or PT["secret"]).encode(), f"{montant}|{ref_tentative}|{PT['key']}".encode(), hashlib.sha256).hexdigest()
    d = {"type_event": evenement, "token": token, "ref_command": ref_tentative, "item_price": str(montant), "final_item_price": str(montant),
         "currency": "XOF", "payment_method": "Wave", "env": "test", "client_phone": "771234567",
         "api_key_sha256": hashlib.sha256(PT["key"].encode()).hexdigest(), "api_secret_sha256": hashlib.sha256(PT["secret"].encode()).hexdigest()}
    if not sans_hmac:
        d["hmac_compute"] = m
    if json_corps:
        return Client().req("paiement/webhook", raw=json.dumps(d).encode(), headers={"Content-Type": "application/json"})
    return Client().req("paiement/webhook", d)


PARAMS = ('prestataire_principal', 'frais_service_pct', 'frais_service_min', 'frais_service_fin', 'commission_annonce_pct', 'commission_annonce_le', 'commission_defaut', 'commission_offre_lancement')
AVANT = {}
try:
    for k in PARAMS:                                   # réglages d'origine, remis tels quels à la fin
        v = sql(f"SELECT valeur FROM parametres WHERE cle='{k}'")
        AVANT[k] = v if v != "" else None
    S.nettoyer()
    sql("DELETE FROM zones_livraison WHERE nom='Zone T60'")
    sql("INSERT INTO zones_livraison (nom, region, frais, delai_jours) VALUES ('Zone T60', 'Ziguinchor', 1000, 1)")
    zone = sql("SELECT id FROM zones_livraison WHERE nom='Zone T60'")
    pw = mot_de_passe()
    for k, nom, role in (("ad", "Admin T60", "admin"), ("ve", "Vendeur T60", "vendeur")):
        sql(f"INSERT INTO users (nom,email,mot_de_passe,role,email_verifie) VALUES ('{nom}','{E[k]}','{hash_mdp(pw)}','{role}',1)")
    sql(f"INSERT INTO boutiques (user_id,nom,slug,statut,commission_pct) SELECT id,'Boutique T60','boutique-t60','active',1 FROM users WHERE email='{E['ve']}'")
    bid = sql("SELECT id FROM boutiques WHERE slug='boutique-t60'")
    sql(f"INSERT INTO produits (boutique_id,categorie_id,nom,slug,prix,stock,statut) VALUES ({bid},(SELECT MIN(id) FROM categories),'Pagne T60','pagne-t60',10000,50,'publie')")
    pid = sql("SELECT id FROM produits WHERE slug='pagne-t60'")
    AD, C = Client(), Client()
    AD.post("connexion", {"email": E["ad"], "mot_de_passe": pw})
    C.post("inscription", {"nom": "Client T60", "email": E["cl"], "telephone": "", "mot_de_passe": "Wax-Zig-2026!!", "mot_de_passe2": "Wax-Zig-2026!!", "accepte": "1"})
    base_env = dict(PAIEMENT_FOURNISSEUR="paydunya,paytech", PAYTECH_API_KEY=PT["key"], PAYTECH_API_SECRET=PT["secret"], PAYTECH_ENV="test",
                    PAYTECH_API_BASE=f"http://127.0.0.1:{PORT}/api", PAYDUNYA_MODE="test", PAYDUNYA_MASTER_KEY=PD["master"], PAYDUNYA_PRIVATE_KEY=PD["private"],
                    PAYDUNYA_TOKEN=PD["token"], PAYDUNYA_API_BASE=f"http://127.0.0.1:{PORT}/v1", APP_URL=BASE.rstrip("/"))
    S.modifier_env(**base_env)

    def commander(methode="wave"):
        C.req("panier/ajouter", {"csrf": C.token("produits"), "produit_id": pid, "quantite": 1, "retour": "/jend/produits"})
        _, _, hd = C.post("commande", {"nom": "Client T60", "telephone": "77 123 45 60", "zone_id": zone, "adresse": "Rue 60", "methode": methode, "acompte_methode": "wave"})
        return hd.get("Location", "").rsplit("/", 1)[-1]

    def payer(ref):
        APPELS.clear()
        st, _, hd = C.post("paiement/" + ref, {}, page_token="commande/" + ref)
        return hd.get("Location", "")

    etat = lambda ref: sql(f"SELECT CONCAT(statut,'|',statut_paiement) FROM commandes WHERE reference='{ref}'")

    S.titre("LES DEUX PRESTATAIRES DANS L'ADMINISTRATION")
    h = AD.get("admin/parametres")[1]
    S.check("section « Prestataires de paiement » : PayDunya et PayTech, clés présentes, mode TEST", "Prestataires de paiement" in h and h.count('name="principal"') == 2 and "PayTech" in h and "mode <b>TEST</b>" in h)
    S.check("sans choix : le premier de la liste (PayDunya) est principal", re.search(r'value="paydunya" checked', h) is not None)
    AD.post("admin/parametres", {"action": "prestataire", "principal": "paytech"}, page_token="admin/parametres")
    S.check("l'admin choisit PayTech comme principal (journalisé)", sql("SELECT valeur FROM parametres WHERE cle='prestataire_principal'") == "paytech" and sql("SELECT COUNT(*) FROM journal_admin WHERE action='prestataire_principal'") == "1")
    AD.post("admin/parametres", {"action": "prestataire", "principal": "cinetpay"}, page_token="admin/parametres")
    S.check("un prestataire non branché est refusé", sql("SELECT valeur FROM parametres WHERE cle='prestataire_principal'") == "paytech")

    S.titre("PAIEMENT PAR PAYTECH (PRINCIPAL)")
    ref0 = commander()
    h1, h2 = C.get("commande/" + ref0)[1], C.get("commande/" + ref0)[1]
    S.check("« Confirmer et payer » : la page de la commande part toute seule vers le paiement (une seule fois, bouton gardé en secours)",
            "data-envoi-auto" in h1 and "Redirection vers la page de paiement" in h1 and "data-envoi-auto" not in h2 and "Payer maintenant" in h2)
    sql(f"UPDATE commandes SET statut='annulee' WHERE reference='{ref0}'")
    ref = commander(); total = int(sql(f"SELECT total FROM commandes WHERE reference='{ref}'"))
    loc = payer(ref)
    S.check("le client part vers la page de paiement PayTech", re.fullmatch(rf"http://127\.0\.0\.1:{PORT}/payment/checkout/pt\d{{6}}tokXYZ", loc) is not None, loc)
    _, ent, ch = APPELS[0] if APPELS else ("", {}, {})
    S.check("demande envoyée par le serveur avec API_KEY / API_SECRET en en-têtes (jamais dans la page)", ent.get("API_KEY") == PT["key"] and ent.get("API_SECRET") == PT["secret"] and PT["secret"] not in C.get("commande/" + ref)[1])
    S.check("montant exact, XOF, mode test, adresses de retour et de notification du site, Wave présélectionné",
            ch.get("item_price") == str(total) and ch.get("currency") == "XOF" and ch.get("env") == "test" and ch.get("ipn_url", "").endswith("/paiement/webhook")
            and ch.get("success_url", "").endswith("/paiement/retour/" + ref) and ch.get("target_payment") == "Wave" and ch.get("ref_command", "").startswith(ref + "-"), ch)
    tok = loc.rsplit("/", 1)[-1]; rt = ch.get("ref_command", "")
    S.check("paiement enregistré « PayTech » avec le jeton reçu", sql(f"SELECT fournisseur FROM paiements WHERE reference_externe='{tok}'") == "paytech")
    S.check("le retour du client seul ne marque PAS la commande payée", (C.get("paiement/retour/" + ref)[0] in (200, 302, 303)) and etat(ref).endswith("|en_attente"))

    S.titre("NOTIFICATION PAYTECH (IPN) : SIGNATURE HMAC")
    st, corps, _ = ipn_paytech(tok, rt, total, secret="mauvais-secret")
    S.check("HMAC faux : refusé (401), commande non payée", st == 401 and etat(ref).endswith("|en_attente"))
    st, _, _ = ipn_paytech(tok, rt, total, sans_hmac=True)
    S.check("sans HMAC (seulement les empreintes SHA-256 des clés, rejouables) : refusé", st == 401 and etat(ref).endswith("|en_attente"))
    st, _, _ = ipn_paytech(tok, rt, total - 100)
    S.check("montant différent (signé) : refusé, commande non payée", st == 400 and etat(ref).endswith("|en_attente"))
    st, _, _ = ipn_paytech(tok, "JND-AUTRE-ABC123", total)
    S.check("référence d'une autre commande : refusée", st == 400 and etat(ref).endswith("|en_attente"))
    st, _, _ = ipn_paytech("pt999999inconnu", rt, total)
    S.check("jeton inconnu : refusé", st == 404)
    st, corps, _ = ipn_paytech(tok, rt, total)
    S.check("IPN valide (sale_complete, bon HMAC, bon montant) : commande payée", st == 200 and etat(ref) == "confirmee|paye", corps)
    st, corps, _ = ipn_paytech(tok, rt, total)
    S.check("même notification rejouée : ignorée (« Déjà traité »), pas de double paiement", st == 200 and json.loads(corps)["message"] == "Déjà traité")
    ref2 = commander(); loc2 = payer(ref2); tok2 = loc2.rsplit("/", 1)[-1]; rt2 = APPELS[0][2]["ref_command"]; total2 = int(sql(f"SELECT total FROM commandes WHERE reference='{ref2}'"))
    st, _, _ = ipn_paytech(tok2, rt2, total2, json_corps=True)
    S.check("notification envoyée en JSON : acceptée aussi", st == 200 and etat(ref2) == "confirmee|paye")
    ref3 = commander(); loc3 = payer(ref3); tok3 = loc3.rsplit("/", 1)[-1]; rt3 = APPELS[0][2]["ref_command"]; total3 = int(sql(f"SELECT total FROM commandes WHERE reference='{ref3}'"))
    ipn_paytech(tok3, rt3, total3, evenement="sale_canceled")
    S.check("paiement annulé chez PayTech : commande « échoué », le client peut réessayer", etat(ref3).endswith("|echoue"))

    S.titre("MODE RÉEL : LES MOTS COURANTS SONT ACCEPTÉS")
    for mot, attendu in (("live", "https://app.paydunya.com/api/v1"), ("production", "https://app.paydunya.com/api/v1"), ("prod", "https://app.paydunya.com/api/v1"), ("test", "https://app.paydunya.com/sandbox-api/v1"), ("", "https://app.paydunya.com/sandbox-api/v1")):
        o, e = php("function env($k, $d = null) { $v = ['PAYDUNYA_MODE' => '%s', 'APP_ENV' => 'prod', 'PAYTECH_ENV' => '%s']; return $v[$k] ?? $d; } require '%s/includes/paydunya.php'; require '%s/includes/paytech.php'; echo paydunya_base(), '|', paytech_mode_test() ? 'test' : 'reel';" % (mot, mot, JEND, JEND))
        S.check(f"PAYDUNYA_MODE={mot or '(vide)'} → {'serveur réel' if 'sandbox' not in attendu else 'bac à sable'}", o.split("|")[0] == attendu, o + e)
    S.check("PAYTECH_ENV=production ou live → réel aussi", "reel" in php("function env($k, $d = null) { return ['PAYTECH_ENV' => 'production'][$k] ?? $d; } require '%s/includes/paytech.php'; echo paytech_mode_test() ? 'test' : 'reel';" % JEND)[0])

    S.titre("SECOURS AUTOMATIQUE ET COEXISTENCE")
    PANNE["paytech"] = True
    ref4 = commander(); loc4 = payer(ref4)
    S.check("PayTech en panne : PayDunya prend le relais, le client paie quand même", re.fullmatch(rf"http://127\.0\.0\.1:{PORT}/checkout/pd\d{{6}}tokXYZ", loc4) is not None and [a[0] for a in APPELS] == ["paytech", "paydunya"], loc4)
    S.check("l'admin est alerté de l'utilisation du secours", "secours" in ((JEND / "storage" / "emails.log").read_text() if (JEND / "storage" / "emails.log").exists() else "").lower() or sql("SELECT COUNT(*) FROM limites WHERE cle LIKE 'alerte:paiement-secours%'") != "0")
    PANNE["paydunya"] = True
    ref5 = commander(); st, _, hd = C.post("paiement/" + ref5, {}, page_token="commande/" + ref5)
    S.check("les deux en panne : pas de page de paiement, message d'erreur, commande non payée", "127.0.0.1:" + str(PORT) not in hd.get("Location", "") and etat(ref5).endswith("|en_attente"))
    h = AD.get("admin/parametres")[1]
    S.check("l'admin voit POURQUOI : « Dernier paiement impossible » avec la raison de chaque prestataire (sans aucune clé)",
            "Dernier paiement impossible" in h and "PayTech : demande refusée par PayTech en mode TEST" in h and "PayDunya : demande refusée par PayDunya en mode TEST (bac à sable)" in h and PT["secret"] not in h and PD["private"] not in h)
    hc = C.get("commande/" + ref5)[1]                   # le message (flash) ne s'affiche qu'une fois
    S.check("le client, lui, ne voit qu'un message simple", "Dernier paiement impossible" not in hc and "momentanément indisponible" in hc)
    PANNE.update(paytech=False, paydunya=False)
    AD.post("admin/parametres", {"action": "prestataire", "principal": "paydunya"}, page_token="admin/parametres")
    ref6 = commander(); loc6 = payer(ref6)
    S.check("retour à PayDunya principal : nouveaux paiements chez PayDunya", "/checkout/pd" in loc6 and APPELS[0][0] == "paydunya")
    ref7 = commander(); AD.post("admin/parametres", {"action": "prestataire", "principal": "paytech"}, page_token="admin/parametres")
    loc7 = payer(ref7); tok7 = loc7.rsplit("/", 1)[-1]; rt7 = APPELS[0][2]["ref_command"]; total7 = int(sql(f"SELECT total FROM commandes WHERE reference='{ref7}'"))
    AD.post("admin/parametres", {"action": "prestataire", "principal": "paydunya"}, page_token="admin/parametres")
    st, _, _ = ipn_paytech(tok7, rt7, total7)
    S.check("paiement PayTech en cours alors que PayDunya redevient principal : toujours confirmé", st == 200 and etat(ref7) == "confirmee|paye")
    S.check("CSP : pages de paiement des deux prestataires autorisées", all(d in C.req("", headers={})[2].get("Content-Security-Policy", "") for d in ("https://paytech.sn", "https://app.paydunya.com")))
    S.modifier_env(**{**base_env, "PAIEMENT_FOURNISSEUR": "paydunya"})
    st, _, _ = ipn_paytech(tok7, rt7, total7)
    S.check("PayTech retiré de la configuration : ses notifications ne sont plus acceptées", st in (400, 401))
    S.modifier_env(**base_env)

    S.titre("DURÉE DES TAUX : NOUVEAU TAUX APPLIQUÉ TOUT SEUL À SA DATE")
    sql("INSERT INTO parametres (cle, valeur) VALUES ('commission_annonce_pct','5'),('commission_annonce_le',DATE_FORMAT(DATE_ADD(CURDATE(), INTERVAL 40 DAY),'%Y-%m-%d')) ON DUPLICATE KEY UPDATE valeur=VALUES(valeur)")
    sql("INSERT INTO parametres (cle, valeur) VALUES ('commission_defaut','1'),('commission_offre_lancement','1') ON DUPLICATE KEY UPDATE valeur=VALUES(valeur)")
    h = C.get("vendre")[1].replace("&#039;", "'")                  # client connecté sans boutique : il voit le formulaire d'ouverture
    S.check("page « Vendre » : offre de lancement à 1 %, sa date de fin et le taux suivant (5 %) avant d'accepter les conditions",
            re.search(r"Offre de lancement : seulement 1 % de commission</b> sur les ventes livrées, jusqu'au \d\d/\d\d/\d{4} \(puis 5 %\)", h) is not None and re.search(r"puis 5 % à partir du \d\d/\d\d/\d{4}", h) is not None)
    rappel = JEND / "storage" / "depenses-rappel.txt"
    rappel.touch(); os.utime(rappel, (time.time() - 7200, time.time() - 7200)); Client().get("")
    S.check("avant la date : rien ne change", sql(f"SELECT commission_pct FROM boutiques WHERE id={bid}") == "1.00")
    sql("UPDATE parametres SET valeur=CURDATE() WHERE cle='commission_annonce_le'")
    os.utime(rappel, (time.time() - 7200, time.time() - 7200)); Client().get("")
    S.check("date atteinte : 5 % appliqué automatiquement à toutes les boutiques et aux nouvelles", sql(f"SELECT commission_pct FROM boutiques WHERE id={bid}") == "5.00" and sql("SELECT valeur FROM parametres WHERE cle='commission_defaut'") == "5")
    S.check("l'annonce est retirée, l'offre de lancement terminée, l'action journalisée « automatiquement »",
            sql("SELECT COUNT(*) FROM parametres WHERE cle IN ('commission_annonce_pct','commission_annonce_le')") == "0" and sql("SELECT valeur FROM parametres WHERE cle='commission_offre_lancement'") == "0"
            and sql("SELECT COUNT(*) FROM journal_admin WHERE action='commission_appliquee' AND detail LIKE '%automatiquement%'") == "1")
    ref8 = commander()
    S.check("les commandes suivantes prennent 5 %", sql(f"SELECT cb.commission FROM commande_boutiques cb JOIN commandes c ON c.id=cb.commande_id WHERE c.reference='{ref8}'") == "500")
    S.check("les commandes déjà passées gardent 1 %", sql(f"SELECT cb.commission FROM commande_boutiques cb JOIN commandes c ON c.id=cb.commande_id WHERE c.reference='{ref}'") == "100")

    S.titre("DURÉE DES TAUX : FRAIS CLIENT AVEC DATE DE FIN")
    sql(f"UPDATE commandes c JOIN users u ON u.id=c.client_id SET c.statut='annulee' WHERE u.email='{E['cl']}' AND c.statut_paiement IN ('en_attente','echoue')")   # (limite de 5 commandes non payées par client)
    demain = time.strftime("%Y-%m-%d", time.localtime(time.time() + 86400))
    AD.post("admin/parametres", {"action": "frais_service", "pct": "2", "minimum": "100", "fin": demain}, page_token="admin/parametres")
    S.check("frais de 2 % (min. 100 F) jusqu'à demain : enregistré et journalisé", sql("SELECT valeur FROM parametres WHERE cle='frais_service_fin'") == demain and sql("SELECT COUNT(*) FROM journal_admin WHERE action='frais_service_modifies' AND detail LIKE '%jusqu%'") == "1")
    S.check("l'admin voit jusqu'à quand le client le paie", "puis il s'arrête tout seul" in AD.get("admin/parametres")[1].replace("&#039;", "'"))
    ref9 = commander()
    S.check("pendant la période : le client paie le frais (2 % de 11 000 = 220 F)", sql(f"SELECT frais_service FROM commandes WHERE reference='{ref9}'") == "220")
    sql("UPDATE parametres SET valeur=DATE_FORMAT(DATE_SUB(CURDATE(), INTERVAL 1 DAY),'%Y-%m-%d') WHERE cle='frais_service_fin'")
    ref10 = commander()
    S.check("date de fin passée : plus aucun frais pour le client, sans rien toucher", sql(f"SELECT frais_service FROM commandes WHERE reference='{ref10}'") == "0")
    AD.post("admin/parametres", {"action": "frais_service", "pct": "2", "minimum": "100", "fin": "pas-une-date"}, page_token="admin/parametres")
    S.check("date invalide : refusée", sql("SELECT valeur FROM parametres WHERE cle='frais_service_fin'") != "pas-une-date")
    S.check("conditions vendeurs : « PayDunya et PayTech », grille de chacun", all(t in Client().get("paiements-vendeurs")[1] for t in ("PayDunya et PayTech", "paytech.sn/#plans", "paydunya.com/service-fees")))
finally:
    serveur.shutdown()
    (JEND / "storage" / "paiement-derniere-erreur.txt").unlink(missing_ok=True)
    for k in PARAMS:
        sql(f"DELETE FROM parametres WHERE cle='{k}'")
        if AVANT.get(k) is not None:
            sql(f"INSERT INTO parametres (cle, valeur) VALUES ('{k}', '{AVANT[k]}')")
    sql("DELETE FROM produits WHERE slug='pagne-t60'")
    S.restaurer_env()
    S.nettoyer()
    sql("DELETE FROM zones_livraison WHERE nom='Zone T60'")
    ok = S.fin()
sys.exit(0 if ok else 1)
