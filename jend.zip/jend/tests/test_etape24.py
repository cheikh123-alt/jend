"""Étape 24 : situation de trésorerie (argent encaissé, dû aux vendeurs, reste à Jënd, frais du prestataire de paiement)."""
import re, sys
from lib import *

S = Suite("Étape 24 — trésorerie", ["ad-t24@jend.local", "cl-t24@jend.local", "va-t24@jend.local"])
E = dict(zip(["ad", "cl", "va"], S.emails))
texte = lambda h: re.sub(r"\s+", " ", re.sub(r"<[^>]+>", " ", h)).replace(" ", " ").replace("\xa0", " ").replace("&#039;", "'")
def ligne(t, debut):
    m = re.search(re.escape(debut) + r"[^0-9\-−]{0,160}?(-?\d[\d ]*) FCFA", t)
    return int(m.group(1).replace(" ", "")) if m else None
try:
    S.nettoyer()
    sql("DELETE FROM parametres WHERE cle IN ('tresorerie_solde_reel','tresorerie_solde_reel_le')")
    sql("DELETE FROM produits WHERE slug='produit-t24'"); sql("DELETE FROM boutiques WHERE slug='boutique-t24'"); sql("DELETE FROM zones_livraison WHERE nom='Zone T24'")
    sql("INSERT INTO zones_livraison (nom, region, frais, delai_jours) VALUES ('Zone T24', 'Touba', 0, 1)")
    zone = int(sql("SELECT id FROM zones_livraison WHERE nom='Zone T24'"))
    pw = mot_de_passe()
    sql(f"INSERT INTO users (nom,email,mot_de_passe,role) VALUES ('Admin T24','{E['ad']}','{hash_mdp(pw)}','admin')")
    sql(f"INSERT INTO users (nom,email,mot_de_passe,role) VALUES ('Vendeur T24','{E['va']}','{hash_mdp(pw)}','vendeur')")
    sql(f"INSERT INTO boutiques (user_id,nom,slug,statut,commission_pct,telephone_paiement) SELECT id,'Boutique T24','boutique-t24','active',10,'+221771112233' FROM users WHERE email='{E['va']}'")
    sql("INSERT INTO produits (boutique_id,categorie_id,nom,slug,description,prix,stock,statut) SELECT b.id,(SELECT MIN(id) FROM categories),'Produit T24','produit-t24','x',10000,50,'publie' FROM boutiques b WHERE b.slug='boutique-t24'")
    prod = int(sql("SELECT id FROM produits WHERE slug='produit-t24'"))
    AD, C, VA = Client(), Client(), Client()
    C.post("inscription", {"nom": "Cliente T24", "email": E["cl"], "mot_de_passe": pw, "mot_de_passe2": pw})
    AD.post("connexion", {"email": E["ad"], "mot_de_passe": pw}); VA.post("connexion", {"email": E["va"], "mot_de_passe": pw})

    S.titre("PAGE VIDE, PUIS SCÉNARIO CHIFFRÉ")
    S.check("onglet « Trésorerie » réservé à l'admin (404 pour client et vendeur, connexion pour visiteur)", "admin/tresorerie" in AD.get("admin")[1] and C.get("admin/tresorerie")[0] == 404 and VA.get("admin/tresorerie")[0] == 404 and Client().get("admin/tresorerie")[0] == 302)
    t0 = texte(AD.get("admin/tresorerie")[1])
    base = {k: ligne(t0, k) for k in ("Encaissé en ligne (clients)", "= Solde théorique", "= Total que tu dois")}
    def commande(qte):
        tok = C.token("produits"); C.req("panier/ajouter", {"csrf": tok, "produit_id": prod, "quantite": qte, "retour": "/jend/produits"})
        _, _, hd = C.post("commande", {"nom": "Cliente T24", "telephone": "78 000 11 22", "zone_id": zone, "adresse": "Rue 24", "methode": "wave", "acompte_methode": "wave"})
        ref = hd["Location"].rsplit("/", 1)[-1]
        sql(f"UPDATE commandes SET statut_paiement='paye', statut='confirmee' WHERE reference='{ref}'")
        sql(f"UPDATE paiements p JOIN commandes c ON c.id=p.commande_id SET p.statut='reussi' WHERE c.reference='{ref}'")
        return ref, sql(f"SELECT cb.id FROM commande_boutiques cb JOIN commandes c ON c.id=cb.commande_id WHERE c.reference='{ref}'")
    ref1, cb1 = commande(1)                                  # 10 000 : livrée
    VA.post("vendeur/commandes", {"id": cb1, "numero_suivi": ""}); VA.post("vendeur/commandes", {"id": cb1, "code_livraison": sql(f"SELECT code_livraison FROM commande_boutiques WHERE id={cb1}")})
    ref2, cb2 = commande(2)                                  # 20 000 : payée, pas livrée
    ref3, cb3 = commande(1)                                  # 10 000 : payée puis annulée (à rembourser)
    sql(f"UPDATE commandes SET statut='annulee' WHERE reference='{ref3}'"); sql(f"UPDATE commande_boutiques SET statut='annulee' WHERE id={cb3}")
    sql("INSERT INTO retraits (boutique_id, montant, methode, statut) SELECT id, 4000, 'wave', 'paye' FROM boutiques WHERE slug='boutique-t24'")
    t = texte(AD.get("admin/tresorerie")[1])
    d = lambda k, base_k=None: ligne(t, k)
    S.check("encaissé en ligne : +40 000 (10 000 + 20 000 + 10 000)", d("Encaissé en ligne (clients)") - base["Encaissé en ligne (clients)"] == 40000)
    S.check("versé aux vendeurs : 4 000 FCFA ; remboursé aux clients : 0 FCFA", "Versé aux vendeurs (retraits payés) − 4 000 FCFA" in t and re.search(r"Remboursé aux clients − 0 FCFA", t) is not None)
    S.check("solde théorique : +36 000 (40 000 − 4 000)", d("= Solde théorique") - base["= Solde théorique"] == 36000)
    S.check("dû aux vendeurs : 5 000 retirables (9 000 net après commission 10 % − 4 000 déjà versés)", d("Aux vendeurs : gains retirables") is not None and "5 000 FCFA" in t)
    S.check("commandes payées pas livrées : 20 000 ; à rembourser (commande annulée) : 10 000", ligne(t, "Commandes payées, pas encore livrées") == 20000 and ligne(t, "Remboursements à envoyer aux clients") == 10000)
    S.check("total dû : +35 000", d("= Total que tu dois") - base["= Total que tu dois"] == 35000)
    reste = ligne(t, "3. Ce qui te reste") if ligne(t, "3. Ce qui te reste") is not None else None
    S.check("ce qui te reste avant frais : 1 000 FCFA (la commission de 10 % sur la vente livrée)", re.search(r"avant frais\)\s*1 000 FCFA", t) is not None, t[t.find("3. Ce qui te reste"):][:120])

    S.titre("COMPARAISON AVEC LE SOLDE RÉEL (frais du prestataire)")
    T = 36000
    AD.post("admin/tresorerie", {"action": "solde_reel", "solde": str(T - 400 - 0)}, page_token="admin/tresorerie")      # 400 de frais (1 %)
    t = texte(AD.get("admin/tresorerie")[1])
    S.check("solde réel saisi : les frais retenus apparaissent (400 FCFA, 1 % de l'encaissé de cet exercice)", "Frais retenus par le prestataire" in t and re.search(r"Frais retenus par le prestataire[^0-9]*400 FCFA", t) is not None)
    S.check("« ce qu'il te reste réellement » = solde réel − dettes (+ 600 ici) et message rassurant", re.search(r"Ce qu'il te reste réellement[^0-9\-]*600 FCFA", t) is not None and "Tu peux payer tout ce que tu dois" in t)
    AD.post("admin/tresorerie", {"action": "solde_reel", "solde": "30000"}, page_token="admin/tresorerie")
    t = texte(AD.get("admin/tresorerie")[1])
    S.check("solde réel trop bas : alerte « Il manque 5 000 FCFA » (de ta poche)", "Il manque 5 000 FCFA" in t)
    AD.post("admin/tresorerie", {"action": "solde_reel", "solde": "abc"}, page_token="admin/tresorerie"); AD.post("admin/tresorerie", {"action": "solde_reel", "solde": "-5"}, page_token="admin/tresorerie")
    S.check("montants invalides (texte, négatif) refusés : le solde saisi reste 30 000", sql("SELECT valeur FROM parametres WHERE cle='tresorerie_solde_reel'") == "30000")
    C.post("admin/tresorerie", {"action": "solde_reel", "solde": "1"}, page_token="compte")
    S.check("un client ne peut rien saisir", sql("SELECT valeur FROM parametres WHERE cle='tresorerie_solde_reel'") == "30000")
    AD.post("admin/tresorerie", {"action": "solde_effacer"}, page_token="admin/tresorerie")
    S.check("le solde saisi peut être effacé ; la saisie est dans le journal", sql("SELECT COUNT(*) FROM parametres WHERE cle='tresorerie_solde_reel'") == "0" and int(sql("SELECT COUNT(*) FROM journal_admin WHERE action='tresorerie_solde_saisi'")) == 2)
    S.check("la page prévient que les espèces ne sont pas comptées", "espèces" in t)
finally:
    sql("DELETE FROM parametres WHERE cle IN ('tresorerie_solde_reel','tresorerie_solde_reel_le')")
    sql("DELETE FROM produits WHERE slug='produit-t24'")
    ok = S.fin()
    sql("DELETE FROM retraits WHERE boutique_id IN (SELECT id FROM boutiques WHERE slug='boutique-t24')")
    sql("DELETE FROM boutiques WHERE slug='boutique-t24'"); sql("DELETE FROM zones_livraison WHERE nom='Zone T24'"); sql("DELETE FROM journal_admin WHERE action='tresorerie_solde_saisi'")
sys.exit(0 if ok else 1)
