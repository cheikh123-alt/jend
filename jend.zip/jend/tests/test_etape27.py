"""Étape 27 : le client confirme lui-même la réception (bouton « J'ai bien reçu ma commande »)."""
import sys
from lib import *

S = Suite("Étape 27 — confirmation de réception par le client", ["cl-t27@jend.local", "c2-t27@jend.local", "va-t27@jend.local", "lv-t27@jend.local", "ad-t27@jend.local"])
E = dict(zip(["cl", "c2", "va", "lv", "ad"], S.emails))
try:
    S.nettoyer()
    sql("REPLACE INTO parametres (cle, valeur) VALUES ('livreurs_jend', '1')")
    sql("DELETE FROM produits WHERE slug IN ('produit-a-t27','produit-b-t27')"); sql("DELETE FROM boutiques WHERE slug IN ('boutique-a-t27','boutique-b-t27')")
    sql("DELETE FROM zones_livraison WHERE nom='Zone T27'")
    sql("INSERT INTO zones_livraison (nom, region, frais, delai_jours) VALUES ('Zone T27', 'Touba', 500, 1)")
    zone = int(sql("SELECT id FROM zones_livraison WHERE nom='Zone T27'"))
    pw = mot_de_passe()
    for k, nom, role in (("cl", "Cliente T27", "client"), ("c2", "Autre T27", "client"), ("va", "Vendeur T27", "vendeur"), ("ad", "Admin T27", "admin")):
        sql(f"INSERT INTO users (nom,email,mot_de_passe,role) VALUES ('{nom}','{E[k]}','{hash_mdp(pw)}','{role}')")
    sql(f"INSERT INTO users (nom,email,telephone,mot_de_passe,role) VALUES ('Livreur T27','{E['lv']}','+221775556677','{hash_mdp(pw)}','livreur')")
    sql(f"INSERT INTO livreurs (user_id) SELECT id FROM users WHERE email='{E['lv']}'")
    sql(f"INSERT INTO boutiques (user_id,nom,slug,statut,commission_pct,livraison_par) SELECT id,'Boutique A T27','boutique-a-t27','active',3,'vendeur' FROM users WHERE email='{E['va']}'")
    sql("INSERT INTO produits (boutique_id,categorie_id,nom,slug,description,prix,stock,statut) SELECT b.id,(SELECT MIN(id) FROM categories),'Produit A','produit-a-t27','x',10000,50,'publie' FROM boutiques b WHERE b.slug='boutique-a-t27'")
    prod = int(sql("SELECT id FROM produits WHERE slug='produit-a-t27'"))
    C, C2, VA, AD = Client(), Client(), Client(), Client()
    C.post("connexion", {"email": E["cl"], "mot_de_passe": pw}); C2.post("connexion", {"email": E["c2"], "mot_de_passe": pw})
    VA.post("connexion", {"email": E["va"], "mot_de_passe": pw}); AD.post("connexion", {"email": E["ad"], "mot_de_passe": pw})
    col = lambda cb, c: sql(f"SELECT {c} FROM commande_boutiques WHERE id={cb}")

    def commander():
        tok = C.token("produits"); C.req("panier/ajouter", {"csrf": tok, "produit_id": prod, "quantite": 1, "retour": "/jend/produits"})
        _, _, hd = C.post("commande", {"nom": "Cliente T27", "telephone": "78 000 11 27", "zone_id": zone, "adresse": "Rue 27 Touba", "methode": "wave"})
        ref = hd["Location"].rsplit("/", 1)[-1]
        sql(f"UPDATE commandes SET statut_paiement='paye', statut='confirmee' WHERE reference='{ref}'")
        cb = int(sql(f"SELECT cb.id FROM commande_boutiques cb JOIN commandes c ON c.id=cb.commande_id WHERE c.reference='{ref}'"))
        return ref, cb
    bouton = "J'ai bien reçu ma commande"
    voir = lambda cl, ref: cl.get(f"commande/{ref}")[1].replace("&#039;", "'")

    S.titre("AVANT L'EXPÉDITION")
    ref, cb = commander()
    S.check("le bouton n'apparaît pas tant que le vendeur n'a pas expédié", bouton not in voir(C, ref))
    C.post(f"commande/{ref}", {"id": cb}, page_token=f"commande/{ref}")
    S.check("et on ne peut pas le forcer par une requête directe", col(cb, "statut") == "a_preparer")

    S.titre("APRÈS L'EXPÉDITION")
    VA.post("vendeur/commandes", {"id": cb, "numero_suivi": ""})
    S.check("expédiée : le client voit le bouton", col(cb, "statut") == "expediee" and bouton in voir(C, ref))
    S.check("un autre client ne voit pas la commande", C2.get(f"commande/{ref}")[0] == 404)
    C2.post(f"commande/{ref}", {"id": cb}, page_token="compte")
    S.check("un autre client ne peut pas confirmer à la place du client", col(cb, "statut") == "expediee")
    C.req(f"commande/{ref}", {"id": cb, "csrf": "faux"})
    S.check("sans jeton CSRF valide : refusé", col(cb, "statut") == "expediee")
    h = C.post(f"commande/{ref}", {"id": cb}, page_token=f"commande/{ref}")
    S.check("le client confirme : livraison « livrée », date enregistrée, commande terminée", col(cb, "statut") == "livree" and col(cb, "livre_le") != "NULL" and sql(f"SELECT statut FROM commandes WHERE reference='{ref}'") == "terminee")
    out, err = php('require "' + str(JEND / "includes") + '/env.php"; require "' + str(JEND / "includes") + '/db.php"; require "' + str(JEND / "includes") + '/parametres.php"; require "' + str(JEND / "includes") + '/vendeur.php"; echo vendeur_gains(' + sql("SELECT id FROM boutiques WHERE slug='boutique-a-t27'") + ')["credit"];')
    S.check("le vendeur est crédité (10 000 − 3 % + 500 de frais de livraison qu'il garde = 10 200)", out.strip() == "10200", out + err)
    S.check("le bouton disparaît ensuite", bouton not in voir(C, ref))
    C.post(f"commande/{ref}", {"id": cb}, page_token=f"commande/{ref}")
    S.check("une 2e confirmation est sans effet", col(cb, "statut") == "livree")

    S.titre("LIVRAISON PAR UN LIVREUR JËND : PAS DE BOUTON")
    sql("UPDATE boutiques SET livraison_par='jend' WHERE slug='boutique-a-t27'")
    ref2, cb2 = commander()
    AD.post("admin/courses", {"id": cb2, "livreur_id": sql(f"SELECT id FROM users WHERE email='{E['lv']}'")})
    sql(f"UPDATE commande_boutiques SET statut='expediee' WHERE id={cb2}")
    S.check("avec un livreur Jënd, le bouton n'est pas proposé (le livreur confirme avec le code)", bouton not in voir(C, ref2))
    C.post(f"commande/{ref2}", {"id": cb2}, page_token=f"commande/{ref2}")
    S.check("et la confirmation directe est refusée", col(cb2, "statut") == "expediee")
finally:
    sql("DELETE FROM parametres WHERE cle='livreurs_jend'")
    ok = S.fin()
    sql("DELETE FROM produits WHERE slug IN ('produit-a-t27','produit-b-t27')"); sql("DELETE FROM boutiques WHERE slug IN ('boutique-a-t27','boutique-b-t27')")
    sql("DELETE FROM zones_livraison WHERE nom='Zone T27'")
sys.exit(0 if ok else 1)
