"""Étape 42 : la page « Livraison et retours » montre où livrent réellement les boutiques."""
import re, sys
from lib import *

S = Suite("Étape 42 — livraison selon les boutiques", ["va-t42@jend.local", "vb-t42@jend.local"])
E = dict(zip(["va", "vb"], S.emails))
try:
    S.nettoyer()
    sql("DELETE FROM boutiques WHERE slug IN ('touba-t42','dakar-t42')")
    pw = mot_de_passe()
    for k in ("va", "vb"):
        sql(f"INSERT INTO users (nom,email,mot_de_passe,role) VALUES ('Vendeur {k}','{E[k]}','{hash_mdp(pw)}','vendeur')")
    sql(f"INSERT INTO boutiques (user_id,nom,slug,statut) SELECT id,'Boutique Touba T42','touba-t42','active' FROM users WHERE email='{E['va']}'")
    sql(f"INSERT INTO boutiques (user_id,nom,slug,statut) SELECT id,'Boutique Dakar T42','dakar-t42','active' FROM users WHERE email='{E['vb']}'")
    sql("INSERT INTO boutique_regions (boutique_id, region) SELECT id, 'Touba' FROM boutiques WHERE slug='touba-t42'")
    sql("INSERT INTO boutique_regions (boutique_id, region) SELECT id, 'Dakar' FROM boutiques WHERE slug='dakar-t42'")
    sauve = sql("SELECT GROUP_CONCAT(id) FROM boutiques WHERE statut='active' AND slug NOT IN ('touba-t42','dakar-t42')")
    if sauve:
        sql(f"UPDATE boutiques SET statut='suspendue' WHERE id IN ({sauve})")       # seules nos deux boutiques sont actives pendant ce test
    h = Client().get("livraison-retours")[1].replace("&#039;", "'")
    def bloc(region):
        m = re.search(r'<details class="region-livraison"[^>]*><summary><b>' + re.escape(region) + r'</b>.*?</details>', h, flags=re.S)
        return m.group(0) if m else ""
    S.check("la page explique que chaque boutique livre elle-même et choisit ses villes", "chaque boutique livre elle-même" in h and "toutes les boutiques de votre panier livrent dans votre zone" in h)
    S.check("Touba : seule la boutique qui y livre est listée, avec un lien vers sa page", "Boutique Touba T42" in bloc("Touba") and "Boutique Dakar T42" not in bloc("Touba") and "/jend/boutique/touba-t42" in bloc("Touba"))
    S.check("Dakar : seule la boutique de Dakar", "Boutique Dakar T42" in bloc("Dakar") and "Boutique Touba T42" not in bloc("Dakar"))
    S.check("chaque ville montre le nombre de boutiques, les frais et le délai, et le détail des zones", "1 boutique" in bloc("Touba") and "FCFA" in bloc("Touba") and "Darou Marnane" in bloc("Touba"))
    S.check("les villes sans boutique sont listées à part (« Pas encore de boutique »)", "Pas encore de boutique qui livre à" in h and "Ziguinchor" in h.split("Pas encore de boutique qui livre à")[1])
    S.check("le bandeau du site n'annonce plus « tout le Sénégal » mais les villes réellement desservies", "Livraison à <strong>Dakar et Touba</strong>" in Client().get("")[1])
    sql("DELETE FROM boutique_regions WHERE boutique_id=(SELECT id FROM boutiques WHERE slug='dakar-t42')")
    S.check("une boutique qui livre partout couvre toutes les villes : « tout le Sénégal » revient", "Livraison à <strong>tout le Sénégal</strong>" in Client().get("")[1])
    if sauve:
        sql(f"UPDATE boutiques SET statut='active' WHERE id IN ({sauve})")
finally:
    ok = S.fin()
    sql("DELETE FROM boutiques WHERE slug IN ('touba-t42','dakar-t42')")
sys.exit(0 if ok else 1)
