"""Étape 25 : caisse des livreurs (espèces à remettre) et dette de commission des vendeurs (blocage des commandes en espèces)."""
import json, sys
from lib import *

S = Suite("Étape 25 — caisse livreurs et dette de commission", ["ad-t25@jend.local", "cl-t25@jend.local", "va-t25@jend.local", "vb-t25@jend.local", "lv-t25@jend.local"])
E = dict(zip(["ad", "cl", "va", "vb", "lv"], S.emails))
INC = JEND / "includes"
PRIX, FRAIS = 10000, 1001
col = lambda cb, c: sql(f"SELECT {c} FROM commande_boutiques WHERE id={cb}")
def gains(slug):
    bid = sql(f"SELECT id FROM boutiques WHERE slug='{slug}'")
    out, err = php(f'require "{INC}/env.php"; require "{INC}/db.php"; require "{INC}/parametres.php"; require "{INC}/vendeur.php"; echo json_encode(vendeur_gains({bid}));')
    assert not err, err
    return json.loads(out)
def especes(uid):
    out, err = php(f'require "{INC}/env.php"; require "{INC}/db.php"; require "{INC}/livreur.php"; echo json_encode(livreur_especes({uid}));')
    assert not err, err
    return json.loads(out)
try:
    S.nettoyer()
    sql("REPLACE INTO parametres (cle, valeur) VALUES ('livreurs_jend', '1')")
    sql("DELETE FROM produits WHERE slug IN ('produit-a-t25','produit-b-t25')"); sql("DELETE FROM boutiques WHERE slug IN ('boutique-a-t25','boutique-b-t25')")
    sql("DELETE FROM zones_livraison WHERE nom='Zone T25'")
    sql(f"INSERT INTO zones_livraison (nom, region, frais, delai_jours) VALUES ('Zone T25', 'Touba', {FRAIS}, 1)")
    zone = int(sql("SELECT id FROM zones_livraison WHERE nom='Zone T25'"))
    pw = mot_de_passe()
    for k, nom, role in (("ad", "Admin T25", "admin"), ("va", "Vendeur A", "vendeur"), ("vb", "Vendeur B", "vendeur")):
        sql(f"INSERT INTO users (nom,email,mot_de_passe,role) VALUES ('{nom}','{E[k]}','{hash_mdp(pw)}','{role}')")
    sql(f"INSERT INTO users (nom,email,telephone,mot_de_passe,role) VALUES ('Livreur T25','{E['lv']}','+221775556677','{hash_mdp(pw)}','livreur')")
    sql(f"INSERT INTO livreurs (user_id) SELECT id FROM users WHERE email='{E['lv']}'")
    for k, slug, mode, pct in (("va", "boutique-a-t25", "vendeur", 90), ("vb", "boutique-b-t25", "jend", 10)):
        sql(f"INSERT INTO boutiques (user_id,nom,slug,statut,commission_pct,livraison_par) SELECT id,'{slug}','{slug}','active',{pct},'{mode}' FROM users WHERE email='{E[k]}'")
        sql(f"INSERT INTO produits (boutique_id,categorie_id,nom,slug,description,prix,stock,statut) SELECT b.id,(SELECT MIN(id) FROM categories),'Produit {k}','produit-{k[1]}-t25','x',{PRIX},80,'publie' FROM boutiques b WHERE b.slug='{slug}'")
    pa, pb = (int(sql(f"SELECT id FROM produits WHERE slug='produit-{x}-t25'")) for x in "ab")
    AD, C, VA, L = Client(), Client(), Client(), Client()
    C.post("inscription", {"nom": "Cliente T25", "email": E["cl"], "mot_de_passe": pw, "mot_de_passe2": pw})
    AD.post("connexion", {"email": E["ad"], "mot_de_passe": pw}); VA.post("connexion", {"email": E["va"], "mot_de_passe": pw})
    L.post("livreur/connexion", {"email": E["lv"], "mot_de_passe": pw})
    lid = int(sql(f"SELECT id FROM users WHERE email='{E['lv']}'"))
    cbs = lambda ref: [int(x) for x in sql(f"SELECT cb.id FROM commande_boutiques cb JOIN commandes c ON c.id=cb.commande_id WHERE c.reference='{ref}' ORDER BY cb.id").split()]
    def commander(prod):
        tok = C.token("produits"); C.req("panier/ajouter", {"csrf": tok, "produit_id": prod, "quantite": 1, "retour": "/jend/produits"})
        s, h, hd = C.post("commande", {"nom": "Client T25", "telephone": "78 000 11 22", "zone_id": zone, "adresse": "Rue 25", "methode": "livraison", "acompte_methode": "wave"})
        return s, h, hd

    S.titre("CAISSE DES LIVREURS")
    S.check("livreur sans course : rien à remettre", especes(lid) == {"encaisse": 0, "remis": 0, "a_remettre": 0})
    s, _, hd = commander(pb); ref = hd["Location"].rsplit("/", 1)[-1]; (cb,) = cbs(ref)
    sql(f"UPDATE commandes SET statut_paiement='acompte', statut='confirmee' WHERE reference='{ref}'")
    AD.post("admin/courses", {"id": cb, "livreur_id": lid})
    for act in ("recuperer", "en_route"):
        L.post(f"livreur/course/{cb}", {"action": act})
    L.post(f"livreur/course/{cb}", {"action": "livrer", "code": col(cb, "code_livraison")})
    attendu = int(sql(f"SELECT sous_total + frais_part - acompte_part FROM commande_boutiques WHERE id={cb}"))
    e = especes(lid)
    S.check(f"après livraison : encaissé = reste à payer ({attendu}), rien remis", col(cb, "statut") == "livree" and attendu > 0 and e["encaisse"] == attendu and e["a_remettre"] == attendu, str(e))
    S.check("le livreur voit « à remettre à Jënd » sur son accueil", "à remettre à Jënd" in L.get("livreur")[1])
    S.check("page Caisse réservée à l'admin", C.get("admin/caisse")[0] in (302, 403, 404) and "Espèces par livreur" in AD.get("admin/caisse")[1])
    AD.post("admin/caisse", {"action": "remise", "livreur_id": lid, "montant": attendu + 1})
    S.check("remise supérieure au dû refusée", sql("SELECT COUNT(*) FROM caisse_livreurs") == "0")
    for mauvais in ("0", "-5", "abc", "1,5", ""):
        AD.post("admin/caisse", {"action": "remise", "livreur_id": lid, "montant": mauvais})
    S.check("montants invalides refusés", sql("SELECT COUNT(*) FROM caisse_livreurs") == "0")
    C.post("admin/caisse", {"action": "remise", "livreur_id": lid, "montant": 1000}, page_token="compte")
    S.check("un client ne peut rien enregistrer", sql("SELECT COUNT(*) FROM caisse_livreurs") == "0")
    AD.post("admin/caisse", {"action": "remise", "livreur_id": lid, "montant": 1000, "note": "Remise 1"})
    e = especes(lid)
    S.check("remise de 1 000 : reste à remettre diminué", e["remis"] == 1000 and e["a_remettre"] == attendu - 1000, str(e))
    S.check("l'opération est journalisée", int(sql("SELECT COUNT(*) FROM journal_admin WHERE action='caisse_remise'")) == 1)
    rid = sql("SELECT id FROM caisse_livreurs LIMIT 1")
    AD.post("admin/caisse", {"action": "annuler", "id": rid})
    S.check("annulation de la remise : on revient au total dû", especes(lid)["a_remettre"] == attendu and sql("SELECT COUNT(*) FROM caisse_livreurs") == "0")
    AD.post("admin/caisse", {"action": "remise", "livreur_id": lid, "montant": attendu})
    S.check("tout remis : plus rien à remettre", especes(lid)["a_remettre"] == 0)
    S.check("la trésorerie s'ouvre sans erreur", "Trésorerie" in AD.get("admin/tresorerie")[1])

    S.titre("DETTE DE COMMISSION DU VENDEUR")
    sql("REPLACE INTO parametres (cle, valeur) VALUES ('dette_commission_max', '5000')")
    s, _, hd = commander(pa); ref = hd["Location"].rsplit("/", 1)[-1]; (cba,) = cbs(ref)
    S.check("sans dette : la commande en espèces passe", s == 302)
    sql(f"UPDATE commandes SET statut_paiement='acompte', statut='confirmee' WHERE reference='{ref}'")
    VA.post("vendeur/commandes", {"id": cba, "numero_suivi": ""}); VA.post("vendeur/commandes", {"id": cba, "code_livraison": col(cba, "code_livraison")})
    g = gains("boutique-a-t25")
    S.check("commission 90 % sur espèces : le vendeur doit plus qu'il n'a de crédit → dette, solde 0", col(cba, "statut") == "livree" and g["dette"] > 5000 and g["solde"] == 0, str(g))
    S.check("« Vous devez à Jënd » affiché dans Mes gains", "Vous devez à Jënd" in VA.get("vendeur/gains")[1])
    s, h, _ = commander(pa)
    S.check("dette au-dessus du plafond : paiement à la livraison refusé", s == 200 and "pas disponible" in h.replace("&#039;", "'") and sql(f"SELECT COUNT(*) FROM commandes c JOIN users u ON u.id=c.client_id WHERE u.email='{E['cl']}'") == "2")
    s, _, hd = C.post("commande", {"nom": "Client T25", "telephone": "78 000 11 22", "zone_id": zone, "adresse": "Rue 25", "methode": "wave"})
    S.check("le paiement en ligne reste possible", s == 302)
    AD.post("admin/parametres", {"action": "dette", "maximum": "0"})
    tok = C.token("produits"); C.req("panier/ajouter", {"csrf": tok, "produit_id": pa, "quantite": 1, "retour": "/jend/produits"})
    s, _, hd = C.post("commande", {"nom": "Client T25", "telephone": "78 000 11 22", "zone_id": zone, "adresse": "Rue 25", "methode": "livraison", "acompte_methode": "wave"})
    S.check("plafond à 0 : blocage désactivé", s == 302)
    for mauvais in ("-1", "abc", "1,5", ""):
        AD.post("admin/parametres", {"action": "dette", "maximum": mauvais})
    S.check("plafond invalide refusé (valeur conservée)", sql("SELECT valeur FROM parametres WHERE cle='dette_commission_max'") == "0")
finally:
    sql("DELETE FROM parametres WHERE cle IN ('livreurs_jend','dette_commission_max')")
    ok = S.fin()
    sql("DELETE FROM produits WHERE slug IN ('produit-a-t25','produit-b-t25')"); sql("DELETE FROM boutiques WHERE slug IN ('boutique-a-t25','boutique-b-t25')")
    sql("DELETE FROM zones_livraison WHERE nom='Zone T25'")
    sql("DELETE FROM journal_admin WHERE action IN ('caisse_remise','caisse_remise_annulee','dette_max_modifiee')")
sys.exit(0 if ok else 1)
