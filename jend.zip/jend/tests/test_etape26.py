"""Étape 26 : durcissement avant production (mots de passe, commandes jamais payées, essais de mot de passe)."""
import sys
from lib import *

S = Suite("Étape 26 — durcissement", ["cl-t26@jend.local", "va-t26@jend.local", "faible-t26@jend.local", "fort-t26@jend.local"])
E = dict(zip(["cl", "va", "faible", "fort"], S.emails))
try:
    S.nettoyer()
    sql("DELETE FROM produits WHERE slug='produit-t26'"); sql("DELETE FROM boutiques WHERE slug='boutique-t26'")
    sql("DELETE FROM zones_livraison WHERE nom='Zone T26'")
    sql("INSERT INTO zones_livraison (nom, region, frais, delai_jours) VALUES ('Zone T26', 'Touba', 500, 1)")
    zone = int(sql("SELECT id FROM zones_livraison WHERE nom='Zone T26'"))
    pw = mot_de_passe()
    sql(f"INSERT INTO users (nom,email,mot_de_passe,role) VALUES ('Vendeur T26','{E['va']}','{hash_mdp(pw)}','vendeur')")
    sql(f"INSERT INTO boutiques (user_id,nom,slug,statut,commission_pct) SELECT id,'Boutique T26','boutique-t26','active',0 FROM users WHERE email='{E['va']}'")
    sql("INSERT INTO produits (boutique_id,categorie_id,nom,slug,description,prix,stock,statut) SELECT b.id,(SELECT MIN(id) FROM categories),'Produit T26','produit-t26','x',5000,30,'publie' FROM boutiques b WHERE b.slug='boutique-t26'")
    prod = int(sql("SELECT id FROM produits WHERE slug='produit-t26'"))
    stock = lambda: int(sql("SELECT stock FROM produits WHERE slug='produit-t26'"))

    S.titre("MOTS DE PASSE")
    for faible in ("12345678", "password123", "Court1", "x" * 73):      # (5 inscriptions par heure et par IP : on en garde une pour le mot de passe solide)
        Client().post("inscription", {"nom": "Faible T26", "email": E["faible"], "mot_de_passe": faible, "mot_de_passe2": faible, "accepte": "1"})
    S.check("mots de passe faibles, trop courts ou trop longs refusés à l'inscription", sql(f"SELECT COUNT(*) FROM users WHERE email='{E['faible']}'") == "0")
    Client().post("inscription", {"nom": "Fort T26", "email": E["fort"], "mot_de_passe": "Zebre-47-lune", "mot_de_passe2": "Zebre-47-lune", "accepte": "1"})
    S.check("un mot de passe solide est accepté", sql(f"SELECT COUNT(*) FROM users WHERE email='{E['fort']}'") == "1")

    S.titre("CHANGEMENT DE MOT DE PASSE : ESSAIS LIMITÉS")
    F = Client()
    F.post("connexion", {"email": E["fort"], "mot_de_passe": "Zebre-47-lune"})
    for _ in range(5):
        F.post("compte/profil", {"action": "mdp", "actuel": "mauvais", "nouveau": "Nouveau-91-pluie", "nouveau2": "Nouveau-91-pluie"}, page_token="compte/profil")
    h = F.post("compte/profil", {"action": "mdp", "actuel": "Zebre-47-lune", "nouveau": "Nouveau-91-pluie", "nouveau2": "Nouveau-91-pluie"}, page_token="compte/profil")[1]
    S.check("après 5 essais ratés, même le bon mot de passe actuel est refusé (15 min)", "Trop d" in h and Client().post("connexion", {"email": E["fort"], "mot_de_passe": "Nouveau-91-pluie"})[0] == 200)

    S.titre("COMMANDES JAMAIS PAYÉES")
    C = Client()
    C.post("connexion", {"email": E["fort"], "mot_de_passe": "Zebre-47-lune"})
    def commander():
        tok = C.token("produits"); C.req("panier/ajouter", {"csrf": tok, "produit_id": prod, "quantite": 1, "retour": "/jend/produits"})
        return C.post("commande", {"nom": "Fort T26", "telephone": "78 000 11 26", "zone_id": zone, "adresse": "Rue 26 Touba", "methode": "wave"})
    refs = []
    for _ in range(5):
        s, _, hd = commander(); refs.append(hd["Location"].rsplit("/", 1)[-1])
    S.check("5 commandes en attente de paiement : acceptées, stock réservé (30 → 25)", stock() == 25 and len(refs) == 5)
    s, h, _ = commander()
    S.check("la 6e est refusée : réglez ou annulez d'abord", s == 200 and "5 commandes en attente" in h and stock() == 25)
    sql(f"UPDATE commandes SET created_at = NOW() - INTERVAL 50 HOUR WHERE reference='{refs[0]}'")
    sql("DELETE FROM limites WHERE cle LIKE 'maintenance:%'")
    C.get("panier")
    S.check("une commande non payée depuis 48 h est annulée et son stock remis (25 → 26)", sql(f"SELECT statut FROM commandes WHERE reference='{refs[0]}'") == "annulee" and stock() == 26)
    S.check("les commandes plus récentes ne sont pas touchées", sql(f"SELECT COUNT(*) FROM commandes WHERE reference IN ('{refs[1]}','{refs[2]}') AND statut='en_attente'") == "2")
    sql(f"UPDATE commandes SET statut_paiement='paye', statut='confirmee', created_at = NOW() - INTERVAL 60 HOUR WHERE reference='{refs[1]}'")
    sql("DELETE FROM limites WHERE cle LIKE 'maintenance:%'")
    C.get("panier")
    S.check("une commande payée n'expire jamais", sql(f"SELECT statut FROM commandes WHERE reference='{refs[1]}'") == "confirmee" and stock() == 26)
finally:
    ok = S.fin()
    sql("DELETE FROM produits WHERE slug='produit-t26'"); sql("DELETE FROM boutiques WHERE slug='boutique-t26'")
    sql("DELETE FROM zones_livraison WHERE nom='Zone T26'"); sql("DELETE FROM limites WHERE cle LIKE 'maintenance:%' OR cle LIKE 'mdp-compte:%' OR cle LIKE 'commande:%'")
sys.exit(0 if ok else 1)
