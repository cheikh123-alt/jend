"""Étape 21 : paiement PayDunya (faux serveur PayDunya local : création de facture, confirmation, IPN, retour du client)."""
import http.server, json, re, socket, subprocess, sys, threading, urllib.parse
from lib import *

S = Suite("Étape 21 — PayDunya", ["cl-t21@jend.local", "cl2-t21@jend.local"])
E = S.emails
CLES = {"master": "test_master_KEY_0123456789", "private": "test_private_KEY_0123456789", "token": "test_token_KEY_0123456789"}
FACTURES, APPELS, REGLAGES = {}, [], {"statut": "pending", "montant": None, "ref": None, "mute": False}


class FauxPayDunya(http.server.BaseHTTPRequestHandler):
    def log_message(self, *a): pass

    def _cles_ok(self):
        return (self.headers.get("PAYDUNYA-MASTER-KEY"), self.headers.get("PAYDUNYA-PRIVATE-KEY"), self.headers.get("PAYDUNYA-TOKEN")) == (CLES["master"], CLES["private"], CLES["token"])

    def _rep(self, obj, code=200):
        corps = json.dumps(obj).encode(); self.send_response(code); self.send_header("Content-Type", "application/json"); self.send_header("Content-Length", str(len(corps))); self.end_headers(); self.wfile.write(corps)

    def do_POST(self):
        n = int(self.headers.get("Content-Length") or 0); corps = json.loads(self.rfile.read(n) or b"{}")
        APPELS.append(("POST", self.path, dict(self.headers), corps))
        if not self._cles_ok():
            return self._rep({"response_code": "1001", "response_text": "Clés invalides"}, 401)
        tok = "tok" + str(len(FACTURES) + 1).zfill(5) + "abcdef"
        FACTURES[tok] = {"montant": corps["invoice"]["total_amount"], "ref": corps["custom_data"]["commande"], "statut": "pending"}
        self._rep({"response_code": "00", "response_text": f"http://127.0.0.1:{PORT}/checkout/{tok}", "description": "Redirection", "token": tok})

    def do_GET(self):
        APPELS.append(("GET", self.path, dict(self.headers), None))
        tok = self.path.rsplit("/", 1)[-1]
        if not self._cles_ok() or tok not in FACTURES:
            return self._rep({"response_code": "1002", "response_text": "Facture introuvable"}, 404)
        f = FACTURES[tok]
        self._rep({"response_code": "00", "status": REGLAGES["statut"] if REGLAGES["statut"] != "auto" else f["statut"],
                   "invoice": {"total_amount": REGLAGES["montant"] if REGLAGES["montant"] is not None else f["montant"]},
                   "custom_data": {"commande": REGLAGES["ref"] or f["ref"]}, "hash": "x"})


s = socket.socket(); s.bind(("127.0.0.1", 0)); PORT = s.getsockname()[1]; s.close()
serveur = http.server.ThreadingHTTPServer(("127.0.0.1", PORT), FauxPayDunya)
threading.Thread(target=serveur.serve_forever, daemon=True).start()

def ipn(token, hash_ok=True, **extra):
    h = __import__("hashlib").sha512(CLES["master"].encode()).hexdigest() if hash_ok else "0" * 128
    champs = {"data[hash]": h, "data[invoice][token]": token, "data[status]": "completed", **extra}
    return Client().req("paiement/webhook", dict(champs))

try:
    S.nettoyer()
    sql("DELETE FROM produits WHERE slug='produit-t21'"); sql("DELETE FROM boutiques WHERE slug='boutique-t21'")
    pw = mot_de_passe()
    sql(f"INSERT INTO users (nom,email,mot_de_passe,role) VALUES ('Vendeur T21','{E[1]}','{hash_mdp(pw)}','vendeur')")
    sql(f"INSERT INTO boutiques (user_id,nom,slug,statut,commission_pct) SELECT id,'Boutique T21','boutique-t21','active',0 FROM users WHERE email='{E[1]}'")
    sql("INSERT INTO produits (boutique_id,categorie_id,nom,slug,description,prix,stock,statut) SELECT b.id,(SELECT MIN(id) FROM categories),'Produit T21','produit-t21','x',20000,50,'publie' FROM boutiques b WHERE b.slug='boutique-t21'")
    prod = int(sql("SELECT id FROM produits WHERE slug='produit-t21'"))
    S.modifier_env(PAIEMENT_FOURNISSEUR="paydunya", PAYDUNYA_MODE="test", PAYDUNYA_MASTER_KEY=CLES["master"], PAYDUNYA_PRIVATE_KEY=CLES["private"], PAYDUNYA_TOKEN=CLES["token"],
                   PAYDUNYA_API_BASE=f"http://127.0.0.1:{PORT}/v1", APP_URL=BASE.rstrip("/"))
    C = Client(); C.post("inscription", {"nom": "Cliente T21", "email": E[0], "mot_de_passe": pw, "mot_de_passe2": pw})
    C2 = Client(); C2.post("inscription", {"nom": "Autre T21", "email": "autre-t21@jend.local", "mot_de_passe": pw, "mot_de_passe2": pw})
    etat = lambda ref: sql(f"SELECT CONCAT(statut,'|',statut_paiement) FROM commandes WHERE reference='{ref}'")
    cmd = lambda ref, c: sql(f"SELECT {c} FROM commandes WHERE reference='{ref}'")
    def payer(ref, c=None):
        c = c or C; REGLAGES.update(statut="pending", montant=None, ref=None)
        s, _, hd = c.post("paiement/" + ref, {}, page_token="commande/" + ref)
        return s, hd.get("Location", "")
    def commande(methode="wave", qte=1):
        tok = C.token("produits"); C.req("panier/ajouter", {"csrf": tok, "produit_id": prod, "quantite": qte, "retour": "/jend/produits"})
        s, _, hd = C.post("commande", {"nom": "Cliente T21", "telephone": "78 000 11 22", "zone_id": zones_actives_ids()[0], "adresse": "Rue 21", "methode": methode, "acompte_methode": "wave"})
        return hd["Location"].rsplit("/", 1)[-1]

    S.titre("DÉMARRAGE DU PAIEMENT : FACTURE PAYDUNYA")
    ref = commande(); total = int(cmd(ref, "total"))
    s, loc = payer(ref)
    S.check("le client est envoyé vers la page de paiement PayDunya (adresse reçue de l'API)", s == 302 and re.fullmatch(rf"http://127\.0\.0\.1:{PORT}/checkout/tok\d{{5}}abcdef", loc) is not None, loc)
    tok = loc.rsplit("/", 1)[-1]
    post = next(a for a in APPELS if a[0] == "POST")
    S.check("les 3 clés partent dans les en-têtes (jamais dans le corps ni dans l'adresse)", post[2].get("PAYDUNYA-MASTER-KEY") == CLES["master"] and post[2].get("PAYDUNYA-PRIVATE-KEY") == CLES["private"] and post[2].get("PAYDUNYA-TOKEN") == CLES["token"] and CLES["private"] not in json.dumps(post[3]) and CLES["private"] not in post[1])
    S.check("le montant de la facture est celui calculé par le SITE (pas celui du navigateur)", post[3]["invoice"]["total_amount"] == total and total == 20000 + int(sql(f"SELECT frais FROM zones_livraison WHERE id={zones_actives_ids()[0]}")))
    S.check("adresses de retour, d'annulation et de notification (IPN) transmises", post[3]["actions"]["return_url"].endswith("/paiement/retour/" + ref) and post[3]["actions"]["cancel_url"].endswith("/paiement/retour/" + ref) and post[3]["actions"]["callback_url"].endswith("/paiement/webhook") and post[3]["custom_data"]["commande"] == ref)
    S.check("la tentative est enregistrée (fournisseur paydunya, jeton, montant)", sql(f"SELECT CONCAT(p.fournisseur,'|',p.reference_externe,'|',p.montant,'|',p.statut) FROM paiements p JOIN commandes c ON c.id=p.commande_id WHERE c.reference='{ref}'") == f"paydunya|{tok}|{total}|initie")
    S.check("la politique de sécurité autorise la redirection vers PayDunya (et seulement elle)", "https://app.paydunya.com" in C.get("panier")[2].get("Content-Security-Policy", "") and "default-src 'self'" in C.get("panier")[2].get("Content-Security-Policy", ""))
    S.check("la page de paiement simulé n'existe plus quand PayDunya est le fournisseur", C.get("paiement/simulation/SIM-" + "a" * 24)[0] == 404)

    S.titre("NOTIFICATION IPN : AUTHENTIFICATION PAR LE HASH")
    s, _, _ = ipn(tok, hash_ok=False)
    S.check("hash invalide → 401, commande non payée", s == 401 and etat(ref) == "en_attente|en_attente")
    S.check("notification sans données → refusée", Client().req("paiement/webhook", {"x": "1"})[0] in (400, 401, 415))
    REGLAGES.update(statut="pending")
    s, h, _ = ipn(tok)
    S.check("hash valide mais PayDunya répond « pending » : toujours pas payée", s == 200 and etat(ref) == "en_attente|en_attente")
    REGLAGES.update(statut="completed", montant=1000)
    s, h, _ = ipn(tok)
    S.check("« completed » mais pour un montant différent : REFUSÉ, rien n'est payé", s == 400 and etat(ref) == "en_attente|en_attente")
    REGLAGES.update(statut="completed", montant=None, ref="JND-AUTRE-0000")
    s, h, _ = ipn(tok)
    S.check("facture rattachée à une autre commande (custom_data) : refusée", s == 400 and etat(ref) == "en_attente|en_attente")
    REGLAGES.update(statut="completed", ref=None)
    s, h, _ = ipn(tok, **{"data[invoice][total_amount]": "1", "data[status]": "cancelled"})
    S.check("l'IPN ne dicte ni le montant ni le statut : seule la réponse de l'API compte (completed + bon montant) → payée", s == 200 and etat(ref) == "confirmee|paye")
    S.check("paiement enregistré « reussi » avec preuve brute ; une notification rejouée est ignorée", sql(f"SELECT p.statut FROM paiements p JOIN commandes c ON c.id=p.commande_id WHERE c.reference='{ref}'") == "reussi" and json.loads(ipn(tok)[1])["message"] == "Déjà traité")
    S.check("l'appel de confirmation a bien été fait avec les clés (vérification serveur à serveur)", any(a[0] == "GET" and a[1].endswith("/confirm/" + tok) and a[2].get("PAYDUNYA-PRIVATE-KEY") == CLES["private"] for a in APPELS))

    S.titre("RETOUR DU CLIENT : VÉRIFICATION SANS IPN (hébergements qui bloquent les appels entrants)")
    ref2 = commande(); s, loc2 = payer(ref2); tok2 = loc2.rsplit("/", 1)[-1]
    REGLAGES.update(statut="pending")
    h = C.get("paiement/retour/" + ref2)[1]
    S.check("retour tant que PayDunya répond « pending » : « en cours de vérification », pas payée", "en cours de vérification" in h and etat(ref2) == "en_attente|en_attente")
    h = C.get("paiement/retour/" + ref2 + "?token=" + tok2 + "&status=completed")[1]
    S.check("un retour truqué (?status=completed) ne paie rien", etat(ref2) == "en_attente|en_attente" and "Paiement reçu" not in h)
    REGLAGES.update(statut="completed")
    h = C.get("paiement/retour/" + ref2)[1]
    S.check("PayDunya confirme « completed » : la page de retour constate le paiement (serveur à serveur) et la commande est confirmée", "Paiement reçu" in h and etat(ref2) == "confirmee|paye")
    S.check("un autre client ne peut pas déclencher ni voir cette vérification (404)", C2.get("paiement/retour/" + ref2)[0] == 404)

    S.titre("ÉCHEC, ANNULATION, NOUVELLE TENTATIVE")
    ref3 = commande(); s, loc3 = payer(ref3); tok3 = loc3.rsplit("/", 1)[-1]
    REGLAGES.update(statut="cancelled")
    h = C.get("paiement/retour/" + ref3)[1]
    S.check("paiement annulé / refusé chez PayDunya : « Paiement refusé », bouton pour réessayer", "refusé" in h and "Réessayer" in h and etat(ref3) == "en_attente|echoue")
    REGLAGES.update(statut="pending")
    s, loc3b = payer(ref3)
    S.check("réessayer crée une NOUVELLE facture (nouveau jeton) et abandonne la précédente", s == 302 and loc3b != loc3 and sql(f"SELECT COUNT(*) FROM paiements p JOIN commandes c ON c.id=p.commande_id WHERE c.reference='{ref3}' AND p.statut='echoue'") == "1")
    REGLAGES.update(statut="completed")
    S.check("2e tentative réussie : commande payée", "Paiement reçu" in C.get("paiement/retour/" + ref3)[1] and etat(ref3) == "confirmee|paye")

    S.titre("COMMANDE À LA LIVRAISON : L'ACOMPTE PASSE PAR PAYDUNYA")
    ref4 = commande("livraison"); acompte = int(cmd(ref4, "acompte"))
    s, loc4 = payer(ref4); tok4 = loc4.rsplit("/", 1)[-1]
    S.check("la facture PayDunya porte le montant de l'ACOMPTE (pas le total)", acompte > 0 and FACTURES[tok4]["montant"] == acompte and acompte < int(cmd(ref4, "total")))
    REGLAGES.update(statut="completed"); ipn(tok4)
    S.check("acompte payé : statut « acompte », commande confirmée ; le reste se paie en espèces", etat(ref4) == "confirmee|acompte")

    S.titre("L'ADMIN PEUT VÉRIFIER LES PAIEMENTS RESTÉS EN ATTENTE")
    sql(f"INSERT INTO users (nom,email,mot_de_passe,role) VALUES ('Admin T21','ad-t21@jend.local','{hash_mdp(pw)}','admin')")
    AD = Client(); AD.post("connexion", {"email": "ad-t21@jend.local", "mot_de_passe": pw})
    ref6 = commande(); s, loc6 = payer(ref6)
    REGLAGES.update(statut="completed")          # le client a payé chez PayDunya puis fermé son navigateur, l'IPN n'est jamais arrivée
    h = AD.get("admin/commandes?vue=attente")[1]
    S.check("la vue « Paiements PayDunya en attente » liste la commande", ref6 in h and "Tout vérifier" in h)
    S.check("un client ne peut pas utiliser cette action", C.post("admin/commandes", {"action": "verifier_paydunya", "id": 0}, page_token="compte")[0] in (302, 404) and etat(ref6) == "en_attente|en_attente")
    AD.post("admin/commandes", {"action": "verifier_paydunya", "id": 0}, page_token="admin/commandes?vue=attente")
    S.check("« Tout vérifier » interroge PayDunya : la commande payée est confirmée", etat(ref6) == "confirmee|paye" and ref6 not in AD.get("admin/commandes?vue=attente")[1])
    S.check("l'action est tracée dans le journal", int(sql("SELECT COUNT(*) FROM journal_admin WHERE action='paydunya_verification'")) == 1)

    S.titre("PANNES ET MAUVAISE CONFIGURATION : MESSAGES CLAIRS, JAMAIS D'ERREUR")
    ref5 = commande()
    S.modifier_env(PAIEMENT_FOURNISSEUR="paydunya", PAYDUNYA_MODE="test", PAYDUNYA_MASTER_KEY="", PAYDUNYA_PRIVATE_KEY=CLES["private"], PAYDUNYA_TOKEN=CLES["token"], PAYDUNYA_API_BASE=f"http://127.0.0.1:{PORT}/v1", APP_URL=BASE.rstrip("/"))
    s, hd = payer(ref5)
    S.check("clé manquante : retour à la commande avec un message, aucune erreur PHP", s == 302 and "commande/" + ref5 in hd and "momentanément indisponible" in C.get("commande/" + ref5)[1])
    S.modifier_env(PAIEMENT_FOURNISSEUR="paydunya", PAYDUNYA_MODE="test", PAYDUNYA_MASTER_KEY="mauvaise", PAYDUNYA_PRIVATE_KEY=CLES["private"], PAYDUNYA_TOKEN=CLES["token"], PAYDUNYA_API_BASE=f"http://127.0.0.1:{PORT}/v1", APP_URL=BASE.rstrip("/"))
    s, hd = payer(ref5)
    S.check("clés refusées par PayDunya : message, rien n'est enregistré", s == 302 and "commande/" + ref5 in hd and sql(f"SELECT COUNT(*) FROM paiements p JOIN commandes c ON c.id=p.commande_id WHERE c.reference='{ref5}' AND p.reference_externe IS NOT NULL") == "0")
    S.modifier_env(PAIEMENT_FOURNISSEUR="paydunya", PAYDUNYA_MODE="test", PAYDUNYA_MASTER_KEY=CLES["master"], PAYDUNYA_PRIVATE_KEY=CLES["private"], PAYDUNYA_TOKEN=CLES["token"], PAYDUNYA_API_BASE="http://127.0.0.1:9/v1", APP_URL=BASE.rstrip("/"))
    s, hd = payer(ref5)
    S.check("PayDunya injoignable : message d'attente, commande intacte, aucune erreur affichée", s == 302 and "commande/" + ref5 in hd and etat(ref5) == "en_attente|en_attente")
    S.check("retour du client pendant la panne : page normale (pas d'erreur)", C.get("paiement/retour/" + ref5)[0] == 200)

    S.titre("RÈGLES DE SÉCURITÉ DE LA CONFIGURATION")
    def php_env(**v):
        import tempfile, os
        f = tempfile.NamedTemporaryFile("w", suffix=".env", delete=False); f.write("".join(f"{k}={x}\n" for k, x in v.items())); f.close()
        out, err = php(f'require "{JEND}/includes/env.php"; require "{JEND}/includes/helpers.php"; require "{JEND}/includes/paiement.php"; require "{JEND}/includes/paydunya.php"; echo paydunya_base();', {"JEND_ENV_FILE": f.name})
        os.unlink(f.name); return out
    S.check("mode test : API « sandbox » officielle", php_env(APP_ENV="prod", PAYDUNYA_MODE="test") == "https://app.paydunya.com/sandbox-api/v1")
    S.check("mode live : API de production officielle", php_env(APP_ENV="prod", PAYDUNYA_MODE="live") == "https://app.paydunya.com/api/v1")
    S.check("PAYDUNYA_API_BASE n'est JAMAIS prise en compte hors développement (impossible de détourner les paiements)", php_env(APP_ENV="prod", PAYDUNYA_MODE="live", PAYDUNYA_API_BASE="http://pirate.example/x") == "https://app.paydunya.com/api/v1")
    import tempfile, os
    def verifier(**v):
        f = tempfile.NamedTemporaryFile("w", suffix=".env", delete=False); f.write("APP_ENV=prod\nAPP_URL=https://jend.example.test\nPAIEMENT_FOURNISSEUR=paydunya\n" + "".join(f"{k}={x}\n" for k, x in v.items())); f.close()
        r = subprocess.run([PHP, str(JEND / "scripts/verifier-production.php"), f"--env={f.name}"], capture_output=True, text=True); os.unlink(f.name); return r.stdout
    sortie = verifier(PAYDUNYA_MASTER_KEY="a", PAYDUNYA_PRIVATE_KEY="b")
    S.check("vérificateur de production : une clé PayDunya manquante est bloquante (PAYDUNYA_TOKEN cité)", "clé(s) manquante(s) : PAYDUNYA_TOKEN" in sortie)
    sortie = verifier(PAYDUNYA_MASTER_KEY="a", PAYDUNYA_PRIVATE_KEY="b", PAYDUNYA_TOKEN="c", PAYDUNYA_MODE="test", PAYDUNYA_API_BASE="http://x")
    S.check("… mode « test » signalé, et PAYDUNYA_API_BASE défini refusé en production", "PAYDUNYA_MODE n'est pas" in sortie and "PAYDUNYA_API_BASE est défini" in sortie)
    sortie = verifier(PAYDUNYA_MASTER_KEY="a", PAYDUNYA_PRIVATE_KEY="b", PAYDUNYA_TOKEN="c", PAYDUNYA_MODE="live")
    S.check("… 3 clés + mode live : PayDunya validé", "les 3 clés sont renseignées" in sortie and "mode LIVE" in sortie)
finally:
    serveur.shutdown()
    sql("DELETE FROM produits WHERE slug='produit-t21'")
    ok = S.fin()
    sql("DELETE FROM boutiques WHERE slug='boutique-t21'"); sql("DELETE FROM users WHERE email IN ('autre-t21@jend.local','ad-t21@jend.local')"); sql("DELETE FROM journal_admin WHERE action='paydunya_verification'")
sys.exit(0 if ok else 1)
