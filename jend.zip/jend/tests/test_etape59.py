"""Étape 59 : bilan de sécurité — double protection des dossiers internes, archives de mise en ligne, et site de TEST
(paiements simulés) clairement signalé jusque dans l'e-mail du vendeur et le message WhatsApp du client."""
import sys, re, os, time, urllib.parse
from lib import *

S = Suite("Étape 59 — bilan de sécurité", ["ve-t59@jend.local", "cl-t59@jend.local"])
E = dict(zip(["ve", "cl"], S.emails))
try:
    S.nettoyer()

    S.titre("DOSSIERS INTERNES : DOUBLE PROTECTION")
    for d in ("storage", "includes", "pages", "database", "scripts", "tests"):
        f = JEND / d / ".htaccess"
        S.check(f"{d}/.htaccess interdit tout accès depuis Internet", f.exists() and "Require all denied" in f.read_text() and "Deny from all" in f.read_text())
    arch = (JEND / "scripts" / "archive-production.sh").read_text()
    ftp = (JEND / "scripts" / "preparer-dossier-ftp.sh").read_text()
    S.check("l'archive de production et le dossier FTP emportent storage/.htaccess (storage/ est vidé)", "cp storage/.htaccess" in arch and "cp storage/.htaccess" in ftp)
    for chemin in ("storage/app-key.txt", "storage/vapid-prive.pem", "includes/env.php", "database/schema.sql", "scripts/sauvegarde.php", "config.env", "deploiement/infinityfree.env"):
        S.check(f"/{chemin} : inaccessible", Client().get(chemin)[0] in (403, 404))

    S.titre("SITE DE TEST : PAIEMENTS SIMULÉS SIGNALÉS PARTOUT")
    S.modifier_env(APP_ENV="test", APP_KEY="t59-" + "a" * 40, PAIEMENT_SECRET=secret_paiement())
    h = Client().get("")[1]
    S.check("bandeau « SITE DE TEST — aucun paiement réel » sur toutes les pages", "SITE DE TEST" in h and "aucun paiement réel" in h)
    sql("DELETE FROM zones_livraison WHERE nom='Zone T59'")
    sql("INSERT INTO zones_livraison (nom, region, frais, delai_jours) VALUES ('Zone T59', 'Louga', 1000, 1)")
    zone = sql("SELECT id FROM zones_livraison WHERE nom='Zone T59'")
    pw = mot_de_passe()
    sql(f"INSERT INTO users (nom,email,mot_de_passe,role,email_verifie) VALUES ('Vendeur T59','{E['ve']}','{hash_mdp(pw)}','vendeur',1)")
    sql(f"INSERT INTO boutiques (user_id,nom,slug,statut,commission_pct,contact_whatsapp) SELECT id,'Boutique T59','boutique-t59','active',0,'771234559' FROM users WHERE email='{E['ve']}'")
    sql("INSERT INTO produits (boutique_id,categorie_id,nom,slug,prix,stock,statut) SELECT b.id,(SELECT MIN(id) FROM categories),'Sac T59','sac-t59',9000,10,'publie' FROM boutiques b WHERE b.slug='boutique-t59'")
    pid = sql("SELECT id FROM produits WHERE slug='sac-t59'")
    C = Client()
    C.post("inscription", {"nom": "Client T59", "email": E["cl"], "telephone": "", "mot_de_passe": "Wax-Louga-2026!", "mot_de_passe2": "Wax-Louga-2026!", "accepte": "1"})
    C.req("panier/ajouter", {"csrf": C.token("produits"), "produit_id": pid, "quantite": 1, "retour": "/jend/produits"})
    _, _, hd = C.post("commande", {"nom": "Client T59", "telephone": "77 123 45 60", "zone_id": zone, "adresse": "Rue 59 Louga", "methode": "wave"})
    ref = hd.get("Location", "").rsplit("/", 1)[-1]
    LOG = JEND / "storage" / "emails.log"
    avant = LOG.read_text() if LOG.exists() else ""
    sql(f"UPDATE commandes SET statut_paiement='paye', statut='confirmee' WHERE reference='{ref}'")
    rappel = JEND / "storage" / "depenses-rappel.txt"
    rappel.touch(); os.utime(rappel, (time.time() - 7200, time.time() - 7200))
    Client().get("")
    nouveaux = (LOG.read_text() if LOG.exists() else "")[len(avant):]
    S.check("e-mail au vendeur : sujet « [SITE DE TEST] » et « paiement SIMULÉ… Ne livrez rien »", f"[SITE DE TEST] Nouvelle commande à préparer : {ref}" in nouveaux and "Ne livrez rien" in nouveaux, nouveaux[-500:])
    h = C.get("commande/" + ref)[1].replace("&amp;", "&")
    m = re.search(r'href="https://wa\.me/221771234559\?text=([^"]+)"', h)
    S.check("message WhatsApp du client : « SITE DE TEST : paiement simulé, ne rien livrer »", m is not None and "SITE DE TEST : paiement simulé" in urllib.parse.unquote(m.group(1)))
    S.restaurer_env()
    S.check("hors site de test : pas de mention (vrai paiement)", "SITE DE TEST" not in urllib.parse.unquote(re.search(r'text=([^"]+)"', C.get("commande/" + ref)[1].replace("&amp;", "&")).group(1)))
finally:
    S.restaurer_env()
    sql("DELETE FROM produits WHERE slug='sac-t59'")
    S.nettoyer()
    sql("DELETE FROM zones_livraison WHERE nom='Zone T59'")
    ok = S.fin()
sys.exit(0 if ok else 1)
