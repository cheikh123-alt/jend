"""Lance tous les tests de bout en bout, l'un après l'autre, et affiche un bilan.   python3 tests/run_all.py"""
import subprocess, sys
from pathlib import Path

ici = Path(__file__).parent
resultats = []
for nom in sorted(ici.glob("test_etape*.py")):
    r = subprocess.run([sys.executable, str(nom)], capture_output=True, text=True)
    derniere = [l for l in r.stdout.splitlines() if "vérifications réussies" in l]
    resultats.append((nom.name, r.returncode == 0, derniere[-1].strip() if derniere else (r.stderr.strip().splitlines() or ["(aucun résultat)"])[-1]))
    print(("✔" if r.returncode == 0 else "✘"), nom.name, "—", resultats[-1][2], flush=True)
    if r.returncode != 0:
        print(r.stdout[-3000:])
sys.exit(0 if all(ok for _, ok, _ in resultats) else 1)
