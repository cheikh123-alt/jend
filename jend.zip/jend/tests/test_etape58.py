"""Étape 58 : prévenir le vendeur d'une nouvelle commande même s'il n'est pas connecté — notification sur le téléphone (Web Push chiffré
et signé, vérifié avec un faux service de notification), e-mail, rattrapage, et page « Relances » de l'équipe (WhatsApp / appel)."""
import sys, re, json, base64, threading, time, os, tempfile, urllib.parse
from http.server import BaseHTTPRequestHandler, HTTPServer
from lib import *

S = Suite("Étape 58 — prévenir le vendeur", ["ad-t58@jend.local", "ve-t58@jend.local", "cl-t58@jend.local"])
E = dict(zip(["ad", "ve", "cl"], S.emails))

# ---------- Faux service de notification (comme fcm.googleapis.com) : garde chaque envoi reçu ----------
RECUS, REPONSE = [], {"code": 201}
class Faux(BaseHTTPRequestHandler):
    def do_POST(self):
        corps = self.rfile.read(int(self.headers.get("Content-Length", 0)))
        RECUS.append({"chemin": self.path, "entetes": dict(self.headers), "corps": corps})
        self.send_response(REPONSE["code"]); self.end_headers()
    def log_message(self, *a): pass
faux = HTTPServer(("127.0.0.1", 0), Faux)
threading.Thread(target=faux.serve_forever, daemon=True).start()
PORT = faux.server_address[1]
ENDPOINT = f"http://127.0.0.1:{PORT}/fcm/send/appareil-t58"

b64 = lambda b: base64.urlsafe_b64encode(b).rstrip(b"=").decode()
TMP = Path(tempfile.mkdtemp(prefix="jend-push-"))
# Clés du « téléphone » (comme celles que crée le navigateur)
out, err = php("$k = openssl_pkey_new(['private_key_type' => OPENSSL_KEYTYPE_EC, 'curve_name' => 'prime256v1']); openssl_pkey_export($k, $pem); $d = openssl_pkey_get_details($k);"
               f"file_put_contents('{TMP}/ua.pem', $pem); echo bin2hex(\"\\x04\" . str_pad($d['ec']['x'], 32, \"\\0\", STR_PAD_LEFT) . str_pad($d['ec']['y'], 32, \"\\0\", STR_PAD_LEFT));")
assert not err, err
UA_PUB = b64(bytes.fromhex(out)); AUTH = b64(os.urandom(16))

def dechiffrer(corps):
    """Ce que fait le téléphone (RFC 8291), écrit ici indépendamment du code du site."""
    (TMP / "corps.bin").write_bytes(corps)
    code = (f"$c = file_get_contents('{TMP}/corps.bin'); $ua = openssl_pkey_get_private(file_get_contents('{TMP}/ua.pem'));"
            "$d64 = fn($t) => base64_decode(strtr($t, '-_', '+/') . str_repeat('=', (4 - strlen($t) % 4) % 4));"
            f"$uaPub = $d64('{UA_PUB}'); $auth = $d64('{AUTH}');"
            "$sel = substr($c, 0, 16); $n = ord($c[20]); $as = substr($c, 21, $n); $ct = substr($c, 21 + $n);"
            "$pem = \"-----BEGIN PUBLIC KEY-----\\n\" . chunk_split(base64_encode(hex2bin('3059301306072a8648ce3d020106082a8648ce3d030107034200') . $as), 64, \"\\n\") . \"-----END PUBLIC KEY-----\\n\";"
            "$s = str_pad(openssl_pkey_derive(openssl_pkey_get_public($pem), $ua, 32), 32, \"\\0\", STR_PAD_LEFT);"
            "$ikm = hash_hmac('sha256', \"WebPush: info\\0\" . $uaPub . $as . \"\\x01\", hash_hmac('sha256', $s, $auth, true), true);"
            "$prk = hash_hmac('sha256', $ikm, $sel, true);"
            "$cek = substr(hash_hmac('sha256', \"Content-Encoding: aes128gcm\\0\\x01\", $prk, true), 0, 16);"
            "$iv = substr(hash_hmac('sha256', \"Content-Encoding: nonce\\0\\x01\", $prk, true), 0, 12);"
            "$p = openssl_decrypt(substr($ct, 0, -16), 'aes-128-gcm', $cek, OPENSSL_RAW_DATA, $iv, substr($ct, -16));"
            "echo $p === false ? 'ECHEC' : rtrim($p, \"\\x02\");")
    o, e = php(code)
    return json.loads(o) if o.startswith("{") else {"erreur": o + e}

def vapid_valide(autorisation, aud):
    """Vérifie la signature du site (VAPID, RFC 8292) avec la clé publique annoncée."""
    m = re.match(r"vapid t=([^,]+), k=(\S+)$", autorisation or "")
    if not m:
        return False, "format"
    jeton, k = m.groups()
    h, c, sig = jeton.split(".")
    pad = lambda t: t + "=" * (-len(t) % 4)
    entete, charge = json.loads(base64.urlsafe_b64decode(pad(h))), json.loads(base64.urlsafe_b64decode(pad(c)))
    if entete.get("alg") != "ES256" or charge.get("aud") != aud or charge.get("exp", 0) < time.time() or not str(charge.get("sub", "")).startswith("mailto:"):
        return False, (entete, charge)
    o, e = php("$d64 = fn($t) => base64_decode(strtr($t, '-_', '+/') . str_repeat('=', (4 - strlen($t) % 4) % 4));"
               f"$sig = $d64('{sig}'); $k = $d64('{k}');"
               "$int = function ($v) { $v = ltrim($v, \"\\0\"); if (ord($v[0]) > 127) { $v = \"\\0\" . $v; } return \"\\x02\" . chr(strlen($v)) . $v; };"
               "$der = $int(substr($sig, 0, 32)) . $int(substr($sig, 32)); $der = \"\\x30\" . chr(strlen($der)) . $der;"
               "$pem = \"-----BEGIN PUBLIC KEY-----\\n\" . chunk_split(base64_encode(hex2bin('3059301306072a8648ce3d020106082a8648ce3d030107034200') . $k), 64, \"\\n\") . \"-----END PUBLIC KEY-----\\n\";"
               f"echo openssl_verify('{h}.{c}', $der, openssl_pkey_get_public($pem), OPENSSL_ALGO_SHA256);")
    return o == "1", o + e

try:
    S.nettoyer()
    sql("DELETE FROM zones_livraison WHERE nom='Zone T58'")
    sql("INSERT INTO zones_livraison (nom, region, frais, delai_jours) VALUES ('Zone T58', 'Kaolack', 1000, 1)")
    zone = int(sql("SELECT id FROM zones_livraison WHERE nom='Zone T58'"))
    pw = mot_de_passe()
    for k, nom, role in (("ad", "Admin T58", "admin"), ("ve", "Fatou Vendeuse", "vendeur")):
        sql(f"INSERT INTO users (nom,email,mot_de_passe,role,email_verifie,telephone) VALUES ('{nom}','{E[k]}','{hash_mdp(pw)}','{role}',1,'771234558')")
    sql(f"INSERT INTO boutiques (user_id,nom,slug,statut,commission_pct,mode_simple) SELECT id,'Boutique T58','boutique-t58','active',0,1 FROM users WHERE email='{E['ve']}'")
    bid = sql("SELECT id FROM boutiques WHERE slug='boutique-t58'")
    vid = sql(f"SELECT id FROM users WHERE email='{E['ve']}'")
    sql(f"INSERT INTO produits (boutique_id,categorie_id,nom,slug,prix,stock,statut) VALUES ({bid},(SELECT MIN(id) FROM categories),'Boubou bazin T58','boubou-t58',15000,50,'publie')")
    pid = sql("SELECT id FROM produits WHERE slug='boubou-t58'")
    AD, VE, C = Client(), Client(), Client()
    AD.post("connexion", {"email": E["ad"], "mot_de_passe": pw}); VE.post("connexion", {"email": E["ve"], "mot_de_passe": pw})
    C.post("inscription", {"nom": "Client T58", "email": E["cl"], "telephone": "", "mot_de_passe": "Wax-Kaolack-2026!", "mot_de_passe2": "Wax-Kaolack-2026!", "accepte": "1"})
    LOG = JEND / "storage" / "emails.log"
    mails = lambda: LOG.read_text() if LOG.exists() else ""

    def commander(qte, methode="wave"):
        C.req("panier/ajouter", {"csrf": C.token("produits"), "produit_id": pid, "quantite": qte, "retour": "/jend/produits"})
        _, _, hd = C.post("commande", {"nom": "Client T58", "telephone": "77 123 45 59", "zone_id": zone, "adresse": "Rue 58 Kaolack", "methode": methode, "acompte_methode": "wave"})
        return hd.get("Location", "").rsplit("/", 1)[-1]

    S.titre("PAR DÉFAUT : BOUTON RETIRÉ, NOTIFICATIONS COUPÉES")
    h = VE.get("simple")[1]
    S.check("sans réglage : aucun bouton « Être prévenu » ni script de notification (accueil simple, commandes, espace complet)",
            all('data-push=' not in VE.get(u)[1] and "notifications.js" not in VE.get(u)[1] for u in ("simple", "simple/commandes", "vendeur", "vendeur/commandes")))
    S.check("… et l'enregistrement d'un téléphone est refusé", VE.req("notifications/push", {"csrf": VE.token("simple"), "action": "abonner", "endpoint": ENDPOINT, "p256dh": UA_PUB, "auth": AUTH})[0] == 503)
    RECUS.clear(); avant = mails()
    ref0 = commander(1)
    sql(f"UPDATE commandes SET statut_paiement='paye', statut='confirmee' WHERE reference='{ref0}'")
    (JEND / "storage" / "depenses-rappel.txt").touch(); os.utime(JEND / "storage" / "depenses-rappel.txt", (time.time() - 7200, time.time() - 7200)); Client().get("")
    nouveaux = mails()[len(avant):]
    S.check("une commande payée prévient quand même le vendeur par e-mail (sans parler de notifications)", ref0 in nouveaux and "Être prévenu des commandes" not in nouveaux and len(RECUS) == 0)
    S.modifier_env(PUSH_TEST_ENDPOINT="http://127.0.0.1:", NOTIFICATIONS_TELEPHONE="1")          # réglage pour un hébergement payant

    S.titre("CHIFFREMENT CONFORME À LA NORME (RFC 8291)")
    o, e = php("function env($k, $d = null) { return $d; } require '%s/includes/push.php';"
               "$pem = \"-----BEGIN EC PRIVATE KEY-----\\n\" . chunk_split(base64_encode(hex2bin('30770201010420') . b64url_lire('yfWPiYE-n46HLnH0KqZOF1fJJU3MYrct3AELtAQ-oRw') . hex2bin('a00a06082a8648ce3d030107a144034200') . b64url_lire('BP4z9KsN6nGRTbVYI_c7VJSPQTBtkgcy27mlmlMoZIIgDll6e3vCYLocInmYWAmS6TlzAC8wEqKK6PBru3jl7A8')), 64, \"\\n\") . \"-----END EC PRIVATE KEY-----\\n\";"
               "echo b64url(push_chiffrer('When I grow up, I want to be a watermelon', 'BCVxsr7N_eNgVRqvHtD0zTZsEc6-VV-JvLexhqUzORcxaOzi6-AYWXvTBHm4bjyPjs7Vd8pZGH6SRpkNtoIAiw4', 'BTBZMqHH6r4Tts7J_aSIgg', openssl_pkey_get_private($pem), b64url_lire('DGv6ra1nlYgDCS1FRnbzlw')));" % JEND)
    S.check("message chiffré identique à l'exemple officiel de la norme RFC 8291", o == "DGv6ra1nlYgDCS1FRnbzlwAAEABBBP4z9KsN6nGRTbVYI_c7VJSPQTBtkgcy27mlmlMoZIIgDll6e3vCYLocInmYWAmS6TlzAC8wEqKK6PBru3jl7A_yl95bQpu6cVPTpK4Mqgkf1CXztLVBSt2Ks3oZwbuwXPXLWyouBWLVWGNWQexSgSxsj_Qulcy4a-fN", o + e)

    S.titre("BOUTON « ÊTRE PRÉVENU DES COMMANDES »")
    h = VE.get("simple")[1]
    S.check("accueil simple : bloc de notification (clé publique du site, grand bouton) + script", 'data-push="' in h and "push-bloc-grand" in h and "notifications.js" in h and "Être prévenu des commandes" in h)
    cle_site = re.search(r'data-push="([^"]+)"', h).group(1)
    S.check("clé publique du site : point P-256 de 65 octets", len(base64.urlsafe_b64decode(cle_site + "=" * (-len(cle_site) % 4))) == 65)
    S.check("la clé privée du site est dans storage/ (dossier interdit depuis Internet)", (JEND / "storage" / "vapid-prive.pem").exists() and Client().get("storage/vapid-prive.pem")[0] in (403, 404))
    S.check("aussi sur « Mes commandes » et dans l'espace complet", 'data-push="' in VE.get("simple/commandes")[1] and 'data-push="' in VE.get("vendeur/commandes")[1])
    sw = Client().get("sw.js")[1]
    S.check("sw.js affiche la notification et ouvre la bonne page au toucher (même site seulement)", "addEventListener('push'" in sw and "showNotification" in sw and "notificationclick" in sw and "cible.origin !== self.location.origin" in sw)

    S.titre("ENREGISTRER LE TÉLÉPHONE")
    ab = lambda cl, **d: cl.req("notifications/push", {"csrf": cl.token("simple" if cl is VE else "compte"), "action": "abonner", "endpoint": ENDPOINT, "p256dh": UA_PUB, "auth": AUTH, **d})
    st, corps, _ = VE.req("notifications/push", {"action": "abonner", "endpoint": ENDPOINT, "p256dh": UA_PUB, "auth": AUTH})
    S.check("sans jeton de sécurité : refusé", st == 403)
    S.check("non connecté : refusé", Client().req("notifications/push", {"csrf": "x", "action": "abonner"})[0] in (401, 403))
    st, corps, _ = ab(VE, endpoint="https://pirate.example.com/collecte")
    S.check("adresse qui n'est pas un service de notification : refusée (le serveur n'envoie jamais n'importe où)", st == 422 and sql(f"SELECT COUNT(*) FROM push_abonnements WHERE user_id={vid}") == "0")
    st, corps, _ = ab(VE, endpoint="http://fcm.googleapis.com/x")
    S.check("service connu mais sans https : refusé", st == 422)
    st, corps, _ = ab(VE, p256dh="AAAA")
    S.check("clés invalides : refusées", st == 422)
    st, corps, _ = ab(VE)
    S.check("téléphone enregistré", st == 200 and json.loads(corps)["ok"] and sql(f"SELECT COUNT(*) FROM push_abonnements WHERE user_id={vid}") == "1")
    ab(VE)
    S.check("enregistrer deux fois le même téléphone : une seule ligne", sql(f"SELECT COUNT(*) FROM push_abonnements WHERE user_id={vid}") == "1")

    S.titre("NOTIFICATION D'ESSAI : CHIFFRÉE ET SIGNÉE")
    RECUS.clear()
    st, corps, _ = VE.req("notifications/push", {"csrf": VE.token("simple"), "action": "tester"})
    S.check("« Tester » : une notification envoyée", st == 200 and json.loads(corps)["envoyes"] == 1 and len(RECUS) == 1, corps)
    r = RECUS[0] if RECUS else {"entetes": {}, "corps": b""}
    S.check("en-têtes du standard : aes128gcm, durée de vie, urgence haute", r["entetes"].get("Content-Encoding") == "aes128gcm" and r["entetes"].get("TTL") == "86400" and r["entetes"].get("Urgency") == "high")
    ok, detail = vapid_valide(r["entetes"].get("Authorization"), f"http://127.0.0.1:{PORT}")
    S.check("signature du site (VAPID) valide, pour ce service, avec la clé publique du site", ok and r["entetes"].get("Authorization", "").endswith("k=" + cle_site), detail)
    msg = dechiffrer(r["corps"])
    S.check("le téléphone déchiffre : « 🔔 Ça marche ! », lien vers « Mes commandes » (mode simple)", msg.get("titre") == "🔔 Ça marche !" and msg.get("url", "").endswith("/simple/commandes"), msg)
    S.check("le contenu n'est pas lisible en clair par le service de notification", b"marche" not in r["corps"])

    S.titre("NOUVELLE COMMANDE PAYÉE EN LIGNE")
    RECUS.clear(); avant = mails()
    ref = commander(2)
    cb = sql(f"SELECT cb.id FROM commande_boutiques cb JOIN commandes c ON c.id=cb.commande_id WHERE c.reference='{ref}'")
    S.check("pas encore payée : personne n'est prévenu", len(RECUS) == 0 and ref not in mails()[len(avant):] and sql(f"SELECT vendeur_prevenu_le IS NULL FROM commande_boutiques WHERE id={cb}") == "1")
    C.post("paiement/" + ref, {}, page_token="commande/" + ref)
    pref = sql(f"SELECT p.reference_externe FROM paiements p JOIN commandes c ON c.id=p.commande_id WHERE c.reference='{ref}' AND p.statut='initie'")
    webhook(pref, "reussi", int(sql(f"SELECT montant FROM paiements WHERE reference_externe='{pref}'")))
    msg = dechiffrer(RECUS[0]["corps"]) if RECUS else {}
    S.check("paiement reçu : le téléphone du vendeur reçoit « 🛍️ Nouvelle commande ! — 2 × Boubou bazin T58 · Zone T58 »",
            len(RECUS) == 1 and msg.get("titre") == "🛍️ Nouvelle commande !" and "2 × Boubou bazin T58" in msg.get("texte", "") and "Zone T58" in msg.get("texte", ""), msg)
    S.check("toucher la notification ouvre « Mes commandes » du mode simple", msg.get("url", "").endswith("/simple/commandes"))
    nouveaux = mails()[len(avant):]
    S.check("e-mail au vendeur : référence, articles, livraison, montant, lien", E["ve"] in nouveaux and f"Nouvelle commande à préparer : {ref}" in nouveaux and "2 × Boubou bazin T58" in nouveaux and "Vous recevrez 31 000 FCFA" in nouveaux and "simple/commandes" in nouveaux, nouveaux[-600:])
    S.check("la commande est notée « vendeur prévenu »", sql(f"SELECT vendeur_prevenu_le IS NOT NULL FROM commande_boutiques WHERE id={cb}") == "1")
    RECUS.clear(); avant = mails()
    webhook(pref, "reussi", int(sql(f"SELECT montant FROM paiements WHERE reference_externe='{pref}'")))
    (JEND / "storage" / "depenses-rappel.txt").touch(); os.utime(JEND / "storage" / "depenses-rappel.txt", (time.time() - 7200, time.time() - 7200))
    Client().get("")                                   # tâches horaires (rattrapage) déclenchées par une visite
    S.check("notification de paiement en double + tâches horaires : le vendeur n'est pas prévenu deux fois", len(RECUS) == 0 and ref not in mails()[len(avant):])

    S.titre("PAIEMENT À LA LIVRAISON SANS ACOMPTE : PRÉVENU TOUT DE SUITE")
    sql("INSERT INTO parametres (cle, valeur) VALUES ('acompte_actif','0') ON DUPLICATE KEY UPDATE valeur='0'")
    RECUS.clear()
    ref2 = commander(1, "livraison")
    msg = dechiffrer(RECUS[0]["corps"]) if RECUS else {}
    S.check("commande à payer en espèces (sans acompte) : notification dès la commande", len(RECUS) == 1 and "1 × Boubou bazin T58" in msg.get("texte", ""), msg)
    S.check("e-mail : « Le client vous paiera … en espèces à la livraison »", "en espèces à la livraison" in mails() and ref2 in mails())
    sql("DELETE FROM parametres WHERE cle='acompte_actif'")

    S.titre("RATTRAPAGE : PAIEMENT VALIDÉ PAR UN AUTRE CHEMIN")
    RECUS.clear()
    ref3 = commander(3)
    sql(f"UPDATE commandes SET statut_paiement='paye', statut='confirmee' WHERE reference='{ref3}'")      # comme une validation manuelle
    os.utime(JEND / "storage" / "depenses-rappel.txt", (time.time() - 7200, time.time() - 7200))
    Client().get("")
    S.check("tâches horaires : le vendeur est prévenu quand même", len(RECUS) == 1 and "3 × Boubou bazin T58" in dechiffrer(RECUS[0]["corps"]).get("texte", ""))
    ref4 = commander(1)
    sql(f"UPDATE commandes SET statut_paiement='paye', statut='confirmee', created_at = NOW() - INTERVAL 3 DAY WHERE reference='{ref4}'")
    RECUS.clear(); os.utime(JEND / "storage" / "depenses-rappel.txt", (time.time() - 7200, time.time() - 7200)); Client().get("")
    S.check("jamais de notification pour une vieille commande (plus de 2 jours)", len(RECUS) == 0)

    S.titre("ÉCHEC D'ENVOI EXPLIQUÉ CLAIREMENT")
    REPONSE["code"] = 500
    st, corps, _ = VE.req("notifications/push", {"csrf": VE.token("simple"), "action": "tester"})
    S.check("le service répond une erreur : le vendeur voit le code et la cause", json.loads(corps)["ok"] is False and "a répondu « 500 »" in json.loads(corps)["message"], corps)
    REPONSE["code"] = 201
    import socket
    sk = socket.socket(); sk.bind(("127.0.0.1", 0)); ferme = sk.getsockname()[1]; sk.close()
    VE.req("notifications/push", {"csrf": VE.token("simple"), "action": "desabonner", "endpoint": ENDPOINT})
    ab(VE, endpoint=f"http://127.0.0.1:{ferme}/fcm/send/ferme")
    st, corps, _ = VE.req("notifications/push", {"csrf": VE.token("simple"), "action": "tester"})
    rep = json.loads(corps)
    S.check("service injoignable (connexions sortantes bloquées) : message « l'hébergeur bloque probablement les connexions sortantes »", "connexions sortantes" in rep["message"] and rep["envoyes"] == 0 and rep["ok"] is False, corps)
    ab(VE)
    st, corps, _ = VE.req("notifications/push", {"csrf": VE.token("simple"), "action": "tester"})
    S.check("un appareil joint, l'autre non : « envoyée à 1 appareil(s), mais pas à tous » avec la cause", "mais pas à tous" in json.loads(corps)["message"] and "connexions sortantes" in json.loads(corps)["message"], corps)
    VE.req("notifications/push", {"csrf": VE.token("simple"), "action": "desabonner", "endpoint": f"http://127.0.0.1:{ferme}/fcm/send/ferme"})
    S.check("diagnostic.php : section « Notifications sur le téléphone » (chiffrement, clé, services Google / Mozilla / Apple joignables)",
            "6 bis. Notifications sur le téléphone" in (JEND / "diagnostic.php").read_text() and "fcm.googleapis.com/fcm/send/diagnostic" in (JEND / "diagnostic.php").read_text())

    S.titre("APPAREIL DÉSABONNÉ")
    REPONSE["code"] = 410
    VE.req("notifications/push", {"csrf": VE.token("simple"), "action": "tester"})
    S.check("le service répond « 410 parti » : le téléphone est retiré de la liste", sql(f"SELECT COUNT(*) FROM push_abonnements WHERE user_id={vid}") == "0")
    REPONSE["code"] = 201
    ab(VE)
    VE.req("notifications/push", {"csrf": VE.token("simple"), "action": "desabonner", "endpoint": ENDPOINT})
    S.check("« désactiver » retire le téléphone", sql(f"SELECT COUNT(*) FROM push_abonnements WHERE user_id={vid}") == "0")

    S.titre("RELANCES PAR L'ÉQUIPE (WHATSAPP / APPEL)")
    cb3 = sql(f"SELECT cb.id FROM commande_boutiques cb JOIN commandes c ON c.id=cb.commande_id WHERE c.reference='{ref3}'")
    h = AD.get("admin/relances")[1]
    S.check("commande prévenue il y a quelques minutes : pas encore à relancer", ref3 not in h)
    sql(f"UPDATE commande_boutiques SET vendeur_prevenu_le = NOW() - INTERVAL 3 HOUR WHERE id={cb3}")
    h = AD.get("admin/relances")[1].replace("&amp;", "&")
    S.check("3 h sans envoi : la commande apparaît (boutique, vendeur, articles, attente, notifications non activées)",
            ref3 in h and "Boutique T58" in h and "3 × Boubou bazin T58" in h and "3 h" in h and "Notifications non activées" in h)
    liens = [urllib.parse.unquote(l) for l in re.findall(r'href="https://wa\.me/221771234558\?text=([^"]+)"', h)]
    texte = next((l for l in liens if ref3 in l), "")
    m = texte != ""
    S.check("bouton WhatsApp vers le vendeur avec le message déjà écrit (référence, articles, lien)", m and ref3 in texte and "Fatou" in texte and "simple/commandes" in texte, texte)
    S.check("bouton Appeler", 'href="tel:771234558"' in h)
    p1 = re.search(r'Relances <b class="pastille-onglet[^"]*"[^>]*>(\d+)</b>', AD.get("admin")[1])
    S.check("pastille rouge sur l'onglet « Relances » (commandes en retard, dont une vieille commande jamais prévenue)", p1 is not None and int(p1.group(1)) >= 1 and "en-retard" in p1.group(0))
    AD.post("admin/relances", {"id": cb3}, page_token="admin/relances")
    S.check("« C'est fait » : relance notée (date + journal)", sql(f"SELECT relance_le IS NOT NULL FROM commande_boutiques WHERE id={cb3}") == "1" and sql("SELECT COUNT(*) FROM journal_admin WHERE action='vendeur_relance'") != "0")
    p2 = re.search(r'Relances <b class="pastille-onglet[^"]*"[^>]*>(\d+)</b>', AD.get("admin")[1])
    S.check("relancé : la pastille baisse d'un, la ligne indique « relancé le »", (int(p2.group(1)) if p2 else 0) == int(p1.group(1)) - 1 and "relancé le" in AD.get("admin/relances")[1])
    S.check("réservé à l'équipe (vendeur et visiteur : page introuvable)", VE.get("admin/relances")[0] == 404 and Client().get("admin/relances")[0] in (302, 303, 404))
    VE.post("simple/commandes", {"id": cb3}, page_token="simple/commandes")
    S.check("le vendeur envoie le colis : la commande quitte les relances", ref3 not in AD.get("admin/relances")[1])

    S.titre("LE CLIENT PRÉVIENT LE VENDEUR SUR WHATSAPP")
    sql(f"UPDATE boutiques SET contact_whatsapp='771234558' WHERE id={bid}")
    ref5 = commander(2)
    h = C.get("commande/" + ref5)[1]
    S.check("commande pas encore payée : pas de bouton (le vendeur ne doit rien préparer)", "Prévenir Boutique T58 sur WhatsApp" not in h)
    sql(f"UPDATE commandes SET statut_paiement='paye', statut='confirmee' WHERE reference='{ref5}'")
    h = C.get("commande/" + ref5)[1].replace("&amp;", "&")
    m = re.search(r'href="https://wa\.me/221771234558\?text=([^"]+)"[^>]*>.*?Prévenir Boutique T58 sur WhatsApp', h, re.S)
    texte = urllib.parse.unquote(m.group(1)) if m else ""
    S.check("commande payée : gros bouton « Prévenir Boutique T58 sur WhatsApp » vers le numéro WhatsApp du vendeur", m is not None and "déjà écrit" in h)
    S.check("message déjà écrit : boutique, articles, référence, « déjà payée en ligne », zone, lien vers ses commandes",
            all(t in texte for t in ("Bonjour Boutique T58", "2 × Boubou bazin T58", ref5, "déjà payée en ligne", "Zone T58", "simple/commandes")), texte)
    cb5 = sql(f"SELECT cb.id FROM commande_boutiques cb JOIN commandes c ON c.id=cb.commande_id WHERE c.reference='{ref5}'")
    VE.post("simple/commandes", {"id": cb5}, page_token="simple/commandes")
    S.check("colis envoyé : le bouton disparaît", sql(f"SELECT statut FROM commande_boutiques WHERE id={cb5}") == "expediee" and "Prévenir Boutique T58" not in C.get("commande/" + ref5)[1])
    S.check("une autre personne ne voit pas la commande (ni le numéro)", Client().get("commande/" + ref5)[0] in (302, 303, 404) and VE.get("commande/" + ref5)[0] == 404)
    sql(f"UPDATE boutiques SET contact_whatsapp=NULL WHERE id={bid}")
    ref6 = commander(1); sql(f"UPDATE commandes SET statut_paiement='paye', statut='confirmee' WHERE reference='{ref6}'")
    S.check("vendeur sans numéro WhatsApp public : pas de bouton (son numéro de paiement n'est jamais montré)", "Prévenir Boutique T58" not in C.get("commande/" + ref6)[1] and "771234558" not in C.get("commande/" + ref6)[1])

    S.titre("RAPPEL « VOTRE NUMÉRO WHATSAPP ? » (BOUTIQUES DÉJÀ OUVERTES)")
    sql(f"UPDATE boutiques SET telephone_paiement='771234558' WHERE id={bid}")
    h = VE.get("simple")[1]
    S.check("sans numéro : rappel sur l'accueil, prérempli avec son numéro de paiement", "Votre numéro WhatsApp ?" in h and "vendeur/whatsapp" in h and 'value="771234558"' in h.replace(" ", ""))
    VE.req("vendeur/whatsapp", {"contact_whatsapp": "77 123 45 58"})
    S.check("sans jeton de sécurité : rien n'est enregistré", sql(f"SELECT contact_whatsapp IS NULL FROM boutiques WHERE id={bid}") == "1")
    VE.post("vendeur/whatsapp", {"contact_whatsapp": "123"}, page_token="simple")
    S.check("numéro invalide : refusé", sql(f"SELECT contact_whatsapp IS NULL FROM boutiques WHERE id={bid}") == "1")
    VE.post("vendeur/whatsapp", {"contact_whatsapp": "77 123 45 58"}, page_token="simple")
    S.check("numéro enregistré : le rappel disparaît, et le client voit maintenant le bouton WhatsApp",
            sql(f"SELECT contact_whatsapp IS NOT NULL FROM boutiques WHERE id={bid}") == "1" and "Votre numéro WhatsApp ?" not in VE.get("simple")[1] and "Prévenir Boutique T58 sur WhatsApp" in C.get("commande/" + ref6)[1])

    S.titre("OUVERTURE DE BOUTIQUE : « CE NUMÉRO EST AUSSI MON WHATSAPP »")
    h = C.get("vendre")[1]
    S.check("case cochée par défaut, expliquée", re.search(r'name="whatsapp" value="1"\s+checked', h) is not None and "Ce numéro est aussi mon WhatsApp" in h)
    C.post("vendre", {"nom": "Boutique Cliente T58", "description": "", "telephone": "78 765 43 21", "accepte": "1", "mode": "simple", "whatsapp": "1"})
    S.check("case cochée : le numéro devient le WhatsApp public de la boutique", sql(f"SELECT b.contact_whatsapp FROM boutiques b JOIN users u ON u.id=b.user_id WHERE u.email='{E['cl']}'") == sql(f"SELECT b.telephone_paiement FROM boutiques b JOIN users u ON u.id=b.user_id WHERE u.email='{E['cl']}'") != "NULL")
    sql(f"DELETE b FROM boutiques b JOIN users u ON u.id=b.user_id WHERE u.email='{E['cl']}'"); sql(f"UPDATE users SET role='client' WHERE email='{E['cl']}'")
    C.post("vendre", {"nom": "Boutique Cliente T58b", "description": "", "telephone": "78 765 43 21", "accepte": "1", "mode": "simple"})
    S.check("case décochée : aucun numéro WhatsApp public", sql(f"SELECT b.contact_whatsapp FROM boutiques b JOIN users u ON u.id=b.user_id WHERE u.email='{E['cl']}'") == "NULL")
    sql(f"DELETE b FROM boutiques b JOIN users u ON u.id=b.user_id WHERE u.email='{E['cl']}'")

    S.titre("MISE À JOUR DE LA BASE")
    mig = (JEND / "database" / "migrations" / "035_prevenir_vendeurs.sql").read_text()
    S.check("migration 035 : les commandes déjà passées sont marquées « prévenues » (aucune notification après coup)", "UPDATE commande_boutiques SET vendeur_prevenu_le = NOW()" in mig and "CREATE TABLE IF NOT EXISTS push_abonnements" in mig)
finally:
    faux.shutdown()
    sql("DELETE FROM parametres WHERE cle='acompte_actif'")
    sql("DELETE FROM produits WHERE slug='boubou-t58'")
    S.restaurer_env()
    S.nettoyer()
    sql("DELETE FROM zones_livraison WHERE nom='Zone T58'")
    ok = S.fin()
sys.exit(0 if ok else 1)
