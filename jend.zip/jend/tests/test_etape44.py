"""Étape 44 : frais de paiement sécurisé (client), protection des retraits, test des e-mails, pages d'erreur muettes."""
import json, re, sys
from lib import *

S = Suite("Étape 44 — risques financiers et retraits", ["ad-t44@jend.local", "cl-t44@jend.local", "va-t44@jend.local"])
E = dict(zip(["ad", "cl", "va"], S.emails))
LOG = lambda: (JEND / "storage" / "emails.log").read_text() if (JEND / "storage" / "emails.log").exists() else ""
INC = JEND / "includes"
try:
    S.nettoyer()
    sql("DELETE FROM produits WHERE slug='produit-t44'"); sql("DELETE FROM boutiques WHERE slug='boutique-t44'")
    sql("DELETE FROM zones_livraison WHERE nom='Zone T44'"); sql("DELETE FROM parametres WHERE cle IN ('frais_service_pct','frais_service_min','retrait_2fa')")
    sql("INSERT INTO zones_livraison (nom, region, frais, delai_jours) VALUES ('Zone T44', 'Touba', 1000, 1)")
    zone = int(sql("SELECT id FROM zones_livraison WHERE nom='Zone T44'"))
    pw = mot_de_passe()
    for k, nom, role in (("ad", "Admin T44", "admin"), ("cl", "Cliente T44", "client"), ("va", "Vendeur T44", "vendeur")):
        sql(f"INSERT INTO users (nom,email,mot_de_passe,role) VALUES ('{nom}','{E[k]}','{hash_mdp(pw)}','{role}')")
    sql(f"INSERT INTO boutiques (user_id,nom,slug,statut,commission_pct,telephone_paiement) SELECT id,'Boutique T44','boutique-t44','active',1,'+221771112233' FROM users WHERE email='{E['va']}'")
    sql("INSERT INTO produits (boutique_id,categorie_id,nom,slug,description,prix,stock,statut) SELECT b.id,(SELECT MIN(id) FROM categories),'Produit T44','produit-t44','x',10000,20,'publie' FROM boutiques b WHERE b.slug='boutique-t44'")
    prod = sql("SELECT id FROM produits WHERE slug='produit-t44'"); bid = sql("SELECT id FROM boutiques WHERE slug='boutique-t44'")
    AD, C, VA = Client(), Client(), Client()
    for cl, k in ((AD, "ad"), (C, "cl"), (VA, "va")):
        cl.post("connexion", {"email": E[k], "mot_de_passe": pw})
    txt = lambda cl, u: cl.get(u)[1].replace("&#039;", "'").replace(" ", " ").replace("&nbsp;", " ")
    def commander():
        C.req("panier/ajouter", {"csrf": C.token("produits"), "produit_id": prod, "quantite": 1, "retour": "/jend/produits"})
        _, _, hd = C.post("commande", {"nom": "Cliente T44", "telephone": "78 000 11 44", "zone_id": zone, "adresse": "Rue 44 Touba", "methode": "wave"})
        return hd["Location"].rsplit("/", 1)[-1]

    S.titre("FRAIS DE PAIEMENT SÉCURISÉ")
    ref = commander()
    S.check("par défaut (0 %) : aucun frais de service, total = produits + livraison", sql(f"SELECT CONCAT(frais_service,'|',total) FROM commandes WHERE reference='{ref}'") == "0|11000")
    for mauvais in ({"pct": "-1", "minimum": "0"}, {"pct": "25", "minimum": "0"}, {"pct": "abc", "minimum": "0"}, {"pct": "2", "minimum": "99999"}):
        AD.post("admin/parametres", {"action": "frais_service", **mauvais})
    S.check("valeurs invalides refusées (négatif, plus de 10 %, texte, minimum énorme)", sql("SELECT COUNT(*) FROM parametres WHERE cle='frais_service_pct'") == "0")
    C.post("admin/parametres", {"action": "frais_service", "pct": "9", "minimum": "0"}, page_token="compte")
    S.check("un client ne peut pas changer ce réglage", sql("SELECT COUNT(*) FROM parametres WHERE cle='frais_service_pct'") == "0")
    AD.post("admin/parametres", {"action": "frais_service", "pct": "2,5", "minimum": "200"})
    C.req("panier/ajouter", {"csrf": C.token("produits"), "produit_id": prod, "quantite": 1, "retour": "/jend/produits"})
    h = txt(C, "commande")
    S.check("la page de commande affiche « Paiement sécurisé » et le calcule par zone (2,5 % de 11 000 = 275)", "Paiement sécurisé" in h and f'value="{zone}" data-frais="1000" data-service="275"' in h)
    _, _, hd = C.post("commande", {"nom": "Cliente T44", "telephone": "78 000 11 44", "zone_id": zone, "adresse": "Rue 44 Touba", "methode": "wave"})
    ref2 = hd["Location"].rsplit("/", 1)[-1]
    S.check("la commande enregistre 275 de frais de service, total 11 275 ; le paiement demandé est de 11 275", sql(f"SELECT CONCAT(frais_service,'|',total) FROM commandes WHERE reference='{ref2}'") == "275|11275"
            and sql(f"SELECT p.montant FROM paiements p JOIN commandes c ON c.id=p.commande_id WHERE c.reference='{ref2}'") == "11275")
    S.check("le récapitulatif de la commande montre la ligne « Paiement sécurisé »", "Paiement sécurisé" in txt(C, f"commande/{ref2}"))
    S.check("le vendeur n'en touche rien : sa part reste 10 000 − 1 % + 1 000 de livraison", sql(f"SELECT CONCAT(cb.sous_total,'|',cb.commission,'|',cb.frais_part) FROM commande_boutiques cb JOIN commandes c ON c.id=cb.commande_id WHERE c.reference='{ref2}'") == "10000|100|1000")
    S.check("les CGV préviennent le client de ces frais", "frais de paiement sécurisé" in txt(C, "cgv"))
    AD.post("admin/parametres", {"action": "frais_service", "pct": "0", "minimum": "0"})

    S.titre("PROTECTION DES RETRAITS")
    sql(f"UPDATE commande_boutiques cb JOIN commandes c ON c.id=cb.commande_id SET cb.statut='livree', cb.livre_le=NOW()-INTERVAL 10 DAY, c.statut_paiement='paye', c.statut='terminee' WHERE c.reference IN ('{ref}','{ref2}')")
    avant = len(LOG())
    VA.post("vendeur/boutique", {"nom": "Boutique T44", "description": "", "telephone": "77 999 88 77", "offres_actives": "1"}, page_token="vendeur/boutique")
    S.check("changer le numéro de paiement : date enregistrée et e-mail de contrôle au vendeur", sql(f"SELECT telephone_modifie_le IS NOT NULL FROM boutiques WHERE id={bid}") == "1" and "Numéro de paiement modifié" in LOG()[avant:] and E["va"] in LOG()[avant:])
    h = VA.post("vendeur/gains", {"montant": "5000", "methode": "wave"}, page_token="vendeur/gains")[1].replace("&#039;", "'")
    S.check("retrait refusé pendant 48 h après le changement de numéro", "suspendus" in h and sql(f"SELECT COUNT(*) FROM retraits WHERE boutique_id={bid}") == "0")
    sql(f"UPDATE boutiques SET telephone_modifie_le = NOW() - INTERVAL 3 DAY WHERE id={bid}")
    h = txt(AD, "admin/retraits")
    avant = len(LOG())
    VA.post("vendeur/gains", {"montant": "5000", "methode": "wave"}, page_token="vendeur/gains")
    S.check("après 48 h, le retrait passe, et un e-mail de contrôle part au vendeur", sql(f"SELECT COUNT(*) FROM retraits WHERE boutique_id={bid}") == "1" and "Demande de retrait de 5 000" in LOG()[avant:].replace(" ", " "))
    S.check("la page Retraits de l'admin signale « Numéro changé » (moins de 7 jours)", "Numéro changé le" in txt(AD, "admin/retraits"))
    AD.post("admin/parametres", {"action": "retrait_2fa", "actif": "1"})
    h = VA.post("vendeur/gains", {"montant": "5000", "methode": "wave"}, page_token="vendeur/gains")[1].replace("&#039;", "'")
    S.check("avec l'option « 2FA obligatoire pour retirer », un vendeur sans 2FA est refusé", "double authentification" in h and sql(f"SELECT COUNT(*) FROM retraits WHERE boutique_id={bid}") == "1")

    S.titre("E-MAILS ET SERVEUR")
    avant = len(LOG())
    AD.post("admin/parametres", {"action": "email_test"})
    S.check("le bouton « M'envoyer un e-mail de test » envoie bien un e-mail à l'admin", "Test d'envoi" in LOG()[avant:] and E["ad"] in LOG()[avant:])
    S.check("la carte « Envoi des e-mails » indique le mode d'envoi", "Envoi des e-mails" in txt(AD, "admin/parametres"))
    ht = (JEND / ".htaccess").read_text()
    S.check(".htaccess : signature du serveur masquée et pages d'erreur sans version", "ServerSignature Off" in ht and 'ErrorDocument 403 "' in ht)
finally:
    sql("DELETE FROM parametres WHERE cle IN ('frais_service_pct','frais_service_min','retrait_2fa')")
    ok = S.fin()
    sql("DELETE FROM retraits WHERE boutique_id IN (SELECT id FROM boutiques WHERE slug='boutique-t44')")
    sql("DELETE FROM produits WHERE slug='produit-t44'"); sql("DELETE FROM boutiques WHERE slug='boutique-t44'"); sql("DELETE FROM zones_livraison WHERE nom='Zone T44'")
sys.exit(0 if ok else 1)
