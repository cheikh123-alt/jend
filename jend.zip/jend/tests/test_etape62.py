"""Étape 62 : règlement des commissions par les vendeurs (ventes payées en espèces, paiement en ligne coupé) —
dette visible, numéro de Jënd et instructions, rappel WhatsApp, règlement enregistré par l'admin, relevé, plafond."""
import sys, re, csv, io, urllib.parse
from lib import *

S = Suite("Étape 62 — règlement des commissions", ["ad-t62@jend.local", "ve-t62@jend.local", "cl-t62@jend.local"])
E = dict(zip(["ad", "ve", "cl"], S.emails))
CLES = ("paiement_en_ligne", "paiement_livraison", "reglement_numero", "dette_commission_max")
AVANT = {}
try:
    for k in CLES:
        v = sql(f"SELECT valeur FROM parametres WHERE cle='{k}'")
        AVANT[k] = v if v != "" else None
    S.nettoyer()
    sql("INSERT INTO parametres (cle, valeur) VALUES ('paiement_livraison','1'),('paiement_en_ligne','0'),('dette_commission_max','1500') ON DUPLICATE KEY UPDATE valeur=VALUES(valeur)")
    sql("DELETE FROM parametres WHERE cle='reglement_numero'")
    sql("DELETE FROM zones_livraison WHERE nom='Zone T62'")
    sql("INSERT INTO zones_livraison (nom, region, frais, delai_jours) VALUES ('Zone T62', 'Kolda', 1000, 1)")
    zone = sql("SELECT id FROM zones_livraison WHERE nom='Zone T62'")
    pw = mot_de_passe()
    for k, nom, role in (("ad", "Admin T62", "admin"), ("ve", "Mariama Vendeuse", "vendeur")):
        sql(f"INSERT INTO users (nom,email,mot_de_passe,role,email_verifie,telephone) VALUES ('{nom}','{E[k]}','{hash_mdp(pw)}','{role}',1,'771234562')")
    sql(f"INSERT INTO boutiques (user_id,nom,slug,statut,commission_pct,mode_simple,livraison_par) SELECT id,'Boutique T62','boutique-t62','active',10,1,'vendeur' FROM users WHERE email='{E['ve']}'")
    bid = sql("SELECT id FROM boutiques WHERE slug='boutique-t62'")
    sql(f"INSERT INTO produits (boutique_id,categorie_id,nom,slug,prix,stock,statut) VALUES ({bid},(SELECT MIN(id) FROM categories),'Wax T62','wax-t62',10000,50,'publie')")
    pid = sql("SELECT id FROM produits WHERE slug='wax-t62'")
    AD, VE, C = Client(), Client(), Client()
    AD.post("connexion", {"email": E["ad"], "mot_de_passe": pw}); VE.post("connexion", {"email": E["ve"], "mot_de_passe": pw})
    C.post("inscription", {"nom": "Client T62", "email": E["cl"], "telephone": "", "mot_de_passe": "Wax-Kolda-2026!", "mot_de_passe2": "Wax-Kolda-2026!", "accepte": "1"})
    txt = lambda cl, u: cl.get(u)[1].replace("&#039;", "'").replace("\xa0", " ").replace(" ", " ")

    def vente():
        C.req("panier/ajouter", {"csrf": C.token("produits"), "produit_id": pid, "quantite": 1, "retour": "/jend/produits"})
        st, corps, hd = C.post("commande", {"nom": "Client T62", "telephone": "77 123 45 62", "zone_id": zone, "adresse": "Rue 62 Kolda", "methode": "livraison"})
        ref = hd.get("Location", "").rsplit("/", 1)[-1] if st in (302, 303) else None
        if ref:
            cb = sql(f"SELECT cb.id FROM commande_boutiques cb JOIN commandes c ON c.id=cb.commande_id WHERE c.reference='{ref}'")
            VE.post("simple/commandes", {"id": cb}, page_token="simple/commandes")
            code = sql(f"SELECT code_livraison FROM commande_boutiques WHERE id={cb}")
            VE.post("simple/commandes", {"id": cb, "code_livraison": code}, page_token="simple/commandes")
        return ref, corps

    S.titre("VENTES EN ESPÈCES : LA COMMISSION DEVIENT UNE DETTE")
    r1, _ = vente(); r2, _ = vente()
    S.check("deux ventes payées en espèces et livrées", r1 and r2 and sql(f"SELECT COUNT(*) FROM commande_boutiques WHERE boutique_id={bid} AND statut='livree'") == "2")
    h = txt(VE, "simple/argent")
    S.check("mode simple : « Commission à régler à Jënd : 2 000 FCFA » (10 % de 2 × 10 000)", "Commission à régler à Jënd" in h and "2 000 FCFA" in h)
    S.check("sans numéro configuré : pas d'instructions inventées, l'équipe contactera le vendeur", "l'équipe Jënd vous contactera" in h and "J'ai payé" not in h)
    S.check("et le plafond est expliqué (1 500 FCFA)", "1 500 FCFA" in h)

    S.titre("RETRAIT : PAS DE BOUTON INACTIF INCOMPRIS")
    hg = txt(VE, "vendeur/gains")
    S.check("paiement en ligne coupé : « Vos clients vous paient en espèces », l'argent est déjà chez le vendeur, pas de formulaire de retrait", "Vos clients vous paient en espèces" in hg and "déjà dans votre poche" in hg and "Demander le retrait</button>" not in hg)
    S.check("mode simple : même explication", "déjà dans votre poche" in txt(VE, "simple/argent"))
    sql("UPDATE parametres SET valeur='1' WHERE cle='paiement_en_ligne'")
    hg = txt(VE, "vendeur/gains")
    S.check("paiement en ligne ouvert mais solde trop faible : le bouton explique pourquoi il est inactif", "Bouton inactif : votre solde disponible" in hg and "5 000 FCFA" in hg)
    sql("UPDATE parametres SET valeur='0' WHERE cle='paiement_en_ligne'")

    S.titre("PLAFOND : COMMANDES EN ESPÈCES SUSPENDUES")
    r3, corps = vente()
    S.check("dette (2 000) au-delà du plafond (1 500) : nouvelle commande en espèces refusée", r3 is None)

    S.titre("NUMÉRO DE JËND ET INSTRUCTIONS")
    AD.post("admin/commissions", {"action": "numero", "numero": "abc"}, page_token="admin/commissions")
    S.check("numéro invalide refusé", sql("SELECT COUNT(*) FROM parametres WHERE cle='reglement_numero'") == "0")
    AD.post("admin/commissions", {"action": "numero", "numero": "77 765 43 21"}, page_token="admin/commissions")
    S.check("numéro de Jënd enregistré", sql("SELECT valeur FROM parametres WHERE cle='reglement_numero'") not in ("", "NULL"))
    h = txt(VE, "simple/argent").replace("&amp;", "&")
    S.check("le vendeur voit : envoyer 2 000 FCFA par Wave / Orange Money au numéro de Jënd, avec le nom de sa boutique",
            "Envoyez <b>2 000 FCFA</b>" in h and "Wave ou Orange Money" in h and "« Boutique T62 »" in h)
    m = re.search(r'href="(https://wa\.me/221777654321\?text=[^"]+)"', h)
    S.check("bouton « J'ai payé : prévenir Jënd » vers le WhatsApp de Jënd, message prérempli", m is not None and "Boutique T62" in urllib.parse.unquote(m.group(1)))
    S.check("aussi dans l'espace complet (Gains)", "Commission à régler à Jënd" in txt(VE, "vendeur/gains"))

    S.titre("PAGE « COMMISSIONS DUES » DE L'ADMIN")
    h = txt(AD, "admin/commissions").replace("&amp;", "&")
    S.check("la boutique apparaît avec 2 000 FCFA, total, et « commandes en espèces suspendues »", "Boutique T62" in h and "2 000 FCFA" in h and "Commandes en espèces suspendues" in h)
    w = re.search(r'href="https://wa\.me/221771234562\?text=([^"]+)"', h)
    S.check("rappel WhatsApp au vendeur : montant, numéro de Jënd, lien vers son espace", w is not None and all(t in urllib.parse.unquote(w.group(1)) for t in ("2 000 FCFA", "Boutique T62", "simple/argent")))
    S.check("pastille sur l'onglet « Commissions dues »", re.search(r'Commissions dues <b class="pastille-onglet[^"]*"[^>]*>1</b>', AD.get("admin")[1]) is not None)
    S.check("réservé à l'admin", VE.get("admin/commissions")[0] == 404 and C.get("admin/commissions")[0] == 404)

    S.titre("ENREGISTRER UN RÈGLEMENT")
    AD.post("admin/commissions", {"action": "reglement", "boutique_id": bid, "montant": "5000", "methode": "wave", "reference": "WV-123"}, page_token="admin/commissions")
    S.check("plus que la dette (5 000 > 2 000) : refusé", sql(f"SELECT COUNT(*) FROM reglements_commission WHERE boutique_id={bid}") == "0")
    AD.req("admin/commissions", {"action": "reglement", "boutique_id": bid, "montant": "1000", "methode": "wave"})
    S.check("sans jeton de sécurité : rien n'est enregistré", sql(f"SELECT COUNT(*) FROM reglements_commission WHERE boutique_id={bid}") == "0")
    VE.post("admin/commissions", {"action": "reglement", "boutique_id": bid, "montant": "1000", "methode": "wave"}, page_token="vendeur")
    S.check("un vendeur ne peut pas s'enregistrer un règlement", sql(f"SELECT COUNT(*) FROM reglements_commission WHERE boutique_id={bid}") == "0")
    AD.post("admin/commissions", {"action": "reglement", "boutique_id": bid, "montant": "1 000", "methode": "wave", "reference": "WV-2026-001"}, page_token="admin/commissions")
    S.check("règlement de 1 000 FCFA par Wave enregistré (référence, admin, journal)",
            sql(f"SELECT CONCAT(montant,'|',methode,'|',reference) FROM reglements_commission WHERE boutique_id={bid}") == "1000|wave|WV-2026-001" and sql("SELECT COUNT(*) FROM journal_admin WHERE action='commission_reglee'") == "1")
    h = txt(VE, "simple/argent")
    S.check("le vendeur ne doit plus que 1 000 FCFA, et voit « Commission déjà réglée à Jënd + 1 000 FCFA »", "Commission à régler à Jënd : <b>1 000 FCFA</b>" in h and "Commission déjà réglée à Jënd" in h)
    r4, _ = vente()
    S.check("sous le plafond : les commandes en espèces reprennent", r4 is not None)
    mois = sql("SELECT DATE_FORMAT(NOW(),'%Y-%m')")
    h = txt(VE, f"vendeur/releves?mois={mois}")
    S.check("relevé du mois : section « Commissions réglées à Jënd » (1 000 FCFA, Wave, référence)", "Commissions réglées à Jënd" in h and "WV-2026-001" in h)
    st, corps, hd = VE.get(f"vendeur/releves?mois={mois}&format=csv")
    S.check("relevé CSV : ligne « Commission réglée à Jënd »", "Commission réglée à Jënd" in corps and "WV-2026-001" in corps)
    reste = int(re.search(r"Commission à régler à Jënd : <b>([\d\s ]+) FCFA", txt(VE, "simple/argent")).group(1).replace(" ", "").replace(" ", ""))
    AD.post("admin/commissions", {"action": "reglement", "boutique_id": bid, "montant": str(reste), "methode": "orange_money", "reference": "OM-77"}, page_token="admin/commissions")
    ha = txt(AD, "admin/commissions")                      # (le message de confirmation, affiché une fois, cite la boutique)
    S.check("tout réglé : plus de dette, la boutique quitte la liste", "Commission à régler" not in txt(VE, "simple/argent") and "Aucune commission en attente" in txt(AD, "admin/commissions"))
    S.check("historique des règlements visible par l'admin", "OM-77" in txt(AD, "admin/commissions"))
    S.check("trésorerie : commissions réglées par les vendeurs comptées à part", "Commissions déjà réglées par les vendeurs" in txt(AD, "admin/tresorerie"))
finally:
    for k, v in AVANT.items():
        sql(f"DELETE FROM parametres WHERE cle='{k}'")
        if v is not None:
            sql(f"INSERT INTO parametres (cle, valeur) VALUES ('{k}', '{v}')")
    sql("DELETE FROM produits WHERE slug='wax-t62'")
    S.nettoyer()
    sql("DELETE FROM zones_livraison WHERE nom='Zone T62'")
    ok = S.fin()
sys.exit(0 if ok else 1)
