"""Étape 36 : l'administrateur voit les offres de prix et les demandes sur mesure (lecture seule)."""
import sys
from lib import *

S = Suite("Étape 36 — vue admin des offres", ["ad-t36@jend.local", "cl-t36@jend.local", "va-t36@jend.local"])
E = dict(zip(["ad", "cl", "va"], S.emails))
try:
    S.nettoyer()
    sql("DELETE FROM produits WHERE slug='produit-t36'"); sql("DELETE FROM boutiques WHERE slug='boutique-t36'")
    pw = mot_de_passe()
    for k, nom, role in (("ad", "Admin T36", "admin"), ("cl", "Cliente T36", "client"), ("va", "Vendeur T36", "vendeur")):
        sql(f"INSERT INTO users (nom,email,mot_de_passe,role) VALUES ('{nom}','{E[k]}','{hash_mdp(pw)}','{role}')")
    sql(f"INSERT INTO boutiques (user_id,nom,slug,statut,commission_pct) SELECT id,'Boutique T36','boutique-t36','active',1 FROM users WHERE email='{E['va']}'")
    sql("INSERT INTO produits (boutique_id,categorie_id,nom,slug,description,prix,stock,statut) SELECT b.id,(SELECT MIN(id) FROM categories),'Produit T36','produit-t36','x',10000,20,'publie' FROM boutiques b WHERE b.slug='boutique-t36'")
    AD, C, VA = Client(), Client(), Client()
    for cl, k in ((AD, "ad"), (C, "cl"), (VA, "va")):
        cl.post("connexion", {"email": E[k], "mot_de_passe": pw})
    C.post("produit/produit-t36", {"action": "offre", "prix": "8000", "quantite": "1"}, page_token="produit/produit-t36")
    VA.post("vendeur/offres", {"id": sql("SELECT MAX(id) FROM offres"), "action": "accepter"})
    h = AD.get("admin/offres")[1]
    S.check("l'admin voit l'offre : produit, boutique, client, prix affiché, offre et prix convenu", all(x in h for x in ("Produit T36", "Boutique T36", "Cliente T36")) and h.replace(" ", " ").replace("&nbsp;", " ").count("8 000") >= 2)
    S.check("les chiffres clés sont affichés (offres faites, prix convenus, remise moyenne de 20 %)", "Offres faites" in h and "Remise moyenne" in h and "20 %" in h)
    S.check("le filtre « En cours » ne montre pas une offre déjà conclue", "Produit T36" not in AD.get("admin/offres?vue=en_cours")[1])
    S.check("la page est en lecture seule (aucun formulaire d'action sur les offres)", 'name="action"' not in h)
    S.check("réservée à l'administrateur", C.get("admin/offres")[0] == 404 and VA.get("admin/offres")[0] == 404)
    S.check("le tableau de bord admin résume l'activité des offres", "Offres de prix (7 jours)" in AD.get("admin")[1])
finally:
    ok = S.fin()
    sql("DELETE FROM produits WHERE slug='produit-t36'"); sql("DELETE FROM boutiques WHERE slug='boutique-t36'"); sql("DELETE FROM limites WHERE cle LIKE 'offre:%'")
sys.exit(0 if ok else 1)
