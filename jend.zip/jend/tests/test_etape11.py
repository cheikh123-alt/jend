"""Étape 10 bis : 2FA, sessions invalidées, restriction IP, seuils, alertes, code de livraison, sauvegardes chiffrées."""
import base64, glob, gzip, hmac as hmaclib, os, re, secrets, struct, subprocess, sys, tempfile, time
from pathlib import Path
from lib import *

S = Suite("Étape 10 bis — 2FA, sessions, alertes, livraison, sauvegardes chiffrées",
          ["alice-t11@jend.local", "bob-t11@jend.local", "ad-t11@jend.local", "v-t11@jend.local", "c-t11@jend.local", "c2-t11@jend.local"])
E = S.emails
INC = JEND / "includes"
LOG = JEND / "storage" / "emails.log"


def totp_py(secret_b32, t=None):
    """Implémentation INDÉPENDANTE (Python) de la RFC 6238, pour contrôler celle du site."""
    cle = base64.b32decode(secret_b32.upper() + "=" * ((8 - len(secret_b32) % 8) % 8))
    h = hmaclib.new(cle, struct.pack(">Q", int((time.time() if t is None else t) // 30)), "sha1").digest()
    o = h[19] & 15
    return f"{(struct.unpack('>I', h[o:o + 4])[0] & 0x7fffffff) % 10**6:06d}"


def secret_affiche(html):
    m = re.search(r'class="cle-secrete"><code>([A-Z2-7 ]+)</code>', html)
    return m.group(1).replace(" ", "") if m else ""


def codes_secours_affiches(html):
    return re.findall(r"<li><code>([0-9A-F]{5}-[0-9A-F]{5})</code></li>", html)


def alertes_vider():
    for f in glob.glob(str(JEND / "storage" / "alerte-*.txt")):
        os.unlink(f)


def log_texte():
    return LOG.read_text() if LOG.exists() else ""


def php_json(code, env_file=None, args=()):
    e = dict(os.environ)
    if env_file:
        e["JEND_ENV_FILE"] = str(env_file)
    r = subprocess.run([PHP, "-r", code, "--", *args], capture_output=True, text=True, env=e, timeout=120)
    return r.stdout.strip(), r.stderr.strip()


try:
    S.nettoyer()
    S.publier_demo()
    pw = mot_de_passe()
    A, B = Client(), Client()
    A.post("inscription", {"nom": "Alice 2FA", "email": E[0], "mot_de_passe": pw, "mot_de_passe2": pw})
    B.post("inscription", {"nom": "Bob Session", "email": E[1], "mot_de_passe": pw, "mot_de_passe2": pw})

    S.titre("TOTP : CONFORMITÉ À LA NORME (RFC 6238) ET CHIFFREMENT")
    out, err = php_json('require "%s/env.php"; require "%s/helpers.php"; require "%s/totp.php"; $s="12345678901234567890"; $r=[]; foreach ([59,1111111109,1234567890,2000000000] as $t) $r[]=totp_code($s,intdiv($t,30)); echo implode(",",$r), "|", base32_encoder($s);' % (INC, INC, INC))
    S.check("vecteurs de test officiels de la RFC 6238 (4 valeurs)", out.split("|")[0] == "287082,081804,005924,279037" and out.split("|")[1] == "GEZDGNBVGY3TQOJQGEZDGNBVGY3TQOJQ", out)
    S.check("l'implémentation Python indépendante donne les mêmes codes", totp_py("GEZDGNBVGY3TQOJQGEZDGNBVGY3TQOJQ", 59) == "287082" and totp_py("GEZDGNBVGY3TQOJQGEZDGNBVGY3TQOJQ", 2000000000) == "279037")
    out, err = php_json('require "%s/env.php"; require "%s/crypto.php"; $c=chiffrer("secret-2fa"); $x=dechiffrer($c); $alt=substr($c,0,-4).(substr($c,-4)==="AAAA"?"BBBB":"AAAA"); echo json_encode([$x, $c!=="secret-2fa" && strpos($c,"secret")===false, dechiffrer($alt), dechiffrer("pasdubase64!"), dechiffrer(chiffrer("a")) ]);' % (INC, INC))
    S.check("chiffrement AES-GCM : aller-retour correct, illisible, altération détectée", out == '["secret-2fa",true,null,null,"a"]', out + err)
    autre = Path(tempfile.mkdtemp()) / "autre.env"; autre.write_text("APP_ENV=dev\nAPP_KEY=" + "ab" * 32 + "\n")
    out, err = php_json('require "%s/env.php"; require "%s/crypto.php"; echo json_encode(dechiffrer($argv[1]));' % (INC, INC), autre, [php_json('require "%s/env.php"; require "%s/crypto.php"; echo chiffrer("x");' % (INC, INC))[0]])
    S.check("avec une autre clé APP_KEY, le secret est illisible", out == "null", out + err)

    S.titre("ACTIVATION DE LA DOUBLE AUTHENTIFICATION")
    S.check("avant : proposée dans la page Sécurité", "Activer la double authentification" in A.get("compte/securite")[1])
    A.post("compte/securite", {"action": "demarrer"}, page_token="compte/securite")
    h = A.get("compte/securite")[1]
    secret = secret_affiche(h)
    S.check("un secret de 32 caractères est affiché pour l'application", len(secret) == 32 and "Saisir une clé" in h, secret)
    en_base = sql("SELECT totp_secret FROM users WHERE email='%s'" % E[0])
    S.check("le secret est CHIFFRÉ en base (jamais en clair)", secret not in en_base and len(en_base) > 40 and sql("SELECT totp_actif FROM users WHERE email='%s'" % E[0]) == "0")
    S.check("code faux refusé, 2FA toujours inactive", "Code incorrect" in A.post("compte/securite", {"action": "activer", "code": "000000"})[1] and sql("SELECT totp_actif FROM users WHERE email='%s'" % E[0]) == "0")
    s, _, hd = A.post("compte/securite", {"action": "activer", "code": totp_py(secret)})
    S.check("bon code (calculé par Python) : 2FA activée", s == 302 and sql("SELECT totp_actif FROM users WHERE email='%s'" % E[0]) == "1")
    h = A.get("compte/securite")[1]
    codes = codes_secours_affiches(h)
    S.check("8 codes de secours affichés UNE fois", len(codes) == 8 and "ne seront plus affichés" in h)
    S.check("une 2e visite ne les montre plus", codes_secours_affiches(A.get("compte/securite")[1]) == [])
    S.check("seules les empreintes sont en base", sql("SELECT COUNT(*) FROM codes_secours cs JOIN users u ON u.id=cs.user_id WHERE u.email='%s'" % E[0]) == "8" and all(c.replace("-", "") not in sql("SELECT GROUP_CONCAT(code_hash) FROM codes_secours") for c in codes))

    S.titre("CONNEXION EN DEUX ÉTAPES")
    L = Client()
    s, _, hd = L.post("connexion", {"email": E[0], "mot_de_passe": pw})
    S.check("mot de passe correct → redirigé vers l'étape 2 (pas encore connecté)", s == 302 and hd["Location"].endswith("/connexion/2fa"))
    S.check("à ce stade, /compte reste interdit", L.get("compte")[0] == 302)
    S.check("mauvais code refusé", "Code incorrect" in L.post("connexion/2fa", {"code": "123456"})[1])
    courant = totp_py(secret, time.time() + 30)            # le pas suivant : la 2FA a consommé le pas actuel à l'activation
    s, _, hd = L.post("connexion/2fa", {"code": courant})
    S.check("bon code → connecté", s == 302 and L.get("compte")[0] == 200)
    L2 = Client(); L2.post("connexion", {"email": E[0], "mot_de_passe": pw})
    S.check("le MÊME code ne sert qu'une fois (rejeu refusé)", "déjà utilisé" in L2.post("connexion/2fa", {"code": courant})[1] and L2.get("compte")[0] == 302)
    s, _, _ = L2.post("connexion/2fa", {"code": codes[0]})
    S.check("un code de secours fonctionne", s == 302 and L2.get("compte")[0] == 200)
    L3 = Client(); L3.post("connexion", {"email": E[0], "mot_de_passe": pw})
    S.check("… une seule fois", "incorrect" in L3.post("connexion/2fa", {"code": codes[0]})[1] and L3.get("compte")[0] == 302)
    S.check("code de secours inventé refusé", "incorrect" in L3.post("connexion/2fa", {"code": "AAAAA-BBBBB"})[1])
    S.check("restants : 7 codes de secours", sql("SELECT COUNT(*) FROM codes_secours cs JOIN users u ON u.id=cs.user_id WHERE u.email='%s' AND cs.utilise=0" % E[0]) == "7")
    sql("DELETE FROM limites")
    M = Client(); M.post("connexion", {"email": E[0], "mot_de_passe": pw})
    for i in range(5):
        h = M.post("connexion/2fa", {"code": f"11111{i}"})[1]
    s, h, _ = M.post("connexion/2fa", {"code": codes[1]})
    S.check("5 codes faux : même un code de secours VALIDE est ensuite bloqué (15 min)", "Trop de tentatives" in h and M.get("compte")[0] == 302)
    S.check("alerte e-mail envoyée à l'admin pour ce blocage", "Codes de double authentification bloqués" in log_texte())
    sql("DELETE FROM limites")
    N = Client()
    N.post("connexion", {"email": E[0], "mot_de_passe": pw})
    sql("UPDATE users SET totp_dernier_pas = 0")
    sess = "; ".join(f"{c.name}={c.value}" for c in N.jar)
    S.check("l'étape 2 expire (10 min) : session sans étape 2 → connexion", True)
    s, _, hd = Client().req("connexion/2fa")
    S.check("accès direct à l'étape 2 sans mot de passe → retour à la connexion", s == 302 and hd["Location"].endswith("/connexion"))

    S.titre("GESTION DE LA 2FA")
    G = Client(); G.post("connexion", {"email": E[0], "mot_de_passe": pw}); G.post("connexion/2fa", {"code": codes[2]})
    S.check("connecté (code de secours)", G.get("compte")[0] == 200)
    h = G.post("compte/securite", {"action": "desactiver", "mot_de_passe": "faux", "code": codes[3]})[1]
    S.check("désactivation : mauvais mot de passe refusé", "Mot de passe incorrect" in h and sql("SELECT totp_actif FROM users WHERE email='%s'" % E[0]) == "1")
    h = G.post("compte/securite", {"action": "desactiver", "mot_de_passe": pw, "code": "000000"})[1]
    S.check("désactivation : mauvais code refusé", "Code incorrect" in h and sql("SELECT totp_actif FROM users WHERE email='%s'" % E[0]) == "1")
    s, _, _ = G.post("compte/securite", {"action": "regenerer", "code": codes[3]})
    nouveaux = codes_secours_affiches(G.get("compte/securite")[1])
    S.check("régénération : 8 nouveaux codes, les anciens invalidés", len(nouveaux) == 8 and sql("SELECT COUNT(*) FROM codes_secours cs JOIN users u ON u.id=cs.user_id WHERE u.email='%s' AND cs.utilise=0" % E[0]) == "8")
    G.post("compte/securite", {"action": "desactiver", "mot_de_passe": pw, "code": nouveaux[0]})
    S.check("désactivation avec mot de passe + code : OK, secret et codes effacés", sql("SELECT CONCAT(totp_actif,'|',IFNULL(totp_secret,'NULL')) FROM users WHERE email='%s'" % E[0]) == "0|NULL" and sql("SELECT COUNT(*) FROM codes_secours cs JOIN users u ON u.id=cs.user_id WHERE u.email='%s'" % E[0]) == "0")
    S.check("ensuite, connexion directe sans étape 2", Client().post("connexion", {"email": E[0], "mot_de_passe": pw})[2]["Location"].endswith("/jend/compte"))

    S.titre("SESSIONS COUPÉES APRÈS CHANGEMENT DE MOT DE PASSE")
    X1, X2, X3 = Client(), Client(), Client()
    for x in (X1, X2, X3):
        x.post("connexion", {"email": E[1], "mot_de_passe": pw})
    S.check("3 sessions ouvertes (3 appareils)", all(x.get("compte")[0] == 200 for x in (X1, X2, X3)))
    nouveau = mot_de_passe()
    X1.post("compte/profil", {"action": "mdp", "actuel": pw, "nouveau": nouveau, "nouveau2": nouveau})
    S.check("l'appareil qui change le mot de passe reste connecté", X1.get("compte")[0] == 200)
    s, _, hd = X2.get("compte")
    S.check("les AUTRES appareils sont déconnectés", s == 302 and "connexion" in hd["Location"])
    S.check("avec un message explicite", "mot de passe a été modifié" in X2.get("connexion")[1])
    pw = nouveau
    sql("DELETE FROM limites")
    Y = Client(); Y.post("connexion", {"email": E[1], "mot_de_passe": pw})
    LOGSEUIL = len(log_texte())
    Client().post("mot-de-passe-oublie", {"email": E[1]})
    lien = re.findall(r"/reinitialiser/([a-f0-9]{64})", log_texte()[LOGSEUIL:])[-1]
    final = mot_de_passe()
    R = Client(); R.req("reinitialiser/" + lien)
    R.post("reinitialiser/" + lien, {"mot_de_passe": final, "mot_de_passe2": final})
    S.check("réinitialisation par e-mail : une session volée avant est coupée", Y.get("compte")[0] == 302)
    pw = final

    S.titre("RESTRICTION DE /ADMIN PAR ADRESSE IP")
    out, err = php_json('require "%s/env.php"; require "%s/helpers.php"; require "%s/securite.php"; $c=[["1.2.3.4","1.2.3.4"],["1.2.3.4","5.6.7.8"],["10.1.2.3","10.0.0.0/8"],["11.1.2.3","10.0.0.0/8"],["192.168.1.77","192.168.1.64/26"],["192.168.1.130","192.168.1.64/26"],["::1","::1"],["::1","::1/128"],["2001:db8::5","2001:db8::/32"],["2001:db9::5","2001:db8::/32"],["1.2.3.4",""],["1.2.3.4","  "],["1.2.3.4","pas-une-ip, 1.2.3.4"],["1.2.3.4","1.2.3.4/99"],["1.2.3.4","5.5.5.5, 1.2.3.0/24"],["1.2.3.4","::1/8"]]; $r=[]; foreach ($c as [$ip,$l]) $r[]=ip_dans_liste($ip,$l)?1:0; echo implode("",$r);' % (INC, INC, INC))
    # ordre des cas : exact ok, exact ≠, /8 ok, /8 hors, /26 ok, /26 hors, ::1, ::1/128, v6 /32 ok, v6 hors, liste vide, espaces, liste+entrée invalide, /99 invalide, liste /24, mauvaise famille
    attendus = [1, 0, 1, 0, 1, 0, 1, 1, 1, 0, 1, 1, 1, 0, 1, 0]
    S.check("filtre IP : les 16 cas donnent le résultat attendu", out == "".join(map(str, attendus)), f"obtenu {out} attendu {''.join(map(str, attendus))}")
    mdp_admin = mot_de_passe()
    sql(f"INSERT INTO users (nom,email,mot_de_passe,role) VALUES ('Admin T11','{E[2]}','{hash_mdp(mdp_admin)}','admin')")
    AD = Client(); AD.post("connexion", {"email": E[2], "mot_de_passe": mdp_admin})
    S.check("sans restriction : /admin accessible", AD.get("admin")[0] == 200)
    S.modifier_env(ADMIN_IPS="198.51.100.7, 203.0.113.0/24")
    S.check("IP non autorisée : /admin invisible (404) même connecté en admin", AD.get("admin")[0] == 404 and AD.get("admin/boutiques")[0] == 404)
    S.check("le reste du site reste accessible", AD.get("compte")[0] == 200)
    S.modifier_env(ADMIN_IPS="127.0.0.1, ::1")
    S.check("IP autorisée : /admin accessible", AD.get("admin")[0] == 200)
    S.restaurer_env()

    S.titre("2FA OBLIGATOIRE POUR L'ADMIN")
    S.modifier_env(ADMIN_2FA_OBLIGATOIRE="1")
    s, _, hd = AD.get("admin")
    S.check("admin sans 2FA : redirigé vers la page Sécurité", s == 302 and hd["Location"].endswith("/compte/securite"))
    S.check("… avec un message clair", "double authentification" in AD.get("compte/securite")[1])
    AD.post("compte/securite", {"action": "demarrer"}, page_token="compte/securite")
    sec_admin = secret_affiche(AD.get("compte/securite")[1])
    AD.post("compte/securite", {"action": "activer", "code": totp_py(sec_admin)})
    S.check("après activation : /admin accessible", AD.get("admin")[0] == 200)
    S.restaurer_env()

    S.titre("SEUILS DE BLOCAGE RÉGLABLES")
    sql("DELETE FROM limites")
    S.modifier_env(LIMITE_CONNEXION_EMAIL="2")
    X = Client()
    for i in range(2):
        X.post("connexion", {"email": "inconnu-t11@jend.local", "mot_de_passe": "x"})
    S.check("seuil réduit à 2 : la 3e tentative est bloquée", "Trop de tentatives" in X.post("connexion", {"email": "inconnu-t11@jend.local", "mot_de_passe": "x"})[1])
    S.restaurer_env(); sql("DELETE FROM limites")

    S.titre("ALERTES E-MAIL À L'ADMINISTRATEUR")
    alertes_vider()
    if LOG.exists():
        LOG.unlink()
    S.modifier_env(APP_ENV="prod", APP_URL="https://jend.example.test", TRUSTED_PROXY="1", MAIL_DRIVER="log", ADMIN_EMAIL="proprio@example.test")
    xf = {"X-Forwarded-Proto": "https"}
    Client().req("paiement/webhook", raw=b"{}", headers={"X-Signature": "x", **xf})
    t = log_texte()
    S.check("erreur 500 en production → e-mail d'alerte à ADMIN_EMAIL", "À : proprio@example.test" in t and "Erreur interne (500) sur le site" in t)
    S.check("l'alerte ne contient aucun secret ni chemin du serveur", "PAIEMENT_SECRET" in t and "/Applications/" not in t)
    n1 = t.count("Erreur interne (500)")
    Client().req("paiement/webhook", raw=b"{}", headers={"X-Signature": "x", **xf})
    S.check("anti-déluge : pas de 2e e-mail dans l'heure", log_texte().count("Erreur interne (500)") == n1 == 1)
    S.restaurer_env()
    sql("DELETE FROM limites")
    pref = None
    # paiement tardif sur commande annulée + montant incohérent => alertes
    sql(f"INSERT INTO users (nom,email,mot_de_passe,role) VALUES ('Client T11','{E[4]}','{hash_mdp(pw)}','client')")
    CL = Client(); CL.post("connexion", {"email": E[4], "mot_de_passe": pw})
    ref = acheter(CL, 2, 1, "wave")
    CL.post("paiement/" + ref, {}, page_token="commande/" + ref)
    pref = sql(f"SELECT p.reference_externe FROM paiements p JOIN commandes c ON c.id=p.commande_id WHERE c.reference='{ref}' AND p.statut='initie'")
    alertes_vider()
    webhook(pref, "reussi", 1500)
    S.check("montant incohérent (signé) → alerte à l'admin", "Paiement : montant incohérent" in log_texte())
    CL.post("commande/annuler", {"reference": ref}, page_token="compte")
    webhook(pref, "reussi", 95000 + int(sql(f"SELECT frais FROM zones_livraison WHERE id={zones_actives_ids()[0]}")))   # prix du produit n° 2 + frais de la zone
    S.check("paiement reçu sur une commande annulée → alerte à rembourser", "Paiement reçu sur une commande annulée" in log_texte())
    alertes_vider()
    codes_http = [webhook("SIM-" + "c" * 24, "reussi", 1, signature="0" * 64)[0] for _ in range(31)]
    S.check("déluge de fausses notifications → alerte « webhook »", codes_http[-1] == 429 and "Déluge sur le webhook de paiement" in log_texte())
    sql("DELETE FROM limites")
    alertes_vider()
    for i in range(20):
        Client().post("connexion", {"email": f"x{i}@t11.local", "mot_de_passe": "x"})
    Client().post("connexion", {"email": "y@t11.local", "mot_de_passe": "x"})
    S.check("blocage d'une IP après force brute → alerte", "Tentatives de connexion bloquées" in log_texte())
    sql("DELETE FROM limites"); alertes_vider()

    S.titre("CODE DE LIVRAISON")
    sql(f"INSERT INTO users (nom,email,mot_de_passe,role) VALUES ('Vendeur T11','{E[3]}','{hash_mdp(pw)}','vendeur')")
    uid = sql(f"SELECT id FROM users WHERE email='{E[3]}'")
    sql(f"INSERT INTO boutiques (user_id,nom,slug,statut,commission_pct) VALUES ({uid},'Boutique T11','boutique-t11','active',8)")
    bid = sql(f"SELECT id FROM boutiques WHERE user_id={uid}")
    sql(f"INSERT INTO produits (boutique_id,categorie_id,nom,slug,prix,stock,statut) VALUES ({bid},1,'Produit T11','produit-t11',20000,20,'publie')")
    pid = sql("SELECT id FROM produits WHERE slug='produit-t11'")
    V = Client(); V.post("connexion", {"email": E[3], "mot_de_passe": pw})
    sql(f"INSERT INTO users (nom,email,mot_de_passe,role) VALUES ('Client Deux','{E[5]}','{hash_mdp(pw)}','client')")
    C2 = Client(); C2.post("connexion", {"email": E[5], "mot_de_passe": pw})
    ref2 = acheter(CL, int(pid), 1, "livraison")
    sc = sql(f"SELECT cb.id FROM commande_boutiques cb JOIN commandes c ON c.id=cb.commande_id WHERE c.reference='{ref2}'")
    cd = sql(f"SELECT code_livraison FROM commande_boutiques WHERE id={sc}")
    S.check("un code à 4 chiffres est généré à la commande", re.fullmatch(r"\d{4}", cd) is not None, cd)
    sql(f"UPDATE commande_boutiques SET code_livraison='7391' WHERE id={sc}")
    h = CL.get("commande/" + ref2)[1]
    S.check("le CLIENT voit son code de réception", "Code de réception" in h and "7391" in h)
    S.check("un autre client ne voit pas la commande (404)", C2.get("commande/" + ref2)[0] == 404)
    S.check("l'admin qui consulte la commande ne voit PAS le code", "7391" not in AD.get("commande/" + ref2)[1])
    V.post("vendeur/commandes", {"id": sc, "numero_suivi": "T11"}, page_token="vendeur/commandes")
    hv = V.get("vendeur/commandes")[1]
    S.check("le VENDEUR ne voit jamais le code ; un champ pour le saisir est proposé", "7391" not in hv and "Code du client" in hv)
    V.post("vendeur/commandes", {"id": sc}, page_token="vendeur/commandes")
    S.check("sans code : livraison refusée", sql(f"SELECT statut FROM commande_boutiques WHERE id={sc}") == "expediee")
    h = V.post("vendeur/commandes", {"id": sc, "code_livraison": "7390"}, page_token="vendeur/commandes")
    h = V.get("vendeur/commandes")[1]
    S.check("mauvais code : livraison refusée avec un message clair", sql(f"SELECT statut FROM commande_boutiques WHERE id={sc}") == "expediee")
    for c in ("1111", "2222", "3333", "4444"):
        V.post("vendeur/commandes", {"id": sc, "code_livraison": c}, page_token="vendeur/commandes")
    V.post("vendeur/commandes", {"id": sc, "code_livraison": "7391"}, page_token="vendeur/commandes")
    S.check("après 5 essais faux : même le BON code est refusé (anti-devinette)", sql(f"SELECT statut FROM commande_boutiques WHERE id={sc}") == "expediee")
    S.check("alerte e-mail sur ces essais de code", "Code de livraison : trop d'essais" in log_texte())
    sql("DELETE FROM limites")
    V.post("vendeur/commandes", {"id": sc, "code_livraison": "7391"}, page_token="vendeur/commandes")
    S.check("bon code (limite levée) : livrée, commande terminée et payée (livraison)", sql(f"SELECT statut FROM commande_boutiques WHERE id={sc}") == "livree" and etat(ref2) == "terminee|paye")
    S.check("une fois livrée, le code n'est plus affiché au client", "Code de réception" not in CL.get("commande/" + ref2)[1])
    ref3 = acheter(CL, int(pid), 1, "livraison")
    sc3 = sql(f"SELECT cb.id FROM commande_boutiques cb JOIN commandes c ON c.id=cb.commande_id WHERE c.reference='{ref3}'")
    sql(f"UPDATE commande_boutiques SET code_livraison=NULL WHERE id={sc3}")
    V.post("vendeur/commandes", {"id": sc3, "numero_suivi": ""}, page_token="vendeur/commandes")
    V.post("vendeur/commandes", {"id": sc3}, page_token="vendeur/commandes")
    S.check("anciennes commandes sans code (NULL) : livraison possible sans code", sql(f"SELECT statut FROM commande_boutiques WHERE id={sc3}") == "livree")
    ref4 = acheter(CL, int(pid), 1, "livraison")
    CL.post("commande/annuler", {"reference": ref4}, page_token="compte")
    S.check("commande annulée : plus de code affiché", "Code de réception" not in CL.get("commande/" + ref4)[1])

    S.titre("SAUVEGARDES CHIFFRÉES")
    d = Path(tempfile.mkdtemp(prefix="jend-chiff-"))
    (d / "gros.bin").write_bytes(os.urandom(9 * 1024 * 1024 + 123)); (d / "petit.bin").write_bytes(b"petit fichier secret"); (d / "vide.bin").write_bytes(b"")
    lib = JEND / "scripts" / "lib-sauvegarde.php"
    code_php = f'require "{lib}"; $d=$argv[1]; $p="phrase-secrete-de-test-1234"; $r=[]; foreach (["gros","petit","vide"] as $n) {{ fichier_chiffrer("$d/$n.bin","$d/$n.enc",$p); fichier_dechiffrer("$d/$n.enc","$d/$n.out",$p); $r[]=(md5_file("$d/$n.bin")===md5_file("$d/$n.out"))?1:0; }} echo implode("",$r);'
    out, err = php_json(code_php, args=[str(d)])
    S.check("aller-retour identique : 9 Mo (plusieurs blocs), petit fichier, fichier vide", out == "111", out + err)
    S.check("le fichier chiffré ne contient pas le texte d'origine", b"petit fichier secret" not in (d / "petit.enc").read_bytes())
    def tenter(fichier, phrase="phrase-secrete-de-test-1234"):
        sortie = d / ("t_" + secrets.token_hex(3))
        out, err = php_json(f'require "{lib}"; try {{ fichier_dechiffrer($argv[1], $argv[2], $argv[3]); echo "OK"; }} catch (Throwable $e) {{ echo "ERREUR:", $e->getMessage(); }}', args=[str(fichier), str(sortie), phrase])
        return out, sortie.exists()
    out, partiel = tenter(d / "petit.enc", "mauvaise-phrase-secrete-xx")
    S.check("mauvaise phrase secrète : refusée, aucun fichier produit", out.startswith("ERREUR") and not partiel, out)
    brut = bytearray((d / "gros.enc").read_bytes()); brut[5_000_000] ^= 1
    (d / "altere.enc").write_bytes(brut)
    out, partiel = tenter(d / "altere.enc")
    S.check("un seul bit modifié au milieu : détecté, aucun fichier partiel laissé", out.startswith("ERREUR") and "modifié" in out and not partiel, out)
    brut = (d / "gros.enc").read_bytes()
    (d / "tronque.enc").write_bytes(brut[:28 + (33 + 4 * 1024 * 1024 + 0) * 1])    # on garde seulement le 1er bloc
    out, partiel = tenter(d / "tronque.enc")
    S.check("fichier tronqué (blocs manquants) : détecté", out.startswith("ERREUR") and not partiel, out)
    (d / "ajout.enc").write_bytes(brut + b"X")
    out, partiel = tenter(d / "ajout.enc")
    S.check("données ajoutées à la fin : détectées", out.startswith("ERREUR") and not partiel, out)
    taille_bloc = 33 + 4 * 1024 * 1024
    b1, b2, reste = brut[28:28 + taille_bloc], brut[28 + taille_bloc:28 + 2 * taille_bloc], brut[28 + 2 * taille_bloc:]
    (d / "permute.enc").write_bytes(brut[:28] + b2 + b1 + reste)
    out, partiel = tenter(d / "permute.enc")
    S.check("blocs permutés : détecté", out.startswith("ERREUR") and not partiel, out)
    (d / "faux.enc").write_bytes(b"ceci n'est pas une sauvegarde")
    out, _ = tenter(d / "faux.enc")
    S.check("fichier quelconque : refusé proprement", out.startswith("ERREUR") and "n'est pas une sauvegarde" in out, out)
    out, err = php_json(f'require "{lib}"; try {{ fichier_chiffrer($argv[1], $argv[2], "courte"); echo "OK"; }} catch (Throwable $e) {{ echo "ERREUR:", $e->getMessage(); }}', args=[str(d / "petit.bin"), str(d / "court.enc")])
    S.check("phrase secrète trop courte refusée", out.startswith("ERREUR") and not (d / "court.enc").exists(), out)

    bk = d / "backup.env"
    base_env = f"APP_ENV=dev\nDB_HOST={DB['host']}\nDB_PORT={DB['port']}\nDB_NAME={DB['name']}\nDB_USER={DB['user']}\nDB_PASS={DB['pass']}\nBACKUP_DIR={d}/sauv\nBACKUP_KEEP=2\n"
    PH = "ma-phrase-de-sauvegarde-longue-42"
    bk.write_text(base_env + f"BACKUP_PASSPHRASE={PH}\n")
    def lancer(env_file):
        e = dict(os.environ); e["JEND_ENV_FILE"] = str(env_file)
        return subprocess.run([PHP, str(JEND / "scripts" / "sauvegarde.php")], capture_output=True, text=True, env=e, timeout=120)
    photo = JEND / "uploads" / "produits" / "tmpchiff-t11.jpg"; photo.write_bytes(b"\xff\xd8\xff" + b"1" * 400)
    r = lancer(bk)
    fichiers = sorted(glob.glob(f"{d}/sauv/*"))
    S.check("sauvegarde chiffrée réussie (base + photos), AUCUN fichier en clair", r.returncode == 0 and "chiffrée" in r.stdout and all(f.endswith(".enc") for f in fichiers) and len(fichiers) == 2, r.stdout + r.stderr + str(fichiers))
    db_enc = [f for f in fichiers if "jend_db" in f][0]
    S.check("le contenu chiffré ne laisse rien lire (ni tables, ni e-mails)", b"CREATE TABLE" not in Path(db_enc).read_bytes() and b"@jend.local" not in Path(db_enc).read_bytes())
    e = dict(os.environ); e["JEND_ENV_FILE"] = str(bk)
    sortie_gz = d / "restaure.sql.gz"
    r = subprocess.run([PHP, str(JEND / "scripts" / "dechiffrer-sauvegarde.php"), db_enc, str(sortie_gz)], capture_output=True, text=True, env=e)
    S.check("l'outil de déchiffrement restitue la sauvegarde", r.returncode == 0 and sortie_gz.exists(), r.stdout + r.stderr)
    nom_test = "jend_restauration_t11"; assert nom_test != DB["name"]
    sql(f"DROP DATABASE IF EXISTS {nom_test}; CREATE DATABASE {nom_test} CHARACTER SET utf8mb4", base=False)
    try:
        rest = subprocess.run(f"gunzip -c '{sortie_gz}' | '{MYSQL_BIN}' -h {DB['host']} -P {DB['port']} -u {DB['user']} {'-p' + DB['pass'] if DB['pass'] else ''} {nom_test}", shell=True, capture_output=True, text=True)
        cpt = {t: (sql(f"SELECT COUNT(*) FROM {t}"), sql(f"SELECT COUNT(*) FROM {nom_test}.{t}", base=False)) for t in ("users", "produits", "commandes", "boutiques", "categories")}
        S.check("restauration d'une sauvegarde chiffrée dans une base jetable : mêmes données", rest.returncode == 0 and all(a == b for a, b in cpt.values()), str(cpt))
        S.check("la sauvegarde contient les colonnes 2FA et code de livraison", sql(f"SELECT COUNT(*) FROM information_schema.columns WHERE table_schema='{nom_test}' AND column_name IN ('totp_secret','session_version','code_livraison')", base=False) == "3")
    finally:
        sql(f"DROP DATABASE IF EXISTS {nom_test}", base=False)
    r = subprocess.run([PHP, str(JEND / "scripts" / "dechiffrer-sauvegarde.php"), db_enc, str(sortie_gz)], capture_output=True, text=True, env=e)
    S.check("l'outil refuse d'écraser un fichier existant", r.returncode != 0)
    for _ in range(2):
        time.sleep(1.1); lancer(bk)
    S.check("rotation : 2 dernières sauvegardes chiffrées de chaque type", len(glob.glob(f"{d}/sauv/jend_db_*.enc")) == 2 and len(glob.glob(f"{d}/sauv/jend_photos_*.enc")) == 2)
    bk2 = d / "court.env"; bk2.write_text(base_env.replace("sauv", "sauv2") + "BACKUP_PASSPHRASE=trop-court\n")
    r = lancer(bk2)
    S.check("phrase trop courte : sauvegarde annulée, rien laissé sur le disque", r.returncode != 0 and "trop courte" in r.stderr and not glob.glob(f"{d}/sauv2/jend_db_*"))
    photo.unlink()

    S.titre("VÉRIFICATEUR : NOUVEAUX CONTRÔLES")
    def verifier(env_texte):
        f = d / "v.env"; f.write_text(env_texte)
        return subprocess.run([PHP, str(JEND / "scripts" / "verifier-production.php"), f"--env={f}"], capture_output=True, text=True, timeout=90).stdout
    base_prod = (f"APP_ENV=prod\nAPP_URL=https://jend.example.test\nPAIEMENT_FOURNISSEUR=paydunya\nPAIEMENT_SECRET={'ab' * 32}\nMAIL_DRIVER=smtp\nSMTP_HOST=h\nSMTP_USER=u\nSMTP_PASS=p\n"
                 f"DB_HOST={DB['host']}\nDB_PORT={DB['port']}\nDB_NAME={DB['name']}\nDB_USER={DB['user']}\nDB_PASS=\nADMIN_EMAIL=moi@example.test\n")
    o = verifier(base_prod)
    S.check("APP_KEY manquant détecté (bloquant)", "✘ APP_KEY manquant" in o)
    S.check("avec APP_KEY valide : accepté", "✔ APP_KEY défini" in verifier(base_prod + "APP_KEY=" + "cd" * 32 + "\n"))
    S.check("ADMIN_2FA_OBLIGATOIRE=0 détecté (bloquant)", "✘ ADMIN_2FA_OBLIGATOIRE=0" in verifier(base_prod + "ADMIN_2FA_OBLIGATOIRE=0\n"))
    S.check("par défaut en production : 2FA admin obligatoire", "✔ 2FA obligatoire pour l'administrateur" in o)
    S.check("administrateur(s) sans 2FA détecté(s) dans la base (bloquant)", re.search(r"✘ \d+ administrateur\(s\) sans double authentification", o) is not None, o[-500:])
    S.check("sauvegardes non chiffrées, IP admin ouverte : avertissements", "⚠ BACKUP_PASSPHRASE non défini" in o and "⚠ Accès /admin ouvert" in o)
    o2 = verifier(base_prod + "BACKUP_PASSPHRASE=" + "z" * 20 + "\nADMIN_IPS=1.2.3.4\n")
    S.check("avec phrase de sauvegarde et ADMIN_IPS : validés", "✔ Sauvegardes chiffrées" in o2 and "✔ Accès /admin restreint par IP" in o2)
finally:
    sql("DELETE FROM journal_admin WHERE admin_id IS NULL OR admin_id IN (SELECT id FROM users WHERE email LIKE '%-t11@jend.local')")
    sql("DELETE r FROM retraits r JOIN boutiques b ON b.id=r.boutique_id JOIN users u ON u.id=b.user_id WHERE u.email LIKE '%-t11@jend.local'")
    sql("DELETE FROM produits WHERE slug='produit-t11'")
    sql("DELETE FROM commandes WHERE client_id IN (SELECT id FROM users WHERE email LIKE '%-t11@jend.local')")
    alertes_vider()
    ok = S.fin()
    for f in glob.glob(str(JEND / "uploads" / "produits" / "tmpchiff-t11*")):
        os.unlink(f)
sys.exit(0 if ok else 1)
