"""Étape 53 : affichage sur téléphone (en-tête compact, onglets défilants, filtres repliables, tableaux qui ne débordent pas)."""
import sys, re
from lib import *

S = Suite("Étape 53 — téléphones")
try:
    S.titre("MOBILE")
    css = (JEND / "assets" / "css" / "identite.css").read_text()
    js = (JEND / "assets" / "js" / "main.js").read_text()
    S.check("en-tête compact et qui se cache en descendant", ".entete.entete-cachee" in css and "entete-cachee" in js and "passive: true" in js)
    S.check("pas de zoom automatique de l'iPhone sur les champs (16 px)", re.search(r"input:not\(\[type=checkbox\]\)[^{]*\{ font-size: 16px", css) is not None)
    S.check("onglets sur une ligne qui défile au doigt", re.search(r"\.onglets \{ flex-wrap: nowrap; overflow-x: auto", css) is not None)
    S.check("animations d'entrée désactivées sur téléphone (affichage immédiat)", "!mobile && typeof Splitting" in js and "!leger && !mobile && window.gsap" in js)
    h = Client().get("produits")[1]
    S.check("catalogue : filtres dans un bloc repliable « Filtrer et trier »", 'class="filtres-repli"' in h and "Filtrer et trier" in h)
    S.check("chaque grand tableau est dans un cadre qui défile (aucun ne fait déborder la page)",
            all(f.read_text().count("<table") <= f.read_text().count("table-defile") for f in (JEND / "pages").glob("*.php") if "<table" in f.read_text()))
    S.check("cartes produits : le bouton « + » reste dans la carte sur petit écran", ".carte .prix-ligne { flex-wrap: wrap" in css)
finally:
    ok = S.fin()
sys.exit(0 if ok else 1)
