"""Étape 50 : tailles et pointures (réglage par catégorie, stock par taille, choix obligatoire, commande, annulation, dépense)."""
import sys, re
from lib import *

S = Suite("Étape 50 — tailles et pointures", ["ad-t50@jend.local", "cl-t50@jend.local", "c2-t50@jend.local", "va-t50@jend.local"])
E = dict(zip(["ad", "cl", "c2", "va"], S.emails))
try:
    S.nettoyer()
    sql("DELETE FROM produits WHERE slug IN ('chaussure-t50','tissu-t50')"); sql("DELETE FROM boutiques WHERE slug='boutique-t50'")
    sql("DELETE FROM categories WHERE slug IN ('chaussures-t50','tissus-t50')"); sql("DELETE FROM zones_livraison WHERE nom='Zone T50'")
    sql("INSERT INTO zones_livraison (nom, region, frais, delai_jours) VALUES ('Zone T50', 'Touba', 1000, 1)")
    zone = int(sql("SELECT id FROM zones_livraison WHERE nom='Zone T50'"))
    pw = mot_de_passe()
    for k, nom, role in (("ad", "Admin T50", "admin"), ("cl", "Cliente T50", "client"), ("c2", "Autre T50", "client"), ("va", "Vendeur T50", "vendeur")):
        sql(f"INSERT INTO users (nom,email,mot_de_passe,role) VALUES ('{nom}','{E[k]}','{hash_mdp(pw)}','{role}')")
    sql(f"INSERT INTO boutiques (user_id,nom,slug,statut,commission_pct) SELECT id,'Boutique T50','boutique-t50','active',1 FROM users WHERE email='{E['va']}'")
    AD, C, C2, VA = Client(), Client(), Client(), Client()
    for cl, k in ((AD, "ad"), (C, "cl"), (C2, "c2"), (VA, "va")):
        cl.post("connexion", {"email": E[k], "mot_de_passe": pw})
    txt = lambda cl, u: cl.get(u)[1].replace("&#039;", "'").replace(" ", " ").replace("&nbsp;", " ").replace("\xa0", " ")

    S.titre("RÉGLAGE PAR CATÉGORIE (ADMIN)")
    AD.post("admin/categories", {"action": "ajouter", "nom": "Chaussures T50", "parent_id": "", "icone": "", "option_type": "pointure"})
    AD.post("admin/categories", {"action": "ajouter", "nom": "Tissus T50", "parent_id": "", "icone": "", "option_type": "n'importe quoi"})
    cat_ch, cat_ti = sql("SELECT id FROM categories WHERE nom='Chaussures T50'"), sql("SELECT id FROM categories WHERE nom='Tissus T50'")
    S.check("catégorie « Chaussures » : pointures ; valeur inventée ignorée (pas de taille)", sql(f"SELECT option_type FROM categories WHERE id={cat_ch}") == "pointure" and sql(f"SELECT option_type IS NULL FROM categories WHERE id={cat_ti}") == "1")
    VA.post("admin/categories", {"action": "option", "id": cat_ti, "option_type": "taille"}, page_token="vendeur")
    S.check("un vendeur ne peut pas changer ce réglage", sql(f"SELECT option_type IS NULL FROM categories WHERE id={cat_ti}") == "1")

    S.titre("LE VENDEUR INDIQUE SES POINTURES")
    base = {"nom": "Babouches T50", "categorie_id": cat_ch, "description": "x", "prix": "12000", "prix_barre": "", "stock": "99", "statut": "publie", "video_url": ""}
    h = txt(VA, "vendeur/produits/nouveau")
    S.check("le formulaire propose les pointures 35 à 47 pour cette catégorie", 'data-option="pointure"' in h and 'name="variantes[pointure][0][libelle]" value="35"' in h)
    VA.multipart("vendeur/produits/nouveau", {**base, "avec_tailles": "1"}, [])
    S.check("« plusieurs tailles » coché sans aucune taille : refusé", sql("SELECT COUNT(*) FROM produits WHERE nom='Babouches T50'") == "0")
    champs = {**base, "avec_tailles": "1"}
    # 40 (index 5) : 2 en stock ; 41 (index 6) : 0 ; 42 (index 7) : 5 ; + une pointure libre « 48 » : 1
    for i, st in ((5, "2"), (6, "0"), (7, "5")):
        champs[f"variantes[pointure][{i}][actif]"] = "1"; champs[f"variantes[pointure][{i}][libelle]"] = str(35 + i); champs[f"variantes[pointure][{i}][stock]"] = st
    champs["variantes[pointure][13][actif]"] = "1"; champs["variantes[pointure][13][libelle]"] = "48"; champs["variantes[pointure][13][stock]"] = "1"
    VA.multipart("vendeur/produits/nouveau", champs, [])
    pid = sql("SELECT id FROM produits WHERE nom='Babouches T50'")
    S.check("produit créé : 4 pointures, stock du produit = somme (8), type « pointure »",
            sql(f"SELECT GROUP_CONCAT(CONCAT(libelle,'=',stock) ORDER BY position) FROM produit_variantes WHERE produit_id={pid}") == "40=2,41=0,42=5,48=1"
            and sql(f"SELECT CONCAT(stock,'|',option_type) FROM produits WHERE id={pid}") == "8|pointure")
    slug = sql(f"SELECT slug FROM produits WHERE id={pid}")
    v = dict(l.split("\t")[::-1] for l in sql(f"SELECT id, libelle FROM produit_variantes WHERE produit_id={pid}").splitlines())

    S.titre("LE CLIENT CHOISIT SA POINTURE")
    h = txt(C, f"produit/{slug}")
    S.check("fiche produit : choix « Pointure » obligatoire, 41 épuisée et non sélectionnable", "Pointure" in h and 'name="variante_id"' in h and re.search(r'value="' + v["41"] + r'" required disabled', h) is not None)
    S.check("la carte du produit envoie vers la fiche pour choisir (pas d'ajout direct)", "Choisir la taille" in txt(C, "boutique/boutique-t50"))
    ajout = lambda d: C.post("panier/ajouter", {"produit_id": pid, "quantite": 1, "retour": f"/jend/produit/{slug}", **d}, page_token=f"produit/{slug}")
    ajout({})
    S.check("sans choisir : refusé, panier vide", "Choisissez d'abord votre pointure" in txt(C, f"produit/{slug}") and "Babouches" not in txt(C, "panier"))
    ajout({"variante_id": v["41"]})
    S.check("pointure épuisée : refusée", "épuisée" in txt(C, f"produit/{slug}") and "Pointure : 41" not in txt(C, "panier"))
    ajout({"variante_id": "999999"})
    S.check("pointure inventée : refusée", "Pointure :" not in txt(C, "panier"))
    ajout({"variante_id": v["40"], "quantite": 5})
    ajout({"variante_id": v["42"]})
    h = txt(C, "panier")
    S.check("panier : deux lignes séparées, 40 plafonnée à son stock (2), 42 × 1", "Pointure : 40" in h and "Pointure : 42" in h and 'value="2" min="1" max="2"' in h)
    C.post("panier/modifier", {"cle": f"{pid}:{v['42']}", "action": "maj", "quantite": "9"}, page_token="panier")
    S.check("quantité limitée au stock de la pointure (42 : 5)", 'value="5" min="1" max="5"' in txt(C, "panier"))
    C.post("panier/modifier", {"cle": f"{pid}:{v['42']}", "action": "maj", "quantite": "1"}, page_token="panier")
    h = txt(C, "commande")
    S.check("récapitulatif de commande avec les pointures", "(Pointure : 40)" in h and "(Pointure : 42)" in h)
    _, _, hd = C.post("commande", {"nom": "Cliente T50", "telephone": "77 123 45 50", "zone_id": zone, "adresse": "Rue 50 Touba", "methode": "wave"})
    ref = hd["Location"].rsplit("/", 1)[-1]
    S.check("commande : 2 lignes avec la pointure copiée", sql(f"SELECT GROUP_CONCAT(CONCAT(cl.quantite,'x',cl.variante_libelle) ORDER BY cl.variante_libelle) FROM commande_lignes cl JOIN commande_boutiques cb ON cb.id=cl.commande_boutique_id JOIN commandes c ON c.id=cb.commande_id WHERE c.reference='{ref}'") == "2xPointure : 40,1xPointure : 42")
    S.check("stocks diminués : 40 → 0, 42 → 4, produit 8 → 5", sql(f"SELECT GROUP_CONCAT(CONCAT(libelle,'=',stock) ORDER BY position) FROM produit_variantes WHERE produit_id={pid}") == "40=0,41=0,42=4,48=1" and sql(f"SELECT stock FROM produits WHERE id={pid}") == "5")
    S.check("le vendeur voit la pointure à préparer", "Pointure : 40" in txt(VA, "vendeur/commandes") and "Pointure : 42" in txt(VA, "vendeur/commandes"))
    S.check("le client la voit sur sa commande", "Pointure : 40" in txt(C, f"commande/{ref}"))
    C2.req("panier/ajouter", {"csrf": C2.token(f"produit/{slug}"), "produit_id": pid, "variante_id": v["40"], "quantite": 1, "retour": "/jend/produits"})
    S.check("autre client : la 40 est maintenant épuisée", "Pointure : 40" not in txt(C2, "panier"))
    C.post("commande/annuler", {"reference": ref}, page_token=f"commande/{ref}")
    S.check("annulation : chaque pointure revient en stock (40 → 2, 42 → 5, produit → 8)",
            sql(f"SELECT GROUP_CONCAT(CONCAT(libelle,'=',stock) ORDER BY position) FROM produit_variantes WHERE produit_id={pid}") == "40=2,41=0,42=5,48=1" and sql(f"SELECT stock FROM produits WHERE id={pid}") == "8")

    S.titre("MODIFICATION ET DÉPENSE DU MOIS")
    C.req("panier/ajouter", {"csrf": C.token(f"produit/{slug}"), "produit_id": pid, "variante_id": v["42"], "quantite": 1, "retour": "/jend/produits"})
    C.post("depense/nouvelle", {"nom": "Chaussures du mois", "jour": "3", "livraison_nom": "Cliente T50", "livraison_telephone": "77 123 45 50", "zone_id": zone, "adresse": "Rue 50 Touba"})
    did = sql(f"SELECT d.id FROM depenses d JOIN users u ON u.id=d.client_id WHERE u.email='{E['cl']}'")
    S.check("la dépense du mois garde la pointure", sql(f"SELECT variante_id FROM depense_lignes WHERE depense_id={did}") == v["42"] and "Pointure : 42" in txt(C, f"depense/{did}"))
    C.post(f"depense/{did}", {"action": "commander"})
    S.check("« Commander maintenant » remet la bonne pointure au panier", "Pointure : 42" in txt(C, "panier"))
    champs2 = {**base, "avec_tailles": "1", "variantes[pointure][0][actif]": "1", "variantes[pointure][0][libelle]": "40", "variantes[pointure][0][stock]": "3"}
    VA.multipart(f"vendeur/produits/{pid}/modifier", champs2, [])
    S.check("le vendeur retire des pointures : il ne reste que la 40 (3), stock 3", sql(f"SELECT GROUP_CONCAT(CONCAT(libelle,'=',stock)) FROM produit_variantes WHERE produit_id={pid}") == "40=3" and sql(f"SELECT stock FROM produits WHERE id={pid}") == "3")
    S.check("la pointure retirée disparaît du panier du client (pas de commande impossible)", "Pointure : 42" not in txt(C, "panier"))
    VA.multipart(f"vendeur/produits/{pid}/modifier", {**base, "categorie_id": cat_ti, "stock": "7"}, [])
    S.check("produit passé dans une catégorie sans taille : tailles supprimées, stock normal", sql(f"SELECT COUNT(*) FROM produit_variantes WHERE produit_id={pid}") == "0" and sql(f"SELECT CONCAT(stock,'|',COALESCE(option_type,'-')) FROM produits WHERE id={pid}") == "7|-")
    S.check("et le client peut l'ajouter directement, sans choix", "Babouches" in (C.req("panier/ajouter", {"csrf": C.token(f"produit/{slug}"), "produit_id": pid, "quantite": 1, "retour": "/jend/produits"}) and txt(C, "panier")))
finally:
    ok = S.fin()
    sql("DELETE FROM produits WHERE nom='Babouches T50'"); sql("DELETE FROM boutiques WHERE slug='boutique-t50'")
    sql("DELETE FROM categories WHERE nom IN ('Chaussures T50','Tissus T50')"); sql("DELETE FROM zones_livraison WHERE nom='Zone T50'")
sys.exit(0 if ok else 1)
