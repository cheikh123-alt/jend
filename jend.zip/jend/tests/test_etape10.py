"""Étape 10 : sécurité (en-têtes, CSP, limites par IP, sessions), production, SMTP, sauvegarde/restauration, vérificateur."""
import base64, email.header, glob, gzip, json, os, re, socketserver, subprocess, sys, tempfile, threading, time
from pathlib import Path
from lib import *

S = Suite("Étape 10 — sécurité et production",
          ["alice-t10@jend.local", "bob-t10@jend.local", "ad-t10@jend.local", "v-t10@jend.local"] + [f"reg{i}-t10@jend.local" for i in range(1, 8)])
E = S.emails
INC = JEND / "includes"
sp_headers = lambda h, nom: h.get_all(nom) or []


def cookies_set(h):
    return [c for c in sp_headers(h, "Set-Cookie")]


def php_cli_mail(envfile, dest, sujet, corps):
    code = f"require '{INC}/env.php'; require '{INC}/mail.php'; echo json_encode(envoyer_email($argv[1], $argv[2], $argv[3]));"
    e = dict(os.environ); e["JEND_ENV_FILE"] = str(envfile)
    r = subprocess.run([PHP, "-r", code, "--", dest, sujet, corps], capture_output=True, text=True, env=e, timeout=40)
    return r.stdout.strip(), r.stderr


# ---------- faux serveur SMTP ----------
class SMTPFake(socketserver.ThreadingTCPServer):
    allow_reuse_address = True
    daemon_threads = True


class Handler(socketserver.StreamRequestHandler):
    def handle(self):
        srv = self.server
        w = lambda s: self.wfile.write((s + "\r\n").encode())
        w("220 fake ESMTP")
        while True:
            ligne = self.rfile.readline()
            if not ligne:
                return
            cmd = ligne.decode().rstrip("\r\n"); u = cmd.upper()
            if u.startswith("EHLO"):
                self.wfile.write(b"250-fake\r\n250-AUTH LOGIN PLAIN\r\n250 8BITMIME\r\n")
            elif u == "AUTH LOGIN":
                w("334 VXNlcm5hbWU6"); user = base64.b64decode(self.rfile.readline().strip()).decode()
                w("334 UGFzc3dvcmQ6"); pw = base64.b64decode(self.rfile.readline().strip()).decode()
                srv.tentatives.append((user, pw))
                if (user, pw) == srv.creds:
                    srv.authed = True; w("235 ok")
                else:
                    w("535 5.7.8 refused")
            elif u.startswith("MAIL FROM"):
                srv.mail_from = cmd; w("250 ok")
            elif u.startswith("RCPT TO"):
                srv.rcpt = cmd; w("250 ok")
            elif u == "DATA":
                w("354 go"); lignes = []
                while True:
                    l = self.rfile.readline().decode().rstrip("\r\n")
                    if l == ".":
                        break
                    lignes.append(l[1:] if l.startswith("..") else l)
                srv.messages.append("\r\n".join(lignes)); w("250 queued")
            elif u == "QUIT":
                w("221 bye"); return
            else:
                w("502 unknown")


def decoder_entete(valeur):
    return "".join(p.decode(c or "utf-8") if isinstance(p, bytes) else p for p, c in email.header.decode_header(valeur))


try:
    S.nettoyer()
    S.publier_demo()
    pw = mot_de_passe()
    A, Bo, AD, V = Client(), Client(), Client(), Client()
    A.post("inscription", {"nom": "Alice Test", "email": E[0], "mot_de_passe": pw, "mot_de_passe2": pw})
    Bo.post("inscription", {"nom": "Bob Test", "email": E[1], "mot_de_passe": pw, "mot_de_passe2": pw})
    mdp_admin = mot_de_passe()
    sql(f"INSERT INTO users (nom,email,mot_de_passe,role) VALUES ('Admin T10','{E[2]}','{hash_mdp(mdp_admin)}','admin')")
    AD.post("connexion", {"email": E[2], "mot_de_passe": mdp_admin})
    V.post("inscription", {"nom": "Vendeur T10", "email": E[3], "mot_de_passe": pw, "mot_de_passe2": pw})
    V.post("vendre", {"nom": "Boutique T10", "description": "", "telephone": "77 111 22 33"})
    sql("DELETE FROM limites")

    S.titre("EN-TÊTES DE SÉCURITÉ")
    s, h, hd = Client().get("")
    csp = hd.get("Content-Security-Policy", "")
    script_src = re.search(r"script-src ([^;]*)", csp).group(1) if "script-src" in csp else ""
    S.check("Content-Security-Policy présente", bool(csp))
    S.check("scripts : ni 'unsafe-inline' ni 'unsafe-eval'", "unsafe-inline" not in script_src and "unsafe-eval" not in script_src, script_src)
    style_src = re.search(r"style-src ([^;]*)", csp).group(1) if "style-src" in csp else ""
    S.check("styles : plus d'exception 'unsafe-inline'", "unsafe-inline" not in style_src, style_src)
    S.check("object-src none, base-uri/form-action/frame-ancestors restreints", all(x in csp for x in ("object-src 'none'", "base-uri 'self'", "form-action 'self'", "frame-ancestors 'self'")))
    S.check("AUCUN domaine externe dans la CSP : tout vient du site lui-même", re.findall(r"https?://", csp) == [] and script_src == "'self'" and style_src == "'self'" and re.search(r"font-src ([^;]*)", csp).group(1) == "'self'", csp)
    S.check("X-Frame-Options, nosniff, Referrer-Policy, Permissions-Policy", all(hd.get(x) for x in ("X-Frame-Options", "X-Content-Type-Options", "Referrer-Policy", "Permissions-Policy")))
    S.check("pas de HSTS en HTTP de développement", hd.get("Strict-Transport-Security") is None)

    S.titre("AUCUN SCRIPT, GESTIONNAIRE NI STYLE EN LIGNE (compatible CSP stricte)")
    tok = A.token("produits"); A.req("panier/ajouter", {"csrf": tok, "produit_id": 2, "quantite": 1, "retour": "/jend/produits"})
    pages = [("anonyme", Client(), p) for p in ("", "produits", "connexion", "inscription", "panier", "vendre", "categories")]
    pages += [("client", A, p) for p in ("commande", "compte", "compte/adresses", "compte/profil", "favoris")]
    pages += [("vendeur", V, p) for p in ("vendeur", "vendeur/produits", "vendeur/produits/nouveau", "vendeur/commandes", "vendeur/gains", "vendeur/boutique")]
    pages += [("admin", AD, p) for p in ("admin", "admin/boutiques", "admin/produits", "admin/commandes", "admin/retraits", "admin/categories", "admin/journal")]
    for role, cl, p in pages:
        s, h, _ = cl.get(p)
        inline = re.findall(r"\son[a-z]+\s*=", h) + re.findall(r"<script(?![^>]*\bsrc=)[^>]*>", h) + re.findall(r"<[a-z][^>]*\sstyle=", h)
        externes = re.findall(r'<(?:script|link|img)\b[^>]*\b(?:src|href)=["\'](?:https?:)?//[^"\']+', h)
        S.check(f"/{p or ''} ({role}) : 200, aucun script/style en ligne, aucune ressource externe", s == 200 and not inline and not externes, f"statut {s} {inline[:2]} {externes[:2]}")

    S.titre("BIBLIOTHÈQUES HÉBERGÉES SUR LE SITE (aucun CDN)")
    sommes = (JEND / "assets" / "vendor" / "SHA256SUMS").read_text().strip().splitlines()
    import hashlib as _h
    ecarts = [rel for ligne in sommes for (emp, rel) in [ligne.split(None, 1)] if not (JEND / "assets" / "vendor" / rel.strip()).is_file() or _h.sha256((JEND / "assets" / "vendor" / rel.strip()).read_bytes()).hexdigest() != emp]
    S.check(f"{len(sommes)} fichiers présents, empreintes SHA-256 conformes à SHA256SUMS", len(sommes) >= 16 and not ecarts, str(ecarts))
    types = {"css/fontshare.css": "text/css", "css/phosphor-regular.css": "text/css", "css/phosphor-fill.css": "text/css", "css/splitting.css": "text/css", "js/gsap.min.js": "javascript", "js/ScrollTrigger.min.js": "javascript", "js/lenis.min.js": "javascript", "js/splitting.min.js": "javascript", "fonts/Phosphor.woff2": "font/woff2", "fonts/satoshi-400.woff2": "font/woff2", "fonts/clash-display-700.woff2": "font/woff2"}
    ok_types = all((lambda r: r[0] == 200 and types[f] in (r[2].get("Content-Type") or "") and "immutable" in (r[2].get("Cache-Control") or ""))(Client().get(f"assets/vendor/{f}")) for f in types)
    S.check("fichiers servis avec le bon type et un cache d'un an", ok_types)
    S.check("SHA256SUMS et LICENCES.md ne sont pas téléchargeables", Client().get("assets/vendor/SHA256SUMS")[0] == 403 and Client().get("assets/vendor/LICENCES.md")[0] == 403)
    css_ok = all(not re.search(r"https?://", (JEND / "assets" / "vendor" / "css" / f).read_text()) for f in ("fontshare.css", "phosphor-regular.css", "phosphor-fill.css", "splitting.css"))
    S.check("les feuilles de style hébergées ne pointent vers aucun domaine externe", css_ok)
    S.check("la police du texte est bien Satoshi (et non plus la police du système)", "font-family: var(--f-texte)" in (JEND / "assets" / "css" / "style.css").read_text() and "'Satoshi'" in (JEND / "assets" / "css" / "style.css").read_text())

    S.titre("BLOCAGE DES CONNEXIONS PAR E-MAIL")
    X = Client()
    for i in range(5):
        h = X.post("connexion", {"email": E[0], "mot_de_passe": "mauvais" + str(i)})[1]
    S.check("5 échecs : message « incorrect »", "incorrect" in h)
    s, h, _ = Client().post("connexion", {"email": E[0], "mot_de_passe": pw})
    S.check("6e tentative avec le BON mot de passe : bloquée (15 min)", s == 200 and "Trop de tentatives" in h)
    S.check("depuis un autre navigateur aussi (limite en base, pas en session)", "Trop de tentatives" in Client().post("connexion", {"email": E[0], "mot_de_passe": pw})[1])
    S.check("un autre compte n'est pas touché", Client().post("connexion", {"email": E[1], "mot_de_passe": pw})[0] == 302)
    sql("DELETE FROM limites")
    S.check("la limite levée, la connexion refonctionne", Client().post("connexion", {"email": E[0], "mot_de_passe": pw})[0] == 302)

    S.titre("BLOCAGE PAR ADRESSE IP (même en changeant d'e-mail ou d'en-tête X-Forwarded-For)")
    for i in range(20):
        Client().post("connexion", {"email": f"inconnu{i}@t10.local", "mot_de_passe": "x"}, headers={"X-Forwarded-For": f"10.0.0.{i}"})
    s, h, _ = Client().post("connexion", {"email": E[1], "mot_de_passe": pw}, headers={"X-Forwarded-For": "203.0.113.77"})
    S.check("après 20 échecs depuis la même IP, même un compte valide est bloqué", "Trop de tentatives" in h and s == 200)
    S.check("l'en-tête X-Forwarded-For falsifié ne contourne pas la limite (TRUSTED_PROXY inactif)", True)
    sql("DELETE FROM limites")

    S.titre("LIMITE D'INSCRIPTIONS ET DE « MOT DE PASSE OUBLIÉ »")
    res = []
    for i in range(1, 7):
        c = Client()
        s, h, hd = c.post("inscription", {"nom": f"Reg {i}", "email": f"reg{i}-t10@jend.local", "mot_de_passe": pw, "mot_de_passe2": pw})
        res.append((s, "Trop d'inscriptions" in h or "Trop d&#039;inscriptions" in h))
    S.check("5 inscriptions acceptées par heure et par IP", all(s == 302 for s, _ in res[:5]), str(res))
    S.check("la 6e est refusée", res[5][0] == 200 and res[5][1] and sql("SELECT COUNT(*) FROM users WHERE email='reg6-t10@jend.local'") == "0", str(res[5]))
    sql("DELETE FROM limites")
    msgs = [Client().post("mot-de-passe-oublie", {"email": E[0]})[1] for _ in range(4)]
    S.check("3 demandes par e-mail acceptées, la 4e refusée", all("Si un compte existe" in m for m in msgs[:3]) and "Trop de demandes" in msgs[3])
    sql("DELETE FROM limites")
    msgs = [Client().post("mot-de-passe-oublie", {"email": f"x{i}@t10.local"})[1] for i in range(6)]
    S.check("5 demandes par IP acceptées, la 6e refusée", all("Si un compte existe" in m for m in msgs[:5]) and "Trop de demandes" in msgs[5])
    sql("DELETE FROM limites")

    S.titre("WEBHOOK : DÉLUGE DE SIGNATURES INVALIDES")
    codes = [webhook("SIM-" + "b" * 24, "reussi", 1000, signature="0" * 64)[0] for _ in range(31)]
    S.check("30 signatures invalides → 401, la 31e → 429", codes[:30].count(401) == 30 and codes[30] == 429, str(codes[-3:]))
    sql("DELETE FROM limites")

    S.titre("SESSIONS")
    forge = "attaquantchoisitcetid1234567890ab"
    s, _, hd = Client().req("connexion", headers={"Cookie": f"jend_session={forge}"})
    nouveaux = [c for c in cookies_set(hd) if c.startswith("jend_session=")]
    S.check("identifiant de session imposé par un attaquant : refusé, un nouveau est généré", bool(nouveaux) and forge not in nouveaux[0], str(nouveaux))
    ck = nouveaux[0] if nouveaux else ""
    S.check("cookie HttpOnly + SameSite=Lax (et pas Secure en HTTP local)", "httponly" in ck.lower() and "samesite=lax" in ck.lower() and "secure" not in ck.lower(), ck)
    s, _, hd = A.get("compte")
    S.check("page d'un utilisateur connecté : Cache-Control no-store", "no-store" in (hd.get("Cache-Control") or ""))
    # déconnexion : l'ancien cookie ne doit plus ouvrir de session
    L = Client(); L.post("connexion", {"email": E[1], "mot_de_passe": pw})
    cookie_vol = "; ".join(f"{c.name}={c.value}" for c in L.jar)
    S.check("avec la session : accès à /compte", Client().req("compte", headers={"Cookie": cookie_vol})[0] == 200)
    L.post("deconnexion", {}, page_token="compte")
    S.check("après déconnexion, le cookie volé n'ouvre plus rien", Client().req("compte", headers={"Cookie": cookie_vol})[0] == 302)
    S.modifier_env(SESSION_INACTIVITE_SECONDES="2")
    I = Client(); I.post("connexion", {"email": E[1], "mot_de_passe": pw})
    time.sleep(3.2)
    s, _, hd = I.get("compte")
    S.check("inactivité dépassée : déconnexion automatique", s == 302 and "connexion" in hd.get("Location", ""))
    S.check("message « session expirée » affiché", "expiré" in I.get("connexion")[1])
    S.restaurer_env()
    sql("DELETE FROM limites")

    S.titre("MODE PRODUCTION")
    S.modifier_env(APP_ENV="prod", MAIL_DRIVER="log", APP_URL="https://jend.example.test", TRUSTED_PROXY="0")
    s, _, hd = Client().req("produits?x=1")
    S.check("HTTP → redirection 301 vers HTTPS de l'adresse officielle", s == 301 and hd.get("Location") == "https://jend.example.test/jend/produits?x=1", hd.get("Location", ""))
    s, _, hd = Client().req("produits", headers={"Host": "evil.example"})
    S.check("l'en-tête Host falsifié n'influence pas la redirection", hd.get("Location", "").startswith("https://jend.example.test/"))
    s, _, hd = Client().req("produits", headers={"X-Forwarded-Proto": "https"})
    S.check("X-Forwarded-Proto ignoré sans TRUSTED_PROXY (pas de contournement du HTTPS)", s == 301)
    S.modifier_env(APP_ENV="prod", MAIL_DRIVER="log", APP_URL="https://jend.example.test", TRUSTED_PROXY="1")
    xf = {"X-Forwarded-Proto": "https"}
    s, _, hd = Client().req("produits", headers=xf)
    S.check("derrière un proxy de confiance en HTTPS : pas de redirection, HSTS actif", s == 200 and "max-age=31536000" in (hd.get("Strict-Transport-Security") or ""))
    ck = [c for c in cookies_set(hd)]
    S.check("cookie de session « __Host- » + Secure + HttpOnly", any(c.startswith("__Host-jend_session=") and "secure" in c.lower() and "httponly" in c.lower() and "path=/;" in c.lower() and "domain" not in c.lower() for c in ck), str(ck))
    s, h, _ = Client().req("paiement/webhook", raw=b"{}", headers={"X-Signature": "x", **xf})
    S.check("erreur interne : page propre, aucun détail technique", s == 500 and "Un souci de notre côté" in h and "PAIEMENT_SECRET" not in h and "/Applications/" not in h and "Stack" not in h, h[:120])
    S.modifier_env(APP_ENV="prod", MAIL_DRIVER="log", APP_URL="https://jend.example.test", TRUSTED_PROXY="1", DB_PASS="mauvais-mot-de-passe")
    s, h, _ = Client().req("", headers=xf)
    S.check("base de données en panne : message neutre, aucun identifiant révélé", s == 500 and "momentanément indisponible" in h and "Access denied" not in h and "root" not in h, h[:120])
    S.restaurer_env()
    S.check("retour en développement : le site répond de nouveau", Client().get("")[0] == 200)

    S.titre("E-MAILS SMTP (faux serveur local)")
    srv = SMTPFake(("127.0.0.1", 0), Handler)
    srv.creds = ("utilisateur", "p@ss'w\"d$1"); srv.authed = False; srv.messages = []; srv.tentatives = []; srv.mail_from = srv.rcpt = ""
    port = srv.server_address[1]
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    d = Path(tempfile.mkdtemp(prefix="jend-env-"))
    def ecrire_env(nom, **kw):
        base = {"APP_ENV": "dev", "APP_URL": "https://jend.example.test", "MAIL_DRIVER": "smtp", "SMTP_HOST": "127.0.0.1", "SMTP_PORT": str(port),
                "SMTP_SECURE": "none", "SMTP_USER": srv.creds[0], "SMTP_PASS": srv.creds[1], "MAIL_FROM": "boutique@jend.example.test", "MAIL_FROM_NAME": "Jënd"}
        base.update(kw)
        f = d / nom; f.write_text("\n".join(f"{k}={v}" for k, v in base.items())); return f
    sujet = "Réinitialisation – é à ç ✓"
    corps = "Bonjour é\n.\nLigne après un point seul\n" + "x" * 300
    out, err = php_cli_mail(ecrire_env("ok.env"), "client@example.com", sujet, corps)
    S.check("envoi SMTP réussi (authentification comprise)", out == "true" and srv.authed, f"{out} {err[:150]}")
    msg = srv.messages[-1] if srv.messages else ""
    entetes, _, brut = msg.partition("\r\n\r\n")
    hdrs = dict(l.split(": ", 1) for l in entetes.split("\r\n") if ": " in l)
    S.check("enveloppe correcte (MAIL FROM / RCPT TO)", "boutique@jend.example.test" in srv.mail_from and "client@example.com" in srv.rcpt)
    S.check("sujet accentué correctement encodé", decoder_entete(hdrs.get("Subject", "")) == sujet)
    S.check("expéditeur « Jënd <boutique@…> » correctement encodé", "boutique@jend.example.test" in hdrs.get("From", "") and decoder_entete(hdrs.get("From", "")).startswith("Jënd"))
    S.check("corps intact (accents, ligne « . » isolée, lignes longues)", base64.b64decode("".join(brut.split("\r\n"))).decode() == corps)
    S.check("en-têtes MIME UTF-8 + Message-ID + Date", "charset=UTF-8" in hdrs.get("Content-Type", "") and "@jend.example.test>" in hdrs.get("Message-ID", "") and "Date" in hdrs)
    n = len(srv.messages)
    out, err = php_cli_mail(ecrire_env("mauvais.env", SMTP_PASS="mauvais"), "client@example.com", "x", "y")
    S.check("mauvais identifiants : échec propre", out == "false" and len(srv.messages) == n and "identifiants refusés" in err)
    S.check("le mot de passe n'apparaît JAMAIS dans les journaux d'erreurs", "mauvais" not in err and srv.creds[1] not in err and base64.b64encode(b"mauvais").decode() not in err)
    out, err = php_cli_mail(ecrire_env("hs.env", SMTP_PORT="1"), "client@example.com", "x", "y")
    S.check("serveur injoignable : échec rapide et propre", out == "false" and "connexion impossible" in err)
    out, err = php_cli_mail(ecrire_env("prod-clair.env", APP_ENV="prod"), "client@example.com", "x", "y")
    S.check("production + identifiants sans chiffrement : refusé", out == "false" and "refusé" in err and len(srv.messages) == n)
    for dest, suj in (("a@b.com\r\nBcc: pirate@x.com", "x"), ("a@b.com", "Sujet\r\nBcc: pirate@x.com"), ("pas-une-adresse", "x")):
        out, err = php_cli_mail(ecrire_env("ok.env"), dest, suj, "y")
        S.check(f"injection d'en-têtes / adresse invalide refusée ({dest[:18]!r})", out == "false" and len(srv.messages) == n)
    srv.shutdown()

    S.titre("SAUVEGARDE ET RESTAURATION")
    dest = Path(tempfile.mkdtemp(prefix="jend-backup-"))
    e = d / "backup.env"
    e.write_text(f"APP_ENV=dev\nDB_HOST={DB['host']}\nDB_PORT={DB['port']}\nDB_NAME={DB['name']}\nDB_USER={DB['user']}\nDB_PASS={DB['pass']}\nBACKUP_DIR={dest}/sauv\nBACKUP_KEEP=2\n")
    photo = JEND / "uploads" / "produits" / "tmpbackup-t10.jpg"
    photo.write_bytes(b"\xff\xd8\xff" + b"0" * 500)
    def lancer():
        env2 = dict(os.environ); env2["JEND_ENV_FILE"] = str(e)
        return subprocess.run([PHP, str(JEND / "scripts" / "sauvegarde.php")], capture_output=True, text=True, env=env2, timeout=120)
    r = lancer()
    S.check("sauvegarde réussie (base + photos)", r.returncode == 0 and "Base sauvegardée" in r.stdout and "Photos sauvegardées" in r.stdout, r.stdout + r.stderr)
    fichiers = sorted(glob.glob(f"{dest}/sauv/jend_db_*.sql.gz"))
    S.check("fichiers de sauvegarde en lecture seule pour le propriétaire (600)", all(oct(os.stat(f).st_mode & 0o777) == "0o600" for f in glob.glob(f"{dest}/sauv/*")))
    contenu = gzip.open(fichiers[0], "rt", encoding="utf-8", errors="replace").read()
    S.check("la sauvegarde contient les tables et un marqueur de fin complet", "CREATE TABLE `users`" in contenu and "Dump completed" in contenu)
    S.check("le mot de passe de la base n'est pas dans la ligne de commande de la sauvegarde", DB["pass"] == "" or DB["pass"] not in contenu)
    nom_test = "jend_restauration_t10"
    assert nom_test != DB["name"]
    sql(f"DROP DATABASE IF EXISTS {nom_test}; CREATE DATABASE {nom_test} CHARACTER SET utf8mb4", base=False)
    try:
        restaure = subprocess.run(f"gunzip -c '{fichiers[0]}' | '{MYSQL_BIN}' -h {DB['host']} -P {DB['port']} -u {DB['user']} {'-p' + DB['pass'] if DB['pass'] else ''} {nom_test}", shell=True, capture_output=True, text=True)
        comptes = {t: (sql(f"SELECT COUNT(*) FROM {t}"), sql(f"SELECT COUNT(*) FROM {nom_test}.{t}", base=False)) for t in ("users", "produits", "commandes", "zones_livraison", "categories", "boutiques")}
        S.check("restauration dans une base jetable : mêmes données que l'originale", restaure.returncode == 0 and all(a == b for a, b in comptes.values()), str(comptes))
        S.check("toutes les tables sont restaurées (même nombre que la base d'origine)", sql(f"SELECT COUNT(*) FROM information_schema.tables WHERE table_schema='{nom_test}'", base=False) == sql(f"SELECT COUNT(*) FROM information_schema.tables WHERE table_schema='{DB['name']}'", base=False) and int(sql(f"SELECT COUNT(*) FROM information_schema.tables WHERE table_schema='{nom_test}'", base=False)) >= 20)
    finally:
        sql(f"DROP DATABASE IF EXISTS {nom_test}", base=False)
    time.sleep(1.1); lancer(); time.sleep(1.1); lancer()
    S.check("rotation : seules les 2 dernières sauvegardes sont gardées", len(glob.glob(f"{dest}/sauv/jend_db_*.sql.gz")) == 2 and len(glob.glob(f"{dest}/sauv/jend_photos_*.tar.gz")) == 2)
    photo.unlink()
    e.write_text(e.read_text().replace(f"DB_NAME={DB['name']}", "DB_NAME=jend;drop"))
    r = lancer()
    S.check("nom de base falsifié (injection) : sauvegarde refusée", r.returncode != 0 and "invalide" in r.stderr)
    S.check("scripts/ inaccessible depuis le web (403)", Client().get("scripts/sauvegarde.php")[0] == 403 and Client().get("scripts/verifier-production.php")[0] == 403)

    S.titre("VÉRIFICATEUR « PRÊT POUR LA PRODUCTION »")
    def verifier(env_texte, *args):
        f = d / "verif.env"; f.write_text(env_texte)
        return subprocess.run([PHP, str(JEND / "scripts" / "verifier-production.php"), f"--env={f}", *args], capture_output=True, text=True, timeout=90)
    r = verifier("APP_ENV=dev\n")
    S.check("configuration de développement : au moins un point bloquant (code 1)", r.returncode == 1 and "✘ APP_ENV doit valoir" in r.stdout and "✘ PAIEMENT_SECRET manquant" in r.stdout)
    bon = (f"APP_ENV=prod\nAPP_URL=https://jend.example.test\nPAIEMENT_FOURNISSEUR=paydunya\nPAIEMENT_SECRET={'ab' * 32}\nMAIL_DRIVER=smtp\nSMTP_HOST=smtp.example.test\nSMTP_USER=u\nSMTP_PASS=p\nSMTP_SECURE=tls\n"
           f"DB_HOST={DB['host']}\nDB_PORT={DB['port']}\nDB_NAME={DB['name']}\nDB_USER={DB['user']}\nDB_PASS=\nADMIN_EMAIL=moi@example.test\n")
    r = verifier(bon)
    S.check("réglages de production corrects reconnus (✔)", all(x in r.stdout for x in ("✔ APP_ENV = prod", "✔ APP_URL en https", "✔ Fournisseur de paiement réel", "✔ PAIEMENT_SECRET défini", "✔ SMTP configuré", "✔ SMTP chiffré (tls)")), r.stdout[:300])
    S.check("mot de passe de base vide détecté comme bloquant", "✘ DB_PASS est vide" in r.stdout and r.returncode == 1)
    r = verifier(bon.replace("tls", "none"))
    S.check("SMTP non chiffré détecté", "✘ SMTP_SECURE doit être tls ou ssl" in r.stdout)
    r = verifier(bon.replace("https://jend.example.test", "http://jend.example.test"))
    S.check("APP_URL en http détectée", "✘ APP_URL doit être une adresse https://" in r.stdout)
    r = verifier(bon, "--url=http://localhost/jend")
    S.check("fichiers sensibles inaccessibles vus depuis Internet (.env, includes/, database/, storage/, scripts/…)", all(f"✔ /{p} inaccessible" in r.stdout for p in (".env", "includes/db.php", "database/schema.sql", "storage/", "scripts/sauvegarde.php", "install.php")), r.stdout[-700:])
    S.check("en-têtes de sécurité vérifiés sur le site", "✔ En-tête Content-Security-Policy présent" in r.stdout)

    S.check("bibliothèques hébergées contrôlées par empreinte (✔)", re.search(r"✔ (1[6-9]|[2-9]\d) bibliothèques hébergées intactes", r.stdout) is not None and "✔ Aucune ressource externe" in r.stdout, r.stdout[-600:])
    cible = JEND / "assets" / "vendor" / "js" / "splitting.min.js"
    original = cible.read_bytes()
    try:
        cible.write_bytes(original + "\n/* code malveillant ajouté */".encode())
        r2 = verifier(bon)
        S.check("une bibliothèque ALTÉRÉE sur le serveur est détectée (bloquant)", "✘ Bibliothèque(s) MODIFIÉE(S)" in r2.stdout and "splitting.min.js" in r2.stdout and r2.returncode == 1, r2.stdout[:300])
    finally:
        cible.write_bytes(original)
    S.check("fichier restauré à l'identique (le site n'est pas resté altéré)", cible.read_bytes() == original)
    import http.server, socketserver, threading as _t
    class H(http.server.BaseHTTPRequestHandler):
        def do_GET(self):
            self.send_response(200); self.send_header("Content-Type", "text/html"); self.send_header("Content-Security-Policy", "default-src 'self'"); self.send_header("X-Frame-Options", "SAMEORIGIN"); self.send_header("X-Content-Type-Options", "nosniff"); self.end_headers()
            self.wfile.write(b'<html><head><script src="https://cdn.exemple-pirate.test/lib.js"></script><link rel="stylesheet" href="https://autre.example/x.css"></head></html>')
        def log_message(self, *a): pass
    faux = socketserver.TCPServer(("127.0.0.1", 0), H)
    _t.Thread(target=faux.serve_forever, daemon=True).start()
    r3 = verifier(bon, f"--url=http://127.0.0.1:{faux.server_address[1]}")
    faux.shutdown()
    S.check("une page qui charge un script/style externe est détectée (bloquant)", "✘ La page d'accueil charge des ressources externes" in r3.stdout and "cdn.exemple-pirate.test" in r3.stdout, r3.stdout[-500:])
finally:
    sql("DELETE FROM journal_admin WHERE admin_id IS NULL OR admin_id IN (SELECT id FROM users WHERE email LIKE '%-t10@jend.local')")
    sql(f"DELETE b FROM boutiques b JOIN users u ON u.id=b.user_id WHERE u.email='{E[3]}'")
    ok = S.fin()
    for f in glob.glob(str(JEND / "uploads" / "produits" / "tmpbackup-t10*")):
        os.unlink(f)
sys.exit(0 if ok else 1)
