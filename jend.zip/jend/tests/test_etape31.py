"""Étape 31 : page boutique publique, partage WhatsApp, régions desservies par boutique, badge « vérifiée » et note."""
import re, sys
from lib import *

S = Suite("Étape 31 — boutique publique, régions, badge", ["ad-t31@jend.local", "cl-t31@jend.local", "va-t31@jend.local", "av-t31@jend.local"])
E = dict(zip(["ad", "cl", "va", "av"], S.emails))
try:
    S.nettoyer()
    sql("DELETE FROM produits WHERE slug='produit-t31'"); sql("DELETE FROM boutiques WHERE slug IN ('boutique-t31','boutique-suspendue-t31')")
    sql("DELETE FROM zones_livraison WHERE nom IN ('Zone T31 Touba','Zone T31 Dakar')")
    sql("INSERT INTO zones_livraison (nom, region, frais, delai_jours) VALUES ('Zone T31 Touba','Touba',500,1),('Zone T31 Dakar','Dakar',1500,2)")
    zt = int(sql("SELECT id FROM zones_livraison WHERE nom='Zone T31 Touba'")); zd = int(sql("SELECT id FROM zones_livraison WHERE nom='Zone T31 Dakar'"))
    pw = mot_de_passe()
    for k, nom, role in (("ad", "Admin T31", "admin"), ("cl", "Cliente T31", "client"), ("va", "Vendeur T31", "vendeur"), ("av", "Avis T31", "client")):
        sql(f"INSERT INTO users (nom,email,mot_de_passe,role) VALUES ('{nom}','{E[k]}','{hash_mdp(pw)}','{role}')")
    sql(f"INSERT INTO boutiques (user_id,nom,slug,description,statut,commission_pct) SELECT id,'Boutique T31','boutique-t31','Wax et artisanat de qualité','active',3 FROM users WHERE email='{E['va']}'")
    sql("INSERT INTO produits (boutique_id,categorie_id,nom,slug,description,prix,stock,statut,note_moyenne,nb_avis) SELECT b.id,(SELECT MIN(id) FROM categories),'Produit T31','produit-t31','x',7000,20,'publie',0,0 FROM boutiques b WHERE b.slug='boutique-t31'")
    prod = int(sql("SELECT id FROM produits WHERE slug='produit-t31'"))
    AD, C, VA, P = Client(), Client(), Client(), Client()
    AD.post("connexion", {"email": E["ad"], "mot_de_passe": pw}); C.post("connexion", {"email": E["cl"], "mot_de_passe": pw}); VA.post("connexion", {"email": E["va"], "mot_de_passe": pw})

    S.titre("PAGE BOUTIQUE ET PARTAGE WHATSAPP")
    s, h, _ = P.get("boutique/boutique-t31")
    S.check("la page publique de la boutique s'affiche (nom, description, produit)", s == 200 and "Boutique T31" in h and "Wax et artisanat" in h and "Produit T31" in h)
    S.check("elle propose « Partager la boutique » (lien wa.me avec l'adresse de la boutique)", "https://wa.me/?text=" in h and "boutique%2Fboutique-t31" in h)
    sql("INSERT INTO boutiques (user_id,nom,slug,statut) SELECT id,'Boutique suspendue T31','boutique-suspendue-t31','suspendue' FROM users WHERE email='" + E['cl'] + "'")
    S.check("une boutique non active n'a pas de page publique (404)", P.get("boutique/boutique-suspendue-t31")[0] == 404)
    sql("DELETE FROM boutiques WHERE slug='boutique-suspendue-t31'")
    h = P.get("produit/produit-t31")[1]
    S.check("la fiche produit propose le partage WhatsApp et le lien vers la boutique", "https://wa.me/?text=" in h and "produit%2Fproduit-t31" in h and 'href="/jend/boutique/boutique-t31"' in h)
    S.check("la carte produit renvoie vers la boutique", "/jend/boutique/boutique-t31" in P.get("produits")[1])
    h = VA.get("vendeur")[1]
    S.check("le tableau de bord vendeur propose de partager sa boutique", "Partager ma boutique" in h and "https://wa.me/?text=" in h)

    S.titre("RÉGIONS DESSERVIES PAR LA BOUTIQUE")
    S.check("sans choix : la boutique livre partout", "tout le Sénégal" in P.get("boutique/boutique-t31")[1])
    def commander(zone):
        tok = C.token("produits"); C.req("panier/ajouter", {"csrf": tok, "produit_id": prod, "quantite": 1, "retour": "/jend/produits"})
        return C.post("commande", {"nom": "Cliente T31", "telephone": "78 000 11 31", "zone_id": zone, "adresse": "Rue 31 Touba", "methode": "wave"})
    s, _, _ = commander(zd)
    S.check("sans restriction, une commande vers Dakar passe", s == 302)
    VA.post("vendeur/boutique", {"action": "regions", "regions[]": "Touba"}, page_token="vendeur/boutique")
    S.check("le vendeur choisit « Touba » seulement", sql("SELECT GROUP_CONCAT(region) FROM boutique_regions WHERE boutique_id=(SELECT id FROM boutiques WHERE slug='boutique-t31')") == "Touba")
    VA.post("vendeur/boutique", {"action": "regions", "regions[]": "RégionInventée"}, page_token="vendeur/boutique")
    S.check("une région qui n'existe pas dans les zones est ignorée", "RégionInventée" not in sql("SELECT COALESCE(GROUP_CONCAT(region),'') FROM boutique_regions"))
    VA.post("vendeur/boutique", {"action": "regions", "regions[]": "Touba"}, page_token="vendeur/boutique")      # (le test précédent a remis « partout » : rien de valide n'était coché)
    s, h, _ = commander(zd)
    S.check("commande vers Dakar : refusée avec un message clair", s == 200 and "ne livre pas à Dakar" in h.replace("&#039;", "'"))
    s, _, _ = commander(zt)
    S.check("commande vers Touba : acceptée", s == 302)
    h = C.get("produit/produit-t31")[1]
    S.check("la fiche produit annonce où la boutique livre", "livre <b>" in h.replace("à : ", "") or "à : <b>Touba</b>" in h)
    h = P.get("boutique/boutique-t31")[1]
    S.check("la page boutique aussi", "<b>Touba</b>" in h)
    C.post("vendeur/boutique", {"action": "regions", "regions[]": "Dakar"}, page_token="compte")
    S.check("un client ne peut pas modifier les régions d'une boutique", sql("SELECT GROUP_CONCAT(region) FROM boutique_regions") == "Touba")
    VA.post("vendeur/boutique", {"action": "regions", "toutes": "1"}, page_token="vendeur/boutique")
    S.check("« Je livre partout » efface les restrictions", sql("SELECT COUNT(*) FROM boutique_regions") == "0")

    S.titre("BADGE « BOUTIQUE VÉRIFIÉE » ET NOTE")
    S.check("pas de badge par défaut", "Boutique vérifiée" not in P.get("boutique/boutique-t31")[1])
    bid = sql("SELECT id FROM boutiques WHERE slug='boutique-t31'")
    VA.post("admin/boutiques", {"action": "verifier", "id": bid}, page_token="vendeur")
    S.check("un vendeur ne peut pas se donner le badge", sql(f"SELECT verifiee FROM boutiques WHERE id={bid}") == "0")
    AD.post("admin/boutiques", {"action": "verifier", "id": bid})
    h = P.get("boutique/boutique-t31")[1]
    S.check("l'admin attribue le badge : visible sur la boutique, la fiche produit et les cartes", sql(f"SELECT verifiee FROM boutiques WHERE id={bid}") == "1" and "Boutique vérifiée" in h
            and "Boutique vérifiée" in P.get("produit/produit-t31")[1] and "badge-verifie-icone" in P.get("produits")[1])
    S.check("l'attribution est journalisée", int(sql("SELECT COUNT(*) FROM journal_admin WHERE action='boutique_verifiee'")) == 1)
    sql(f"INSERT INTO avis (produit_id,user_id,note,commentaire) SELECT {prod}, id, 5, 'Très bien' FROM users WHERE email='{E['cl']}'")
    sql(f"INSERT INTO avis (produit_id,user_id,note,commentaire) SELECT {prod}, id, 4, 'Bien' FROM users WHERE email='{E['av']}'")
    h = P.get("boutique/boutique-t31")[1]
    S.check("la note de la boutique (moyenne des avis de ses produits : 4,5 sur 2 avis) s'affiche", "4,5" in h and "2 avis" in h)
    AD.post("admin/boutiques", {"action": "verifier", "id": bid})
    S.check("l'admin peut retirer le badge", sql(f"SELECT verifiee FROM boutiques WHERE id={bid}") == "0")
finally:
    ok = S.fin()
    sql("DELETE FROM produits WHERE slug='produit-t31'"); sql("DELETE FROM boutiques WHERE slug IN ('boutique-t31','boutique-suspendue-t31')")
    sql("DELETE FROM zones_livraison WHERE nom IN ('Zone T31 Touba','Zone T31 Dakar')")
    sql("DELETE FROM journal_admin WHERE action IN ('boutique_verifiee','boutique_verification_retiree')")
sys.exit(0 if ok else 1)
