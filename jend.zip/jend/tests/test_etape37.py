"""Étape 37 : sécurité des fonctions récentes (lien vidéo, offres, sur-mesure, produits réservés, parrainage)."""
import sys
from lib import *

S = Suite("Étape 37 — sécurité des nouveautés", ["cl-t37@jend.local", "c2-t37@jend.local", "va-t37@jend.local", "vb-t37@jend.local"])
E = dict(zip(["cl", "c2", "va", "vb"], S.emails))
try:
    S.nettoyer()
    sql("DELETE FROM produits WHERE slug LIKE '%t37%' OR nom LIKE 'Commande sur mesure SM-%'"); sql("DELETE FROM boutiques WHERE slug IN ('boutique-t37','autre-t37')")
    sql("DELETE FROM zones_livraison WHERE nom='Zone T37'")
    sql("INSERT INTO zones_livraison (nom, region, frais, delai_jours) VALUES ('Zone T37', 'Touba', 500, 1)")
    zone = int(sql("SELECT id FROM zones_livraison WHERE nom='Zone T37'"))
    pw = mot_de_passe()
    for k, nom, role in (("cl", "Cliente T37", "client"), ("c2", "Autre T37", "client"), ("va", "Vendeur T37", "vendeur"), ("vb", "Vendeur B T37", "vendeur")):
        sql(f"INSERT INTO users (nom,email,mot_de_passe,role) VALUES ('{nom}','{E[k]}','{hash_mdp(pw)}','{role}')")
    for k, slug in (("va", "boutique-t37"), ("vb", "autre-t37")):
        sql(f"INSERT INTO boutiques (user_id,nom,slug,statut,commission_pct,sur_mesure,code_parrain,telephone_paiement) SELECT id,'{slug}','{slug}','active',1,1,UPPER(SUBSTRING(MD5('{slug}'),1,8)),'+221771112233' FROM users WHERE email='{E[k]}'")
    sql("INSERT INTO produits (boutique_id,categorie_id,nom,slug,description,prix,stock,statut) SELECT b.id,(SELECT MIN(id) FROM categories),'Produit T37','produit-t37','x',10000,20,'publie' FROM boutiques b WHERE b.slug='boutique-t37'")
    prod = sql("SELECT id FROM produits WHERE slug='produit-t37'"); cat = sql("SELECT MIN(id) FROM categories")
    C, C2, VA, VB, P = Client(), Client(), Client(), Client(), Client()
    for cl, k in ((C, "cl"), (C2, "c2"), (VA, "va"), (VB, "vb")):
        cl.post("connexion", {"email": E[k], "mot_de_passe": pw})
    txt = lambda cl, u: cl.get(u)[1].replace("&#039;", "'")
    maj = lambda video: VA.post(f"vendeur/produits/{prod}/modifier", {"nom": "Produit T37", "categorie_id": cat, "description": "x", "prix": "10000", "prix_barre": "", "stock": "20", "statut": "publie", "video_url": video}, page_token=f"vendeur/produits/{prod}/modifier")

    S.titre("LIEN VIDÉO : ADRESSES PIÉGÉES")
    for piege in ("https://site-pirate.net\\@tiktok.com/x", "https://utilisateur@tiktok.com/x", "https://tiktok.com:8443/x", "https://tiktok.com.pirate.net/x", "https://www.youtube.com/\"><script>alert(1)</script>", "data:text/html,<script>alert(1)</script>", "//tiktok.com/x"):
        maj(piege)
    S.check("barre oblique inversée, identifiants, port, faux domaine, balise, data:, lien sans protocole : tous refusés", sql(f"SELECT COALESCE(video_url,'') FROM produits WHERE id={prod}") == "")
    maj("https://www.tiktok.com/@jend/video/42")
    h = txt(P, "produit/produit-t37")
    S.check("un vrai lien TikTok (avec @compte) est accepté, et la page n'a aucun script en ligne", sql(f"SELECT video_url FROM produits WHERE id={prod}") == "https://www.tiktok.com/@jend/video/42" and "<script>alert" not in h and "onclick=" not in h and "onchange=" not in h)
    S.check("la page boutique n'utilise plus de gestionnaire en ligne (interdit par la politique de sécurité)", "onchange=" not in txt(P, "boutique/boutique-t37"))

    S.titre("OFFRES : VALEURS EXTRÊMES ET ACCÈS")
    for prix in ("-5000", "0", "99999999999999999999", "8000.5", "8000 OR 1=1", "<b>8000</b>"):
        C.post("produit/produit-t37", {"action": "offre", "prix": prix, "quantite": "1"}, page_token="produit/produit-t37")
    S.check("prix négatif, nul, gigantesque, décimal ou piégé : aucune offre créée", sql("SELECT COUNT(*) FROM offres") == "0")
    C.post("produit/produit-t37", {"action": "offre", "prix": "8000", "quantite": "999"}, page_token="produit/produit-t37")
    oid = sql("SELECT MAX(id) FROM offres")
    S.check("quantité absurde ramenée à 10 au plus", int(sql(f"SELECT quantite FROM offres WHERE id={oid}")) <= 10)
    P.post("vendeur/offres", {"id": oid, "action": "accepter"})
    C.post("vendeur/offres", {"id": oid, "action": "accepter"}, page_token="compte")
    S.check("un visiteur ou le client lui-même ne peut pas accepter l'offre à la place du vendeur", sql(f"SELECT statut FROM offres WHERE id={oid}") == "en_attente")
    VA.post("vendeur/offres", {"id": oid, "action": "accepter"}); VA.post("vendeur/offres", {"id": oid, "action": "contre", "contre": "9900"})
    S.check("une offre acceptée ne peut plus être modifiée par le vendeur", sql(f"SELECT CONCAT(statut,'|',prix_final) FROM offres WHERE id={oid}") == "acceptee|8000")
    sql(f"UPDATE offres SET prix_final = 1 WHERE id={oid}")          # (simulation d'une valeur falsifiée en base : le plancher ne dépend pas du navigateur)
    sql(f"UPDATE offres SET prix_final = 8000 WHERE id={oid}")
    C2.post("offres", {"id": oid, "action": "acheter"})
    S.check("un autre client ne peut pas acheter avec l'offre d'un autre", "prix négocié" not in txt(C2, "panier"))

    S.titre("SUR-MESURE : LE PRIX VU EST LE PRIX PAYÉ")
    C.post("sur-mesure/boutique-t37", {"description": "Un boubou brodé bleu nuit avec <script>alert(1)</script> broderie", "mesures": "", "budget": "", "date": ""}, page_token="sur-mesure/boutique-t37")
    did = sql("SELECT MAX(id) FROM demandes_mesure")
    S.check("la description est affichée échappée chez le vendeur (pas de balise active)", "<script>alert(1)</script>" not in VA.get("vendeur/sur-mesure")[1] and "&lt;script&gt;" in VA.get("vendeur/sur-mesure")[1])
    VA.post("vendeur/sur-mesure", {"id": did, "action": "devis", "prix": "20000", "delai": "5", "message": ""})
    VA.post("vendeur/sur-mesure", {"id": did, "action": "devis", "prix": "90000", "delai": "5", "message": ""})       # le vendeur change son devis pendant que le client lit l'ancien
    C.post("sur-mesure", {"id": did, "action": "accepter", "prix": "20000"})
    S.check("le client qui clique sur l'ancien prix (20 000) n'accepte pas le nouveau (90 000) sans le voir", sql(f"SELECT statut FROM demandes_mesure WHERE id={did}") == "devis")
    C.post("sur-mesure", {"id": did, "action": "accepter"})
    S.check("sans le prix vu, l'acceptation est refusée aussi", sql(f"SELECT statut FROM demandes_mesure WHERE id={did}") == "devis")
    C.post("sur-mesure", {"id": did, "action": "accepter", "prix": "90000"})
    pid = sql(f"SELECT produit_id FROM demandes_mesure WHERE id={did}")
    S.check("avec le prix réellement affiché, l'acceptation passe", sql(f"SELECT statut FROM demandes_mesure WHERE id={did}") == "acceptee" and pid not in ("", "NULL"))
    VA.post(f"vendeur/produits/{pid}/modifier", {"nom": "Piège", "categorie_id": cat, "description": "x", "prix": "500000", "prix_barre": "", "stock": "1", "statut": "publie", "video_url": ""}, page_token="vendeur/produits")
    VA.post("vendeur/produits", {"id": pid, "action": "supprimer"})
    S.check("le vendeur ne peut ni changer le prix ni supprimer le produit réservé après l'accord", sql(f"SELECT prix FROM produits WHERE id={pid}") == "90000")
    VA.post("vendeur/sur-mesure", {"id": did, "action": "devis", "prix": "150000", "delai": "5", "message": ""})
    S.check("ni modifier son devis une fois accepté", sql(f"SELECT prix FROM demandes_mesure WHERE id={did}") == "90000")

    S.titre("PARRAINAGE : PAS D'AUTO-RÉCOMPENSE")
    code = sql("SELECT code_parrain FROM boutiques WHERE slug='boutique-t37'")
    S.check("un code invalide ou piégé dans le lien est ignoré", "Vous êtes invité par" not in txt(C2, "vendre?parrain=<script>") and "Vous êtes invité par" not in txt(C2, "vendre?parrain=ZZZZZZZZ"))
    S.check("un vendeur qui a déjà une boutique ne peut pas en créer une seconde avec son propre lien", VA.get(f"vendre?parrain={code}")[2].get("Location", "").endswith("/vendeur"))
    C2.get(f"vendre?parrain={code}")
    C2.post("vendre", {"nom": "Filleul T37", "description": "", "telephone": "77 555 66 77", "accepte": "1"}, page_token="vendre")
    fid = sql("SELECT id FROM boutiques WHERE nom='Filleul T37'")
    C2.post("admin/boutiques", {"action": "activer", "id": fid}, page_token="vendeur")
    S.check("le filleul ne peut pas se valider lui-même pour déclencher la récompense", sql(f"SELECT CONCAT(statut,'|',parrainage_recompense) FROM boutiques WHERE id={fid}") == "en_attente|0")
finally:
    ok = S.fin()
    sql("DELETE FROM produits WHERE slug LIKE '%t37%' OR nom LIKE 'Commande sur mesure SM-%'"); sql("DELETE FROM boutiques WHERE slug IN ('boutique-t37','autre-t37') OR nom='Filleul T37'")
    sql("DELETE FROM zones_livraison WHERE nom='Zone T37'"); sql("DELETE FROM limites WHERE cle LIKE 'offre:%' OR cle LIKE 'mesure:%'")
sys.exit(0 if ok else 1)
