"""Étape 56 : marketing — canal d'arrivée des clients, kit de promotion (affiche QR, textes), page « Devenez vendeur », tableau de bord Croissance."""
import sys, re
from lib import *

S = Suite("Étape 56 — marketing", ["ad-t56@jend.local", "cl-t56@jend.local", "va-t56@jend.local"])
E = dict(zip(["ad", "cl", "va"], S.emails))
try:
    S.nettoyer()
    sql("DELETE FROM produits WHERE slug='produit-t56'"); sql("DELETE FROM boutiques WHERE slug='boutique-t56'"); sql("DELETE FROM zones_livraison WHERE nom='Zone T56'")
    sql("INSERT INTO zones_livraison (nom, region, frais, delai_jours) VALUES ('Zone T56', 'Touba', 1000, 1)")
    zone = int(sql("SELECT id FROM zones_livraison WHERE nom='Zone T56'"))
    pw = mot_de_passe()
    for k, nom, role in (("ad", "Admin T56", "admin"), ("va", "Vendeur T56", "vendeur")):
        sql(f"INSERT INTO users (nom,email,mot_de_passe,role) VALUES ('{nom}','{E[k]}','{hash_mdp(pw)}','{role}')")
    sql(f"INSERT INTO boutiques (user_id,nom,slug,statut,commission_pct) SELECT id,'Boutique T56','boutique-t56','active',1 FROM users WHERE email='{E['va']}'")
    sql("INSERT INTO produits (boutique_id,categorie_id,nom,slug,description,prix,stock,statut) SELECT b.id,(SELECT MIN(id) FROM categories),'Bissap T56','produit-t56','x',3000,20,'publie' FROM boutiques b WHERE b.slug='boutique-t56'")
    prod = sql("SELECT id FROM produits WHERE slug='produit-t56'")
    AD, VA = Client(), Client()
    AD.post("connexion", {"email": E["ad"], "mot_de_passe": pw}); VA.post("connexion", {"email": E["va"], "mot_de_passe": pw})
    txt = lambda cl, u: cl.get(u)[1].replace("&#039;", "'").replace(" ", " ").replace("&nbsp;", " ").replace("\xa0", " ")

    S.titre("CANAL D'ARRIVÉE")
    C = Client()
    C.get("boutique/boutique-t56?src=affiche")          # arrivé en scannant l'affiche
    C.get("produits?src=tiktok")                         # le premier canal est gardé
    C.post("inscription", {"nom": "Cliente T56", "email": E["cl"], "telephone": "", "mot_de_passe": "Wax-Touba-2026!", "mot_de_passe2": "Wax-Touba-2026!"})
    S.check("inscription : le canal d'arrivée (affiche) est enregistré, pas le second", sql(f"SELECT source FROM users WHERE email='{E['cl']}'") == "affiche")
    C.req("panier/ajouter", {"csrf": C.token("produits"), "produit_id": prod, "quantite": 1, "retour": "/jend/produits"})
    _, _, hd = C.post("commande", {"nom": "Cliente T56", "telephone": "77 123 45 56", "zone_id": zone, "adresse": "Rue 56 Touba", "methode": "wave"})
    ref = hd["Location"].rsplit("/", 1)[-1]
    S.check("commande : même canal enregistré", sql(f"SELECT source FROM commandes WHERE reference='{ref}'") == "affiche")
    C2 = Client(); C2.get("produits?src=%3Cscript%3E"); C2.get("produits?src=canal-invente")
    C2.post("inscription", {"nom": "Autre T56", "email": "c2-t56@jend.local", "telephone": "", "mot_de_passe": "Wax-Touba-2026!", "mot_de_passe2": "Wax-Touba-2026!"})
    S.check("canal inventé enregistré comme « autre », jamais tel quel ; balise refusée", sql("SELECT source FROM users WHERE email='c2-t56@jend.local'") == "autre")
    sql("DELETE FROM users WHERE email='c2-t56@jend.local'")
    S.check("les liens partagés sont marqués : WhatsApp (boutique) et lien de paiement", "src%3Dwhatsapp" in Client().get("boutique/boutique-t56")[1] and "src=lien" in VA.get("vendeur/produits")[1].replace("&amp;", "&"))

    S.titre("KIT DE PROMOTION")
    h = txt(VA, "vendeur/kit")
    S.check("onglet « Promouvoir » : QR code SVG, textes à copier, idées TikTok", "<svg" in h and "QR code de la boutique Boutique T56" in h and h.count("data-copier") >= 6 and "idées de vidéos TikTok" in h)
    S.check("les textes contiennent le lien marqué de la boutique", "boutique/boutique-t56?src=whatsapp" in h)
    h = txt(VA, "vendeur/affiche")
    S.check("affiche imprimable : nom, promesse, QR code, bouton Imprimer", "Payez-moi en toute sécurité" in h and "<svg" in h and "data-imprimer" in h)
    S.check("un client n'a pas accès au kit", Client().get("vendeur/kit")[0] in (302, 303))
    m = php("require '%s/includes/qrcode.php'; $m = qr_matrice('https://jend.sn/boutique/x?src=affiche'); echo count($m), '|', $m[0][0] ? 1 : 0, $m[6][6] ? 1 : 0, $m[0][7] ? 1 : 0;" % JEND)[0]
    S.check("QR code : adresse courte en version 3 (29×29), carrés de repérage corrects", m == "29|110")

    S.titre("PAGE « DEVENEZ VENDEUR »")
    h = txt(Client(), "vendre")
    S.check("page de présentation : étapes, avantages, comparaison WhatsApp, FAQ, bouton vers le formulaire",
            "Comment ça marche" in h and "Ce que vous gagnez avec Jënd" in h and "Vendre seul sur WhatsApp" in h and "Questions fréquentes" in h and 'href="#ouvrir"' in h)
    cod = sql("SELECT valeur FROM parametres WHERE cle='paiement_livraison'") == "1"
    S.check("la promesse suit le réglage du paiement à la livraison (« Zéro impayé » seulement s'il est désactivé)", ("Moins d'impayés" in h and "Zéro impayé" not in h) if cod else ("Zéro impayé" in h))

    S.titre("TABLEAU DE BORD CROISSANCE")
    sql(f"UPDATE commandes SET statut_paiement='paye', statut='confirmee' WHERE reference='{ref}'")
    h = txt(AD, "admin/croissance")
    S.check("réservé à l'admin", Client().get("admin/croissance")[0] in (302, 303, 404) and VA.get("admin/croissance")[0] == 404)
    S.check("canaux : « Affiche / QR code » avec 1 commande", "Affiche / QR code" in h and re.search(r"<b>1</b> commande\(s\)", h) is not None)
    S.check("chiffres des 30 jours, fidélité, catalogue, semaines", "Commandes payées" in h and "Clients qui ont recommandé" in h and "Boutiques « prêtes »" in h and "Semaine par semaine" in h)
    S.check("barres dessinées sans style dans le HTML (politique de sécurité)", "data-largeur=" in h and ' style="' not in h)
finally:
    ok = S.fin()
    sql("DELETE FROM produits WHERE slug='produit-t56'"); sql("DELETE FROM boutiques WHERE slug='boutique-t56'"); sql("DELETE FROM zones_livraison WHERE nom='Zone T56'")
sys.exit(0 if ok else 1)
