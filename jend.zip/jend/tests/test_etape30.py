"""Étape 30 : profil et mot de passe depuis l'espace vendeur."""
import sys
from lib import *

S = Suite("Étape 30 — profil du vendeur", ["cl-t30@jend.local", "va-t30@jend.local"])
E = dict(zip(["cl", "va"], S.emails))
try:
    S.nettoyer()
    sql("DELETE FROM boutiques WHERE slug='boutique-t30'")
    pw = mot_de_passe()
    for k, nom, role in (("cl", "Cliente T30", "client"), ("va", "Vendeur T30", "vendeur")):
        sql(f"INSERT INTO users (nom,email,mot_de_passe,role) VALUES ('{nom}','{E[k]}','{hash_mdp(pw)}','{role}')")
    sql(f"INSERT INTO boutiques (user_id,nom,slug,statut,commission_pct) SELECT id,'Boutique T30','boutique-t30','active',3 FROM users WHERE email='{E['va']}'")
    V, C = Client(), Client()
    V.post("connexion", {"email": E["va"], "mot_de_passe": pw}); C.post("connexion", {"email": E["cl"], "mot_de_passe": pw})

    h = V.get("vendeur")[1]
    S.check("le tableau de bord vendeur propose « Mon profil » et « Mot de passe »", 'href="/jend/vendeur/profil"' in h and "Mot de passe" in h)
    h = V.get("vendeur/profil")[1]
    S.check("la page profil est dans l'espace vendeur (onglets vendeur, formulaires profil + mot de passe)", "Mon profil" in h and 'name="action" value="profil"' in h and 'name="action" value="mdp"' in h and "Tableau de bord" in h)
    S.check("un client ne peut pas ouvrir cette page", "Mes informations" not in C.get("vendeur/profil")[1])

    V.post("vendeur/profil", {"action": "profil", "nom": "Moussa Diop", "telephone": "77 123 45 67"}, page_token="vendeur/profil")
    S.check("le vendeur met à jour son nom et son téléphone", sql(f"SELECT CONCAT(nom,'|',telephone) FROM users WHERE email='{E['va']}'") == "Moussa Diop|+221771234567")
    V.post("vendeur/profil", {"action": "profil", "nom": "M", "telephone": "abc"}, page_token="vendeur/profil")
    S.check("un nom trop court ou un téléphone invalide sont refusés", sql(f"SELECT nom FROM users WHERE email='{E['va']}'") == "Moussa Diop")

    V.post("vendeur/profil", {"action": "mdp", "actuel": "mauvais", "nouveau": "Nouveau-62-sable", "nouveau2": "Nouveau-62-sable"}, page_token="vendeur/profil")
    S.check("mauvais mot de passe actuel : refusé", Client().post("connexion", {"email": E["va"], "mot_de_passe": "Nouveau-62-sable"})[0] == 200)
    V.post("vendeur/profil", {"action": "mdp", "actuel": pw, "nouveau": "12345678", "nouveau2": "12345678"}, page_token="vendeur/profil")
    S.check("mot de passe trop faible : refusé", Client().post("connexion", {"email": E["va"], "mot_de_passe": "12345678"})[0] == 200)
    V.post("vendeur/profil", {"action": "mdp", "actuel": pw, "nouveau": "Nouveau-62-sable", "nouveau2": "Nouveau-62-sable"}, page_token="vendeur/profil")
    N = Client()
    s, _, hd = N.post("connexion", {"email": E["va"], "mot_de_passe": "Nouveau-62-sable"}, page_token="connexion")
    S.check("mot de passe changé : la connexion avec le nouveau fonctionne et mène à l'espace vendeur", hd.get("Location", "").endswith("/vendeur"))
finally:
    ok = S.fin()
    sql("DELETE FROM boutiques WHERE slug='boutique-t30'")
sys.exit(0 if ok else 1)
