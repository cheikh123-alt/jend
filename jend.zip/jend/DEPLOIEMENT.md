# Mettre Jënd en ligne — guide pas à pas

> Ce guide suppose que vous avez déjà essayé le site en local (XAMPP) et que `python3 tests/run_all.py` est entièrement vert.
> Rien ici ne vous engage : tant que vous n'avez pas envoyé le site sur un serveur accessible depuis Internet, il reste privé.

## 0. Ce qu'il vous faut avant de commencer

| Besoin | Pourquoi | Remarque |
|---|---|---|
| **Un hébergement** (voir §1) | faire tourner PHP + MySQL | PHP ≥ 8.0 avec `pdo_mysql`, `gd`, `fileinfo`, `mbstring` |
| **Un nom de domaine** (voir §2) | l'adresse du site, et les e-mails | ex. `jend.sn` |
| **Un compte marchand** PayDunya ou CinetPay | encaisser Wave / Orange Money / carte | **sans lui, seul le paiement à la livraison est possible** |
| **Un service d'e-mail** (SMTP) | « mot de passe oublié », notifications | Brevo, Mailjet, SendGrid… ou celui de l'hébergeur |
| **Les pages légales** (voir §9) | obligations légales, confiance des clients | actuellement, les liens du pied de page sont des « # » |

## 1. Choisir l'hébergement

| Option | Pour | Contre |
|---|---|---|
| **Hébergement mutualisé** (cPanel) | simple, peu cher, HTTPS en un clic (AutoSSL), phpMyAdmin fourni | pas toujours de terminal ; performances limitées |
| **VPS** (serveur à vous) | contrôle total, performances, terminal | vous gérez les mises à jour et la sécurité du serveur |

Dans les deux cas : choisissez un hébergeur qui fournit **des sauvegardes** et le **HTTPS gratuit** (Let's Encrypt).
Un hébergement proche du Sénégal réduit le temps de chargement ; comparez les offres et leurs conditions vous-même.

**Serveur Apache** (le plus courant en mutualisé) : le site fonctionne tel quel, car il s'appuie sur les fichiers `.htaccess`.
Vérifiez que `mod_rewrite` est actif et que `AllowOverride All` est autorisé (c'est le cas chez la plupart des hébergeurs mutualisés).

**Serveur Nginx** : `.htaccess` est **ignoré**. Sans la configuration du §7, vos fichiers secrets (`.env`, `includes/`) seraient lisibles par tout le monde. N'ouvrez jamais le site sans l'avoir mise en place et vérifiée (§6).

## 2. Le nom de domaine

Pour un `.sn`, l'enregistrement passe par le registre national (NIC Sénégal) ou un revendeur agréé : renseignez-vous sur les conditions et pièces demandées.
Un `.com` s'achète chez n'importe quel registrar. Notez où le domaine est géré : il faudra y pointer le site (enregistrement DNS vers l'hébergeur).

## 3. Préparer le serveur

1. **Envoyer le site.** Sur votre Mac : `sh scripts/archive-production.sh` crée `jend-production.zip` (sans tests, sans secrets, sans photos de démo). Envoyez-le sur le serveur et décompressez-le dans le dossier public (souvent `public_html`).
2. **Créer la base MySQL** avec l'outil de l'hébergeur, **et un utilisateur dédié** à cette base, avec un mot de passe long. N'utilisez jamais `root`.
3. **Importer la structure** (phpMyAdmin → Importer) : d'abord `database/schema.sql`, puis `database/seed.sql`.
   > ⚠ `schema.sql` **supprime puis recrée** les tables. Ne l'importez jamais sur une base qui contient déjà des clients.
   > Si votre hébergeur impose un nom de base différent de `jend`, remplacez `jend` dans les deux premières lignes utiles de `schema.sql` (`CREATE DATABASE` et `USE`) et dans `seed.sql` (`USE`) avant l'import, ou retirez ces deux instructions et choisissez la base dans phpMyAdmin.
4. **Créer le fichier `.env`** sur le serveur : copiez `.env.production.example` en `.env` et remplissez **toutes** les valeurs (adresse du site en `https://`, base de données, e-mails…). Il faut deux clés aléatoires distinctes, `PAIEMENT_SECRET` et `APP_KEY`, générées chacune avec : `php -r "echo bin2hex(random_bytes(32));"`.
   > **Sauvegardez `APP_KEY` ailleurs que sur le serveur** : elle chiffre les secrets de double authentification. Perdue, tous les utilisateurs devront reconfigurer leur 2FA.
   > Choisissez aussi `BACKUP_PASSPHRASE` (16 caractères minimum), et gardez-la **séparée** des sauvegardes.
5. **Permissions** (terminal ou gestionnaire de fichiers) : dossiers `755`, fichiers `644`, `.env` en `600`. Les dossiers `storage/` et `uploads/` doivent être **inscriptibles** par le serveur web.
6. **Créer le compte administrateur** : `php install.php` (sans `--demo`). Le script crée l'admin avec un mot de passe aléatoire **affiché une seule fois dans le terminal** : notez-le tout de suite, puis changez-le dans votre profil.
   *Sans terminal chez votre hébergeur :* créez une tâche planifiée (cron) à exécuter une seule fois, `php /chemin/du/site/install.php > /chemin/prive/admin.txt`, lisez le fichier, supprimez-le et supprimez la tâche.
7. **Supprimer** `install.php` du serveur.
8. **Activer la double authentification de l'administrateur** : en production elle est **obligatoire**. À la première connexion, le site vous envoie directement sur *Compte → Sécurité*. Installez une application d'authentification (Google Authenticator, Microsoft Authenticator, Aegis, Authy…), entrez la clé affichée, confirmez avec le code, puis **notez les 8 codes de secours** (affichés une seule fois). Vous pourrez alors entrer dans l'administration.
9. *(Recommandé)* **Limiter `/admin` à vos adresses IP** : `ADMIN_IPS=votre.ip.fixe` dans `.env`. Les autres visiteurs verront une page 404, même avec le bon mot de passe. Si votre adresse IP change souvent, laissez vide.

## 4. HTTPS

- **Mutualisé** : activez AutoSSL / Let's Encrypt dans le panneau de l'hébergeur.
- **VPS** : `certbot --nginx -d votre-domaine.sn` (ou `--apache`).

Le site force ensuite lui-même le HTTPS (redirection permanente, cookies sécurisés, HSTS) dès que `APP_ENV=prod` et `APP_URL=https://…`.
Derrière un proxy ou un CDN (Cloudflare…) mettez `TRUSTED_PROXY=1`, sinon le site croirait que tout arrive en HTTP.

## 5. E-mails

Dans `.env` : `MAIL_DRIVER=smtp` puis `SMTP_HOST`, `SMTP_PORT` (587 + `SMTP_SECURE=tls`, ou 465 + `ssl`), `SMTP_USER`, `SMTP_PASS`, `MAIL_FROM`.
Chez votre service d'e-mail, **authentifiez votre domaine (SPF et DKIM)** : sinon les messages finissent en spam.
Testez avec « mot de passe oublié » sur un compte à vous.

## 6. Vérifier avant d'ouvrir au public

```
php scripts/verifier-production.php --url=https://votre-domaine.sn
```

Il contrôle la configuration, la base, les permissions, **et ce qu'un visiteur d'Internet peut réellement atteindre** (`.env`, `includes/`, `database/`, `storage/`…), les en-têtes de sécurité, la redirection HTTP → HTTPS et le HSTS.
**N'ouvrez pas le site tant qu'il affiche un ✘.** Les ⚠ sont à traiter vite (compte de démo, adresses de test, etc.).

À faire aussi à la main : créer une vraie commande de test en paiement à la livraison, annuler-la, vérifier que l'e-mail arrive.

## 7. Configuration Nginx (uniquement si votre serveur n'est pas Apache)

```nginx
server {
    listen 443 ssl http2;
    server_name votre-domaine.sn;
    root /var/www/jend;
    index index.php;
    client_max_body_size 20m;                      # photos de produits

    # Dossiers et fichiers internes : JAMAIS accessibles
    location ~ ^/(includes|pages|database|storage|scripts|maquette|tests)/ { return 404; }
    location ~ /\.(?!well-known) { return 404; }                      # .env, .git, .htaccess…
    location ~* \.(sql|md|log|lock|sh|py)$ { return 404; }

    # Photos : servies, mais AUCUN script exécuté dans uploads/
    location ^~ /uploads/ {
        location ~ \.(jpe?g|png)$ { try_files $uri =404; }
        return 404;
    }

    location /assets/ { try_files $uri =404; expires 7d; }

    # URL propres : tout passe par index.php
    location / { try_files $uri $uri/ /index.php?$query_string; }

    location = /index.php {
        include fastcgi_params;
        fastcgi_param SCRIPT_FILENAME $document_root$fastcgi_script_name;
        fastcgi_pass unix:/run/php/php8.1-fpm.sock;   # adaptez à votre version de PHP
        fastcgi_param HTTPS on;
    }
    location ~ \.php$ { return 404; }                # aucun autre fichier PHP exécutable
}
server { listen 80; server_name votre-domaine.sn; return 301 https://$host$request_uri; }
```
*Cette configuration n'a pas été testée sur un vrai serveur Nginx.* Après l'avoir installée, `php scripts/verifier-production.php --url=https://…` est votre filet de sécurité.

## 8. Le paiement réel

Aujourd'hui le paiement fonctionne en **simulation** (une fausse page de paiement, qui n'existe qu'en mode développement). Pour de vrais paiements :

1. Ouvrez un compte marchand chez **PayDunya** ou **CinetPay** (documents d'entreprise demandés ; le délai varie).
2. Dans leur tableau de bord, indiquez l'adresse de notification : `https://votre-domaine.sn/paiement/webhook`.
3. Dans `.env` : `PAIEMENT_FOURNISSEUR=…`, `PAIEMENT_SECRET=…`, et `CSP_FORM_ACTION=https://domaine-de-la-page-de-paiement` (sinon le navigateur refuse l'envoi du client vers leur page).
4. Il reste à adapter **deux fonctions** (`paiement_initier()` et `paiement_notification_traiter()` dans `includes/paiement.php`) au format exact de l'API de votre fournisseur. Le reste du parcours (commande, statut, remboursements, interface) ne change pas.
5. Testez d'abord avec leur **mode test** (cartes et numéros fictifs) avant le moindre vrai paiement.

> Cette intégration n'est **pas** faite : elle exige votre compte marchand et ses clés.

## 9. Avant le lancement commercial

- **Pages légales** : conditions générales de vente, politique de confidentialité, mentions légales (identité de l'exploitant, adresse, contact), politique de retour. À faire rédiger/relire par un professionnel.
- **Données personnelles** : le site collecte noms, téléphones, adresses. Au Sénégal, la protection des données personnelles est encadrée par une loi et une autorité (CDP) : renseignez-vous sur la déclaration à effectuer.
- **Statut de l'entreprise et fiscalité** : voyez avec un comptable local (immatriculation, TVA, facturation).
- **Contacts** : remplacez les liens « # » du pied de page par de vraies pages et un vrai moyen de contact (le bandeau promet un support WhatsApp).
- **Supprimer les données de démo** : compte `vendeur@jend.local`, boutique « Marché Démo », comptes en `@jend.local` (le vérificateur les signale).

## 9 bis. Les bibliothèques hébergées (aucun service externe)

Le site n'appelle **aucun CDN** : animations (GSAP), défilement (Lenis), texte animé (Splitting), icônes (Phosphor) et polices (Clash Display, Satoshi) sont dans `assets/vendor/`. Avantages : un service tiers piraté ne peut pas injecter de script sur vos pages (surtout celle de paiement), le site est plus rapide et fonctionne même si ces services sont en panne.

- `assets/vendor/LICENCES.md` : version, licence et source de chaque fichier. **Lisez les licences** (GSAP : « no charge » pour l'usage commercial, avec conditions ; polices Fontshare : licence ITF Free Font License).
- `assets/vendor/SHA256SUMS` : empreinte de chaque fichier. `php scripts/verifier-production.php` signale tout fichier **modifié** (piratage, mauvais transfert).
- **Mettre une bibliothèque à jour** : changez sa version dans `scripts/installer-bibliotheques.py`, lancez `python3 scripts/installer-bibliotheques.py` (il télécharge, recoupe sur deux sources et réécrit les empreintes), puis `python3 tests/run_all.py`. N'éditez jamais ces fichiers à la main.
- Si vous ajoutez une nouvelle bibliothèque externe, ajoutez-la **au script** (liste blanche de domaines) : la politique de sécurité refuse tout le reste.

## 10. Après l'ouverture

| Quoi | Comment |
|---|---|
| **Sauvegardes** | `php scripts/sauvegarde.php` chaque nuit (chiffrées si `BACKUP_PASSPHRASE` est défini). Pour lire une sauvegarde chiffrée : `php scripts/dechiffrer-sauvegarde.php fichier.sql.gz.enc base.sql.gz`, puis `gunzip -c base.sql.gz \| mysql …`. Exemple de tâche cron : `30 2 * * * php /chemin/du/site/scripts/sauvegarde.php`. Mettez `BACKUP_DIR` **hors du dossier public**, et **copiez les fichiers ailleurs** (un disque, un autre service) : une sauvegarde sur le même serveur ne protège pas d'une panne du serveur. |
| **Tester la restauration** | une fois par trimestre, restaurez une sauvegarde dans une base d'essai : `gunzip -c sauvegarde.sql.gz \| mysql -u … -p base_essai`. Une sauvegarde jamais testée n'en est pas une. |
| **Surveiller** | le journal d'erreurs PHP du serveur, et l'onglet **Journal** de l'administration (actions sensibles). Le site vous **envoie un e-mail** (au maximum un par type et par heure) pour : erreur 500, paiement anormal (montant incohérent, double paiement, paiement sur commande annulée), déluge de fausses notifications de paiement, force brute, codes 2FA ou de livraison devinés. Vérifiez que `ALERT_EMAIL` (ou `ADMIN_EMAIL`) est une adresse que vous lisez. Ajoutez un service externe de supervision (il prévient si le site ne répond plus). |
| **Utilisateur qui a perdu son téléphone (2FA)** | il a 8 codes de secours. S'il les a perdus aussi : vérifiez son identité, puis désactivez sa 2FA en base (`UPDATE users SET totp_actif=0, totp_secret=NULL WHERE email='…'` ; `DELETE FROM codes_secours WHERE user_id=…`). |
| **Livraisons** | le client reçoit un code à 4 chiffres à donner à la réception ; le vendeur doit le saisir pour marquer « livrée ». En cas de litige, consultez le journal et l'historique de la commande. |
| **Remboursements** | onglet « Commandes → À rembourser » : un paiement reçu sur une commande annulée y apparaît. Le remboursement réel se fait chez votre fournisseur, puis vous le marquez ici. |
| **Mises à jour** | gardez PHP et MySQL à jour (hébergeur). Relancez `verifier-production.php` après chaque changement de configuration. |

## 11. En cas de problème

- **Site en erreur 500** : lisez le journal d'erreurs PHP ; vérifiez `.env` (un mot de passe de base incorrect donne « Service momentanément indisponible »).
- **403 sur tout le site** : permissions des dossiers (`755`).
- **Annuler une mise en ligne** : remettez la sauvegarde de la veille (base + fichiers). Gardez toujours l'ancienne version du site avant de la remplacer.

## Ce qui n'a pas pu être testé ici

Aucun serveur réel n'était disponible. Ne sont donc **pas** vérifiés : STARTTLS/SSL vers un vrai serveur SMTP (seul le protocole en clair l'a été, avec un faux serveur local), Nginx, HTTPS réel (simulé par en-têtes), les API PayDunya/CinetPay, et la montée en charge.

## Mise à jour d'une base déjà installée (migrations)
Une nouvelle installation n'en a pas besoin (`schema.sql` / `preparer-installation.php` contiennent tout). Pour une base existante, importez dans l'ordre ceux qui manquent (phpMyAdmin → Importer, ou `mysql jend < fichier`) :
- `005_livraison_touba.sql` : livraison limitée à Touba (anciennes zones désactivées, quartiers de Touba ajoutés).
- `006_livreurs.sql` : espace livreur (rôle livreur, table `livreurs`, suivi des courses).
- `007_livraison_horodatage.sql` : heure de livraison (historique et totaux du jour du livreur).
- `008_mdp_provisoire.sql` : mot de passe provisoire à changer à la première connexion (livreurs).
- `009_litiges.sql` : « Signaler un problème » (tables `litiges` et `litige_photos`).
- `010_livraison_par.sql` : qui livre (réglage par boutique) et part du frais de livraison de chaque livraison.
- `011_acompte.sql` : acompte pour les commandes payées à la livraison.
- `012_parametres.sql` : réglages modifiables par l'administrateur (Administration → Paramètres).
- `013_caisse_livreurs.sql` : remises d'espèces des livreurs Jënd (Administration → Caisse).
- `014_livraison_tout_le_senegal.sql` : active la livraison dans tout le Sénégal (principales villes de chaque région, en plus des quartiers de Touba). Frais et délais à ajuster dans Administration → Zones.
- `015_regions_et_verification.sql` : régions desservies par boutique (table `boutique_regions`) et badge « boutique vérifiée ».
- `016_offres.sql` : propositions de prix des clients (« faire une offre », table `offres`) et réglage par boutique.
- `017_video_parrainage.sql` : lien vidéo des produits et parrainage entre vendeurs (code, période sans commission).
- `018_sur_mesure.sql` : commandes sur mesure (table `demandes_mesure`, produits réservés à un client).
- `019_confirmation_email.sql` : confirmation de l'adresse e-mail à l'inscription (les comptes existants sont considérés comme confirmés).
- `020_messages_support.sql` : « Aide et contact » (messages des clients, vendeurs et visiteurs, réponses de l'admin).
- `021_conversations_support.sql` : les demandes d'aide deviennent des conversations (réponses dans le même fil, clôture par l'admin).
- `022_frais_boutiques.sql` : chaque boutique fixe ses frais et délais de livraison par zone (table `boutique_frais`).
- `023_frais_service_securite_retraits.sql` : frais de paiement sécurisé payés par le client (0 % par défaut) et suspension des retraits après un changement de numéro.
- `024_litige_evenements.sql` : chronologie détaillée de chaque signalement (messages du client et de l'équipe, décision, remboursement), reprise des signalements existants.
- `025_fetes.sql` : « Spécial fêtes » (Magal, Tabaski, Korité…) : fêtes saisies par l'administrateur et produits rattachés par les vendeurs.
- `026_commande_cadeau.sql` : « Envoyer à ma famille » (commande cadeau pour un proche, petit mot, code transmis au proche).
- `027_promo_fetes.sql` : promotion de fête facultative (pourcentage choisi par le vendeur, appliquée automatiquement pendant la vitrine).
- `028_position_depense_voix_alertes.sql` : position GPS de livraison, « dépense du mois », description vocale des produits, alertes « prévenez-moi ».
- `029_tailles_pointures.sql` : tailles et pointures par produit, avec un stock par taille (réglage par catégorie).
- `030_versements.sql` : versements aux vendeurs à date fixe, référence du transfert, relevés.
- `031_vitrine_boutique.sql` : vitrine professionnelle de la boutique (logo, bannière, accroche, réseaux, WhatsApp). Envoyer aussi le dossier `uploads/boutiques/`.
- `032_sources_marketing.sql` : canal d'arrivée des clients et des commandes (tableau de bord Croissance).
- `033_mode_simple.sql` : « mode simple » de l'espace vendeur (vendeurs qui lisent peu : photo, prix, voix).
- `034_index_vitesse.sql` : index pour garder le catalogue rapide avec beaucoup de produits.
- `035_prevenir_vendeurs.sql` : prévenir le vendeur d'une nouvelle commande (notifications sur le téléphone, e-mail, relances WhatsApp de l'équipe).
- `036_reglements_commission.sql` : règlement des commissions par les vendeurs (ventes payées en espèces).

## Espace livreur
- L'administrateur crée les comptes dans **/admin/livreurs** (mot de passe provisoire affiché une seule fois) et affecte chaque livraison dans **/admin/courses**, puis prévient le livreur avec le bouton WhatsApp (message pré-rempli ; le téléphone du client n'y figure pas).
- Le livreur se connecte sur le site (**/livreur**) depuis son téléphone et peut « Ajouter à l'écran d'accueil » (appli installable ; elle exige HTTPS, donc sur le vrai site ou InfinityFree en https, pas en `http://localhost` depuis un téléphone).
- Étapes : récupéré → en route → livré. Pour « livré », le livreur saisit le code à 4 chiffres donné par le client. Quand un livreur est affecté, le vendeur ne peut plus marquer la livraison lui-même.
- Pas encore fait : affectation automatique, notifications push, SMS, API WhatsApp Business.

## Suivi client et signalements
- Le client voit sur sa commande une chronologie par livraison (livreur affecté — prénom seulement —, récupéré, en route, livré) ; la page se rafraîchit toute seule pendant que le livreur est en route. Il reçoit un e-mail « en route » et « livraison confirmée » (le code de livraison n'est jamais envoyé par e-mail).
- « Signaler un problème » : possible pendant 7 jours après la livraison, ou si un colis n'est toujours pas arrivé après 2 jours. Promesse affichée : réponse sous 48 h. L'administrateur traite les signalements dans **/admin/litiges** (pastille rouge si le délai est dépassé) : répondre, rembourser, remplacer ou refuser, puis confirmer l'envoi de l'argent (Wave / Orange Money, à la main). Les photos sont dans `storage/litiges/` (à inclure dans vos sauvegardes).

## Qui livre ? (réglage par boutique)
- Par défaut, **le vendeur livre lui-même** et **touche le frais de livraison** payé par le client (réparti entre les livraisons si la commande vient de plusieurs boutiques). L'administrateur peut confier une boutique aux **livreurs Jënd** (page Boutiques) : Jënd garde alors le frais de livraison. Le mode est figé sur chaque commande au moment où elle est passée.
- Paiement en ligne : le vendeur est crédité du prix − commission (+ frais de livraison s'il livre).
- Paiement à la livraison, vendeur qui livre : il a déjà encaissé les espèces ; Jënd ne lui doit rien et **retient la commission sur son solde** (elle apparaît « à reverser »).
- Paiement à la livraison, livreur Jënd : le livreur encaisse pour Jënd ; le vendeur est crédité du prix − commission. Le suivi des espèces rapportées par les livreurs reste manuel.

## Acompte pour les commandes payées à la livraison
- Réglage dans `.env` : `ACOMPTE_POURCENT` (20 par défaut ; 0 = aucun acompte) et `ACOMPTE_MINIMUM` (1000 FCFA). L'acompte est arrondi à la centaine supérieure et ne dépasse jamais le total.
- Le client règle l'acompte en ligne (Wave, Orange Money, Free Money ou carte) : la commande n'est confirmée, et le vendeur ne peut la préparer, qu'une fois l'acompte reçu (notification signée du fournisseur, comme pour un paiement complet). Le reste est payé en espèces à la livraison.
- Annulation avant préparation : l'acompte est remboursé (Administration → Commandes → « À rembourser »). Client absent / refus : Administration → Commandes → « Client absent / refus » : la livraison est retournée, les produits remis en stock, l'acompte conservé (au profit du vendeur qui livrait, ou de Jënd si ce sont ses livreurs).
- Comptabilité : le livreur ou le vendeur n'encaisse en espèces que le reste ; le vendeur qui livre est crédité de l'acompte reçu par Jënd, moins sa commission.

## Lancer les tests sans risque pour vos données
`python3 scripts/tester-en-isolation.py` copie le site dans un dossier temporaire, crée une base jetable (`jend_test_iso`) avec des produits de démonstration, démarre un petit serveur PHP et lance toute la batterie (`tests/run_all.py`), puis supprime tout. Un seul test : `python3 scripts/tester-en-isolation.py test_etape9.py`. Les tests refusent désormais de tourner directement sur votre vraie base.

## Fonctionnalités à activer plus tard (Administration → Paramètres)
- **Livraison par les livreurs Jënd** : désactivée au démarrage (chaque vendeur livre lui-même et touche le frais de livraison). Activée par l'admin quand le site grandit : les onglets « Courses » et « Livreurs » apparaissent, et les boutiques confiées aux livreurs Jënd (page Boutiques) sont livrées par eux pour les **prochaines** commandes.
- **Acompte** pour les paiements à la livraison : activé par défaut, réglable (pourcentage, minimum) ou désactivable.
- **Commission des nouvelles boutiques** : 0 % au lancement, relevable à tout moment (prévenir les vendeurs 30 jours avant).
- Les valeurs réglées ici l'emportent sur celles du `.env` (`ACOMPTE_*`, `COMMISSION_DEFAUT`). Chaque changement est dans le journal admin.

## Identité visuelle (« l'étal de Touba »)
- Les motifs tissés sont dans `assets/img/motifs/` (20 fichiers SVG) ; le dessin des pages d'accueil, des cartes produit et du pied de page est dans `assets/css/identite.css` (chargé après `style.css`). Pour changer une couleur de motif, modifiez le fichier SVG correspondant.
- Signature : entrées de dictionnaire wolof (jënd = acheter, jaay = vendre), étiquettes de prix suspendues, coins taillés asymétriques, banderole et bordures « tressées », registre à points de conduite, « Notre parole » numérotée.
- Polices : Clash Display + Satoshi (déjà hébergées dans `assets/vendor/`). Aucune ressource externe.

## Commission : démarrer à 0 % puis l'annoncer
- Au lancement, la commission est de 0 % (`COMMISSION_DEFAUT=0` ou Administration → Paramètres). La page publique « Frais et commissions » le dit clairement, annonce qu'une commission pourra être appliquée plus tard, et que les taux peuvent changer (préavis de 30 jours par e-mail, jamais rétroactif, liberté de fermer sa boutique).
- Pour introduire ou changer la commission : Administration → Paramètres → « Annoncer un changement de commission » (taux + date au moins 30 jours plus tard). Les vendeurs reçoivent un e-mail ; l'annonce s'affiche sur « Frais et commissions » et dans leur espace. À la date, le bouton « Appliquer à toutes les boutiques » devient disponible ; avant, il est bloqué.

## Brancher PayDunya (paiement réel)
**Ce qui est prêt dans le code** (testé contre un faux serveur PayDunya, pas encore contre le vrai) : création de la facture (montant calculé par le site), redirection vers la page de paiement PayDunya, notification IPN contrôlée par le hash de la clé principale puis **confirmation directe auprès de PayDunya**, vérification au retour du client, acompte, échec/annulation, nouvelle tentative, bouton admin « Paiements PayDunya en attente ».

**À faire de votre côté**
1. Créez votre compte sur paydunya.com et validez votre entreprise (la validation est indispensable pour le mode « live »).
2. Tableau de bord PayDunya → **Intégrez notre API** → créez une application « Jënd » : vous obtenez 3 clés (master key, private key, token), en version **test** et en version **live**.
3. Dans `.env` (jamais dans le code, jamais dans un message) :
   `PAIEMENT_FOURNISSEUR=paydunya`, `PAYDUNYA_MODE=test`, `PAYDUNYA_MASTER_KEY=…`, `PAYDUNYA_PRIVATE_KEY=…`, `PAYDUNYA_TOKEN=…`, et `APP_URL` en https avec l'adresse publique du site (PayDunya doit pouvoir renvoyer le client chez vous).
4. Essayez d'abord en **test** (paiements d'essai, numéros de test de la documentation PayDunya). Puis passez `PAYDUNYA_MODE=live` avec les clés « live ».
5. Lancez `php scripts/verifier-production.php` : il contrôle les 3 clés, le mode live et l'absence de `PAYDUNYA_API_BASE`.
- **Hébergement gratuit (InfinityFree)** : les appels entrants (IPN) y sont probablement bloqués. Ce n'est pas grave : la confirmation se fait quand le client revient sur le site, et l'admin peut interroger PayDunya à la demande (Commandes → « Paiements PayDunya en attente »). Pour des paiements réels, préférez un hébergement payant.
- **Frais** : PayDunya prélève sa propre commission sur chaque paiement ; elle n'apparaît nulle part dans le code du site. Vérifiez leur grille tarifaire et tenez-en compte dans vos prix.

## Reverser les vendeurs (retraits)
- **Délai avant retrait** : un gain devient retirable quelques jours après la livraison confirmée (3 par défaut, réglable de 0 à 30 dans Administration → Paramètres → « Retraits des vendeurs »). Le vendeur voit « Bientôt retirable » pendant ce délai. Pendant ce temps, le client peut encore signaler un problème sans que l'argent soit parti.
- **Reverser à jour fixe** (par exemple le lundi) : Administration → Retraits → « Exporter les retraits à payer (CSV) » donne la liste (boutique, vendeur, mode, numéro, montant, total), à ouvrir dans Excel ou à recopier dans Wave / Orange Money. Une fois envoyé, cliquez « Payé » sur chaque ligne. Les noms qui commencent par `=`, `+`, `-` ou `@` sont neutralisés dans le fichier (pas d'exécution de formule).
- **Reversement automatique par PayDunya** : leur API de décaissement (Wave Sénégal, Orange Money, Free Money…) existe, mais elle doit être **activée par PayDunya sur votre compte**. Non branchée pour l'instant.

## Trésorerie : savoir si tu peux payer tout le monde (Administration → Trésorerie)
- **1. Ce qui devrait être sur ton compte de paiement** : encaissé en ligne − remboursé aux clients − versé aux vendeurs = solde théorique, **avant** les frais du prestataire (PayDunya les retient sur chaque paiement).
- **2. Ce que tu dois encore** (cet argent n'est pas à toi) : gains retirables, « bientôt retirables » et mis de côté des vendeurs, retraits demandés, commandes payées pas encore livrées, remboursements à envoyer aux clients.
- **3. Ce qui te reste** avant frais : tes commissions et frais de livraison.
- **4. Compare avec la réalité** : saisis le solde lu dans ton tableau de bord PayDunya. L'écart avec le solde théorique = les frais retenus (en FCFA et en % de l'encaissé), et on t'affiche ce qui te reste réellement, ou ce qui **manque** pour payer tout le monde (à compléter de ta poche, ou à couvrir par une commission).
- Les espèces encaissées par les vendeurs ou les livreurs ne passent pas par ce compte : elles ne sont pas comptées. Fais cette comparaison chaque semaine, avant de reverser les vendeurs.

## Archive prête avec la configuration (dossier `deploiement/`)
Les configurations de mise en ligne sont rangées dans `deploiement/` (privé, exclu des archives). Pour créer l'archive à décompresser chez l'hébergeur :
`sh scripts/preparer-mise-en-ligne.sh infinityfree` ou `sh scripts/preparer-mise-en-ligne.sh production` (voir `deploiement/LISEZ-MOI.md`).
