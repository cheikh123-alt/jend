<?php
declare(strict_types=1);

/**
 * DIAGNOSTIC DU SERVEUR — à utiliser UNE FOIS sur un hébergement sans terminal (ex : InfinityFree).
 *
 *   1. Dans .env, ajoutez une ligne :  DIAGNOSTIC_CLE=une-phrase-aleatoire-de-16-caracteres-minimum
 *   2. Envoyez ce fichier à la racine du site (à côté de index.php).
 *   3. Ouvrez dans VOTRE NAVIGATEUR :  https://votre-site/diagnostic.php?cle=la-meme-phrase
 *   4. Lisez le rapport (ou cliquez sur « Copier le rapport » et collez-le à votre assistant).
 *   5. SUPPRIMEZ ce fichier du serveur ET la ligne DIAGNOSTIC_CLE de .env.
 *
 * Sans clé valable, la page répond « 404 » comme si elle n'existait pas. Elle n'affiche JAMAIS de mot de passe ni de clé.
 * Les contrôles de sécurité « vu de l'extérieur » sont faits par votre NAVIGATEUR (sur ce type d'hébergement, seuls
 * les vrais navigateurs peuvent joindre le site : les outils automatiques sont bloqués).
 */
require __DIR__ . '/includes/env.php';

function non_trouve(): void
{
    http_response_code(404);
    header('Content-Type: text/plain; charset=UTF-8');
    exit('Not found');
}

$cle = (string) env('DIAGNOSTIC_CLE', '');
if (strlen($cle) < 16 || !hash_equals($cle, (string) ($_GET['cle'] ?? ''))) {
    non_trouve();
}
header('Cache-Control: no-store');
header('X-Robots-Tag: noindex, nofollow');

$racine = __DIR__;
$fichierPiege = $racine . '/uploads/produits/diag-exec-test.php';

// Petites actions appelées par le navigateur (contrôle « un script déposé dans uploads/ ne doit pas s'exécuter »)
if (($_GET['action'] ?? '') === 'creer') {
    @mkdir(dirname($fichierPiege), 0755, true);
    echo file_put_contents($fichierPiege, "<?php echo 'SCRIPT-EXECUTE';") !== false ? 'ok' : 'echec';
    exit;
}
if (($_GET['action'] ?? '') === 'supprimer') {
    @unlink($fichierPiege);
    echo is_file($fichierPiege) ? 'echec' : 'ok';
    exit;
}

$lignes = [];                       // [etat, texte, aide]  etat : ok | ko | warn
$compte = ['ok' => 0, 'ko' => 0, 'warn' => 0];
function ligne(string $etat, string $texte, string $aide = ''): void
{
    global $lignes, $compte;
    $lignes[] = [$etat, $texte, $aide];
    $compte[$etat]++;
}
function titre(string $t): void
{
    global $lignes;
    $lignes[] = ['titre', $t, ''];
}
function controle(bool $cond, string $bon, string $mauvais, string $aide = '', bool $bloquant = true): void
{
    $cond ? ligne('ok', $bon) : ligne($bloquant ? 'ko' : 'warn', $mauvais, $aide);
}

/* ---------------- 1. Serveur ---------------- */
titre('1. Serveur et PHP');
controle(PHP_VERSION_ID >= 80000, 'PHP ' . PHP_VERSION . ' (8.0 minimum)', 'PHP ' . PHP_VERSION . ' : trop ancien (8.0 minimum)', 'Choisissez une version de PHP 8.x dans le panneau de votre hébergeur.');
ligne('ok', 'Système : ' . PHP_OS_FAMILY . ' · interface : ' . PHP_SAPI);
ligne('ok', 'memory_limit = ' . ini_get('memory_limit') . ' · upload_max_filesize = ' . ini_get('upload_max_filesize') . ' · post_max_size = ' . ini_get('post_max_size') . ' · max_file_uploads = ' . ini_get('max_file_uploads') . ' · max_execution_time = ' . ini_get('max_execution_time') . ' s');
$interdites = array_filter(array_map('trim', explode(',', (string) ini_get('disable_functions'))));
$utiles = ['random_bytes', 'hash_hmac', 'password_hash', 'openssl_encrypt', 'imagecreatefromjpeg', 'imagecreatefrompng', 'imagejpeg', 'imagepng', 'finfo_open', 'mb_strtolower', 'stream_socket_client', 'file_put_contents', 'session_start', 'preg_match'];
$bloquees = array_values(array_intersect($utiles, $interdites));
controle(!$bloquees, 'Aucune fonction nécessaire au site n\'est désactivée par l\'hébergeur', 'Fonction(s) nécessaires désactivées : ' . implode(', ', $bloquees), 'Le site ne pourra pas fonctionner correctement.');
ligne('ok', 'Fonctions désactivées par l\'hébergeur : ' . ($interdites ? implode(', ', $interdites) : 'aucune'));
foreach (['pdo_mysql' => 'accès à la base', 'mbstring' => 'textes accentués', 'fileinfo' => 'contrôle des photos', 'openssl' => 'chiffrement (2FA)', 'json' => 'JSON', 'ctype' => 'ctype'] as $ext => $role) {
    controle(extension_loaded($ext), "Extension $ext ($role)", "Extension $ext MANQUANTE ($role)");
}
$gd = function_exists('gd_info') ? gd_info() : [];
controle(!empty($gd), 'Extension gd (traitement des photos)', 'Extension gd MANQUANTE : envoi de photos impossible', 'Les vendeurs ne pourront pas ajouter de photos.');
controle(!empty($gd['JPEG Support']) && !empty($gd['PNG Support']), 'gd : JPEG et PNG pris en charge', 'gd : JPEG ou PNG non pris en charge');
controle(function_exists('openssl_get_cipher_methods') && in_array('aes-256-gcm', openssl_get_cipher_methods(), true), 'OpenSSL : chiffrement AES-256-GCM disponible', 'OpenSSL : AES-256-GCM indisponible (2FA et sauvegardes chiffrées impossibles)');
controle((new DateTimeZone('Africa/Dakar'))->getName() === 'Africa/Dakar', 'Fuseau horaire Africa/Dakar disponible', 'Fuseau Africa/Dakar indisponible', '', false);

/* ---------------- 2. HTTPS et adresse ---------------- */
titre('2. HTTPS, adresse du site et visiteurs');
$https = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off');
$xfp = strtolower((string) ($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? ''));
ligne('ok', 'Vu par PHP : HTTPS = ' . ($_SERVER['HTTPS'] ?? '(absent)') . ' · port = ' . ($_SERVER['SERVER_PORT'] ?? '?') . ' · X-Forwarded-Proto = ' . ($xfp ?: '(absent)') . ' · adresse du visiteur (REMOTE_ADDR) = ' . ($_SERVER['REMOTE_ADDR'] ?? '?') . ' · Host = ' . ($_SERVER['HTTP_HOST'] ?? '?'));
$vuEnHttps = $https || ($xfp === 'https');
controle($vuEnHttps, 'Cette page a été ouverte en HTTPS et PHP le sait : la redirection HTTPS du site fonctionnera', 'PHP NE VOIT PAS le HTTPS (HTTPS absent / X-Forwarded-Proto absent)', 'Si vous avez ouvert cette page en https:// : mettez FORCE_HTTPS=0 dans .env, sinon le site bouclerait en redirections. Si vous l\'avez ouverte en http:// : ouvrez-la en https://.');
$appUrl = (string) env('APP_URL', '');
$hoteUrl = (string) parse_url($appUrl, PHP_URL_HOST);
controle(str_starts_with($appUrl, 'https://') && $hoteUrl !== '' && substr($appUrl, -1) !== '/', 'APP_URL valide en https : ' . $appUrl, 'APP_URL absent ou invalide (https://… sans « / » final)', 'Exemple : APP_URL=https://monsite.great-site.net');
controle($hoteUrl !== '' && strcasecmp($hoteUrl, (string) ($_SERVER['HTTP_HOST'] ?? '')) === 0, 'L\'adresse de APP_URL correspond à celle que vous utilisez', 'APP_URL (' . $hoteUrl . ') ≠ adresse utilisée (' . ($_SERVER['HTTP_HOST'] ?? '?') . ')', 'La redirection HTTPS du site vous enverrait vers une autre adresse.');
controle(stripos((string) ($_SERVER['HTTP_HOST'] ?? ''), 'www.') !== 0, 'Adresse sans « www. » (les sous-domaines gratuits ne supportent pas le HTTPS avec www)', 'Adresse avec « www. »', 'Utilisez l\'adresse sans www.', false);

/* ---------------- 3. Fichiers ---------------- */
titre('3. Fichiers du site');
foreach (['index.php', '.htaccess', 'includes/bootstrap.php', 'includes/db.php', 'pages/accueil.php', 'assets/css/style.css', 'uploads/.htaccess'] as $f) {
    controle(is_file("$racine/$f"), "$f présent", "$f MANQUANT", $f === '.htaccess' ? 'Les fichiers cachés (.htaccess, .env) ne s\'envoient pas toujours : activez « afficher les fichiers cachés » dans votre logiciel FTP.' : 'Renvoyez ce fichier.');
}
controle(is_file("$racine/.env"), '.env présent', '.env MANQUANT', 'Créez-le à partir de hebergeur-test.env (généré par scripts/preparer-installation.php), avec « afficher les fichiers cachés » activé dans le FTP.');
foreach (['storage', 'uploads/produits'] as $d) {
    $essai = "$racine/$d/.diag-ecriture";
    @mkdir("$racine/$d", 0755, true);
    $ok = @file_put_contents($essai, 'x') !== false;
    @unlink($essai);
    controle($ok, "$d/ accessible en écriture", "$d/ NON accessible en écriture", 'Vérifiez que le dossier existe et ses permissions (755).');
}
$sommes = "$racine/assets/vendor/SHA256SUMS";
if (is_file($sommes)) {
    $ecarts = [];
    $n = 0;
    foreach (file($sommes, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) as $l) {
        [$h, $rel] = preg_split('/\s+/', trim($l), 2) + [1 => ''];
        $n++;
        $f = "$racine/assets/vendor/$rel";
        if (!is_file($f) || !hash_equals($h, hash_file('sha256', $f))) {
            $ecarts[] = $rel;
        }
    }
    controle(!$ecarts, "$n bibliothèques (polices, icônes, animations) intactes", 'Fichier(s) abîmé(s) ou manquant(s) : ' . implode(', ', array_slice($ecarts, 0, 6)), 'Un envoi FTP interrompu ou en mode « ASCII » corrompt les polices. Réenvoyez-les en mode BINAIRE.');
} else {
    ligne('ko', 'assets/vendor/SHA256SUMS manquant', 'Renvoyez le dossier assets/vendor/ en entier.');
}
foreach (['install.php' => 'inutile ici (pas de terminal)', 'scripts' => 'inutile sur le serveur', 'tests' => 'ne doit pas être en ligne', 'database' => 'inutile sur le serveur', 'maquette' => 'ancienne maquette', 'jend.zip' => 'archive inutile'] as $f => $pourquoi) {
    controle(!file_exists("$racine/$f"), "$f absent", "$f présent ($pourquoi)", 'Supprimez-le du serveur.', false);
}

/* ---------------- 4. Configuration (sans afficher de valeur secrète) ---------------- */
titre('4. Configuration (.env)');
$appEnv = (string) env('APP_ENV', '');
controle(in_array($appEnv, ['test', 'prod'], true), "APP_ENV = $appEnv", 'APP_ENV doit valoir « test » (essais) ou « prod »', 'Avec « dev », les erreurs techniques seraient visibles de tous.');
controle(strlen((string) env('APP_KEY', '')) >= 32, 'APP_KEY défini (32 caractères minimum)', 'APP_KEY manquant ou trop court');
controle(strlen((string) env('PAIEMENT_SECRET', '')) >= 32, 'PAIEMENT_SECRET défini (32 caractères minimum)', 'PAIEMENT_SECRET manquant ou trop court');
foreach (['DB_HOST', 'DB_NAME', 'DB_USER', 'DB_PASS'] as $k) {
    controle((string) env($k, '') !== '', "$k renseigné", "$k MANQUANT");
}
$driver = (string) env('MAIL_DRIVER', '');
controle(in_array($driver, ['smtp', 'log', 'mail'], true), "MAIL_DRIVER = $driver" . ($driver === 'mail' ? ' (mail() est très restreint sur les hébergements gratuits : préférez smtp)' : ''), 'MAIL_DRIVER doit valoir smtp, mail ou log', '', false);
if ($driver === 'smtp') {
    controle(env('SMTP_HOST') && env('SMTP_USER') && env('SMTP_PASS') && env('MAIL_FROM'), 'SMTP configuré (hôte, identifiant, mot de passe, expéditeur)', 'SMTP incomplet (SMTP_HOST, SMTP_USER, SMTP_PASS, MAIL_FROM)');
}
controle(strlen($cle) >= 16, 'DIAGNOSTIC_CLE défini : pensez à le SUPPRIMER après ce diagnostic', '', '', false);

/* ---------------- 5. Base de données ---------------- */
titre('5. Base de données');
try {
    $pdo = new PDO(sprintf('mysql:host=%s;port=%s;dbname=%s;charset=utf8mb4', env('DB_HOST', 'localhost'), env('DB_PORT', '3306'), env('DB_NAME', '')), (string) env('DB_USER', ''), (string) env('DB_PASS', ''), [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_TIMEOUT => 8]);
    ligne('ok', 'Connexion à la base réussie · serveur : ' . $pdo->query('SELECT VERSION()')->fetchColumn());
    ligne('ok', 'sql_mode : ' . $pdo->query('SELECT @@sql_mode')->fetchColumn());
    $n = (int) $pdo->query('SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = DATABASE()')->fetchColumn();
    controle($n >= 40, "$n tables présentes (40 attendues)", "$n tables seulement (40 attendues)", 'Importez jend-installation.sql dans phpMyAdmin (base vide).');
    if ($n >= 25) {
        $admins = (int) $pdo->query("SELECT COUNT(*) FROM users WHERE role = 'admin' AND actif = 1")->fetchColumn();
        controle($admins >= 1, "$admins administrateur(s) actif(s)", 'Aucun administrateur : le fichier d\'installation a-t-il été généré avec --admin-email ?');
        ligne('ok', 'Zones de livraison : ' . $pdo->query('SELECT COUNT(*) FROM zones_livraison')->fetchColumn() . ' · catégories : ' . $pdo->query('SELECT COUNT(*) FROM categories')->fetchColumn());
        $demo = (int) $pdo->query("SELECT COUNT(*) FROM users WHERE email = 'vendeur@jend.local'")->fetchColumn();
        ligne($demo ? 'warn' : 'ok', $demo ? 'Comptes de démonstration présents (normal pour un test ; à supprimer avant un vrai lancement)' : 'Aucun compte de démonstration');
    }
} catch (Throwable $e) {
    ligne('ko', 'Connexion à la base IMPOSSIBLE : ' . substr($e->getMessage(), 0, 200), 'Sur InfinityFree, l\'hôte n\'est PAS « localhost » : copiez « MySQL Hostname » (sqlXXX.infinityfree.com), le nom complet de la base (if0_…_nom) et l\'utilisateur depuis le panneau « MySQL Databases ».');
}

/* ---------------- 6. Envoi d'e-mails (connexions sortantes) ---------------- */
titre('6. Connexions sortantes (e-mails)');
foreach ([['smtp.gmail.com', 587, 'tcp'], ['smtp.gmail.com', 465, 'ssl']] as [$hote, $port, $mode]) {
    $ctx = stream_context_create(['ssl' => ['verify_peer' => true, 'verify_peer_name' => true]]);
    $fp = @stream_socket_client("$mode://$hote:$port", $errno, $errstr, 8, STREAM_CLIENT_CONNECT, $ctx);
    if ($fp) {
        stream_set_timeout($fp, 6);
        $accueil = trim((string) fgets($fp, 256));
        fclose($fp);
        controle(str_starts_with($accueil, '220'), "$hote:$port ($mode) joignable" . ($mode === 'ssl' ? ', certificat vérifié' : '') . ' : ' . substr($accueil, 0, 40), "$hote:$port répond de façon inattendue : $accueil", '', false);
    } else {
        ligne('warn', "$hote:$port ($mode) INJOIGNABLE : $errstr", 'L\'envoi d\'e-mails par SMTP ne fonctionnera pas depuis cet hébergement.');
    }
}

/* ---------------- 6 bis. Notifications sur le téléphone (Web Push) ---------------- */
titre('6 bis. Notifications sur le téléphone');
require_once __DIR__ . '/includes/push.php';
controle(function_exists('openssl_pkey_derive'), 'openssl_pkey_derive disponible (chiffrement des notifications)', 'openssl_pkey_derive ABSENT : PHP trop ancien ou openssl incomplet', 'Choisissez PHP 8.1 ou plus dans le panneau de l\'hébergeur.');
controle(function_exists('curl_init'), 'Extension curl disponible', 'Extension curl ABSENTE', 'Activez curl (PHP) dans le panneau de l\'hébergeur.');
controle(in_array('aes-128-gcm', openssl_get_cipher_methods(), true), 'Chiffrement aes-128-gcm disponible', 'aes-128-gcm ABSENT');
ligne((string) env('NOTIFICATIONS_TELEPHONE', '0') === '1' ? 'ok' : 'warn', 'Notifications sur le téléphone : ' . ((string) env('NOTIFICATIONS_TELEPHONE', '0') === '1' ? 'ACTIVÉES' : 'désactivées (NOTIFICATIONS_TELEPHONE=1 dans config.env pour les activer)'));
if (push_possible()) {
    try {
        $cleSite = push_cle_site();
        ligne('ok', 'Clé du site pour les notifications : OK (' . PUSH_CLE_FICHIER . ')');
        $essaiUa = openssl_pkey_new(['private_key_type' => OPENSSL_KEYTYPE_EC, 'curve_name' => 'prime256v1']);
        $essai = push_chiffrer('{"essai":1}', b64url(push_point_public($essaiUa)), b64url(random_bytes(16)));
        controle(strlen($essai) > 86, 'Chiffrement d\'un message d\'essai : OK', 'Chiffrement d\'un message d\'essai : ÉCHEC');
        controle(str_starts_with(push_vapid('https://fcm.googleapis.com/fcm/send/x'), 'vapid t='), 'Signature VAPID : OK', 'Signature VAPID : ÉCHEC');
    } catch (Throwable $e) {
        ligne('ko', 'Clé ou chiffrement des notifications : ' . $e->getMessage(), 'Vérifiez que le dossier storage/ est accessible en écriture.');
    }
    // Les vrais services de notification répondent par une erreur 4xx à une demande vide : l'important est qu'ils RÉPONDENT
    foreach (['https://fcm.googleapis.com/fcm/send/diagnostic' => 'Google (Android, Chrome)', 'https://updates.push.services.mozilla.com/wpush/v2/diagnostic' => 'Mozilla (Firefox)', 'https://web.push.apple.com/diagnostic' => 'Apple (iPhone)'] as $url => $nom) {
        $ch = curl_init($url);
        curl_setopt_array($ch, [CURLOPT_POST => true, CURLOPT_POSTFIELDS => '', CURLOPT_RETURNTRANSFER => true, CURLOPT_CONNECTTIMEOUT => 6, CURLOPT_TIMEOUT => 8, CURLOPT_HTTPHEADER => ['TTL: 60']]);
        curl_exec($ch);
        $code = (int) curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
        $err = curl_errno($ch) ? curl_error($ch) : '';
        curl_close($ch);
        controle($code > 0, "Service de notification $nom joignable (réponse $code)", "Service de notification $nom INJOIGNABLE : " . mb_substr($err ?: 'pas de réponse', 0, 100),
            'L\'hébergeur bloque les connexions sortantes vers ce service : les notifications ne peuvent pas partir de ce serveur (les e-mails restent possibles si le SMTP passe). Il faudra un hébergement qui autorise les connexions sortantes.');
    }
}

/* ---------------- 7. PayDunya (si c'est le fournisseur choisi) ---------------- */
$fournisseursDiag = array_map('trim', explode(',', strtolower((string) env('PAIEMENT_FOURNISSEUR', ''))));
if (in_array('paytech', $fournisseursDiag, true)) {
    titre('7 bis. PayTech');
    foreach (['PAYTECH_API_KEY', 'PAYTECH_API_SECRET'] as $k) {
        controle((string) env($k, '') !== '', "$k renseigné", "$k MANQUANT", 'Espace marchand PayTech → paramètres API.');
    }
    $prod = in_array(strtolower(trim((string) env('PAYTECH_ENV', 'test'))), ['prod', 'production', 'live'], true);
    ligne($prod ? 'ok' : 'warn', 'Mode PayTech : ' . ($prod ? 'PROD (vrais paiements)' : 'TEST (une petite somme réelle de 100 à 150 F est débitée à chaque essai)'));
    $fp = @stream_socket_client('ssl://paytech.sn:443', $errno, $errstr, 8, STREAM_CLIENT_CONNECT, stream_context_create(['ssl' => ['verify_peer' => true, 'verify_peer_name' => true]]));
    controle((bool) $fp, 'paytech.sn:443 joignable, certificat vérifié', 'paytech.sn injoignable depuis ce serveur : ' . substr((string) $errstr, 0, 80), 'Sans connexion sortante vers PayTech, aucun paiement ne peut être créé. Contactez l\'hébergeur.');
    if ($fp) {
        fclose($fp);
    }
    ligne('warn', 'PayTech confirme les paiements uniquement par sa notification (IPN) vers paiement/webhook : sur un hébergement gratuit qui filtre les robots (InfinityFree), elle risque de ne jamais arriver.');
}
if (in_array('unitech', $fournisseursDiag, true)) {
    titre('7 ter. UnitechPay');
    controle((string) env('UNITECH_API_KEY', '') !== '', 'UNITECH_API_KEY renseigné', 'UNITECH_API_KEY MANQUANT', 'Tableau de bord UnitechPay → Paramètres → API.');
    ligne('warn', 'UnitechPay : pas de mode test documenté, chaque essai est un vrai paiement. Wave et Orange Money seulement (ni carte ni Free Money).');
    $fp = @stream_socket_client('ssl://api.unitech.sn:443', $errno, $errstr, 8, STREAM_CLIENT_CONNECT, stream_context_create(['ssl' => ['verify_peer' => true, 'verify_peer_name' => true]]));
    controle((bool) $fp, 'api.unitech.sn:443 joignable, certificat vérifié', 'api.unitech.sn injoignable depuis ce serveur : ' . substr((string) $errstr, 0, 80), 'Sans connexion sortante vers UnitechPay, aucun paiement ne peut être créé. Contactez l\'hébergeur.');
    if ($fp) {
        fclose($fp);
    }
    ligne('warn', 'UnitechPay confirme les paiements uniquement par son webhook vers paiement/webhook (bouton « Enregistrer cette adresse chez UnitechPay » dans Paramètres) : sur un hébergement gratuit qui filtre les robots, il risque de ne jamais arriver.');
}
if (in_array('paydunya', $fournisseursDiag, true)) {
    titre('7. PayDunya');
    foreach (['PAYDUNYA_MASTER_KEY', 'PAYDUNYA_PRIVATE_KEY', 'PAYDUNYA_TOKEN'] as $k) {
        controle((string) env($k, '') !== '', "$k renseigné", "$k MANQUANT", 'Tableau de bord PayDunya → Intégrez notre API → votre application.');
    }
    $live = in_array(strtolower(trim((string) env('PAYDUNYA_MODE', 'test'))), ['live', 'prod', 'production'], true);          // live, prod ou production
    ligne($live ? 'ok' : 'warn', 'Mode PayDunya : ' . ($live ? 'LIVE (vrais paiements)' : 'TEST (paiements d\'essai)'));
    $fp = @stream_socket_client('ssl://app.paydunya.com:443', $errno, $errstr, 8, STREAM_CLIENT_CONNECT, stream_context_create(['ssl' => ['verify_peer' => true, 'verify_peer_name' => true]]));
    controle((bool) $fp, 'app.paydunya.com:443 joignable, certificat vérifié', 'app.paydunya.com injoignable depuis ce serveur : ' . substr((string) $errstr, 0, 80), 'Sans connexion sortante vers PayDunya, aucun paiement ne peut être créé ni vérifié. Contactez l\'hébergeur.');
    if ($fp) {
        fclose($fp);
    }
    ligne('warn', 'Sur un hébergement gratuit (InfinityFree), PayDunya ne pourra probablement pas appeler la notification IPN : la confirmation se fait au retour du client, ou via Administration → Commandes → « Paiements PayDunya en attente ».');
}

/* ---------------- Rapport + contrôles côté navigateur ---------------- */
$icone = ['ok' => '✔', 'ko' => '✘', 'warn' => '⚠'];
$texteRapport = "Rapport de diagnostic Jënd — " . date('Y-m-d H:i') . "\n";
foreach ($lignes as [$etat, $texte, $aide]) {
    $texteRapport .= $etat === 'titre' ? "\n== $texte ==\n" : "{$icone[$etat]} $texte" . ($aide && $etat !== 'ok' ? "\n    → $aide" : '') . "\n";
}
?><!DOCTYPE html>
<html lang="fr"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1"><meta name="robots" content="noindex">
<title>Diagnostic du serveur — Jënd</title>
<style>
 body{font-family:system-ui,sans-serif;max-width:900px;margin:1.5rem auto;padding:0 1rem;background:#FAF3E7;color:#1B1410;line-height:1.5}
 h1{margin:.2em 0}h2{margin:1.6em 0 .4em;font-size:1.1rem;border-bottom:2px solid #F1E6D2;padding-bottom:.2em}
 .l{padding:.25rem 0}.ok{color:#0F3D2E}.ko{color:#B3261E;font-weight:700}.warn{color:#8A5A00}.aide{display:block;color:#6B5E52;font-weight:400;font-size:.9rem;margin-left:1.4rem}
 .bilan{background:#fff;border-radius:12px;padding:1rem 1.2rem;margin:1rem 0;font-size:1.05rem}
 button{font:inherit;padding:.6rem 1.2rem;border-radius:99px;border:0;background:#C2471F;color:#fff;font-weight:700;cursor:pointer}
 pre{background:#fff;padding:1rem;border-radius:12px;white-space:pre-wrap;font-size:.85rem}
</style></head><body>
<h1>Diagnostic du serveur</h1>
<div class="bilan"><b class="ok">✔ <?= $compte['ok'] ?></b> &nbsp; <b class="warn">⚠ <?= $compte['warn'] ?></b> &nbsp; <b class="ko">✘ <?= $compte['ko'] ?></b>
 — <?= $compte['ko'] === 0 ? 'aucun point bloquant côté serveur.' : 'corrigez les ✘ avant d\'aller plus loin.' ?></div>
<p><button id="copier" type="button">Copier le rapport</button> <small>(à coller à votre assistant)</small></p>
<?php foreach ($lignes as [$etat, $texte, $aide]): ?>
  <?php if ($etat === 'titre'): ?><h2><?= htmlspecialchars($texte) ?></h2>
  <?php else: ?><div class="l <?= $etat ?>"><?= $icone[$etat] ?> <?= htmlspecialchars($texte) ?><?php if ($aide && $etat !== 'ok'): ?><span class="aide">→ <?= htmlspecialchars($aide) ?></span><?php endif; ?></div><?php endif; ?>
<?php endforeach; ?>
<h2>7. Sécurité vue de l'extérieur (contrôlée par votre navigateur)</h2>
<div id="externe"><div class="l">Contrôle en cours…</div></div>
<h2>Rapport complet</h2>
<pre id="rapport"><?= htmlspecialchars($texteRapport) ?></pre>
<script>
(function () {
  var cle = <?= json_encode($cle) ?>, base = location.pathname.replace(/diagnostic\.php$/, ''), sortie = document.getElementById('externe'), rapport = document.getElementById('rapport');
  function ligne(etat, texte, aide) {
    var d = document.createElement('div'); d.className = 'l ' + etat;
    d.textContent = ({ok: '✔ ', ko: '✘ ', warn: '⚠ '})[etat] + texte;
    if (aide) { var s = document.createElement('span'); s.className = 'aide'; s.textContent = '→ ' + aide; d.appendChild(s); }
    sortie.appendChild(d);
    rapport.textContent += ({ok: '✔ ', ko: '✘ ', warn: '⚠ '})[etat] + texte + (aide && etat !== 'ok' ? '\n    → ' + aide : '') + '\n';
  }
  function statut(url) { return fetch(base + url, {credentials: 'same-origin', redirect: 'manual', cache: 'no-store'}).then(function (r) { return r; }).catch(function () { return null; }); }
  sortie.innerHTML = ''; rapport.textContent += '\n== 7. Sécurité vue de l\'extérieur ==\n';
  var interdits = ['.env', 'includes/db.php', 'includes/bootstrap.php', 'pages/accueil.php', 'storage/', 'storage/app-key.txt', 'database/schema.sql', 'scripts/sauvegarde.php', 'tests/lib.py', 'assets/vendor/SHA256SUMS', 'assets/vendor/LICENCES.md', 'uploads/produits/'];
  var suite = Promise.resolve();
  interdits.forEach(function (u) {
    suite = suite.then(function () { return statut(u); }).then(function (r) {
      var s = r ? r.status : 0, ok = (s === 403 || s === 404);
      if (r && r.type === 'opaqueredirect') { ok = true; s = 'redirection'; }
      ok ? ligne('ok', '/' + u + ' inaccessible (HTTP ' + s + ')') : ligne('ko', '/' + u + ' est ACCESSIBLE (HTTP ' + s + ')', 'Fichier sensible exposé : vérifiez que .htaccess est bien en place (fichiers cachés !).');
    });
  });
  suite = suite.then(function () { return fetch('diagnostic.php?cle=' + encodeURIComponent(cle) + '&action=creer', {cache: 'no-store'}).then(function (r) { return r.text(); }); })
    .then(function () { return statut('uploads/produits/diag-exec-test.php').then(function (r) { return r ? r.text().then(function (t) { return [r.status, t]; }) : [0, '']; }); })
    .then(function (x) { (x[1].indexOf('SCRIPT-EXECUTE') === -1) ? ligne('ok', 'Un script déposé dans uploads/ ne s\'exécute PAS (HTTP ' + x[0] + ')') : ligne('ko', 'Un script déposé dans uploads/ S\'EXÉCUTE !', 'uploads/.htaccess n\'est pas pris en compte : n\'ouvrez PAS ce site aux vendeurs.'); })
    .then(function () { return fetch('diagnostic.php?cle=' + encodeURIComponent(cle) + '&action=supprimer', {cache: 'no-store'}).then(function (r) { return r.text(); }); })
    .then(function (t) { if (t !== 'ok') ligne('warn', 'Fichier de test non supprimé : effacez uploads/produits/diag-exec-test.php à la main'); })
    .then(function () { return fetch(base, {credentials: 'same-origin', cache: 'no-store'}); })
    .then(function (r) {
      var h = function (n) { return r.headers.get(n); };
      ligne(r.status === 200 ? 'ok' : 'ko', 'Page d\'accueil : HTTP ' + r.status);
      var csp = h('Content-Security-Policy') || '';
      ligne(csp && !/https?:\/\//.test(csp) ? 'ok' : 'ko', csp ? 'Politique de sécurité (CSP) présente, sans domaine externe' : 'Politique de sécurité (CSP) ABSENTE');
      ligne(h('X-Frame-Options') && h('X-Content-Type-Options') ? 'ok' : 'ko', 'En-têtes anti-clickjacking / nosniff ' + (h('X-Frame-Options') && h('X-Content-Type-Options') ? 'présents' : 'ABSENTS'));
      <?php if (in_array($appEnv, ['test', 'prod'], true)): ?>
      ligne(h('Strict-Transport-Security') ? 'ok' : 'warn', h('Strict-Transport-Security') ? 'HSTS actif' : 'HSTS absent', 'Normal si PHP ne voit pas le HTTPS (voir section 2).');
      <?php endif; ?>
      <?php if ($appEnv === 'test'): ?>
      ligne(/noindex/.test(h('X-Robots-Tag') || '') ? 'ok' : 'ko', 'Indexation par les moteurs de recherche interdite (X-Robots-Tag)');
      <?php endif; ?>
      return r.text();
    })
    .then(function (html) {
      var ext = html.match(/<(?:script|link|img)\b[^>]*\b(?:src|href)=["'](?:https?:)?\/\/[^"']+/gi) || [];
      ligne(ext.length === 0 ? 'ok' : 'ko', ext.length === 0 ? 'Aucune ressource externe (CDN) sur la page d\'accueil' : 'Ressources externes détectées : ' + ext.slice(0, 3).join(' | '));
      return Promise.all(['assets/vendor/js/gsap.min.js', 'assets/vendor/fonts/satoshi-400.woff2', 'assets/css/style.css'].map(function (u) { return statut(u).then(function (r) { return [u, r ? r.status : 0, r ? r.headers.get('Content-Type') : '']; }); }));
    })
    .then(function (liste) { liste.forEach(function (x) { ligne(x[1] === 200 ? 'ok' : 'ko', '/' + x[0] + ' servi (HTTP ' + x[1] + ', ' + (x[2] || 'type inconnu') + ')'); }); })
    .then(function () { return fetch(base + 'robots.txt', {cache: 'no-store'}).then(function (r) { return r.text(); }); })
    .then(function (t) { ligne(/Disallow:/.test(t) ? 'ok' : 'warn', 'robots.txt : ' + t.split('\n').slice(0, 2).join(' / ')); })
    .catch(function (e) { ligne('ko', 'Contrôle interrompu : ' + e); });
  document.getElementById('copier').onclick = function () { navigator.clipboard.writeText(rapport.textContent).then(function () { document.getElementById('copier').textContent = 'Copié ✔'; }); };
})();
</script>
<p><b>N'oubliez pas :</b> supprimez <code>diagnostic.php</code> du serveur et la ligne <code>DIAGNOSTIC_CLE</code> de <code>.env</code> quand vous avez fini.</p>
</body></html>
