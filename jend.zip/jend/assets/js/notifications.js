// « Être prévenu des commandes » : notifications sur le téléphone, même quand Jënd est fermé (includes/push.php, sw.js).
(function () {
  var bloc = document.querySelector('[data-push]');
  if (!bloc) return;
  var base = (document.querySelector('meta[name="base"]') || {}).content || '/';
  var off = bloc.querySelector('.push-off'), on = bloc.querySelector('.push-on'), info = bloc.querySelector('[data-push-info]');
  var activer = bloc.querySelector('[data-push-activer]'), tester = bloc.querySelector('[data-push-tester]');

  function dire(texte) { info.textContent = texte; info.hidden = !texte; }
  function etat(actif) { off.hidden = actif; on.hidden = !actif; bloc.hidden = false; }
  function cle(b64) {
    var pad = '='.repeat((4 - b64.length % 4) % 4), brut = atob((b64 + pad).replace(/-/g, '+').replace(/_/g, '/'));
    var tab = new Uint8Array(brut.length);
    for (var i = 0; i < brut.length; i++) tab[i] = brut.charCodeAt(i);
    return tab;
  }
  function envoyer(action, abo) {
    var d = new FormData();
    d.append('csrf', bloc.getAttribute('data-csrf'));
    d.append('action', action);
    if (abo) {
      var j = abo.toJSON();
      d.append('endpoint', j.endpoint);
      d.append('p256dh', (j.keys || {}).p256dh || '');
      d.append('auth', (j.keys || {}).auth || '');
    }
    return fetch(base + 'notifications/push', { method: 'POST', body: d, credentials: 'same-origin' }).then(function (r) { return r.json(); });
  }

  var ios = /iPad|iPhone|iPod/.test(navigator.userAgent);
  var installe = window.matchMedia && window.matchMedia('(display-mode: standalone)').matches || navigator.standalone === true;
  if (!('serviceWorker' in navigator) || !('PushManager' in window) || !('Notification' in window)) {
    etat(false);
    activer.hidden = true;
    dire(ios && !installe
      ? 'Sur iPhone : touchez le bouton Partager, puis « Sur l\'écran d\'accueil ». Ouvrez ensuite Jënd depuis la nouvelle icône pour activer les notifications.'
      : 'Ce navigateur ne permet pas les notifications. Utilisez Chrome sur votre téléphone, ou surveillez vos e-mails.');
    return;
  }

  var BLOQUE = 'Les notifications sont bloquées pour Jënd : autorisez-les dans les réglages du navigateur (cadenas à côté de l\'adresse), puis touchez Activer.';
  var enregistrement = navigator.serviceWorker.register(base + 'sw.js', { scope: base }).then(function () { return navigator.serviceWorker.ready; });
  enregistrement.then(function (reg) { return reg.pushManager.getSubscription(); }).then(function (abo) {
    if (abo && Notification.permission === 'granted') {
      etat(true);
      envoyer('abonner', abo).catch(function () {});        // garde le serveur à jour (compte qui a changé, clés renouvelées)
    } else {
      etat(false);
      if (Notification.permission === 'denied') dire(BLOQUE);
    }
  }).catch(function () {
    etat(false);
    dire(Notification.permission === 'denied' ? BLOQUE : 'Les notifications ne peuvent pas démarrer sur ce navigateur. Essayez avec Chrome, ou surveillez vos e-mails.');
  });

  activer.addEventListener('click', function () {
    activer.disabled = true;
    dire('');
    Notification.requestPermission().then(function (p) {
      if (p !== 'granted') throw new Error('refus');
      return enregistrement;
    }).then(function (reg) {
      return reg.pushManager.getSubscription().then(function (ancien) {
        return ancien || reg.pushManager.subscribe({ userVisibleOnly: true, applicationServerKey: cle(bloc.getAttribute('data-push')) });
      });
    }).then(function (abo) {
      return envoyer('abonner', abo);
    }).then(function (rep) {
      if (!rep.ok) throw new Error(rep.message || 'erreur');
      etat(true);
      dire('C\'est activé ! Touchez « Tester » pour entendre une notification.');
    }).catch(function (e) {
      dire(e && e.message === 'refus'
        ? 'Vous avez refusé. Pour changer d\'avis : réglages du navigateur → Notifications → autoriser Jënd.'
        : 'L\'activation n\'a pas marché. Vérifiez votre connexion et réessayez.');
    }).then(function () { activer.disabled = false; });
  });

  tester.addEventListener('click', function () {
    tester.disabled = true;
    envoyer('tester').then(function (rep) { dire(rep.ok ? 'Notification envoyée : elle arrive dans quelques secondes.' : (rep.message || 'Échec.')); })
      .catch(function () { dire('Pas de connexion : réessayez.'); })
      .then(function () { setTimeout(function () { tester.disabled = false; }, 3000); });
  });
})();
