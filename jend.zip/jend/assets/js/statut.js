// « Images pour mon statut » : dessine dans le navigateur une image 1080 × 1920 (statut WhatsApp / TikTok) pour un produit.
// Rien n'est envoyé au serveur : la photo du produit est déjà sur le site, l'image est créée ici puis partagée ou téléchargée.
(function () {
  var choix = document.querySelectorAll('.statut-choix');
  if (!choix.length) return;
  var apercu = document.getElementById('statut-image');
  var actions = document.getElementById('statut-actions');
  var vide = document.getElementById('statut-vide');
  var aide = document.getElementById('statut-aide');
  var btnPartager = document.getElementById('statut-partager');
  var lienTelecharger = document.getElementById('statut-telecharger');
  var btnCopier = document.getElementById('statut-copier');
  var C = { terre: '#C2471F', vert: '#0F3D2E', creme: '#FAF3E7', safran: '#F2B632', encre: '#1B1410', doux: '#6B5B4E' };
  var W = 1080, H = 1920;
  var fichierCourant = null, urlCourante = null, lienCourant = '';

  function chargerImage(src) {
    return new Promise(function (ok) {
      if (!src) return ok(null);
      var img = new Image();
      img.onload = function () { ok(img); };
      img.onerror = function () { ok(null); };
      img.src = src;
    });
  }
  function polices() {
    if (!document.fonts || !document.fonts.load) return Promise.resolve();
    return Promise.all([
      document.fonts.load('700 96px "Clash Display"'), document.fonts.load('600 64px "Clash Display"'),
      document.fonts.load('500 40px "Satoshi"'), document.fonts.load('700 40px "Satoshi"')
    ]).catch(function () {});
  }
  function arrondi(ctx, x, y, w, h, r) {
    ctx.beginPath();
    ctx.moveTo(x + r, y); ctx.arcTo(x + w, y, x + w, y + h, r); ctx.arcTo(x + w, y + h, x, y + h, r);
    ctx.arcTo(x, y + h, x, y, r); ctx.arcTo(x, y, x + w, y, r); ctx.closePath();
  }
  function lignes(ctx, texte, largeur, max) {
    var mots = texte.split(/\s+/), res = [], ligne = '';
    mots.forEach(function (m) {
      var essai = ligne ? ligne + ' ' + m : m;
      if (ctx.measureText(essai).width > largeur && ligne) { res.push(ligne); ligne = m; } else { ligne = essai; }
    });
    if (ligne) res.push(ligne);
    if (res.length > max) { res = res.slice(0, max); res[max - 1] = res[max - 1].replace(/\s*\S*$/, '') + '…'; }
    return res;
  }
  // Choisit la plus grande taille de police (de « taille » à « min ») pour que le texte tienne dans « largeur »
  function ajuster(ctx, texte, style, taille, famille, largeur, min) {
    for (var t = taille; t > min; t -= 2) {
      ctx.font = style + ' ' + t + 'px ' + famille;
      if (ctx.measureText(texte).width <= largeur) return t;
    }
    ctx.font = style + ' ' + min + 'px ' + famille;
    return min;
  }
  function couvrir(ctx, img, x, y, w, h) {
    var r = Math.max(w / img.width, h / img.height), sw = w / r, sh = h / r;
    ctx.drawImage(img, (img.width - sw) / 2, (img.height - sh) / 2, sw, sh, x, y, w, h);
  }

  function dessiner(d, photo) {
    var cv = document.createElement('canvas'); cv.width = W; cv.height = H;
    var ctx = cv.getContext('2d');
    ctx.fillStyle = C.creme; ctx.fillRect(0, 0, W, H);

    // Bandeau du haut
    ctx.fillStyle = C.vert; ctx.fillRect(0, 0, W, 170);
    ctx.font = '700 84px "Clash Display", sans-serif'; ctx.textBaseline = 'middle';
    ctx.fillStyle = C.creme; ctx.fillText('Jënd', 70, 90);
    var lg = ctx.measureText('Jënd').width; ctx.fillStyle = C.terre; ctx.fillText('.', 70 + lg, 90);
    ctx.font = '700 34px "Satoshi", sans-serif'; ctx.fillStyle = C.safran; ctx.textAlign = 'right';
    ctx.fillText('Paiement protégé', W - 70, 90); ctx.textAlign = 'left';

    // Photo
    var px = 80, py = 240, pw = W - 160, ph = 900;
    ctx.save(); arrondi(ctx, px, py, pw, ph, 48); ctx.clip();
    if (photo) { couvrir(ctx, photo, px, py, pw, ph); } else {
      ctx.fillStyle = C.terre; ctx.fillRect(px, py, pw, ph);
      ctx.fillStyle = 'rgba(250, 243, 231, .22)'; ctx.font = '700 260px "Clash Display", sans-serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      ctx.fillText('Jënd', W / 2, py + ph / 2); ctx.textAlign = 'left'; ctx.textBaseline = 'alphabetic';
    }
    ctx.restore();
    ctx.lineWidth = 6; ctx.strokeStyle = C.encre; arrondi(ctx, px, py, pw, ph, 48); ctx.stroke();

    // Nom du produit
    ctx.textBaseline = 'alphabetic'; ctx.fillStyle = C.encre; ctx.font = '600 68px "Clash Display", sans-serif';
    var y = 1250;
    lignes(ctx, d.nom, W - 160, 2).forEach(function (l) { ctx.fillText(l, 80, y); y += 80; });

    // Prix (l'ancien prix barré se place à droite s'il tient, sinon en dessous)
    y += 30;
    ajuster(ctx, d.prix, '700', 96, '"Clash Display", sans-serif', W - 240, 60);
    var tw = ctx.measureText(d.prix).width;
    ctx.fillStyle = C.terre; arrondi(ctx, 70, y - 90, tw + 70, 125, 24); ctx.fill();
    ctx.fillStyle = '#FFFFFF'; ctx.fillText(d.prix, 105, y + 8);
    var yBoutique = y + 110;
    if (d.prixBarre) {
      ctx.font = '500 48px "Satoshi", sans-serif'; ctx.fillStyle = C.doux;
      var bw = ctx.measureText(d.prixBarre).width, bx = 70 + tw + 110, by = y - 4;
      if (bx + bw > W - 80) { bx = 80; by = y + 100; yBoutique = y + 175; }
      ctx.fillText(d.prixBarre, bx, by); ctx.fillRect(bx, by - 16, bw, 4);
    }
    ctx.fillStyle = C.doux;
    ajuster(ctx, 'chez ' + d.boutique, '500', 42, '"Satoshi", sans-serif', W - 160, 28);
    ctx.fillText('chez ' + d.boutique, 80, yBoutique);

    // Pied : comment commander
    ctx.fillStyle = C.vert; ctx.fillRect(0, H - 300, W, 300);
    ctx.fillStyle = C.safran; ctx.fillRect(0, H - 300, W, 10);
    ctx.fillStyle = C.creme; ctx.font = '700 44px "Satoshi", sans-serif';
    ctx.fillText('Commandez en toute sécurité sur', 80, H - 210);
    var court = d.lien.replace(/^https?:\/\/(www\.)?/, '');
    ctx.fillStyle = C.safran; ajuster(ctx, court, '600', 50, '"Clash Display", sans-serif', W - 160, 26);
    ctx.fillText(court, 80, H - 135);
    ctx.fillStyle = '#CFE3D7'; ajuster(ctx, 'Argent protégé jusqu\'à la réception · Wave · Orange Money', '500', 34, '"Satoshi", sans-serif', W - 160, 24);
    ctx.fillText('Argent protégé jusqu\'à la réception · Wave · Orange Money', 80, H - 65);
    return cv;
  }

  function creer(bouton) {
    var d = { nom: bouton.dataset.nom, prix: bouton.dataset.prix, prixBarre: bouton.dataset.prixBarre, boutique: bouton.dataset.boutique, lien: bouton.dataset.lien };
    choix.forEach(function (b) { b.classList.toggle('actif', b === bouton); });
    vide.textContent = 'Préparation de l\'image…'; vide.hidden = false;
    Promise.all([polices(), chargerImage(bouton.dataset.image)]).then(function (r) {
      dessiner(d, r[1]).toBlob(function (blob) {
        if (!blob) { vide.textContent = 'Impossible de créer l\'image sur ce navigateur.'; return; }
        if (urlCourante) URL.revokeObjectURL(urlCourante);
        urlCourante = URL.createObjectURL(blob);
        fichierCourant = new File([blob], bouton.dataset.fichier, { type: 'image/png' });
        lienCourant = d.lien;
        apercu.src = urlCourante; apercu.hidden = false; vide.hidden = true;
        lienTelecharger.href = urlCourante; lienTelecharger.setAttribute('download', bouton.dataset.fichier);
        btnPartager.hidden = !(navigator.canShare && navigator.canShare({ files: [fichierCourant] }));
        actions.hidden = false; aide.hidden = false;
        if (window.matchMedia('(max-width: 860px)').matches) apercu.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }, 'image/png');
    });
  }

  choix.forEach(function (b) { b.addEventListener('click', function () { creer(b); }); });
  btnPartager.addEventListener('click', function () {
    if (!fichierCourant) return;
    navigator.share({ files: [fichierCourant], text: lienCourant }).catch(function () {});
  });
  btnCopier.addEventListener('click', function () {
    if (!lienCourant) return;
    var fini = function () { btnCopier.innerHTML = '<i class="ph ph-check"></i> Lien copié'; setTimeout(function () { btnCopier.innerHTML = '<i class="ph ph-link"></i> Copier le lien du produit'; }, 2000); };
    if (navigator.clipboard) { navigator.clipboard.writeText(lienCourant).then(fini, function () { window.prompt('Copiez ce lien :', lienCourant); }); }
    else { window.prompt('Copiez ce lien :', lienCourant); }
  });
})();
