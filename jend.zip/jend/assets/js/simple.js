// Mode simple de l'espace vendeur : aperçu des photos, prix lisible (« 5 000 »), boutons « − » / « + », aide audio.
(function () {
  // Aide audio : un bouton joue (ou arrête) le message enregistré de la page
  document.querySelectorAll('[data-aide]').forEach(function (btn) {
    var son = document.getElementById(btn.getAttribute('data-aide'));
    if (!son) return;
    btn.addEventListener('click', function () {
      if (son.paused) { son.currentTime = 0; son.play(); btn.classList.add('en-cours'); } else { son.pause(); btn.classList.remove('en-cours'); }
    });
    son.addEventListener('ended', function () { btn.classList.remove('en-cours'); });
  });

  // Photos : aperçu immédiat de chaque photo choisie ou prise
  var apercus = document.getElementById('simple-apercus');
  function montrer() {
    if (!apercus) return;
    apercus.innerHTML = '';
    document.querySelectorAll('.simple-photo-champ').forEach(function (champ) {
      Array.prototype.forEach.call(champ.files || [], function (f) {
        var img = document.createElement('img');
        img.alt = '';
        img.src = URL.createObjectURL(f);
        apercus.appendChild(img);
      });
    });
    apercus.classList.toggle('plein', apercus.children.length > 0);
  }
  document.querySelectorAll('.simple-photo-champ').forEach(function (c) { c.addEventListener('change', montrer); });

  // Prix : espaces entre les milliers pendant la saisie (le serveur ne garde que les chiffres)
  var prix = document.querySelector('.simple-prix input');
  if (prix) {
    prix.addEventListener('input', function () {
      var c = prix.value.replace(/\D/g, '').slice(0, 9);
      prix.value = c.replace(/\B(?=(\d{3})+(?!\d))/g, ' ');
    });
  }

  // Quantité : « − » et « + »
  document.querySelectorAll('.simple-compteur').forEach(function (bloc) {
    var champ = bloc.querySelector('input');
    if (!champ) return;
    function changer(d) {
      var n = parseInt(champ.value.replace(/\D/g, ''), 10) || 0;
      champ.value = String(Math.max(1, Math.min(100000, n + d)));
    }
    var moins = bloc.querySelector('.simple-moins'), plus = bloc.querySelector('.simple-plus');
    if (moins) moins.addEventListener('click', function () { changer(-1); });
    if (plus) plus.addEventListener('click', function () { changer(1); });
  });

  // Avant l'envoi : ce qui manque est montré en grand (les photos choisies ne sont pas perdues)
  var form = document.querySelector('.simple-form');
  if (form) {
    form.addEventListener('submit', function (ev) {
      var manque = null, cible = null;
      var nbPhotos = 0;
      form.querySelectorAll('.simple-photo-champ').forEach(function (c) { nbPhotos += (c.files || []).length; });
      if (!nbPhotos) { manque = 'Ajoutez une photo.'; cible = form.querySelector('.simple-photo-choix'); }
      else if (!form.querySelector('input[name="categorie_id"]:checked')) { manque = 'Touchez l\'image de ce que vous vendez.'; cible = form.querySelector('.simple-categories'); }
      else if ((parseInt((prix && prix.value || '').replace(/\D/g, ''), 10) || 0) < 100) { manque = 'Écrivez le prix.'; cible = prix; }
      if (!manque) return;
      ev.preventDefault();
      var msg = form.querySelector('.simple-erreur');
      if (!msg) {
        msg = document.createElement('p');
        msg.className = 'simple-erreur';
        msg.setAttribute('role', 'alert');
        form.insertBefore(msg, form.children[1]);
      }
      msg.innerHTML = '<i class="ph-fill ph-warning-circle"></i> <span></span>';
      msg.querySelector('span').textContent = manque;
      if (cible) { cible.scrollIntoView({ block: 'center' }); cible.classList.add('simple-manque'); setTimeout(function () { cible.classList.remove('simple-manque'); }, 1600); }
    });
  }

  // Mes produits : « − », « + », retirer, remettre en vente sans recharger la page.
  // Le chiffre change tout de suite ; les envois partent l'un après l'autre et le serveur donne le chiffre final.
  document.querySelectorAll('[data-produit]').forEach(function (carte) {
    var file = Promise.resolve();
    var nombre = carte.querySelector('.simple-stock');
    var moins = carte.querySelector('button[value="moins"]');
    function afficher(stock) {
      if (!nombre || stock === null || stock === undefined) return;
      nombre.textContent = String(stock);
      nombre.classList.toggle('simple-zero', stock === 0);
      if (moins) moins.disabled = stock === 0;
    }
    function etat(enVente) {
      carte.classList.toggle('simple-produit-retire', !enVente);
      var lbl = carte.querySelector('.simple-etat');
      if (lbl) lbl.innerHTML = enVente ? '<i class="ph-fill ph-check-circle"></i> En vente' : '<i class="ph-fill ph-pause-circle"></i> Pas en vente';
      var b = carte.querySelector('.simple-produit-action button');
      if (b) {
        b.value = enVente ? 'retirer' : 'vendre';
        b.className = 'simple-petit-btn' + (enVente ? '' : ' simple-petit-btn-vert');
        b.innerHTML = enVente ? '<i class="ph ph-pause"></i> Retirer' : '<i class="ph ph-play"></i> Remettre en vente';
      }
    }
    function signaler(msg) {
      var p = carte.querySelector('.simple-carte-msg');
      if (!p) { p = document.createElement('p'); p.className = 'simple-carte-msg'; p.setAttribute('role', 'alert'); carte.appendChild(p); }
      p.textContent = msg;
      setTimeout(function () { if (p.parentNode) p.parentNode.removeChild(p); }, 4000);
    }
    carte.querySelectorAll('form').forEach(function (form) {
      form.addEventListener('submit', function (ev) {
        var bouton = ev.submitter || form.querySelector('button');
        if (!bouton || !window.fetch || !window.FormData) return;          // sans fetch : envoi classique (la page se recharge)
        ev.preventDefault();
        var action = bouton.value;
        var donnees = new FormData(form);
        donnees.set('action', action);
        if (nombre && (action === 'plus' || action === 'moins')) {
          afficher(Math.max(0, (parseInt(nombre.textContent, 10) || 0) + (action === 'plus' ? 1 : -1)));
        }
        if (action === 'retirer' || action === 'vendre') etat(action === 'vendre');
        file = file.then(function () {
          return fetch(form.getAttribute('action') || location.pathname, { method: 'POST', body: donnees, credentials: 'same-origin', headers: { 'X-Requested-With': 'fetch' } })
            .then(function (r) { return r.json(); })
            .then(function (j) {
              afficher(j.stock);
              if (j.en_vente !== null && j.en_vente !== undefined) etat(j.en_vente);
              if (!j.ok) signaler(j.message || 'Erreur, réessayez.');
            })
            .catch(function () { signaler('Pas de connexion : réessayez.'); });
        });
      });
    });
  });
})();

