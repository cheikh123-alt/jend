// Fiche produit (vendeur) : enregistrer une description vocale avec le micro du téléphone (1 minute maximum).
// L'enregistrement est placé dans le champ fichier « voix » du formulaire : il part avec le produit, comme une photo.
(function () {
  var bloc = document.getElementById('voix-bloc');
  if (!bloc || !window.MediaRecorder || !navigator.mediaDevices || !window.DataTransfer) return;   // sinon : seul le choix de fichier reste
  var zone = bloc.querySelector('.voix-enregistreur');
  var demarrer = document.getElementById('voix-demarrer'), arreter = document.getElementById('voix-arreter');
  var chrono = document.getElementById('voix-chrono'), apercu = document.getElementById('voix-apercu');
  var fichier = document.getElementById('voix-fichier'), aide = document.getElementById('voix-aide');
  var MAX = 60, enreg = null, morceaux = [], minuteur = null, secondes = 0, flux = null;
  zone.hidden = false;

  function format() {
    var types = ['audio/webm;codecs=opus', 'audio/webm', 'audio/mp4', 'audio/ogg;codecs=opus'];
    for (var i = 0; i < types.length; i++) { if (MediaRecorder.isTypeSupported && MediaRecorder.isTypeSupported(types[i])) return types[i]; }
    return '';
  }
  function finir() {
    clearInterval(minuteur);
    if (enreg && enreg.state !== 'inactive') enreg.stop();
    if (flux) flux.getTracks().forEach(function (t) { t.stop(); });
    arreter.hidden = true; demarrer.hidden = false;
  }
  demarrer.addEventListener('click', function () {
    navigator.mediaDevices.getUserMedia({ audio: true }).then(function (s) {
      flux = s; morceaux = []; secondes = 0; chrono.textContent = '0';
      var type = format();
      enreg = type ? new MediaRecorder(s, { mimeType: type, audioBitsPerSecond: 48000 }) : new MediaRecorder(s);
      enreg.ondataavailable = function (e) { if (e.data && e.data.size) morceaux.push(e.data); };
      enreg.onstop = function () {
        var mime = (enreg.mimeType || 'audio/webm').split(';')[0];
        var ext = mime.indexOf('mp4') > -1 ? 'm4a' : (mime.indexOf('ogg') > -1 ? 'ogg' : 'webm');
        var blob = new Blob(morceaux, { type: mime });
        var dt = new DataTransfer();
        dt.items.add(new File([blob], 'description-vocale.' + ext, { type: mime }));
        fichier.files = dt.files;
        apercu.src = URL.createObjectURL(blob); apercu.hidden = false;
        aide.textContent = 'Enregistrement prêt (' + secondes + ' s) : écoutez-le, puis enregistrez le produit. Vous pouvez recommencer.';
        demarrer.innerHTML = '<i class="ph ph-arrow-counter-clockwise"></i> Recommencer';
      };
      enreg.start();
      demarrer.hidden = true; arreter.hidden = false;
      minuteur = setInterval(function () { secondes++; chrono.textContent = String(secondes); if (secondes >= MAX) finir(); }, 1000);
    }).catch(function () {
      aide.textContent = 'Micro refusé ou indisponible : autorisez le micro pour ce site, ou choisissez un fichier audio.';
    });
  });
  arreter.addEventListener('click', finir);
})();
