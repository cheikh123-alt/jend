// Suivi de livraison : pendant que le livreur est en route, la page se met à jour toute seule (toutes les 45 s, onglet visible).
const zone = document.querySelector('[data-rafraichir]');
if (zone) {
  const delai = (parseInt(zone.dataset.rafraichir, 10) || 45) * 1000;
  setInterval(() => { if (!document.hidden) location.reload(); }, delai);
}
