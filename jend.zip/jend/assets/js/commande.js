// Page « Finaliser ma commande » : frais et total qui suivent la zone choisie, et adresses enregistrées.
// (le serveur recalcule TOUT à la validation : ces valeurs ne servent qu'à l'affichage)
(function () {
  var form = document.querySelector('form[data-sous-total]');
  var zone = document.getElementById('zone');
  if (!form || !zone) return;

  var frais = document.getElementById('frais');
  var total = document.getElementById('total');
  var sousTotal = parseInt(form.dataset.sousTotal, 10) || 0;
  var saved = document.getElementById('adresses-enregistrees');

  function fmt(n) { return n.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ' ') + ' FCFA'; }

  if (saved) saved.addEventListener('change', function () {
    var o = saved.options[saved.selectedIndex];
    if (!o.dataset.zone) return;
    zone.value = o.dataset.zone;
    document.querySelector('[name=adresse]').value = o.dataset.adresse;
    document.querySelector('[name=telephone]').value = o.dataset.tel;
    var la = document.getElementById('pos-lat'), lo = document.getElementById('pos-lng');
    if (la && lo) { la.value = o.dataset.lat || ''; lo.value = o.dataset.lng || ''; afficherPosition(!!o.dataset.lat); }
    zone.dispatchEvent(new Event('change'));
  });

  // « Ma position » : coordonnées GPS du téléphone (le serveur vérifie qu'elles sont au Sénégal)
  var posBouton = document.getElementById('pos-bouton'), posEtat = document.getElementById('pos-etat');
  function afficherPosition(ok, precision) {
    if (!posEtat) return;
    posEtat.textContent = ok ? 'Position enregistrée' + (precision ? ' (précision ± ' + Math.round(precision) + ' m)' : '') + ' : le livreur aura l\'itinéraire exact.' : posEtat.textContent;
    posEtat.classList.toggle('pos-ok', !!ok);
  }
  if (posBouton) {
    if (!navigator.geolocation) { posBouton.hidden = true; }
    posBouton.addEventListener('click', function () {
      posEtat.textContent = 'Recherche de votre position…';
      navigator.geolocation.getCurrentPosition(function (p) {
        document.getElementById('pos-lat').value = p.coords.latitude.toFixed(6);
        document.getElementById('pos-lng').value = p.coords.longitude.toFixed(6);
        afficherPosition(true, p.coords.accuracy);
      }, function (err) {
        posEtat.textContent = err.code === 1 ? 'Position refusée : autorisez la localisation pour ce site, ou décrivez bien l\'adresse.' : 'Position introuvable pour le moment. Réessayez dehors ou près d\'une fenêtre.';
      }, { enableHighAccuracy: true, timeout: 20000, maximumAge: 60000 });
    });
  }

  zone.addEventListener('change', function () {
    var opt = zone.options[zone.selectedIndex];
    var f = opt.dataset.frais ? parseInt(opt.dataset.frais, 10) : 0;
    var s = opt.dataset.service ? parseInt(opt.dataset.service, 10) : 0;
    var service = document.getElementById('service');
    frais.textContent = opt.value ? fmt(f) : 'à choisir';
    if (service && opt.value) service.textContent = fmt(s);
    total.textContent = fmt(sousTotal + f + (service ? s : 0));
  });
})();
