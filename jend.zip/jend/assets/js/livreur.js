// Appli livreur : installation (service worker), nouvelles courses en direct, copie d'adresse, confirmations, anti double-clic.
const base = document.querySelector('meta[name="base"]')?.content || '/';
const toast = (texte, lien) => {
  const t = document.getElementById('toast');
  if (!t) return;
  t.textContent = texte + ' ';
  if (lien) { const a = document.createElement('a'); a.href = lien; a.textContent = 'Voir'; t.appendChild(a); }
  t.hidden = false;
  clearTimeout(toast.minuteur);
  toast.minuteur = setTimeout(() => { t.hidden = true; }, 6000);
};

if ('serviceWorker' in navigator) {
  navigator.serviceWorker.register(base + 'sw.js', { scope: base }).catch(() => {});
}

// Copier l'adresse
document.addEventListener('click', async e => {
  const b = e.target.closest('[data-copier]');
  if (!b) return;
  try { await navigator.clipboard.writeText(b.dataset.copier); toast('Adresse copiée'); } catch { toast('Copie impossible : sélectionnez l\'adresse à la main'); }
});

// Le code de livraison : chiffres seulement
document.querySelectorAll('.saisie-code').forEach(i => i.addEventListener('input', () => { i.value = i.value.replace(/\D/g, '').slice(0, 4); }));

// Confirmation (data-confirm) et anti double-clic : le bouton se désactive une fois le formulaire parti
document.addEventListener('submit', e => {
  const f = e.target;
  if (f.dataset && f.dataset.confirm && !confirm(f.dataset.confirm)) { e.preventDefault(); return; }
  setTimeout(() => f.querySelectorAll('button[type="submit"]').forEach(b => { b.disabled = true; b.classList.add('envoi'); }), 0);
});

// Nouvelles courses : on interroge le serveur toutes les 30 s tant que l'appli est visible
const connus = (document.body.dataset.courses || '').split(',').filter(Boolean).map(Number);
async function verifier() {
  if (document.hidden) return;
  try {
    const r = await fetch(base + 'livreur/etat', { headers: { Accept: 'application/json' }, cache: 'no-store', credentials: 'same-origin' });
    if (!r.ok || r.redirected) { clearInterval(minuteur); return; }   // déconnecté : inutile de continuer
    const { ids } = await r.json();
    const nouvelles = ids.filter(i => !connus.includes(i));
    if (nouvelles.length) {
      nouvelles.forEach(i => connus.push(i));
      if (navigator.vibrate) navigator.vibrate([200, 100, 200]);
      const accueil = location.pathname.replace(/\/$/, '') === new URL(base + 'livreur', location.href).pathname;
      if (accueil) { toast('Nouvelle course !'); setTimeout(() => location.reload(), 1200); }
      else toast('Nouvelle course !', base + 'livreur');
    }
  } catch { /* hors connexion : on réessaiera */ }
}
const minuteur = setInterval(verifier, 30000);
document.addEventListener('visibilitychange', verifier);
