// Page relais du paiement : ouvre aussitôt la page (ou l'application) de paiement. Le bouton reste en secours.
(function () {
  var a = document.getElementById('paiement-aller');
  if (a) setTimeout(function () { window.location.href = a.href; }, 300);
})();
