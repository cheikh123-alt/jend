// Favoris : bascule sans recharger la page (le serveur garde l'état)
const meta = n => document.querySelector('meta[name="' + n + '"]')?.content || '';
document.addEventListener('click', async e => {
  const coeur = e.target.closest('.coeur');
  if (!coeur) return;
  if (meta('connecte') !== '1') {
    location.href = meta('base') + 'connexion?retour=' + encodeURIComponent(location.pathname + location.search);
    return;
  }
  coeur.disabled = true;
  try {
    const rep = await fetch(meta('base') + 'favoris/basculer', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({ csrf: meta('csrf'), produit_id: coeur.dataset.id })
    });
    if (rep.ok) {
      const { actif } = await rep.json();
      coeur.classList.toggle('actif', actif);
      coeur.setAttribute('aria-pressed', actif ? 'true' : 'false');
      coeur.querySelector('i').className = (actif ? 'ph-fill' : 'ph') + ' ph-heart';
    }
  } finally {
    coeur.disabled = false;
  }
});

// Copier un texte dans le presse-papiers : <button data-copier="texte">
document.addEventListener('click', async e => {
  const b = e.target.closest('[data-copier]');
  if (!b) return;
  try { await navigator.clipboard.writeText(b.dataset.copier); const t = b.innerHTML; b.textContent = 'Copié !'; setTimeout(() => { b.innerHTML = t; }, 1800); } catch { /* sélection manuelle possible */ }
});

// Confirmation avant les actions sensibles : <form data-confirm="Question ?"> ou <button data-confirm="Question ?">
document.addEventListener('submit', e => {
  const msg = (e.submitter && e.submitter.dataset.confirm) || (e.target.dataset && e.target.dataset.confirm);
  if (msg && !confirm(msg)) e.preventDefault();
});

// Animations (désactivées si l'utilisateur préfère moins de mouvement, ou en mode « économie de données » : bibliothèques non chargées)
const reduit = matchMedia('(prefers-reduced-motion: reduce)').matches;
const leger = document.documentElement.classList.contains('leger');
const mobile = matchMedia('(max-width: 760px)').matches;      // sur téléphone : affichage immédiat, sans animation d'entrée
document.documentElement.classList.remove('sans-js');
if (!leger && !mobile && typeof Splitting === 'function') Splitting();

// (défilement natif du navigateur : plus rapide et plus naturel au doigt qu'un défilement « lissé »)
if (!reduit && !leger && !mobile && window.gsap && window.ScrollTrigger) {
  gsap.registerPlugin(ScrollTrigger);

  // Signature : le titre se révèle lettre par lettre
  gsap.to('.affiche h1 .char', { y: 0, duration: 1, ease: 'power4.out', stagger: .014, delay: .15 });
  gsap.from('.entree-dico, .affiche .intro, .affiche .cta, .mention-livraison', { y: 20, opacity: 0, duration: .8, stagger: .12, delay: .7 });
  gsap.from('.tuile', { y: 50, opacity: 0, rotate: 2, duration: .9, stagger: .09, ease: 'power3.out', delay: .35 });

  gsap.utils.toArray('.titre-section, .carte, .parole li, .registre li').forEach(el => {
    gsap.from(el, { y: 40, opacity: 0, duration: .8, ease: 'power3.out', scrollTrigger: { trigger: el, start: 'top 90%' } });
  });
}

// ---------- Confort sur téléphone ----------
// En-tête : se cache quand on descend (plus de place pour lire), réapparaît dès qu'on remonte
const entete = document.querySelector('.entete');
if (entete && matchMedia('(max-width: 760px)').matches) {
  let dernier = scrollY;
  addEventListener('scroll', () => {          // traitement minuscule : directement à chaque défilement (passif, ne bloque jamais le doigt)
    const y = scrollY;
    if (Math.abs(y - dernier) < 8) return;     // ignore les micro-mouvements
    const saisie = entete.contains(document.activeElement);
    entete.classList.toggle('entete-cachee', !saisie && y > 160 && y > dernier);
    dernier = y;
  }, { passive: true });
}
// Barres d'onglets (espaces vendeur / admin / compte) : une seule ligne qui défile, onglet actif centré
document.querySelectorAll('.onglets').forEach(nav => {
  const actif = nav.querySelector('.actif');
  if (actif && nav.scrollWidth > nav.clientWidth) nav.scrollLeft = actif.offsetLeft - (nav.clientWidth - actif.offsetWidth) / 2;
});
// Catalogue : filtres repliés sur téléphone (sauf si des filtres sont déjà appliqués)
const repli = document.querySelector('.filtres-repli');
if (repli && matchMedia('(max-width: 860px)').matches && !repli.dataset.actifs) repli.removeAttribute('open');
// Bouton « Imprimer / PDF » (relevés) : pas de script dans le HTML, la politique de sécurité l'interdit
document.addEventListener('click', e => { if (e.target.closest('[data-imprimer]')) window.print(); });
// Barres des graphiques (tableau de bord Croissance) : la largeur vient d'un attribut, la politique de sécurité interdisant les styles dans le HTML
document.querySelectorAll('[data-largeur]').forEach(b => { b.style.width = Math.max(0, Math.min(100, parseInt(b.dataset.largeur, 10) || 0)) + '%'; });

// Après « Confirmer et payer » : envoi automatique du formulaire de paiement (vers PayDunya / PayTech). Le bouton reste en secours.
(function () {
  var f = document.querySelector('form[data-envoi-auto]');
  if (!f) return;
  var b = f.querySelector('button');
  if (b) { b.disabled = true; b.textContent = 'Redirection vers le paiement…'; }
  setTimeout(function () { if (b) b.disabled = false; f.submit(); }, 400);
})();

