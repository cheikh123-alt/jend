// Page « Partager ma position » (proche qui reçoit un cadeau) : lit le GPS du téléphone puis envoie le formulaire.
(function () {
  var bouton = document.getElementById('pos-envoyer'), etat = document.getElementById('pos-etat'), form = document.getElementById('form-position');
  if (!bouton || !form) return;
  if (!navigator.geolocation) { etat.textContent = 'Ce téléphone ne permet pas de partager la position : appelez le livreur le jour de la livraison.'; bouton.disabled = true; return; }
  bouton.addEventListener('click', function () {
    bouton.disabled = true; etat.textContent = 'Recherche de votre position…';
    navigator.geolocation.getCurrentPosition(function (p) {
      document.getElementById('pos-lat').value = p.coords.latitude.toFixed(6);
      document.getElementById('pos-lng').value = p.coords.longitude.toFixed(6);
      form.submit();
    }, function (err) {
      bouton.disabled = false;
      etat.textContent = err.code === 1 ? 'Vous avez refusé la localisation. Autorisez-la dans les réglages du navigateur, puis réessayez.' : 'Position introuvable pour le moment. Réessayez dehors ou près d\'une fenêtre.';
    }, { enableHighAccuracy: true, timeout: 20000, maximumAge: 0 });
  });
})();
