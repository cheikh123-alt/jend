// Fiche produit (vendeur) : affiche les tailles ou pointures qui correspondent à la catégorie choisie.
// (le serveur ne lit de toute façon que la grille de la catégorie choisie)
(function () {
  var cat = document.querySelector('select[name=categorie_id]'), bloc = document.getElementById('tailles-bloc');
  if (!cat || !bloc) return;
  var avec = document.getElementById('avec-tailles'), stock = document.querySelector('input[name=stock]'), aide = document.getElementById('stock-tailles');
  function maj() {
    var type = cat.options[cat.selectedIndex] ? cat.options[cat.selectedIndex].dataset.option : '';
    bloc.hidden = !type;
    bloc.querySelectorAll('.tailles-grille').forEach(function (g) { g.hidden = !avec.checked || g.dataset.type !== type; });
    var actif = !!type && avec.checked;
    stock.readOnly = actif; aide.hidden = !actif;
    if (actif) {
      var total = 0;
      bloc.querySelectorAll('.tailles-grille[data-type="' + type + '"] .taille-ligne').forEach(function (l) {
        if (l.querySelector('input[type=checkbox]').checked) total += parseInt(l.querySelector('input[type=number]').value, 10) || 0;
      });
      stock.value = total;
    }
  }
  cat.addEventListener('change', maj); avec.addEventListener('change', maj); bloc.addEventListener('input', maj); bloc.addEventListener('change', maj);
  maj();
})();
