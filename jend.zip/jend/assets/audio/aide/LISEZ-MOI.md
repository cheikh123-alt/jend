# Messages d'aide audio du mode simple

Enregistrez chaque message (en wolof, ou dans la langue de vos vendeurs), puis déposez le fichier ici **sous ce nom exact**.
Formats acceptés : `.mp3`, `.m4a`, `.ogg` ou `.webm` (un message vocal WhatsApp exporté convient).
Dès qu'un fichier est présent, le bouton jaune « 🔊 Écouter » apparaît en haut de la page correspondante. Sans fichier, rien n'est affiché.
Gardez chaque message court : 20 à 40 secondes.

| Fichier | Page | Ce que le message doit expliquer (à dire avec vos mots) |
|---|---|---|
| `accueil.mp3` | Accueil du mode simple | Bienvenue sur Jënd. Le bouton rouge avec l'appareil photo sert à mettre un produit. Le bouton vert montre vos commandes : un chiffre jaune apparaît quand un client a commandé. Le bouton jaune montre votre argent. Le bouton noir montre vos produits. |
| `produit.mp3` | Mettre un produit | 1 : prenez une belle photo du produit, à la lumière. 2 : touchez l'image de ce que vous vendez. 3 : écrivez le prix en chiffres. 4 : avec moins et plus, dites combien vous en avez. 5 : si vous voulez, touchez « Parler » et décrivez le produit avec votre voix. Puis touchez le grand bouton rouge « Mettre en vente ». |
| `produits.mp3` | Mes produits | Voici vos produits. Avec moins et plus, changez la quantité quand vous vendez ou recevez de la marchandise. Touchez « Retirer » si vous n'en avez plus, et « Remettre en vente » quand il revient. |
| `commandes.mp3` | Mes commandes | Chaque carte est une commande d'un client. Si c'est écrit « Attendez », le client n'a pas encore payé : n'envoyez rien. Sinon, préparez le colis et touchez « J'ai envoyé le colis ». Quand vous remettez le colis, demandez au client son code à 4 chiffres, écrivez-le, et touchez « Le client a reçu ». Vous pouvez appeler le client avec le bouton vert. |
| `argent.mp3` | Mon argent | Le grand chiffre, c'est l'argent que Jënd garde pour vous. Il est envoyé sur votre téléphone, Wave ou Orange Money, le jour indiqué. |
