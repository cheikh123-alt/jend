<?php
declare(strict_types=1);

/**
 * Installation de Jënd — à lancer UNE FOIS, en ligne de commande :
 *   php install.php            crée la base, les tables, les catégories, les zones et le compte admin
 *   php install.php --demo     ajoute aussi une boutique et 8 produits de démonstration
 *   php install.php --force    réinstalle en EFFAÇANT les données existantes
 */
if (PHP_SAPI !== 'cli') {
    http_response_code(403);
    exit('Interdit.');
}

require __DIR__ . '/includes/env.php';
require __DIR__ . '/includes/helpers.php';

$demo  = in_array('--demo', $argv, true);
$force = in_array('--force', $argv, true);

$nomBase = env('DB_NAME', 'jend');
if (!preg_match('/^[A-Za-z0-9_]+$/', $nomBase)) {
    exit("DB_NAME invalide dans .env\n");
}
if (!is_file(__DIR__ . '/.env')) {
    exit("Fichier .env introuvable : copiez .env.example en .env puis relancez.\n");
}

try {
    $pdo = new PDO(
        sprintf('mysql:host=%s;port=%s;charset=utf8mb4', env('DB_HOST', '127.0.0.1'), env('DB_PORT', '3306')),
        env('DB_USER', 'root'),
        env('DB_PASS', ''),
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC]
    );
} catch (PDOException $e) {
    exit("Connexion MySQL impossible : {$e->getMessage()}\nVérifiez que MySQL est démarré et que .env est correct.\n");
}

// Sécurité : ne jamais effacer une base qui contient déjà des utilisateurs sans --force
$st = $pdo->prepare("SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = ? AND table_name = 'users'");
$st->execute([$nomBase]);
$schemaExiste = (int) $st->fetchColumn() > 0;

if ($schemaExiste && !$force) {
    $nbUsers = (int) $pdo->query("SELECT COUNT(*) FROM `$nomBase`.users")->fetchColumn();
    if ($nbUsers > 0) {
        exit("La base « $nomBase » contient déjà $nbUsers utilisateur(s). Utilisez --force pour tout effacer et recommencer.\n");
    }
    echo "→ Tables déjà présentes et aucun utilisateur : on les garde, on ajoute seulement les comptes.\n";
    $pdo->exec("USE `$nomBase`");
} else {
    $schemaExiste = false;   // --force ou base absente : (ré)installation complète
}

/** Exécute un fichier .sql instruction par instruction. */
function executer_sql(PDO $pdo, string $fichier, string $nomBase): void
{
    $sql = file_get_contents($fichier);
    $sql = preg_replace('/^\s*--.*$/m', '', $sql);                       // lignes de commentaires
    $sql = preg_replace('/\b(CREATE DATABASE IF NOT EXISTS|USE)\s+jend\b/', '$1 `' . $nomBase . '`', $sql);
    foreach (preg_split('/;\s*(\r?\n|$)/', $sql) as $instruction) {
        if (trim($instruction) !== '') {
            $pdo->exec($instruction);
        }
    }
}

if (!$schemaExiste) {
    echo "→ Création de la base et des tables…\n";
    executer_sql($pdo, __DIR__ . '/database/schema.sql', $nomBase);
    echo "→ Zones de livraison et catégories…\n";
    executer_sql($pdo, __DIR__ . '/database/seed.sql', $nomBase);
}

function mot_de_passe_aleatoire(): string
{
    return rtrim(strtr(base64_encode(random_bytes(12)), '+/', '-_'), '=');
}

function creer_user(PDO $pdo, string $nom, string $email, string $role, string $mdp): int
{
    $pdo->prepare('INSERT INTO users (nom, email, mot_de_passe, role) VALUES (?, ?, ?, ?)')
        ->execute([$nom, $email, password_hash($mdp, PASSWORD_DEFAULT), $role]);
    return (int) $pdo->lastInsertId();
}

// ----- Compte administrateur -----
$mdpAdmin   = mot_de_passe_aleatoire();
$emailAdmin = env('ADMIN_EMAIL', 'admin@jend.local');
creer_user($pdo, env('ADMIN_NOM', 'Administrateur'), $emailAdmin, 'admin', $mdpAdmin);

// ----- Données de démonstration (optionnel) -----
$mdpVendeur = null;
if ($demo) {
    echo "→ Boutique et produits de démonstration…\n";
    $mdpVendeur = mot_de_passe_aleatoire();
    $vendeurId  = creer_user($pdo, 'Vendeur Démo', 'vendeur@jend.local', 'vendeur', $mdpVendeur);
    $pdo->prepare("INSERT INTO boutiques (user_id, nom, slug, description, statut) VALUES (?, 'Marché Démo', 'marche-demo', 'Boutique de démonstration', 'active')")
        ->execute([$vendeurId]);
    $boutiqueId = (int) $pdo->lastInsertId();

    $exemples = [
        // nom, catégorie (slug), prix, prix barré, stock, note, nb avis
        ['Pagne wax premium 6 yards',        'tissus-wax',               18500, 26000, 40, 4.8, 124],
        ['Smartphone 128 Go double SIM',     'telephones',               95000, null,  12, 4.5, 78],
        ['Sac en cuir tressé artisanal',     'artisanat',                22000, null,  15, 4.9, 56],
        ['Bissap séché bio 500 g',           'alimentation',             2500,  null, 200, 4.7, 210],
        ['Écouteurs sans fil',               'accessoires-electronique', 12000, 18000, 60, 4.3, 342],
        ['Beurre de karité pur 250 ml',      'beaute',                   4500,  null,  80, 4.6, 98],
        ['Ensemble boubou brodé homme',      'boubous-tenues',           35000, null,  10, 4.8, 41],
        ['Lampe décorative en calebasse',    'maison',                   14500, null,  18, 4.4, 33],
    ];
    $cat = $pdo->prepare('SELECT id FROM categories WHERE slug = ?');
    $ins = $pdo->prepare(
        "INSERT INTO produits (boutique_id, categorie_id, nom, slug, description, prix, prix_barre, stock, statut, note_moyenne, nb_avis)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'publie', ?, ?)"
    );
    foreach ($exemples as [$nom, $slugCat, $prix, $barre, $stock, $note, $avis]) {
        $cat->execute([$slugCat]);
        $ins->execute([$boutiqueId, (int) $cat->fetchColumn(), $nom, slugify($nom), "Produit de démonstration : $nom.", $prix, $barre, $stock, $note, $avis]);
    }
}

echo "\n✔ Installation terminée.\n\n";
echo "Compte administrateur (notez-le maintenant, il ne sera plus affiché) :\n";
echo "  e-mail       : $emailAdmin\n";
echo "  mot de passe : $mdpAdmin\n";
if ($mdpVendeur !== null) {
    echo "Compte vendeur démo :\n  e-mail       : vendeur@jend.local\n  mot de passe : $mdpVendeur\n";
}
echo "\nChangez ces mots de passe dès la connexion, et supprimez install.php en production.\n";
