# Jënd — Cahier des charges

**Jënd** (« acheter » en wolof) : marketplace sénégalaise, multi-vendeurs, multi-catégories.

## Marché
- Sénégal, prix en FCFA, français (wolof plus tard), livraison par zone (Dakar d'abord).

## Rôles
- **Client** : parcourt, achète, suit ses commandes, laisse des avis.
- **Vendeur** : s'inscrit, publie ses produits, gère stocks et commandes, voit ses gains.
- **Admin** : valide les vendeurs et produits, gère catégories, litiges, commissions.

## Paiements (via agrégateur type PayDunya / CinetPay)
- Wave, Orange Money, Free Money
- Carte bancaire
- Paiement à la livraison

## Stack
- PHP 8 + MySQL (PDO), HTML/CSS/JS sur mesure, sans Bootstrap.

## Identité visuelle
| Rôle | Couleur |
|---|---|
| Primaire (terracotta) | `#C2471F` |
| Vert profond | `#0F3D2E` |
| Fond crème | `#FAF3E7` |
| Accent safran | `#F2B632` |
| Encre (texte) | `#1B1410` |

- Titres : **Clash Display** — Texte : **Satoshi** (Fontshare)
- Icônes : Phosphor
- Effet signature : texte du hero révélé mot à mot (Splitting + GSAP) + curseur personnalisé
- Animations : GSAP/ScrollTrigger, défilement fluide Lenis, `prefers-reduced-motion` respecté

## Feuille de route
1. Cadrage ✅
2. Design (charte + maquette accueil) ✅
3. Base de données MySQL ✅ (database/schema.sql + seed.sql)
4. Structure PHP (PDO, templates, routeur) ✅
5. Catalogue (liste, filtres, recherche, fiche produit) ✅
6. Panier et commande ✅ (+ inscription/connexion de base)
7. Comptes clients ✅ (adresses, profil, favoris, avis, annulation, mot de passe oublié)
8. Paiement ✅ (mode simulation : fausse page + webhook signé ; fournisseur réel à brancher)
9. Espace vendeur + admin
10. Sécurité et mise en ligne ✅ (audit, limites par IP, CSP, HTTPS, SMTP, 2FA, code de livraison, alertes, sauvegardes chiffrées, vérificateur — voir AUDIT_SECURITE.md et DEPLOIEMENT.md)
