// Données de démonstration — remplacées par PHP/MySQL à l'étape 5
const produits = [
  { nom: 'Pagne wax premium 6 yards', vendeur: 'Maison Aïssatou', prix: 18500, ancien: 26000, note: 4.8, avis: 124, icone: 'ph-t-shirt', couleur: '#C2471F' },
  { nom: 'Smartphone 128 Go double SIM', vendeur: 'Dakar Mobile', prix: 95000, note: 4.5, avis: 78, icone: 'ph-device-mobile', couleur: '#0F3D2E' },
  { nom: 'Sac en cuir tressé artisanal', vendeur: 'Atelier Kër Ndiaye', prix: 22000, note: 4.9, avis: 56, icone: 'ph-handbag', couleur: '#8A5A2B' },
  { nom: 'Bissap séché bio 500 g', vendeur: 'Saveurs de Casamance', prix: 2500, note: 4.7, avis: 210, icone: 'ph-orange-slice', couleur: '#9C2B3C' },
  { nom: 'Écouteurs sans fil', vendeur: 'Tech Plateau', prix: 12000, ancien: 18000, note: 4.3, avis: 342, icone: 'ph-headphones', couleur: '#2F4B7C' },
  { nom: 'Beurre de karité pur 250 ml', vendeur: 'Karité du Sahel', prix: 4500, note: 4.6, avis: 98, icone: 'ph-flower-lotus', couleur: '#B8892B' },
  { nom: 'Ensemble boubou brodé homme', vendeur: 'Couture Thiès', prix: 35000, note: 4.8, avis: 41, icone: 'ph-coat-hanger', couleur: '#3E6B5A' },
  { nom: 'Lampe décorative en calebasse', vendeur: 'Déco Saint-Louis', prix: 14500, note: 4.4, avis: 33, icone: 'ph-lamp', couleur: '#A8552B' }
];

const fcfa = n => n.toLocaleString('fr-FR').replace(/ | /g, ' ') + ' FCFA';
const echapper = s => s.replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

const grille = document.getElementById('produits-grille');
grille.innerHTML = produits.map(p => {
  const remise = p.ancien ? Math.round((1 - p.prix / p.ancien) * 100) : 0;
  return `
  <article class="carte">
    <div class="photo" style="background:${p.couleur}">
      <i class="ph-fill ${p.icone}" aria-hidden="true"></i>
      ${remise ? `<span class="promo">-${remise}%</span>` : ''}
      <button class="coeur" aria-label="Ajouter aux favoris"><i class="ph ph-heart"></i></button>
    </div>
    <div class="infos">
      <span class="vendeur"><i class="ph-fill ph-seal-check"></i> ${echapper(p.vendeur)}</span>
      <h3>${echapper(p.nom)}</h3>
      <span class="etoiles"><i class="ph-fill ph-star"></i> ${p.note}<small>(${p.avis})</small></span>
      <div class="prix-ligne">
        <span class="prix">${fcfa(p.prix)}${p.ancien ? `<s>${fcfa(p.ancien)}</s>` : ''}</span>
        <button class="ajout" aria-label="Ajouter au panier"><i class="ph ph-plus"></i></button>
      </div>
    </div>
  </article>`;
}).join('');

// Panier + favoris (démo)
const pastille = document.querySelector('.pastille');
let nb = 0;
grille.addEventListener('click', e => {
  const ajout = e.target.closest('.ajout');
  const coeur = e.target.closest('.coeur');
  if (ajout) { pastille.textContent = ++nb; gsap.fromTo(pastille, { scale: 1.8 }, { scale: 1, duration: .4, ease: 'back.out(3)' }); }
  if (coeur) coeur.classList.toggle('actif');
});

// Animations (désactivées si l'utilisateur préfère moins de mouvement)
const reduit = matchMedia('(prefers-reduced-motion: reduce)').matches;
document.documentElement.classList.remove('sans-js');
Splitting();

if (!reduit) {
  gsap.registerPlugin(ScrollTrigger);

  const lenis = new Lenis();
  lenis.on('scroll', ScrollTrigger.update);
  gsap.ticker.add(t => lenis.raf(t * 1000));
  gsap.ticker.lagSmoothing(0);

  // Signature : le titre se révèle lettre par lettre
  gsap.to('.hero h1 .char', { y: 0, duration: 1, ease: 'power4.out', stagger: .02, delay: .2 });
  gsap.from('.hero .etiquette, .hero .intro, .hero .cta', { y: 24, opacity: 0, duration: .8, stagger: .15, delay: .9 });
  gsap.from('.bloc', { scale: .8, opacity: 0, duration: 1, stagger: .15, ease: 'back.out(1.6)', delay: .3 });

  gsap.utils.toArray('.titre-section, .cat, .carte, .confiance > div').forEach(el => {
    gsap.from(el, { y: 40, opacity: 0, duration: .8, ease: 'power3.out', scrollTrigger: { trigger: el, start: 'top 90%' } });
  });
}

// Signature : curseur personnalisé
const curseur = document.querySelector('.curseur');
if (curseur && matchMedia('(hover: hover) and (pointer: fine)').matches) {
  addEventListener('mousemove', e => {
    curseur.style.left = e.clientX + 'px';
    curseur.style.top = e.clientY + 'px';
  });
  document.addEventListener('mouseover', e => {
    curseur.classList.toggle('grand', !!e.target.closest('a, button, .carte'));
  });
}
