# Guide de contenu : vendeurs, produits et textes légaux

## 1. Textes légaux (déjà dans le site)
Pages : `/cgu`, `/cgv`, `/conditions-vendeur`, `/livraison-retours`, `/confidentialite`, `/mentions-legales`, `/frais-commissions`, `/a-propos`, `/contact`.
Le texte est dans `includes/legal.php`. Les informations de l'exploitant viennent du `.env` (`SOCIETE_*`, `CONTACT_EMAIL`, `HEBERGEUR`).
Tant qu'elles sont vides, le site affiche « [À COMPLÉTER : …] » et `scripts/verifier-production.php` le signale.

À faire avant l'ouverture :
1. Renseigner les `SOCIETE_*` avec les vraies informations (NINEA, RCCM, adresse).
2. **Faire relire les textes par un juriste sénégalais.** Ce sont des modèles sérieux mais génériques.
3. Vérifier les choix commerciaux écrits dans les textes, et les modifier dans `legal.php` si besoin :
   - commission de 8 % (taux réel : colonne `commission_pct`, modifiable par boutique dans l'admin) ;
   - réclamation « dans les 7 jours suivant la livraison prévue » ;
   - retrait minimum 5 000 FCFA (constante `RETRAIT_MINIMUM`) ;
   - horaires de l'assistance (« lundi au samedi »).
4. Déclarer le traitement des données auprès de la CDP (Commission de Protection des Données Personnelles) si votre situation l'exige.

## 2. Recruter les premiers vendeurs
Visez 10 à 20 boutiques avant le lancement, 20 produits chacune, réparties sur plusieurs catégories.
- Où : commerçants des marchés (Sandaga, HLM), créatrices de wax, artisans, revendeurs d'électronique, producteurs de bissap, karité, etc.
- Argumentaire : boutique gratuite, commission seulement sur les ventes livrées, paiement garanti par le code de livraison, retrait sur Wave / Orange Money.
- À leur demander : pièce d'identité, numéro Wave ou Orange Money, NINEA / RCCM s'ils en ont, photos réelles de leurs produits.
- Validez chaque boutique dans `/admin/boutiques` après avoir vérifié l'identité.

## 3. Règles pour de bonnes fiches produits
- Titre précis : « Pagne wax premium 6 yards », pas « Super pagne ».
- 3 photos au minimum, fond clair, lumière naturelle, produit entier puis détails. Format JPG ou PNG, 10 Mo maximum.
- Description : matière, dimensions, couleurs, état (neuf / occasion), garantie, contenu du colis.
- Prix en FCFA, stock réel, délai de préparation honnête.
- Interdits : produits illicites, contrefaçons, médicaments non autorisés, etc. (liste complète dans `/conditions-vendeur`).

## 4. Données de démonstration
`php scripts/preparer-installation.php --admin-email=… --demo` ajoute une boutique « Marché Démo » et 8 produits **pour tester seulement**. Supprimez-les avant l'ouverture publique (`/admin/produits`, `/admin/boutiques`).
